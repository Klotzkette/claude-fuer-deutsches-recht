HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Wer schuldet den Lichtbogen?

In der Werkstatt der Lichtwerft fehlen 6.426 Euro für eine Leuchtschrift. Buchhaltung, Einkaufsbestellung und Zahlung nennen drei leicht verwechselbare Firmennamen. Die Geschäftsführerin möchte erst wissen, gegen wen und wegen welcher Summe die Kanzlei überhaupt vorgehen kann.

Legen Sie den anwaltlichen Eingang an. Schreiben Sie die Forderungen beider Projekte auseinander, bestimmen Sie den möglichen Auftraggeber der Kanzlei und setzen Sie eine Wiedervorlage für den offenen Buchungsbeleg. Die Geschäftsführerin hat zunächst nur eine Prüfung bestellt.

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
