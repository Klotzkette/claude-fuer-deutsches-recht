HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Die Urkunde von Frau Eller

Ein Sohn möchte für seine Mutter eine weitere Ausfertigung einer Vollmacht aus dem Jahr 2019. Die Post landet im Nurnotariat der heutigen Verwahrerin. Die Mutter wohnt seit einem Umzug unter neuer Anschrift. Der Sohn verwendet ihre alte Mailadresse.

Erfassen Sie den Eingang zur bestehenden Verwahrung. Bereiten Sie die persönliche Entscheidung über Antrag, Berechtigung, Form und Empfänger vor. Bearbeiten Sie später die Erklärung der Mutter im selben Vorgang.

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
