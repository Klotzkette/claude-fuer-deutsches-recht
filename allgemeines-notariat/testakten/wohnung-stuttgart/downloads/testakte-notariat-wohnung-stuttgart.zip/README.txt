HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Der zweite Schlüssel zur Wohnung am Hang

Eva Sailer verkauft ihre seit Jahren selbst genutzte Wohnung an Maya und Leander Ott. Der Möbelwagen ist gebucht. In der Objektmappe gibt es zwei Grundbuchblätter, zwei Banken und einen Schlüssel mit der Aufschrift „17“, während im Kaufpreisblatt ein Stellplatz „12“ steht.

Bereiten Sie für alle Parteien den Entwurf und den weiteren Ablauf vor. Klären Sie, was mitverkauft werden soll, welche Rechte gelöscht werden können und wer unter welchen Voraussetzungen Zahlungen und Schlüsselübergabe veranlassen darf.

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
