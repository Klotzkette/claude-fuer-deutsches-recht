HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Der blaue Ordner hinter der Seekarte

Die verwitwete Buchbinderin Almut Krogmann lebt mit ihrem Partner Ben Cordes in ihrer Wohnung in Lübeck. Sie möchte ihn dort absichern und auch seine Tochter berücksichtigen. Von einem gemeinschaftlichen Testament mit ihrem verstorbenen Mann ist zunächst nur ein alter Durchschlag greifbar.

Führen Sie ein persönliches erbrechtliches Beratungsgespräch mit Almut Krogmann und bereiten Sie einen öffentlichen Testamentsentwurf nur so weit vor, wie ihre frühere Verfügung, ihr eigener Wille und ihre Vermögensverhältnisse es tragen.

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
