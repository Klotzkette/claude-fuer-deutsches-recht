HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Zwei Fassungen, eine Wahl – wer vertritt das Lichtspielhaus?

Im Verein Lichtspiel an der Saale e. V. soll die Kinotechnikerin Yara Born den Vorsitz übernehmen. Der Förderverein braucht bald einen unterschriebenen Projektvertrag. Das Register sieht gemeinsame Vertretung vor. Auf der Webseite steht Einzelvertretung. Und schon bei den abgegebenen Stimmen passen Protokoll und Zählliste nicht zusammen.

Bereiten Sie die notarielle Besprechung und die gegebenenfalls mögliche Registeranmeldung vor. Ordnen Sie Satzungsstände, Wahl und Annahme jedem Amt zu. Formulieren Sie die Rückfrage an den Verein so, dass er die fehlenden Originale gezielt suchen und über das Förderprojekt rechtzeitig disponieren kann.

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
