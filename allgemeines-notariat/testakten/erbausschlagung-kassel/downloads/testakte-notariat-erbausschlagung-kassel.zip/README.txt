HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Zwei Briefe für Mara – wer erbt nach Ruth Hartmann?

Lina Mohr hat nach dem Tod ihrer Mutter für sich selbst ausgeschlagen. Für ihre elfjährige Tochter Mara bittet sie um einen Termin. Der Vater hat gemeinsames Sorgerecht und kennt bislang nur ein Handyfoto. Auf einer zweiten beschriebenen Seite steht Maras Name.

Bereiten Sie die Erstberatung beider Eltern vor. Legen Sie für jede Person fest, ab welchem belegten Ereignis eine Frist in Betracht kommt. Welche Unterlagen, Erklärungen und gegebenenfalls gerichtlichen Schritte braucht die Familie, und welche Handlung duldet keinen Aufschub?

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
