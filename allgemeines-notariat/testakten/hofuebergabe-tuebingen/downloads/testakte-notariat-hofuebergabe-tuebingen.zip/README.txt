HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Wer hat im Winter den Schlüssel zum Heizraum?

Am Schönbuchrand betreut Jette Reber die Obstwiesen ihres Vaters. Er will ihr Hofstelle und eigene Wiesen übergeben und mit seiner Frau im Erdgeschoss bleiben. Was auf dem Küchentisch als „unten alles für uns“ bezeichnet wurde, sieht auf dem alten Grundriss anders aus.

Bereiten Sie das Beratungsgespräch und einen belegten Überlassungsentwurf vor. Arbeiten Sie heraus, wem welche Flächen gehören, wer wo wohnen oder mitbenutzen möchte und wessen Zustimmung oder Mitwirkung noch einzuholen ist.

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
