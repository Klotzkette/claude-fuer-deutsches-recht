---
name: arbeitsprodukt-ausarbeiten-und-kontrollieren-bearbeiten
description: "Prüft den Behördenentwurf auf Zahlenfehler, fehlende Belege und angreifbare Wertungen. Bearbeitet Gegenargumente und dokumentiert offene Freigaben für ein entscheidungsreifes Vergabeprodukt."
---

# Arbeitsprodukt ausarbeiten und kontrollieren

## 1. Zweck und Anwendungsfall

Arbeitsprodukt ausarbeiten und kontrollieren: Den verlangten Text oder die Berechnung fertigstellen, Gegenposition, Quellenstatus und offene Punkte prüfen und die nächste Handlung erklären.

Bearbeite den konkreten Auftrag bis zum nutzbaren Arbeitsprodukt. Übernimm bereits vorliegende Angaben, benenne entscheidungserhebliche Lücken und arbeite an den davon unabhängigen Teilen weiter.

## 2. Eingaben

- Den konkreten Auftrag und das gewünschte Dokument aus dem Gespräch übernehmen.
- Bereits vorliegende Fachunterlagen, Fassungen, Belege und zeitliche Angaben zuerst lesen; nur entscheidende Lücken erfragen.

## 3. Ablauf

### 3.1. Arbeitsschritt

Arbeitsprodukt ausarbeiten und kontrollieren: Den verlangten Text oder die Berechnung fertigstellen, Gegenposition, Quellenstatus und offene Punkte prüfen und die nächste Handlung erklären.

### 3.2. Arbeitsschritt

Den passenden Fachinhalt unten anhand des konkreten Gegenstands auswählen und vollständig lesen. Mehrere betroffene Themen gemeinsam behandeln; nicht bei einer bloßen Menüauswahl stehen bleiben.

### 3.3. Arbeitsschritt

Welcher Antrag vor Vergabekammer verhindert oder korrigiert den Zuschlag.

### 3.4. Arbeitsschritt

Belegte Tatsachen, maßgebliche Quellen, Gegenposition und Unsicherheit am jeweiligen Ergebnis ausweisen. Änderungen in derselben Fassung fortführen und das bestellte Arbeitsprodukt ausarbeiten.

### 3.5. Fachvertiefungen gezielt laden

Wähle anhand des Auftrags nur die einschlägigen Vertiefungen. Lies deren vollständige Fachanweisungen vor der jeweiligen Teilprüfung; berücksichtige die dort verknüpften lokalen Werkzeuge, Vorlagen und Belege. Die folgenden Dateien sind Fachinhalte dieses Arbeitswegs, keine zusätzlichen auswählbaren Skills.

- [Konzvgv: Risikoampel, Gegenargumente und Verteidigungslinien](../konzvgv-risikoampel-und-gegenargumente/FACHINHALT.md)
- [Orientierung Fehlerkatalog](../orientierung-fehlerkatalog/FACHINHALT.md)
- [Vergabestelle: Rechtsregime und nächste Freigabe bestimmen](../orientierung-mandat-anwaltliche-vertiefung/FACHINHALT.md)
- [Output wählen](../output-waehlen/FACHINHALT.md)
- [Schnittstelle: Zahlen, Schwellenwerte und Berechnung](../schnittstelle-zahlen-schwellen-und-berechnung/FACHINHALT.md)
- [Orientierung: Red-Team und Qualitätskontrolle](../spezial-orientierung-red-team-und-qualitaetskontrolle/FACHINHALT.md)

## 4. Quellenpflicht

Trenne vorgelegte Tatsachen, eigene Berechnungen und rechtliche oder fachliche Wertungen. Prüfe entscheidungstragende Normen, Rechtsprechung und sonstige Quellen anhand zugänglicher Primärquellen auf Geltungszeitpunkt, Aussage und Übertragbarkeit. Historische Quellen sind in ihrem zeitlichen Zusammenhang auszuwerten. Eine Quellenangabe im Fachinhalt ersetzt keine aktuelle Einzelfallprüfung; behaupte keine nicht durchgeführte Verifikation.

## 5. Ausgabeformat

<!-- BEGIN output-format-block (autogen) -->

Schriftart Times New Roman, Schriftgrad 11 pt. Dezimalgliederung 1, 1.1, 1.1.1, 2, 2.1 fortlaufend ohne Lücken, maximal vier Ebenen. Aufzählungen mit Spiegelstrich oder Bullet. Hervorhebung nur durch Kursivsetzung bei Gesetzes- und Aktenzeichenfundstellen, kein Fettdruck, keine Unterstreichung. Vollständige Regeln in [`references/OUTPUT-FORMAT.md`](../../references/OUTPUT-FORMAT.md). Bei abweichenden Vorgaben der Stelle (Portal, Gericht, Kammer) gilt die Stelle.

<!-- END output-format-block (autogen) -->

- Das im Auftrag verlangte, ausgearbeitete Ergebnis zu „Arbeitsprodukt ausarbeiten und kontrollieren“, mit konkreten Belegstellen und erkennbaren offenen Punkten.
- Nur soweit hilfreich: eine Vergleichstabelle, Zeitleiste oder grafische Übersicht zusätzlich zum vollständigen Text.

Liefere das beauftragte Dokument vollständig in ausformuliertem Text mit Dezimalgliederung. Für juristische Schriftsätze und Gutachten ist die Zieltypografie Times New Roman 11 pt; Tabellen und Grafiken ergänzen die Begründung. Wähle zur Aufgabe passende Vergleiche, Zeitleisten oder andere Visualisierungen. Nutze eine interaktive Ansicht nur, wenn die Laufzeit sie tatsächlich bereitstellt; stelle sonst eine unmittelbar lesbare Tabelle oder Grafik bereit. Kennzeichne fehlende Daten und offene Prüfungen an der betroffenen Stelle und schließe mit dem konkreten nächsten Arbeitsschritt.

## 6. Beispiele

- Ein Auftrag zu „Konzvgv: Risikoampel, Gegenargumente und Verteidigungslinien“: die zugehörige Fachvertiefung lesen, vorhandene Belege auswerten und das verlangte Ergebnis ausarbeiten.
- Ein Auftrag zu „Orientierung Fehlerkatalog“: die zugehörige Fachvertiefung lesen, vorhandene Belege auswerten und das verlangte Ergebnis ausarbeiten.
