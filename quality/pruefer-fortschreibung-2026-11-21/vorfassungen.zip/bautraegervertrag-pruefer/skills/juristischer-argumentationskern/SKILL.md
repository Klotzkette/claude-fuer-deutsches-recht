---
name: juristischer-argumentationskern
description: "Schaltet sich ein, wenn in Bauträgervertrag Prüfer ein juristisches Arbeitsprodukt tragfähig begründet werden muss; verbindet konkrete Aktenfundstellen mit Tatbestandsmerkmal, Beweislast, stärkster Gegenposition und Rechtsfolge."
---

# Juristischer Argumentationskern - Bauträgervertrag Prüfer

## 1. Direktstart

Gleiche Vertragsentwurf, Baubeschreibung, Ratenplan und Sicherungsunterlagen aus Sicht der vertretenen Partei ab. Begründe das einzelne Risiko und formuliere die dafür benötigte Vertragsänderung.

Für die Gesamtbearbeitung den [Hauptarbeitsweg](../bautraegerpruefung-steuern/SKILL.md) und die [Rollen- und Quellenregeln](../../references/rechtsprechung-und-rollen.md) hinzunehmen. [Der frühere Argumentationskern des zweiten Prüfers](REFERENZ-bautraegervertragspruefer.md) bleibt als Detailreferenz erhalten.

1.1. Lies zuerst die auftragsrelevanten Unterlagen und halte erkennbare Fristen fest. Prüfe Namen, Fassungen und Anlagen, soweit sie für das Ergebnis eine Rolle spielen.
1.2. Beginne bei klarem Auftrag mit dem verlangten Arbeitsprodukt. Frage nur nach Tatsachen, die Anspruch, Einwendung, Antrag, Frist oder Beweisführung ändern. Arbeite an den übrigen Teilen weiter und übernimm die Antwort in denselben Entwurf.
1.3. Trenne Aktenfund, gesicherte Rechtsquelle, vertretbare Schlussfolgerung und offene Prüfung sichtbar. Erfinde weder Tatsache noch Fundstelle noch Aktenzeichen.

Übernimm eine bekannte Beauftragung als Erwerber, Bauträger, Gemeinschaft der Wohnungseigentümer oder Verwalter. Vertrete die beauftragte Seite und behandle die übrigen Perspektiven als Gegenpositionen. Liefere nur das bestellte Dokument. Ein Paket aus drei Dokumenten benötigt einen eigenen Auftrag.

## 2. Die tragende These

Formuliere das Ergebnis für Bauträgervertrag Prüfer in einem Satz und nenne darin Parteirolle, begehrte oder abzuwehrende Rechtsfolge und den entscheidenden Prüfpunkt. Typische Rechtsfolgen in diesem Arbeitsfeld sind: Nachtrag, Behinderungsanzeige, Abnahme, Mangelrüge, Vergütung, Gutachterfrage oder Sicherung.

Die These ist nur belastbar, wenn die folgende Kette ohne Sprung funktioniert:

2.1. Rechtsfolge: Was soll das fertige Arbeitsprodukt rechtlich oder praktisch bewirken?
2.2. Norm: Welche Vorschrift oder gesicherte Rechtsregel trägt genau diese Folge?
2.3. Tatbestandsmerkmal: Welches einzelne Merkmal ist dafür entscheidend?
2.4. Tatsache: Welche konkrete, zeitlich und personell bestimmte Aktenangabe erfüllt oder widerlegt das Merkmal?
2.5. Beleg: Welche Fundstelle, Urkunde, Aussage, Messung oder Berechnung trägt die Tatsache?
2.6. Beweislast und Beweismaß: Wer verliert den Punkt, wenn die Tatsache offenbleibt?
2.7. Gegenposition: Was ist der stärkste ernsthafte Angriff auf Norm, Tatsache, Beleg oder Rechtsfolge?
2.8. Antwort: Welcher Gegenbeleg, welche Auslegung oder welche Beweislastregel hält diesem Angriff stand?

## 3. Materienspezifische Tatbestandsarbeit

| Prüfpunkt | Konkrete Arbeitsfrage |
| --- | --- |
| Vertragssoll | Leistungsbeschreibung, Pläne, Nachträge, Termine, Vergütung und Sicherheiten erfassen |
| Bauablauf | Behinderung, Bedenkenhinweis, Koordination, Abnahme und Dokumentation ordnen |
| Mangel | Soll-Ist-Abweichung, Verantwortlichkeit, Fristsetzung, Selbstvornahme und Schaden prüfen |
| Architekt | Leistungsphase, Überwachungspflicht, Kostenkontrolle, Haftungsanteil und Gesamtschuld darstellen |
| Raten und Sicherheiten | Vereinbartes Zahlungsmodell, Bautenstand, richtige Bezugsgröße, Verbrauchersicherheit, Vormerkung und Lastenfreistellung getrennt prüfen |
| Gemeinschaft und Verwalter | Anspruchsinhaber, gemeinschaftliche Ausübung, Beschlussumfang, Vertretung und Fristwahrung getrennt belegen |
| Öffentlich-rechtliche Schnittstelle | Nur bei konkretem Bezug Folgekosten, Erschließung, Durchführungsvertrag und vertragliche Kostenweitergabe prüfen |

### 3.1. Verknüpfung mit den tragenden Fachskills

3.1.1. [Bauzeit, Verzug, Vertragsstrafe und höhere Gewalt](../bauzeit-verzug-vertragsstrafe-und-hoehere-gewalt/FACHINHALT.md): Lies die Fachvertiefung und führe Norm, Aktenfund, Beweislast, Gegenposition und Rechtsfolge in den Argumentationskern zurück.
3.1.2. [Beurkundung, Verbraucherfrist, Notar und Bezugsurkunden](../beurkundung-verbraucherfrist-notar-und-bezugsurkunden/FACHINHALT.md): Lies die Fachvertiefung und führe Norm, Aktenfund, Beweislast, Gegenposition und Rechtsfolge in den Argumentationskern zurück.
3.1.3. [Geschäftsführer-, Architekten- und Bautenstandshaftung](../geschaeftsfuehrer-architekt-und-bautenstandshaftung/FACHINHALT.md): Lies die Fachvertiefung und führe Norm, Aktenfund, Beweislast, Gegenposition und Rechtsfolge in den Argumentationskern zurück.
3.1.4. [Notarhaftung, Belehrung und Streitverkündung](../notarhaftung-belehrung-und-streitverkuendung/FACHINHALT.md): Lies die Fachvertiefung und führe Norm, Aktenfund, Beweislast, Gegenposition und Rechtsfolge in den Argumentationskern zurück.

Ordne für jeden Tabellenpunkt eine konkrete Tatsache, Fundstelle, Beweislast, Gegenposition und Rechtsfolge zu. Ein bloßes Ergebniswort oder die Wiedergabe einer Norm ist keine Subsumtion.

## 4. Normenanker

4.1. BGB Paragraf 631: Werkvertragliche Hauptpflichten.
4.2. BGB Paragraf 633: Sach- und Rechtsmängel des Werkes.
4.3. BGB Paragraf 634: Rechte des Bestellers bei Mängeln.
4.4. BGB Paragraf 640: Abnahme.
4.5. BGB Paragraf 650a: Bauvertrag.
4.6. BGB Paragraf 650q: Architekten- und Ingenieurvertrag.

4.7. BGB Paragrafen 650u und 650v, Paragraf 1 AbschlagsV sowie Paragrafen 3 und 7 MaBV: Bauträgervertrag, Abschlagsvereinbarung und die konkret einschlägigen Sicherungsmodelle.
4.8. WEG Paragrafen 9a, 18 und 19: Gemeinschaftsstellung und Verwaltung von der konkreten vertraglichen Erwerberposition unterscheiden.
4.9. BGB Paragrafen 203, 204 und 634a: tatsächlichen Hemmungstatbestand, Verjährungsdauer und Beginn belegen; Beschlussfassung ist für sich keine Hemmung.

Normen werden nicht als Dekoration gesammelt. Hinter jedem Anker steht das konkrete Merkmal, das er im Fall steuert, und die Rechtsfolge, die daraus folgen kann.

## 5. Rechtsprechung und Quellenstatus

5.1. BGH, Urteil vom 22.02.2018 - VII ZR 46/17: fiktive Mängelbeseitigungskosten sind im Werkvertragsrecht nicht mehr als Schaden abrechenbar.
5.2. BGH, Urteil vom 08.11.2007 - VII ZR 183/05: Architekt und Unternehmer können bei Baumangel und Überwachungsfehler gesamtschuldnerisch haften.
5.3. BGH, Urteil vom 24.01.2008 - VII ZR 280/05: Bedenkenhinweis muss rechtzeitig, inhaltlich klar und adressatengerecht erfolgen.
5.4. BGH, Urteil vom 10.10.2013 - VII ZR 19/12: Eine formularmäßige Verkürzung der Verjährung von Mängelansprüchen gegen Architekten auf zwei Jahre ab Abnahme ist unwirksam; eine Teilabnahme folgt nicht schon aus einer Vertragsklausel, nach der die Verjährung mit Abnahme der letzten Unternehmerleistung beginnt.

5.5. Ordne jede Entscheidung als tragenden Rechtssatz, Abgrenzungsfall, bloße Analogie oder nicht übertragbar ein. Eine Entscheidung aus anderem Verfahrens- oder Tatsachenkontext wird nicht nur wegen eines ähnlichen Stichworts zitiert.
5.6. Gib den Quellenstatus an: amtlicher Normtext, amtliche Entscheidung, frei zugängliche Gerichtsveröffentlichung, Aktenfund oder noch offene Recherche. Unsichere Aktenzeichen werden weggelassen.

## 6. Beweislast und Gegenangriff

Beweislast je Anspruch, konkreter streitiger Tatsache, Abnahmestand und prozessualer Lage bestimmen. Eine pauschale Verteilung „Auftragnehmer für Leistung, Auftraggeber für Mangel“ reicht nicht aus. Vertragliche Erwerberrechte, gemeinschaftliche Ausübung, Vertretung und tatsächlich eingetretene Fristwirkung gesondert belegen; insbesondere hemmt ein interner Gemeinschaftsbeschluss nicht für sich die Verjährung.

6.1. Baue zuerst die stärkste vertretbare Gegenposition auf, nicht eine leicht widerlegbare Ersatzposition.
6.2. Prüfe getrennt, ob der Angriff die Anspruchsgrundlage, ein einzelnes Merkmal, die Schlüssigkeit, die Erheblichkeit, den Beweiswert, die Beweislast, die Rechtsfolge oder nur die Höhe betrifft.
6.3. Bezeichne bei Urkunden Seite und Passage, bei Zeugen das konkrete Beweisthema, bei Berechnungen Eingabewert und Quelle, bei Gutachten Anknüpfungstatsache und offene Fachfrage.
6.4. Wenn der Kernbeleg fehlt, formuliere eine gezielte Nachforderung statt die Lücke mit einer Annahme zu schließen.

## 7. Prüffolge

7.1. Welches Vertragssoll ist beweisbar vereinbart.
7.2. Ist abgenommen oder abnahmereif.
7.3. Welche Mängelrechte sind nach Fristsetzung eröffnet.
7.4. Welche Bauzeit- oder Nachtragsfolge ist kausal belegt.
7.5. Welche technische Frage muss ein Sachverständiger klären.
7.6. Welche Festsetzung oder städtebauliche Vertragsbindung begrenzt Planung, Genehmigung oder Kostenweitergabe.

## 8. Juristisches Schreiben

8.1. Stelle das Ergebnis oder den Antrag an den Anfang. Der Leser muss nach dem ersten Absatz wissen, welche Position vertreten wird und warum.
8.2. Verwende pro tragendem Punkt die Reihenfolge Kernsatz, Rechtsregel, konkrete Tatsache mit Fundstelle, Subsumtion, Gegenargument, Antwort und Rechtsfolge.
8.3. Schreibe Tatsachen konkret mit Datum, Person, Handlung, Betrag und Dokument. Vermeide Leerformeln wie offensichtlich, zweifellos oder nach ständiger Rechtsprechung ohne Beleg.
8.4. Trenne Hauptargument, Hilfsargument und bloßen Recherchepunkt. Die stärkste Linie steht zuerst; Varianten werden nach Erfolgsaussicht, Beweisrisiko und praktischem Aufwand geordnet.
8.5. Typische fertige Ausgabe für dieses Plugin: Ausgabe entlang der Kernfelder Vertragssoll, Bauablauf, Mangel, Architekt: Kurzvermerk, Prüfmatrix, Entwurf, Fristenblatt oder Fragenliste mit nächstem Schritt.

## 9. Ausgabemodi

| Bedarf | Sofortausgabe |
| --- | --- |
| Schnell entscheiden | Kernsatz, stärkster Anker, schwächster Punkt, Gegenposition, Empfehlung und nächster Schritt |
| Vertieft prüfen | Tatbestandsmatrix mit Norm, Tatsache, Fundstelle, Beweislast, Gegenargument, Antwort und Rechtsfolge |
| Versenden | Empfängergerechter Entwurf mit Antrag oder Ziel, Tatsachenvortrag, Rechtsausführung, Beweisangeboten und Anlagenbezug |
| Verhandeln | Hauptposition, belastbare Untergrenze, gegnerischer Hebel, Zugeständnisfolge und formulierter Vorschlag |
| Entscheiden | Optionen mit Rechtsgrundlage, Tatsachenbasis, Risiko, Aufwand, Termin und dokumentierter Empfehlung |

## 10. Qualitätskontrolle

10.1. Deckt jeder Antrag oder Ergebnissatz eine benannte Rechtsfolge ab?
10.2. Ist jedes tragende Tatbestandsmerkmal mit konkreter Tatsache und Fundstelle verknüpft?
10.3. Ist die Beweislast dort benannt, wo eine Tatsache streitig oder offen ist?
10.4. Wurde die stärkste Gegenposition fair aufgebaut und beantwortet?
10.5. Passt jede Entscheidung in Tatsachen- und Verfahrenskontext und ist ihr Quellenstatus sichtbar?
10.6. Sind Frist, Form, Zuständigkeit, Betrag, Anlagen und nächster Arbeitsschritt widerspruchsfrei?
10.7. Ist das Ergebnis unmittelbar als Nachtrag, Behinderungsanzeige, Abnahme, Mangelrüge, Vergütung, Gutachterfrage oder Sicherung verwendbar?

<!-- BEGIN werkstatt-visualisierung -->
## 11. Verständlich arbeiten und sichtbar prüfen

Bei komplexem Material zuerst verständlich machen, wer beteiligt ist, was geschehen ist und welche Entscheidung ansteht. Vorhandene Unterlagen auswerten und Fachbegriffe beim ersten Gebrauch kurz erklären. Danach das erste nutzbare Arbeitsergebnis liefern. Die Fachansicht und ihre Beispiele an den konkreten Auftrag, Empfänger und Bearbeitungsstand anpassen; daraus entsteht kein Auftrag für ein zusätzliches Verfahren oder andere Unterlagen. Eine passende Visualisierung direkt erstellen, wenn sie Vergleich, Ablauf, Mengen oder Zusammenhänge verständlicher macht; nicht erst allgemein anbieten oder eine Auswahl aus Werkzeugnamen verlangen. Einfache Einzelfragen knapp beantworten. Anfangs eine zentrale Ansicht mit verständlichen Beschriftungen und kurzem Befund zeigen; weitere Details nach Bedarf öffnen.

**Leitfrage für Bau- und Architektenrecht:** Welche Abhängigkeit zwischen Bedarf, Planung, Ausführung und Nachweis verursacht das Problem?

**Erste Ansicht:** Zeige Projektabschnitte oder Bauteile mit Bedarf, Planstand, Abhängigkeit, Termin, Kostenbezug und Beleg. Eine kleine Ablauf- oder Planänderungsansicht soll den konkreten Engpass sichtbar machen.

**Sinnvolle Interaktion:** Wähle Bauteil, Planstand oder belegte Terminvariante und aktualisiere die betroffenen Positionen, Folgearbeiten und Schreiben. Eine schematische Skizze darf keine vermessene oder freigegebene Planung vortäuschen.

**Datengrundlage:** Bauteil oder Leistung, Menge und Einheit, Planversion, Verantwortlicher, Terminbasis und Originalunterlage. Je tragendem Wert die Datei und Seite, Tabellenblatt/Zelle, Zeile oder Belegkennung mitführen.

**Weiter zum Ergebnis:** nachvollziehbarer Projektvermerk mit dem bestellten Leistungs-, Nachtrags-, Anzeige- oder Abstimmungstext. Die Ansicht ist ein Arbeitsmittel auf diesem Weg.

Nutze eine tatsächlich verfügbare Visualisierung oder Fachanwendung; bei geeigneter interaktiver Oberfläche direkt ein Applet erstellen oder die vorhandene Anwendung verwenden. Ohne diese Fähigkeit eine verständliche Tabelle oder Skizze liefern. Belege und Annahmen trennen, fehlende Werte nicht als null behandeln. Auswahl und neue Angaben im selben Arbeitsprodukt fortschreiben und dieses ausformulieren. Keine Datenübermittlung, Speicherung oder erfolgreiche Funktion behaupten, die nicht stattfand.

Bei interaktiver Arbeit die [lokalen Regeln für Oberfläche, Belege und Fortsetzung](../../references/arbeitsoberflaeche-und-visualisierung.md) lesen.
<!-- END werkstatt-visualisierung -->
