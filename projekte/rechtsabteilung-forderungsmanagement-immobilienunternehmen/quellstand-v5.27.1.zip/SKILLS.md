# Skill-Gesamtübersicht

Automatisch erzeugte Gesamtübersicht aller **59 Skills** in **2 Plugins**.

Stand: `v5.27.1`.

## Alle Skills auf einmal herunterladen

| Paket | Inhalt | Download |
| --- | --- | --- |
| Alle Skills als Markdown | Direkt entpackbare `SKILL.md`-Dateien beider Plugins mit je einem README-Index | [`alle-skills-markdown.zip`](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-skills-markdown.zip) |
| Vollständige Offline-Dokumentation | Getrackter Repo-Inhalt mit READMEs, Skills, Referenzen, Vorlagen und Testaktenquellen | [`immobilien-forderungsmanagement-dokumentation.zip`](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/immobilien-forderungsmanagement-dokumentation.zip) |

Für Cowork oder Claude Code ist das jeweilige **Plugin-ZIP** die verlässlichste Wahl, weil es neben den Skills auch die benötigten Referenzen, Prüfraster und Vorlagen enthält. Das reine Markdown-Paket eignet sich zum Lesen, Vergleichen und für Umgebungen, in denen der Skilltext zusammen mit den darin genannten Hilfsdateien bereitgestellt wird.

Wer nur ein bestimmtes Plugin benötigt, findet in der Tabelle unten dessen Plugin-ZIP, Markdown-ZIP und Detailseite. Werkstatt- und Schnellstartprompt existieren bewusst nur für das Fachplugin; die fachlich neutrale beA-Werkstatt wird ausschließlich als Plugin und Skill-Sammlung ausgeliefert.

## Skill einzeln öffnen

1. In der Plugin-Tabelle die Detailseite öffnen.
2. Beim gewünschten Skill auf **Ansehen** klicken.
3. Für einen echten Datei-Download **Herunterladen** wählen oder das Markdown-ZIP des Plugins verwenden.
4. In einer anderen KI-Umgebung zusätzlich alle im Skill genannten Referenzen und Eingabedateien bereitstellen. Ohne diese Paketdateien kann ein einzelner Skill weniger leisten als das installierte Plugin.

Die Detailseiten liegen unter [`skills-index/`](skills-index/). Der Katalog wird aus dem Marketplace und den gültigen `SKILL.md`-Frontmattern erzeugt und vor jedem Release auf Drift geprüft.

## Alle Plugins

Das Plugin-ZIP enthält den vollständigen Cowork-/Claude-Code-Lieferumfang. Das Markdown-ZIP enthält direkt entpackbare Skilltexte. Prompt-Downloads sind nur dort aufgeführt, wo die Assets tatsächlich veröffentlicht werden.

| Plugin | Skills | Detailseite | Plugin-ZIP | Markdown-ZIP | Schnellstartprompt | Werkstattprompt |
| --- | ---: | --- | --- | --- | --- | --- |
| `forderungsmanagement-immobilien` | 50 | [Skills ansehen](skills-index/forderungsmanagement-immobilien.md) | [Plugin](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien.zip) | [Markdown](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-skills-markdown.zip) | [MD](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.md) / [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.zip) | [MD](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-grosser-prompt-skill.md) / [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-grosser-prompt-skill.zip) |
| `schriftsatzwerkstatt-bea` | 9 | [Skills ansehen](skills-index/schriftsatzwerkstatt-bea.md) | [Plugin](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/schriftsatzwerkstatt-bea.zip) | [Markdown](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/schriftsatzwerkstatt-bea-skills-markdown.zip) | nicht vorgesehen | nicht vorgesehen |
