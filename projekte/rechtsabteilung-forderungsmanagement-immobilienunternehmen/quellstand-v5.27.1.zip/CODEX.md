# Hinweise für automatisierte Aufräum- und Codex-Läufe

Diese Datei richtet sich an Codex, Claude Code und vergleichbare
automatisierte Agenten, die im Repo aufräumen, refaktorieren oder
Wartungs-Sweeps durchführen. Sie ist verbindlich.

## Repo-Identität

Dieses Repo ist `immobilien-forderungsmanagement` mit genau zwei Plugins:
`forderungsmanagement-immobilien` mit 50 Skills für den Fachprozess und
`schriftsatzwerkstatt-bea` mit neun Skills für die fachlich neutrale
technische Endfertigung. Hinzu kommen neun Berliner Fachfallakten plus
Mietspiegel-Akte. Es ist kein Sammelmarktplatz wie das Mutter-Repo
`claude-fuer-deutsches-recht`.
Alte Strukturhinweise (213 Werkstattprompt-Vorlagen, viele Plugins, viele
Formatvorlagen-Plugins) gelten hier nicht; lösche aber dennoch keine
fremden Hilfsverzeichnisse ohne Rücksprache.

Zielgruppe des Plugins sind hochtrainierte Rechtsanwalts- und
Notarfachangestellte, Renofas, Rechtsfachwirt:innen und
Forderungsmanagement-Spezialist:innen eines Immobilienkonzerns. Sie sind
keine Anwälte und müssen es für den vorgesehenen Amtsgerichts- und
10.000-EUR-Bearbeitungsbereich auch nicht sein. Jede Änderung soll
deshalb juristisch korrekt, aber menügeführt, tabellarisch und in klarer
Arbeitssprache bleiben.

## Bitte NICHT löschen oder leeren

Die folgenden Bestandteile sind absichtlich da, auch wenn sie auf den
ersten Blick wie Hilfsdateien oder Duplikate aussehen können. Sie
dürfen nicht entfernt, verschoben oder geleert werden, ohne dass
Klotzkette das ausdrücklich anweist.

### Testakten und Schulungsmaterial

- `testakten/mietrueckstand-meier-wilhelmstrasse/`
- `testakten/raeumungsklage-kowalski-friedrichshain/`
- `testakten/mieterhoehung-becker-tempelhof/`
- `testakten/mietrueckstand-lange-zwei-raten-versehen/`
- `testakten/mietrueckstand-demir-fuenf-raten-absichtlich/`
- `testakten/nebenkosten-braun-nachzahlung-unbezahlt/`
- `testakten/ratenplan-riedel-gebrochen/`
- `testakten/vollstreckung-krueger-titel-teilzahlung/`
- `testakten/mieterklage-schimmel-schulz-verteidigung/`
- `testakten/mietspiegel-berlin/`

Jede fachliche Testakte braucht dauerhaft drei direkte Nutzungsformen im
Release: Gesamt-PDF als eigenes Asset, Arbeits-ZIP und Einzel-PDF-ZIP mit
benannten Einzel-PDFs.
Die Release-Validatoren müssen diese Dreiteilung prüfen.

Alle Testakten-ZIPs bleiben flach und enthalten keine Unterordner. Das
Arbeits-ZIP enthält ausschließlich DOCX, XLSX und PDF, kein Markdown und keine
Dublette des separat angebotenen Gesamt-PDFs.

### Zentrale Dokumente

- `README.md` für Rollout, Schulung und Release-Downloads.
- `forderungsmanagement-immobilien/README.md` für Plugin-Nutzung und
  Skill-Pfade.
- `schriftsatzwerkstatt-bea/README.md` für die technische PDF-, Anlagen-,
  Signatur- und beA-Versandwerkstatt. Dieses Plugin bleibt bei höchstens
  zehn Skills und enthält keine Rechtsprechungsanker.
- `forderungsmanagement-grosser-prompt.md` und `forderungsmanagement-kleiner-prompt.md` für den Gesamtworkflow und den
  knappen Einzelprompt.
- `CLAUDE.md`, `AGENTS.md` und `CODEX.md` als Agenten-Anweisungen.
- `references/` und `forderungsmanagement-immobilien/references/` für
  Zitierweise, Quellenhygiene und geprüfte BGH-Anker.
- `tests/smoke-tests.md` als manuelle Abnahmeliste.

### Hilfsscripts unter `scripts/`

Folgende Skripte sind idempotente Wartungs-Werkzeuge und sollen erhalten
bleiben — auch wenn sie nur einmal oder unregelmäßig laufen:

- `cleanup-grosser-prompt-disclaimers.py`
- `move-grosser-prompt-block-to-end.py`
- `fill-missing-plugin-keywords.py`
- `inject-grosser-prompt-section.py`
- `generate-grosser-prompt.py`
- `generate-formatvorlagen.py`
- `sweep-umlaut-welle-2.py`, `sweep-umlaut-welle-3.py`
- alle `validate-*` Scripts und `generate-skills-*` Scripts

### Plugin-Hilfsdateien

- `forderungsmanagement-immobilien/.claude-plugin/plugin.json` ist das
  installierbare Plugin-Manifest.
- `schriftsatzwerkstatt-bea/.claude-plugin/plugin.json` ist das
  Manifest der eigenständigen beA-Schriftsatzwerkstatt.
- `.claude-plugin/marketplace.json` ist die Marketplace-Definition.
- `scripts/build-cloud-cowork-prompt-skills.py` erzeugt Werkstattprompt und
  Schnellstartprompt als Standalone-Skill-Assets für Cloud-Co-Work. Der
  Schnellstartprompt muss unter 7.500 Zeichen bleiben.

## Verbindliche Regeln

1. Vor jeder Löschung mehr als einer Datei: `git fetch origin` und auf
   den letzten `main`-Stand prüfen.
2. Keine Skill-Frontmatter-Felder einfügen außer `name` und
   `description`.
3. Skill-`description` maximal 1024 Zeichen; `plugin.json`- und
   Marketplace-Plugin-`description` maximal 300 Zeichen. In allen
   Description-Feldern: keine `\d,\d`-Komma-Zahlen, keine spitzen
   Klammern, keine eingebetteten doppelten Anführungszeichen, keine
   Emojis oder Symbolzeichen und keine verbotenen Web-Auslese-Anglizismen.
4. `name`-Felder in YAML-Frontmatter und Plugin-Manifest: ausschließlich
   `[a-z0-9-]`, maximal 64 Zeichen. Slug == Ordnername.
5. Commits niemals mit Author `Claude`, `Codex`, `AI` oder
   vergleichbaren Maschinen-Identitäten taggen. Verwende
   `Klotzkette / 39582916+Klotzkette@users.noreply.github.com`.
6. Vor jedem Push: Pflichtvalidatoren laufen lassen:
   - Für Release-Builds und -Prüfungen die festgeschriebene Umgebung mit
     `uv run --with-requirements requirements-release.txt` verwenden.
   - `python3 scripts/validate-yaml-frontmatter.py`
   - `python3 scripts/validate-legal-anchors.py`
   - `python3 scripts/validate-umlaut-prose.py`
   - `python3 scripts/validate-markdown-links.py --selftest`
   - `python3 scripts/validate-markdown-links.py`
   - `python3 scripts/validate-readme-navigation.py`
   - `python3 scripts/validate-skill-frontmatter-parsers.py`
   - `uv run --with pypdf python3 schriftsatzwerkstatt-bea/scripts/validate_bea_package.py --selftest`
   - `node scripts/validate-plugin-structure.mjs`
   - `python3 scripts/validate-testakten-gesamt-pdf.py`
   - `python3 scripts/validate-testakten-financial-consistency.py`
   - `python3 scripts/validate-testakten-stammdaten.py`
   - `python3 scripts/validate-testakten-document-quality.py`
   - `python3 -m unittest discover -s tests -p 'test_*.py'`
7. Versions-Bumps konsistent durchziehen:
   beide Plugin-Manifeste und `.claude-plugin/marketplace.json` müssen
   dieselbe Version tragen.
8. Tags `vX.Y.Z` triggern `.github/workflows/release-plugin-zips.yml`.
   Ein zweites Tag mit gleicher Versionsnummer muss vorher gelöscht
   werden (`git push origin :refs/tags/vX.Y.Z`).
9. Nach einem Tag-Release den GitHub-Workflow abwarten. Der Workflow
   prüft die hochgeladenen Release-Assets remote mit
   `scripts/validate-release-assets.py`. Für manuelle Nachprüfung nach
   Workflow-Ende die veröffentlichten Assets herunterladen und
   `validate-testakten-release-zips.py` sowie `validate-release-zips.py`
   gegen dieses Download-Verzeichnis ausführen.
10. Außenwirksame Dokumente nur mit getrennter Freigabekarte ausgeben.
    Standardstatus ist `ENTWURF - NICHT VERSENDEN/EINREICHEN`; nur eine
    reale benannte Freigabeperson setzt `FREIGEGEBEN`. Relevante
    Änderungen an Dokument oder Aktenstand heben die Freigabe auf.
11. README-Menüs und Release-Downloads zusammen pflegen. Root-README,
    Plugin-README, Skill-Index und Testakten-READMEs müssen durchgängig
    klickbar bleiben; `validate-readme-navigation.py` ist Pflicht. Jeder
    Release enthält Offline-Dokumentation, Asset-Katalog und Prüfsummen.
12. Gerichtsfertige Schriftsatzpakete laufen über Skill `39` und danach
    Skill `23`: Originale unverändert, fortlaufende K-/B-Nummern,
    Hauptschriftsatz und jede Anlage als eigene PDF-Arbeitskopie,
    ASCII-Dateinamen, ERV-/Signaturgate und Eingangsnachweis. Ein Modell
    versendet nicht selbst aus beA.
13. Ist der juristische Inhalt bereits fertig und nur die technische
    Versandfertigung beauftragt, startet `schriftsatzwerkstatt-bea` mit
    Skill `01-bea-ordner-annahme`. Keine Fachprüfung hineinziehen;
    inhaltlichen Änderungsbedarf als Stopp an die verantwortliche Person
    zurückgeben.

## Was Codex bei einem Veredelungs-Lauf gefahrlos darf

- Tippfehler in Markdown-Fließtext korrigieren.
- Trailing whitespace und leere Zeilen-Sequenzen normalisieren.
- README-Block-Reihenfolge angleichen (z. B. `<!-- BEGIN
  grosser-prompt-und-vorlagen -->`-Block am Datei-Ende lassen, nicht
  oben).
- Navigationslinks, Breadcrumbs, Skill-Dateilinks und Downloadtabellen
  konkret verbessern und danach beide README-Validatoren ausführen.
- Plugin-`keywords`-Listen erweitern, sofern sie ein bestehendes
  Keyword nicht entfernen.
- Skill-`description`-Felder umformulieren, solange Pflichtregeln
  eingehalten sind.

Sollten Zweifel bestehen, lieber einen separaten Branch mit
`chore/codex-cleanup-YYYY-MM-DD` anlegen und einen PR für Klotzkette
öffnen, statt direkt auf main zu pushen.

## Aktueller Wartungsfokus

- Plugin-ZIP, Marketplace-Datei und Standalone-Prompt-Skills müssen ohne
  Repo-Klon nutzbar sein.
- README und Plugin-README müssen einer Pilotgruppe erklären, welches
  Asset wofür gedacht ist.
- Release-Katalog, Offline-Dokumentation und Prüfsummen müssen jeden
  veröffentlichten Download auffindbar und überprüfbar machen.
- Testakten müssen als direktes Gesamt-PDF, Arbeits-ZIP und Einzel-PDF-ZIP
  verfügbar bleiben.
- Skills und Prompts müssen denselben Bedienmodus sprechen:
  menügeführt, tabellarisch, juristisch korrekt und für starke
  Fachangestellte verständlich.
- Mahnung, Kündigung, Klage, Replik, Vergleich, KFA und Vollstreckung
  müssen das konkrete Freigabegate aus
  `references/bedienfuehrung-workflows.md` einhalten.
- `references/gepruefte-bgh-anker-mietrecht.md` ist die aktuelle
  Kontrollspur für BGH-Anker; die Kopie unter
  `forderungsmanagement-immobilien/references/` muss identisch bleiben,
  damit das Plugin-ZIP ohne Repo-Klon nutzbar ist.
- `references/erv-dokumentenproduktion.md`,
  `references/rechtsprechungsradar-mietrecht-2021-2026.md` und
  `references/schriftsatz-und-argumentationsstandard.md` müssen ebenfalls
  mit ihren Plugin-Kopien identisch und im Release-ZIP enthalten bleiben.
