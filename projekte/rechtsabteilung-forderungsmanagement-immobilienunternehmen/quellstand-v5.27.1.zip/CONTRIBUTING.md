# Mitwirken

Beiträge sind willkommen, wenn sie den Immobilien-Forderungsmanagement-Workflow konkreter, prüfbarer und leichter bedienbar machen. Besonders hilfreich sind aktualisierte BGH-Anker, bessere Testakten, klare Fristenlogik und präzisere Arbeitshilfen für Rechtsanwalts- und Notarfachangestellte im Konzern-Inhouse-Modell.

## Pull-Request-Checkliste

- [ ] Sprache deutsch.
- [ ] Zitierweise nach [`references/zitierweise.md`](./references/zitierweise.md).
- [ ] Mietrechtliche Anker nach [`references/gepruefte-bgh-anker-mietrecht.md`](./references/gepruefte-bgh-anker-mietrecht.md) und [`references/leitentscheidungen-anker.md`](./references/leitentscheidungen-anker.md).
- [ ] Skill-Frontmatter enthält nur `name` und `description`.
- [ ] `description` ist kurz, konkret und validatorfest.
- [ ] Skills sind abteilungstauglich: reproduzierbar, mit Quellenpflicht, Fristlogik, Ampel und nächstem Arbeitsschritt.
- [ ] Keine echten Mieter-, Konzernvertrags- oder personenbezogenen Daten im Beispiel.
- [ ] Alle Validatoren aus dem Repo-Root laufen fehlerfrei.

## Skill-Struktur

```
<plugin>/skills/<skill-name>/SKILL.md
<plugin>/skills/<skill-name>/references/  (optional)
```

`SKILL.md`-Frontmatter:

```yaml
---
name: kuerzer-skill-name
description: Konkreter Ausloeser und Ergebnis dieses Skills in einem Satz.
---
```

## Wie ergänze ich einen Workflow-Schritt?

1. Skill-Verzeichnis anlegen.
2. `SKILL.md` mit Frontmatter, Ablauf, Tabellen, Ampel, Fristen und Quellenpflicht schreiben.
3. Auf `references/zitierweise.md`, `references/gepruefte-bgh-anker-mietrecht.md` und passende Testakten verweisen.
4. Bei neuen Release-Assets die README nur an einer zentralen Downloadstelle ergänzen.
5. PR mit kurzer Begründung und Validator-Ausgabe.

## Pflichtprüfungen

```bash
python3 scripts/validate-yaml-frontmatter.py
python3 scripts/validate-umlaut-prose.py
python3 scripts/validate-skill-frontmatter-parsers.py
node scripts/validate-plugin-structure.mjs
python3 scripts/validate-testakten-gesamt-pdf.py
python3 scripts/validate-testakten-financial-consistency.py
```

## Code of Conduct

Siehe [`CODE_OF_CONDUCT.md`](./CODE_OF_CONDUCT.md).

## Lizenz

Doppellizenziert unter **Apache License, Version 2.0** ODER **MIT License**, nach Wahl der Nutzerin / des Nutzers (`SPDX-License-Identifier: Apache-2.0 OR MIT`) – siehe [`LICENSE`](./LICENSE), [`LICENSE-APACHE`](./LICENSE-APACHE), [`LICENSE-MIT`](./LICENSE-MIT) und [`NOTICE`](./NOTICE). Mit deinem Beitrag stimmst du der Veröffentlichung unter diesen Bedingungen zu.
