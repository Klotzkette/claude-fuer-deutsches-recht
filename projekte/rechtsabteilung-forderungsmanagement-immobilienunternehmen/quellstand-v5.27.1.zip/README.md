# immobilien-forderungsmanagement

Privates Plugin-System für das Forderungsmanagement und die technische Schriftsatzproduktion in der Rechtsabteilung eines deutschen Immobiliengroßkonzerns. Das Fachplugin führt Mietforderungen, Mieterhöhungen, Räumung, Prozessreaktion, Kostenfestsetzung und Vollstreckung; die getrennte beA-Schriftsatzwerkstatt macht bereits inhaltlich fertige Schriftsätze und Anlagen technisch versandbereit.

## Direktstart: zwei klare Wege

Du musst weder die 59 Skills kennen noch vorab einen Workflow auswählen. Entscheide nur, ob der juristische Fall noch bearbeitet werden soll oder ob ein bereits fertiger Schriftsatz technisch versandbereit gemacht werden soll.

| Dein Ausgangspunkt | Einmal herunterladen | Danach genau dieser Auftrag |
|---|---|---|
| Neuer oder laufender Immobilienfall mit SAP-, DMS-, Konto-, Vertrags-, Mieter- oder Gerichtsunterlagen | [Forderungsmanagement-Plugin](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien.zip) | `Neuer Fall. Prüfe den gesamten Ordner, sichere zuerst alle Fristen und arbeite ohne Skillauswahl bis zur nächsten freigabefähigen Entscheidung weiter.` |
| Juristischer Inhalt ist fertig; Schriftsatz und Anlagen müssen nur noch technisch versandbereit werden | [beA-Schriftsatzwerkstatt](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/schriftsatzwerkstatt-bea.zip) | `Mache diesen Ordner beA-fertig. Verändere den juristischen Inhalt nicht und frage nur nach Angaben, die du nicht sicher aus den Dateien entnehmen kannst.` |
| Zielumgebung akzeptiert nur einen einzelnen Skill | [Schnellstartprompt](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.zip) | denselben Auftrag wie beim Forderungsmanagement-Plugin verwenden |

Beim Fachplugin erscheinen zuerst Frist, Aktenstand und nächste Aktion. Danach folgt das konkrete Arbeitsergebnis: Restforderung, Mieterantwort, Klageentwurf oder Beleganforderung. Register und Rechenwege bleiben nachvollziehbar, werden im Chat aber nicht ständig wiederholt. [Weitere fertige Arbeitsaufträge](#start-in-30-sekunden)

**Zum Ausprobieren:** Öffne [Lange: Bankwechsel und Kulanz](./testakten/mietrueckstand-lange-zwei-raten-versehen/README.md), lade dort genau eines der drei Aktenformate und verwende den Startauftrag oben. Das Ergebnis muss die erste Rate einmal anrechnen, die erneut übersandte Bankanzeige als Belegdublette erkennen und die noch offene Juni-Miete gesondert ausweisen. Für eine anspruchsvollere zweite Runde folgt [Braun: Betriebskosten und fehlende Leistungsnachweise](./testakten/nebenkosten-braun-nachzahlung-unbezahlt/README.md).

<!-- BEGIN top-sofort-downloads (autogen) -->
## Sofort-Downloads (latest Release)

Dieses Repo ist privat. Alle Download-Links unten funktionieren nur, wenn du im Browser bei GitHub eingeloggt bist und Lesezugriff auf das Repo hast. Ohne Login antwortet GitHub mit `404` — das ist erwartetes Verhalten, nicht ein kaputter Link.

Die URLs zeigen auf die Dateien des aktuellen Releases. Werkstatt- und Schnellstartprompt sind Alternativen zum Fachplugin; für denselben Fall genügt eine Variante. Die beiden Prompt-Skills werden separat angeboten und nicht zusätzlich durch das Plugin geladen. Bei einem fehlenden Direktdownload zuerst Anmeldung und Repository-Zugriff prüfen, dann die [Release-Übersicht](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest) öffnen.

### Plugin und Skills

| Was | Format | Direkt-Download |
| --- | --- | --- |
| Forderungsmanagement-Plugin (50 Skills, Manifest, Quellenleitplanken) | ZIP | [forderungsmanagement-immobilien.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien.zip) |
| Forderungsmanagement-Skills als Markdown (50 `SKILL.md` plus README-Index) | ZIP | [forderungsmanagement-immobilien-skills-markdown.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-skills-markdown.zip) |
| Fachlich neutrale beA-Schriftsatzwerkstatt (9 Skills) | ZIP | [schriftsatzwerkstatt-bea.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/schriftsatzwerkstatt-bea.zip) |
| beA-Werkstatt-Skills als Markdown (9 `SKILL.md` plus README-Index) | ZIP | [schriftsatzwerkstatt-bea-skills-markdown.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/schriftsatzwerkstatt-bea-skills-markdown.zip) |
| Alle 59 Skills direkt entpackbar | ZIP | [alle-skills-markdown.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-skills-markdown.zip) |
| Komplettes Offline-Paket (alle getrackten Repo-Dateien ohne Git-Metadaten und Build-Abfall) | ZIP | [immobilien-forderungsmanagement-dokumentation.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/immobilien-forderungsmanagement-dokumentation.zip) |
| Marketplace-Eintrag | JSON | [marketplace.json](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/marketplace.json) |

### Werkstattprompt (vollständiger Workflow, eine Markdown-Datei)

| Was | Format | Direkt-Download |
| --- | --- | --- |
| Werkstattprompt als Standalone-Skill (Frontmatter plus Body) | `.md` | [forderungsmanagement-immobilien-grosser-prompt-skill.md](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-grosser-prompt-skill.md) |
| Werkstattprompt als Cloud-Co-Work-ZIP (`SKILL.md` an ZIP-Wurzel) | ZIP | [forderungsmanagement-immobilien-grosser-prompt-skill.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-grosser-prompt-skill.zip) |

### Schnellstartprompt (unter 7.500 Zeichen, eine Markdown-Datei)

| Was | Format | Direkt-Download |
| --- | --- | --- |
| Schnellstartprompt als Standalone-Skill (Frontmatter plus Body) | `.md` | [forderungsmanagement-immobilien-kleiner-prompt-skill.md](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.md) |
| Schnellstartprompt als Cloud-Co-Work-ZIP (`SKILL.md` an ZIP-Wurzel) | ZIP | [forderungsmanagement-immobilien-kleiner-prompt-skill.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.zip) |

### Testakten (neun Berliner Fachfälle plus Mietspiegel-Referenz)

| Was | Format | Direkt-Download |
| --- | --- | --- |
| Alle Testakten als flaches Arbeitsdatei-Sammelpaket | ZIP | [alle-testakten.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-testakten.zip) |
| Alle Testakten als Einzel-PDFs (sauber benannte PDFs je Unterlage) | ZIP | [alle-testakten-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-testakten-einzel-pdfs.zip) |
| Jede Akte in allen drei Downloadformen | PDF/ZIP | [Direktdownload-Matrix](./testakten/README.md#direktdownloads-je-testakte) |
| Maschinenlesbarer Asset-Index | JSON | [testakten-release-index.json](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakten-release-index.json) |

### Vollständigkeit und Integrität

| Was | Format | Direkt-Download |
| --- | --- | --- |
| Vollständiger Katalog aller Release-Dateien mit Zweck und Größe | Markdown | [release-katalog.md](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/release-katalog.md) |
| SHA-256-Prüfsummen aller übrigen Release-Dateien | Text | [checksums-sha256.txt](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/checksums-sha256.txt) |

Die [Testakten-Downloadmatrix](./testakten/README.md#direktdownloads-je-testakte) führt für jede Akte separat zum Gesamt-PDF, Arbeits-ZIP und Einzel-PDF-ZIP.

Komplette Release-Übersicht inkl. älterer Versionen: [GitHub Releases](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases).

<!-- END top-sofort-downloads (autogen) -->

## Schnellnavigation

| Ich will ... | Hier starten | Ergebnis |
|---|---|---|
| Sofort mit einem Fall oder Versandordner beginnen | [Direktstart](#direktstart-zwei-klare-wege) | passendes Plugin, ein Satz als Auftrag und festes erstes Ergebnis |
| Plugin installieren | [Sofort-Downloads](#sofort-downloads-latest-release) | Plugin-ZIP, Marketplace-Datei und Prompt-Skills aus dem aktuellen Release |
| Bedienlogik verstehen | [Plugin-README](./forderungsmanagement-immobilien/README.md) | Autostart, Startskills, Workflow-Phasen, Kontrollpunkte und Rollout-Hinweise |
| Fertige Schriftsätze und Anlagen nur technisch beA-fertig machen | [Schriftsatzwerkstatt beA](./schriftsatzwerkstatt-bea/README.md) | separate PDFs, Anlagenstempel, ASCII-Dateinamen, Manifest, Signaturweg, Preflight und Eingangssicherung |
| Testakten auswählen oder einzeln herunterladen | [Testakten-Übersicht](./testakten/README.md) | Fallauswahl, Gesamt-PDF, Arbeits-ZIP, Einzel-PDF-ZIP und Qualitätssicherung |
| Einzelnen Skill öffnen oder herunterladen | [Pluginübergreifender Skill-Index](./SKILLS.md) | Alle 59 Skills mit Beschreibung, Quelldatei und passendem Downloadpaket |
| Prompt-Fallback nutzen | [Werkstattprompt](./forderungsmanagement-grosser-prompt.md) und [Schnellstartprompt](./forderungsmanagement-kleiner-prompt.md) | Autarke Einzelprompt-Variante ohne Plugin-Installation |
| Tagesworkflow nachschlagen | [Tagesworkflow](#tagesworkflow-für-bearbeiter) | Vom Upload über Intake und Triage bis Freigabe und Fortschreibung |
| Schriftsatz gerichtsfertig machen | [Gerichtspaket-Workflow](./forderungsmanagement-immobilien/README.md#gerichtsfertiges-dokumentenpaket) | Beweis-/Anlagenmanifest, Einzel-PDFs, ERVV, Signatur, Versandauftrag und Eingang |
| E-Akte anbinden | [Elektronische Akten](#anschluss-an-elektronische-akten) und [Schnittstellenprofile](./references/schnittstellenprofile.md) | SAP, DocuWeb/DocuWare, DATEV, RA-MICRO, XML und MCP-Übergaben |
| Quellen und Methodik prüfen | [Fach- und Betriebsreferenzen](#fach--und-betriebsreferenzen) | Rechtsprechungsanker, Zitierweise, Quellenhygiene und Bedienführung |
| Release abnehmen | [Smoke-Tests](./tests/smoke-tests.md), [Changelog](./CHANGELOG.md) und [Release-Katalog](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/release-katalog.md) | Prüfpunkte, Versionshistorie und vollständiger Asset-Satz |

Der Einsatzfall ist bewusst praktisch: Die Abteilung bekommt SAP-/DMS-Exporte, Mietverträge, Mietkonten, Mieterpost, Schreiben von Mieterverein oder Gegenseite und Gerichtsunterlagen. Das Plugin strukturiert daraus eine arbeitsfähige Fallakte, erstellt Tabellen, prüft Rollen- und Freigabegrenzen und führt die Bearbeiter bis zum nächsten Dokumententwurf. Wohnraummietsachen laufen insbesondere vor dem Amtsgericht (Paragraf 23 Nr. 2a GVG; Prozessvertretung nach Paragraf 79 ZPO; eigene Angelegenheit nach Paragraf 2 Abs. 1 RDG beziehungsweise Konzernverbund nach Paragraf 2 Abs. 3 Nr. 6 RDG). Die interne 10.000-EUR-Grenze wird als Bearbeitungs- und Freigabekriterium behandelt; bei allgemeinen Zivilsachen ist daneben die aktuelle gesetzliche AG-Grenze des Paragrafen 23 Nr. 1 GVG gesondert zu prüfen.

Der Modus operandi ist: starke Fachangestellte, klare Technik, saubere Akte. Die Nutzer sind keine Anwälte und sollen nicht mit abgehobener Anwaltsprosa arbeiten müssen. Sie bekommen Sofortkarten, kompakte Tabellen, Ampeln, begründete Kontrollfragen und genau eine nächste Arbeitsaktion; nur echte Unternehmensentscheidungen erscheinen als kleine Auswahl. Juristische Präzision bleibt Pflicht, die Sprache bleibt arbeitsnah.

Strukturell und qualitativ ist dieses Repo an [`claude-fuer-deutsches-recht`](https://github.com/Klotzkette/claude-fuer-deutsches-recht) angelehnt. Die [geprüfte BGH-/BVerfG-Kontrollspur](./references/gepruefte-bgh-anker-mietrecht.md) wird durch das [Rechtsprechungsradar 2021 bis 2026](./references/rechtsprechungsradar-mietrecht-2021-2026.md) für KG, OLG, LG, EuGH und Sekundärquellen ergänzt. Der [Rechtsstand 2026 für Verfahren, Vollstreckung und Mietrechtsnovelle](./references/rechtsstand-2026-verfahren-vollstreckung.md) trennt geltendes Recht, verkündetes Zukunftsrecht und BT-Drs. 21/6807 als bloßen Entwurf. Die [ERV-/eBO-/beA-Referenz](./references/erv-dokumentenproduktion.md) steuert das gerichtsfertige Einreichungspaket. Alle Referenzen liegen im Plugin-ZIP. Der amtliche BGH-Feed und die neuen Arbeitsanker zu Härtefall, Vormiete, Auskunft, Online-Verfahren, Pfändungsfreigrenzen, digitaler Zwangsvollstreckung und Gesetzgebungsstatus wurden am 09.08.2026 kontrolliert; jede Referenz nennt ihren eigenen Prüfstand.

## Inhalt

| Bereich | Link | Zweck |
|---|---|---|
| Hauptplugin | [forderungsmanagement-immobilien/](./forderungsmanagement-immobilien/) | Plugin-README, Manifest, 50 Skills und mitgelieferte Quellenleitplanken |
| beA-Schriftsatzwerkstatt | [schriftsatzwerkstatt-bea/](./schriftsatzwerkstatt-bea/) | Eigenständiges Plugin mit neun fachlich neutralen Skills für die technische Versandfertigung |
| Skills | [forderungsmanagement-immobilien/skills/](./forderungsmanagement-immobilien/skills/) | Fachliche Arbeitsmasken für Intake, Triage, Klage, Räumung, Mieterhöhung, Kosten und Vollstreckung |
| Skill-Gesamtindex | [SKILLS.md](./SKILLS.md) | Alle Fach- und beA-Skills mit Detailseiten und geprüften Downloadwegen |
| Testakten | [testakten/](./testakten/) | Neun Berliner Fachfälle plus Mietspiegel-Referenz, jeweils mit Arbeits-ZIP, Gesamt-PDF und Einzel-PDF-ZIP |
| Werkstattprompt | [forderungsmanagement-grosser-prompt.md](./forderungsmanagement-grosser-prompt.md) | Vollständiger autarker Workflow für große Kontexte |
| Schnellstartprompt | [forderungsmanagement-kleiner-prompt.md](./forderungsmanagement-kleiner-prompt.md) | Kompakter autarker Workflow unter 7.500 Zeichen |
| Validatoren | [scripts/](./scripts/) | Struktur-, Frontmatter-, Umlaut-, Testakten- und Release-Prüfungen |
| Abnahmetests | [tests/smoke-tests.md](./tests/smoke-tests.md) | Manuelle Prüfliste für Plugin, Prompt-Skills und Testakten-Assets |
| Agentenhinweise | [CLAUDE.md](./CLAUDE.md), [AGENTS.md](./AGENTS.md), [CODEX.md](./CODEX.md) | Verbindliche Arbeitsregeln für automatisierte Änderungen |
| Mitwirken und Verhalten | [CONTRIBUTING.md](./CONTRIBUTING.md), [CODE_OF_CONDUCT.md](./CODE_OF_CONDUCT.md) | Beitragsablauf, Qualitätsregeln und Verhaltensstandard |
| Rechtliches | [LICENSE](./LICENSE), [NOTICE](./NOTICE) | Lizenzwahl, Drittinhalte und Hinweise |
| Release-Log | [CHANGELOG.md](./CHANGELOG.md) | Versionshistorie und Qualitätslog |
| Marketplace | [.claude-plugin/marketplace.json](./.claude-plugin/marketplace.json) | Interner Marketplace-Eintrag mit Plugin-Version |
| Fach- und Betriebsreferenzen | [references/](./references/) | Bedienführung, Schnittstellen, Rechtsprechungsanker, Methodik, Quellenhygiene und Zitierweise |
| Offline-Paket | [Repo-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/immobilien-forderungsmanagement-dokumentation.zip) | Vollständigen getrackten Repo-Inhalt ohne GitHub-Navigation lokal öffnen |

## Fach- und Betriebsreferenzen

| Referenz | Wofür sie gebraucht wird |
|---|---|
| [Bedienführung und Workflows](./references/bedienfuehrung-workflows.md) | Sofortkarte, automatische Workflow-Wahl, Rückfragegrenze, Übergabe und Freigabekarte |
| [100-Punkte-Bediencheck](./references/100-punkte-bediencheck.md) | konkrete Abnahme für Einstieg, Fristen, Stapel, Lesbarkeit, Quellen, DMS, Prompts, Testakten und Downloads |
| [Schnittstellenprofile](./references/schnittstellenprofile.md) | SAP-, DMS-, DATEV-, RA-MICRO-, XML- und MCP-Feldmapping |
| [Geprüfte BGH-Anker Mietrecht](./references/gepruefte-bgh-anker-mietrecht.md) | Öffentliche Primärquellen und konkrete Kontrollbefunde |
| [Rechtsprechungsradar 2021 bis 2026](./references/rechtsprechungsradar-mietrecht-2021-2026.md) | BGH-/BVerfG-/EuGH-, KG-, OLG- und LG-Suchspur mit Quellenstatus und Sekundärquellenkontrolle |
| [Rechtsstand 2026: Verfahren, Vollstreckung und Mietrechtsnovelle](./references/rechtsstand-2026-verfahren-vollstreckung.md) | Online-Verfahren, Pfändungsfreigrenzen, digitale Zwangsvollstreckung und hartes Entwurfs-Gate für BT-Drs. 21/6807 |
| [Schriftsatz- und Argumentationsstandard](./references/schriftsatz-und-argumentationsstandard.md) | Tatsachenkarte, Substantiierung, Bestreiten, Beweisangebot, Subsumtion und fallbezogene Endkontrolle |
| [ERV-, eBO- und beA-Dokumentenproduktion](./references/erv-dokumentenproduktion.md) | Einzel-PDFs, K-/B-Anlagen, Dateinamen, Rollengate, Signatur, Versandpaket und Eingangsnachweis |
| [Leitentscheidungen-Anker](./references/leitentscheidungen-anker.md) | Sucheinstieg nach Falltyp, Norm und Rechtsfolge |
| [Methodik Bürgerliches Recht](./references/methodik-buergerliches-recht.md) | Anspruchsaufbau, Einwendungen, Beweislast und Rechtsfolgen |
| [Quellenhygiene](./references/quellenhygiene.md) | Quellenstatus, Live-Verifikation und Umgang mit Unsicherheit |
| [Zitierweise](./references/zitierweise.md) | Einheitliche Fundstellen in Vermerken und Schriftsätzen |

Die eigenständige beA-Werkstatt verwendet zusätzlich den [Inhaltstreue- und Renderabgleich](./schriftsatzwerkstatt-bea/references/inhaltstreue-und-renderabgleich.md). Er bindet jede erzeugte PDF an ihre unveränderte Quelle und sperrt das Paket bei Abweichungen in Antrag, Betrag, Namen, Termin, Seite oder juristischem Inhalt.

## Einsatzentscheidung

| Einsatz | Asset | Zweck |
|---|---|---|
| Voller Rollout als Plugin | [Plugin-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien.zip) | 50 Skills, Plugin-Manifest und mitgelieferte Quellenleitplanken |
| Nur technische Schriftsatz-Endfertigung | [beA-Werkstatt-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/schriftsatzwerkstatt-bea.zip) | neun Skills für Konvertierung, Anlagen, PDF-Sichtprüfung, Dateinamen, Signaturweg, Manifest und Eingang |
| Interner Marketplace | [marketplace.json](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/marketplace.json) | Einträge für beide Plugins mit derselben Version wie beide Plugin-Manifeste |
| Cloud-Co-Work ohne Plugin-Installation | [Schnellstartprompt-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.zip) | Schnellstartprompt als einzelner kompakter Skill |
| Cloud-Co-Work mit großem Kontext | [Werkstattprompt-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-grosser-prompt-skill.zip) | Werkstattprompt als einzelner Skill mit Vollworkflow |
| Training und Abnahme | [Alle Arbeitsakten](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-testakten.zip) oder [alle Einzel-PDFs](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-testakten-einzel-pdfs.zip) | realistische Uploads aus SAP, DMS, Mietkonto, Vertrag und Korrespondenz |
| Offline lesen und prüfen | [Offline-Paket](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/immobilien-forderungsmanagement-dokumentation.zip) | Vollständiger getrackter Repo-Inhalt; relative Links funktionieren nach dem Entpacken |

Wenn die Zielumgebung nur einen einzelnen Skill akzeptiert, zuerst den Schnellstartprompt testen. Wenn genug Kontext vorhanden ist, den Werkstattprompt für den vollständigen Prozess verwenden. Das volle Plugin bleibt der empfohlene Produktivpfad.

Aktueller Release: [GitHub Releases](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest)

Die wesentlichen Änderungen pro Version stehen in [CHANGELOG.md](./CHANGELOG.md).

## Start in 30 Sekunden

Für Pilotgruppen ist der Einstieg bewusst niedrigschwellig. Ein Aktenordner, ein Einzel-PDF-ZIP oder ein gemischtes Upload-Bundle reicht; die Bearbeiter müssen keinen Skillnamen kennen.

| Situation | Eingabe an das Plugin | Erwartete erste Ausgabe |
|---|---|---|
| Unsortierter neuer Fall | `Neuer Fall. Prüfe den gesamten Ordner, sichere zuerst alle Fristen und arbeite ohne Skillauswahl bis zur nächsten freigabefähigen Entscheidung weiter.` | sofort die einheitliche Sofortkarte; danach automatisch Inventar, Startkarte und nächster Arbeitsschritt |
| SAP-Status und Mietkonto | `Bitte lies den SAP-Auszug und das Mietkonto ein und prüfe den Rückstand.` | normalisierte Stammdaten, Mietkonto-Ampel, Beleglücken, Triage |
| Laufende Akte mit Neuzugang | `Hier sind eine neue Zahlung und ein neues Schreiben zur vorhandenen Akte. Bitte fortschreiben.` | Änderungskarte mit Stichtag, Alt-/Neu-Saldo, neuer Frist, überholtem Arbeitsstand und genau einer nächsten Arbeitsaktion |
| Gerichtspost kommt rein | `Bitte werte die neue Gerichtspost aus und zeige Frist, Einwendungen, Beweise und nächsten Schriftsatz.` | Prozesskarte mit Frist, Einwendungsmatrix, Beweisbedarf und nächster Arbeitsaktion |
| Schriftsatz ist fachlich fertig | `Bitte finalisiere den Schriftsatz mit allen Anlagen als gerichtsfertiges Einreichungspaket.` | Rollengate Eigenvertretung/Kanzlei, Anlagenmanifest, Einzel-PDFs, beA-/eBO-/Formcheck, Freigabekarte und Versandauftrag |
| Titel, KFB oder Zahlung nach Urteil | `Bitte prüfe Kosten, Fristen, Zahlung und den nächsten Vollstreckungsschritt.` | Kosten-/Titelkarte, Stopprisiken, Tilgungsstatus und nächster Vollstreckungsschritt |

Bei großen Uploads gilt: zuerst den gesamten sichtbaren Bestand auf Gerichtspost, Zustellung, Frist, Zahlung, Kündigung und defekte Dateien scannen. Die erste Ausgabe ist eine kurze Sofortkarte mit frühester möglicher Frist, Quelle, Ampel, Dateistand, höchstens drei Kernlücken und genau einer nächsten Arbeitsaktion in Klartext. Danach vertieft das Plugin automatisch in priorisierten Stapeln von höchstens 20 Dateien oder 30 PDF-Seiten. Nach jedem Stapel sichert eine Fortsetzungsmarke Akten-ID, Stichtag, verarbeitet/offen, letzte Quelle/Seite, früheste Frist und nächsten Stapel. So setzt die Bearbeitung nach Unterbrechung ohne erneute Vollausgabe fort; interne Skillnummern müssen Bearbeiter nicht auswählen.

Bei einer laufenden Akte gilt das Gegenstück: keinen Vollintake wiederholen. Das Plugin übernimmt Akten-ID und Stichtag, verarbeitet nur den Neuzugang, schreibt Chronologie, Saldo, Beweise und Fristen fort und kennzeichnet ausdrücklich, welcher frühere Entwurf oder Prüfstand überholt ist.

## Rollout in einer Konzern-Immobilienabteilung

Empfohlener Start ist ein kontrollierter Pilot mit 5 bis 10 Bearbeitern aus Forderungsmanagement, Mietrecht und Prozesskoordination.

1. Berechtigungen klären: Zugriff nur für die konkrete Rechts- und Forderungsmanagementeinheit. Keine produktiven Mieterdaten in unsichere oder ungeprüfte Umgebungen laden.
2. Plugin installieren: Release-Asset `forderungsmanagement-immobilien.zip` hochladen und intern nur für die Pilotgruppe aktivieren.
3. Testakten verteilen: Pro Fall über die [Downloadmatrix](./testakten/README.md#direktdownloads-je-testakte) Gesamt-PDF, Arbeits-ZIP oder Einzel-PDF-ZIP passend zum Trainingsziel bereitstellen. Im Training zuerst mit Testakten arbeiten, nicht mit Live-Akten.
4. SAP-/DMS-Exportstandard festlegen: Typische Inputs definieren: Statusauszug, FBL5N-Mietkonto, Mietvertrag, Nachträge, Mahnungen, Kündigung, Mieterpost, Gerichtspost, DocuWeb/DocuWare-Export, DATEV-Dokumentenablage und RA-MICRO E-Akte.
5. Freigabegrenzen hinterlegen: 10.000-EUR-Grenze, RA-Eskalation, Landgericht/Berufung, Insolvenz, Strafrecht und Sachverständigenthemen als harte Eskalationspunkte trainieren.
6. Dokumentenabnahme festlegen: Jeder Entwurf bleibt Bearbeitungsvorschlag. Einreichung über Kanzlei/beA, Eigenvertretung/eBO oder einen zulässigen schriftlichen Weg, Kostenantrag und Vollstreckungsauftrag brauchen die interne fachliche Freigabe.
7. Pilotfälle auswerten: Bearbeitungszeit, Vollständigkeit der Belegmatrix, Qualität der Chronologie, Trefferquote bei Eskalation und Nacharbeit am Dokument messen.

## Tagesworkflow für Bearbeiter

Der normale Ablauf ist absichtlich linear und für wiederholte Sachbearbeitung geeignet. Im Alltag reicht als Einstieg: Aktenordner oder Upload-Bundle bereitstellen und sagen "neuer Fall" oder "mach die Akte fertig". Das Plugin soll dann mit `33-dokumentenmix-ocr-sichten` starten, die Unterlagen inventarisieren und ohne manuelle Skillauswahl den nächsten Fachpfad vorschlagen.

1. Akte laden: SAP-/DMS-Export, Vertragsunterlagen, Mietkonto und Korrespondenz zusammen in die Session geben.
2. Autostart laufen lassen: Skill 33 liefert sofort Frist-/Risikokarte und Dateistand, danach automatisch Startkarte, kompaktes Dokumentenregister, Beweiswert und Lückenliste. Große Bestände werden stapelweise mit Fortsetzungsmarke bearbeitet.
3. Intake vertiefen: Skills 01 bis 05 erzeugen Stammdaten, Mietakte, Mietkontoauswertung, Belegmatrix und Chronologie.
4. Triage entscheiden: Skills 06 bis 08 prüfen Rollenbefugnis, Fallziel, Streitwert, Eskalation und RA-Bedarf.
5. Fachpfad automatisch fortsetzen lassen: Zahlungsklage, Räumung, Mieterhöhung, Prozessreaktion, Verteidigung, Kostenfestsetzung oder Vollstreckung. Nur eine echte Unternehmensentscheidung wird als Auswahl vorgelegt.
6. Tabellen prüfen: Forderungsaufstellung, Fristen, Beweis-/Anlagenmatrix und Kosten werden vor jedem Schriftsatz abgeglichen.
7. Entwurf erzeugen: Schreiben, Klage, Replik, Kostenfestsetzungsantrag oder Vollstreckungsauftrag wird aus der strukturierten Akte erstellt.
8. Gerichtspaket bauen: Skill 39 schließt Beweise und fortlaufende K-/B-Nummern; Skill 23 erzeugt Hauptschriftsatz, einzelne Anlagen-PDFs, Anlagenkennzeichnung, ASCII-Dateinamen, Manifest und ERV-/Signaturcheck.
9. Fachlich freigeben: Eine getrennte Freigabekarte kontrolliert Aktenstichtag, Adressat, Rechtsfolge, Betragslogik, Beweise, Anlagen, Frist, Zustell-/Einreichungsweg und Rolle. Bis eine reale Freigabeperson entscheidet, bleibt der Status `ENTWURF - NICHT VERSENDEN/EINREICHEN`.
10. Akte fortschreiben: Eingangsbestätigung, Versand, Rücklauf, Zahlung, Vergleich oder Titel werden als Änderungskarte in Chronologie und Monitoring übernommen; überholte Arbeitsstände bleiben erkennbar.

Jeder Skill soll dabei wie eine geführte Arbeitsmaske wirken: erst Aktenlage sortieren, dann klärbare Lücken markieren, dann Entscheidung oder Entwurf liefern. Die Bedienlogik steht in [`references/bedienfuehrung-workflows.md`](./references/bedienfuehrung-workflows.md): Sofortkarte, Ampel, höchstens drei Rückfragen, automatische Pfadwahl und eine nächste Arbeitsaktion in Klartext. Schwierige Rechtsfragen werden nicht versteckt, sondern als klarer Eskalationspunkt formuliert.

## Anschluss an elektronische Akten

Das Plugin ist kein API-Client für SAP, DocuWeb, DATEV oder RA-MICRO und baut keinen MCP-Server. Es bereitet aber die Übergabe so vor, dass IT, DMS-Administration oder Fachabteilung daraus Import- und Exportpakete, ein MCP-Gateway oder einen Legacy-Import ableiten können. Maßgeblich sind Skills 01, 33, 34 und 45 sowie [`references/schnittstellenprofile.md`](./references/schnittstellenprofile.md).

Neutrale Austauschformate sind Standard:

| Format | Zweck | Inhalt |
|---|---|---|
| `fallakte.json` | strukturierte Fallakte für Systemwechsel, Automatisierung oder Übergabe an IT | Stammdaten, Forderungen, Fristen, Dokumente, Beweise, Risiken, nächste Schritte |
| `dms-register.csv` | Register-/Dokumentenliste für DocuWeb/DocuWare-artige DMS, DATEV-Dokumentenablage, RA-MICRO E-Akte oder andere elektronische Akten | Datei, Zielregister, Dokumenttyp, Datum, Absender, Empfänger, Aktenzeichen, Vertragsnummer, Betrag, Frist, Datenschutzklasse, Quelle |
| `fallakte.xml` | flacher Legacy-Export für XML-Import, Middleware oder Altverfahren | gleiche Fachinhalte wie `fallakte.json`, UTF-8, keine proprietären Annahmen |
| `mcp-context-manifest.json` | Planung für MCP-Server oder Kontext-Gateway | Resources, mögliche Tools, Prompts, Rechte, Schreibsperren, Protokollierung |
| `schnittstellenauftrag.md` | Rückfragen an IT, DMS-Administration oder Fachkoordination | Zielsystem, Feldmapping, Pflichtfelder, Rechte, Testimport, Rückexport, Frist |

Die Originaldateien bleiben unverändert. Importfähigkeit wird nicht behauptet, solange Feldnamen, Rechte, API/Webservice, MCP-Server, Middleware oder Importmaske des Zielsystems nicht geprüft sind. Schreibende Aktionen bleiben gelb oder rot, bis Berechtigung, Freigabe, Protokollierung und Testsystem geklärt sind.

## Kostenpfad nach Klageeinreichung

Wenn nach Einreichung einer Klage etwas passiert, wird nicht automatisch zurückgenommen oder erledigt erklärt. Zahlung, Aufrechnung, dauernde Einrede, Unmöglichkeit oder Wegfall des Rechtsschutzbedürfnisses lösen zuerst eine Kostenpfad-Matrix aus:

| Prüffeld | Warum es wichtig ist |
|---|---|
| Datum der Klageeinreichung | trennt Anhängigkeit von späterer Rechtshängigkeit |
| Datum der Zustellung | löst Rechtshängigkeit, Prozessfristen und Schonfristfenster aus |
| Ereignis und Umfang | entscheidet vollständig/teilweise und einseitig/übereinstimmend |
| Vorverzug und Kostenkausalität | Verzug muss vor dem kostenauslösenden Schritt bestanden haben; Erforderlichkeit wird aus damaliger Sicht geprüft |
| Forderungsstatus bei Einreichung | offen, bezahlt, gebucht, noch nicht erkennbar oder streitig; bestimmt Ampel und Eskalation |
| Kostenweg | Paragraf 91a ZPO, Paragraf 269 Abs. 3 S. 3 ZPO, materiell-rechtliche Kostenerstattung oder RA-Eskalation |

Diese Weiche ist besonders wichtig im Massengeschäft: Eine schnelle Zahlung nach Klageeinreichung ist gut für die Forderung, kann aber bei falscher prozessualer Reaktion Kosten verlieren. Der grüne Standardfall setzt Vorverzug, eine bei Einreichung noch offene Forderung sowie erforderliche und kausale Klagekosten voraus. Ist eine Zahlung unmittelbar vor Einreichung eingegangen, war aber objektiv noch nicht erkennbar, wird der Vorgang gelb markiert und mit Zahlungsweg, Buchungszeitpunkt und Kenntnisstand zur RA-Prüfung gegeben.

Praktische Teamregel: Ohne belegten Vorverzug keine materiell-rechtliche Kostenerstattung als Standardvorschlag. Dann wird der Vorgang gelb oder rot markiert und mit konkreter Kostenfrage an RA oder Konzernrechtsabteilung gegeben.

## Plugin: forderungsmanagement-immobilien

50 Skills, gegliedert nach dem realen Workflow einer Konzern-Rechtsabteilung:

- Phase A — Intake aus SAP (5 Skills): SAP-Akte importieren, Mietakte rekonstruieren, FBL5N-Mietkonto auslesen, Belegmatrix, Chronologie
- Phase B — Triage / Fallziel (3 Skills): Renofa-Triage, RDG-Grenzen, Eskalation an Anwalt
- Phase C — Mahnwesen (4 Skills): Mahnung, Zahlungsplan, Verzugsschaden, letzte Frist
- Phase D — Kündigung (4 Skills): fristlos, ordentlich, Zustellung, Widerspruch
- Phase E — Optionales Mahnverfahren (3 Skills): nur als Abzweigung nach Rückfrage, Standard bleibt direkte Klage
- Phase F — Klage (4 Skills): Zahlungsklage, Streitwert/GKG, Zuständigkeit AG, gerichtsfertiges Paket mit beA-/eBO-/Formweg
- Phase G — Räumung (4 Skills): Räumungsklage, Räumungsfrist, Berliner Modell, Schonfristzahlung
- Phase H — Mieterhöhung (4 Skills): Paragraf 558 BGB, Mieterhöhungsverlangen, Zustimmungsklage, Kappungsgrenze
- Phase I — Querschnitt (1 Skill): DSGVO/Mieterdaten
- Phase J — Daten- und Strategieveredelung (4 Skills): Dokumentenmix/OCR, SAP-Excel-PDF-Normalisierung, Beleglücken, Fallstrategie bis 10.000 EUR
- Phase K — Prozessreaktion und Verteidigung (9 Skills): Klageerwiderung, Replik, Beweisplan, Urkundsprozess-Prüfung, Vergleich, Mieterklage-Verteidigung, Mieterverein, Betriebskosten, Hausverwaltungsschnittstelle
- Phase L — Kosten und Vollstreckung (5 Skills): Kostenfestsetzung, Kostenbeschluss, titulierte Forderung, Kontoermittlung, Vollstreckungsmonitoring

## Plugin: schriftsatzwerkstatt-bea

Dieses eigenständige Plugin beginnt erst, wenn Inhalt, Anträge, Vortrag, Beweisentscheidung und Fristen fachlich geklärt sind. Ein gemeinsamer Projektordner genügt; der Autostart inventarisiert die Quellen unverändert und führt ohne manuelle Skillauswahl durch neun technische Stufen:

1. Ordnerannahme und gebündelte Pflichtfragen.
2. Sperren der richtigen Schriftsatzfassung.
3. Fortführen und sichtbares Kennzeichnen der K-/B-Anlagenfolge.
4. Konvertieren von Office-, Tabellen-, E-Mail-, Bild-, Scan- und PDF-Quellen in getrennte PDF-Arbeitskopien; unveränderte grüne Ergebnisse werden nur bei vollständigem Hash- und Profiltreffer wiederverwendet.
5. Rendern und visuelles Prüfen jeder relevanten Seite.
6. Bilden kurzer ASCII-Dateinamen mit höchstens 80 Zeichen und Erzeugen des SHA-256-Manifests.
7. Prüfen von qeS oder einfacher Signatur samt tatsächlichem Versender.
8. Preflight, reale Freigabe und Versandauftrag ohne automatischen beA-Versand.
9. Prüfen der automatisierten Eingangsbestätigung und Sichern der Versandakte.

Die [vollständige Werkstattanleitung](./schriftsatzwerkstatt-bea/README.md) enthält Schnellstart, Ergebnisordner, Signaturmatrix, alle Skilllinks, Vorlagen und Direktdownloads. Der [100-Punkte-Fehlerkatalog](./schriftsatzwerkstatt-bea/references/100-punkte-fehlerkatalog.md) führt von der Quellenannahme bis zur gerichtlichen Eingangsbestätigung; der schnelle Delta-Lauf bearbeitet nur geänderte Quellen neu und lässt den vollständigen finalen Preflight bestehen. Das Plugin enthält bewusst keine Rechtsprechungsanker und ändert keine fachlichen Aussagen. Erkennt es Änderungsbedarf am Inhalt, stoppt es und gibt die konkrete Datei an die verantwortliche Person zurück.

## Typische Einsatzszenarien

| Szenario | Start-Skills | Ergebnis |
|---|---|---|
| Mietrückstand aus SAP | 01 bis 05, 20 bis 23 | Forderungsaufstellung, Anlagenmatrix, Zahlungsklage |
| Zahlungsverzug mit Kündigung | 01 bis 05, 13 bis 16, 24 bis 27 | Kündigung, Räumungsklage, Reaktion auf Schonfristzahlung |
| Mieterhöhung nach Paragraf 558 BGB | 28 bis 31 | Mieterhöhungsverlangen, Zustimmungsklage, Mietspiegel-Bezug |
| Gerichtliche Klageerwiderung oder Hinweis | 37 bis 42 | Erwiderungsmatrix, Replikplan, Beweisplan oder Verteidigung |
| Außergerichtliches Mieterverein-/Anwaltsschreiben | 43, fachlich ggf. 44 | Kommunikationsstatus, Einwendungsmatrix und freizugebender Antwortentwurf |
| Betriebskosten- oder Hausverwaltungsstreit | 44 bis 45 | Forderungs- und Einwendungsmatrix, Schnittstellenauftrag |
| Nach Urteil oder Vergleich | 46 bis 50, bei Unterliegen 08 | Kostenfestsetzungsantrag, Titelprüfung, Vollstreckungsakte oder Rechtsmittel-Skizze |

## Was das Plugin bewusst nicht macht

- Kein ungeprüfter Versand an Gericht, Mieter, Gerichtsvollzieher oder Gegenseite.
- Kein Ersatz für anwaltliche Freigabe bei Landgericht, Berufung, Revision, Insolvenz, Strafrecht oder komplexen Sachverständigenfragen.
- Keine eigenständige Rechtsmittelführung nach abweisendem oder teilweise abweisendem Amtsgerichtsurteil; das Plugin liefert nur Fristen-, Beschwer- und Fortsetzungs-Skizze für die anwaltliche Prüfung.
- Kein automatisches gerichtliches Mahnverfahren als Standardpfad. Mahnbescheid und Vollstreckungsbescheid bleiben optionale Abzweigung nach ausdrücklicher Entscheidung.
- Keine produktive Datenmigration aus SAP oder DMS. Das Plugin arbeitet mit den exportierten Unterlagen, die die Abteilung bereitstellt.
- Keine eigenständige Rechtsberatung für konzernfremde Dritte.

## Testakten

Neun vollständige Berliner Wohnraumfälle mit Konzern-Stammdaten Wohnen Berlin Immobilien GmbH, jeweils mit fallbezogenem SAP-Status, Vertrag, Konto-, DMS-, Korrespondenz-, Beweis- oder Gerichtsunterlagen. Der Mietspiegel ist eine eigene Referenz-Testakte:

| Fall | Akte | Hauptpfad |
|---|---|---|
| Mietrückstand Meier | [mietrueckstand-meier-wilhelmstrasse](./testakten/mietrueckstand-meier-wilhelmstrasse/) | Zahlungsklage-Regelfall mit Kündigungsoption |
| Räumung Kowalski | [raeumungsklage-kowalski-friedrichshain](./testakten/raeumungsklage-kowalski-friedrichshain/) | Kündigung, Räumungsklage, Jobcenter-Schonfristzahlung und Kostenpfad |
| Mieterhöhung Becker | [mieterhoehung-becker-tempelhof](./testakten/mieterhoehung-becker-tempelhof/) | Paragraf 558 BGB, Berliner Mietspiegel 2026, Kappungsgrenze und Zustimmungsklage |
| Bankwechsel Lange | [mietrueckstand-lange-zwei-raten-versehen](./testakten/mietrueckstand-lange-zwei-raten-versehen/) | Zwei offene Mieten, glaubhafte versehentliche Nichtzahlung und Kulanz-Ratenplan |
| Zahlungsstopp Demir | [mietrueckstand-demir-fuenf-raten-absichtlich](./testakten/mietrueckstand-demir-fuenf-raten-absichtlich/) | Fünf offene Mieten, bewusster Zahlungsstopp, Kündigung und Räumung |
| Nebenkosten Braun | [nebenkosten-braun-nachzahlung-unbezahlt](./testakten/nebenkosten-braun-nachzahlung-unbezahlt/) | Laufende Miete bezahlt, Betriebskosten-Nachzahlung offen und pauschal bestritten |
| Ratenplan Riedel | [ratenplan-riedel-gebrochen](./testakten/ratenplan-riedel-gebrochen/) | Gebrochener Kulanzplan bei wieder stabiler laufender Miete |
| Vollstreckung Krüger | [vollstreckung-krueger-titel-teilzahlung](./testakten/vollstreckung-krueger-titel-teilzahlung/) | Versäumnisurteil, KFB, Teilzahlung, Tilgungsjournal und Vollstreckungsmonitoring |
| Mieterklage Schulz | [mieterklage-schimmel-schulz-verteidigung](./testakten/mieterklage-schimmel-schulz-verteidigung/) | Zugestellte Schimmelklage, Notfrist, technische Ursachenklärung, Beweisplan und Klageerwiderung |

Dazu eine [Kurzfassung des Berliner Mietspiegels 2026](./testakten/mietspiegel-berlin/berliner-mietspiegel-2026.md) als Trainingsunterlage.

## Schulung mit Testakten

Für Trainings in einer großen Abteilung ist diese Reihenfolge praktikabel:

1. 30 Minuten Orientierung: Was ist das Plugin, welche Daten dürfen hinein, wo liegen die Grenzen.
2. 45 Minuten Mietrückstand: Testakte Meier, Skills 01 bis 05 und Zahlungsklage-Pfad.
3. 45 Minuten Räumung: Testakte Kowalski, Kündigung, Räumungsklage, Schonfristzahlung, Erledigungsreaktion.
4. 30 Minuten Kostenpfad: simulierte Zahlung nach Klageeinreichung, Rechtshängigkeit, prozessuale Kostenentscheidung, materielle Kostenerstattung und RA-Eskalation.
5. 45 Minuten Mieterhöhung: Testakte Becker, Mietspiegel, Kappungsgrenze, Zustimmungsklage.
6. 45 Minuten Kulanz und Ratensteuerung: Testakten Lange und Riedel, gelbe Ampel, Zahlungsplan, Wiedervorlage, Kulanzende.
7. 45 Minuten harte Eskalation: Testakte Demir, bewusster Zahlungsstopp, Kündigung, Zahlung und Räumung.
8. 30 Minuten Nebenkosten: Testakte Braun, Abrechnung, Belegeinsicht, Durchsetzbarkeit und Zahlungsklage.
9. 45 Minuten Mieterklage verteidigen: Testakte Schulz, Notfrist, tatsächlicher Schimmel, Ursachen- und Beweisoffenheit, Klageerwiderung und Gerichtspaket.
10. 30 Minuten Abschluss: Testakte Krüger, Kostenfestsetzung, Tilgungsjournal nach Paragraf 367 BGB, Vollstreckungsauftrag, Monitoring, Eskalationsregeln.

Die Einzel-PDF-ZIPs sind für realistische Upload-Tests gedacht: jede Unterlage liegt als eigene PDF-Datei vor, sauber benannt, aber nicht zu einem Gesamt-PDF verschmolzen. Das entspricht der typischen Arbeitssituation, wenn Dokumente aus SAP, DMS, E-Mail und Scanstrecken zusammenkommen.

Seit v5.11.0 enthalten die Testakten zusätzlich bewusst unaufgeräumte Aktenstücke wie DMS-Beifang, Dublettenhinweise, unklare Zahlungstexte, Rückrufnotizen und angekündigte fehlende Anlagen. Im Training sollen Bearbeiter deshalb zuerst Dokumenteninventar, Beifang-Liste, Belegstatus und Rückfragen erstellen, bevor Forderung, Kündigung, Klage oder Vollstreckung freigegeben werden.

## Werkstattprompt und Schnellstartprompt

- [Forderungsmanagement-Werkstattprompt](./forderungsmanagement-grosser-prompt.md) — vertiefter autarker Workflow von SAP-/DMS-Intake über Beweis- und Qualitätsgates bis Kostenfestsetzung und Vollstreckung; die erzeugte Standalone-`SKILL.md` bleibt einschließlich Frontmatter unter 30.000 Zeichen.
- [Forderungsmanagement-Schnellstartprompt](./forderungsmanagement-kleiner-prompt.md) — kompakter autarker Workflow unter 7.500 Zeichen für Einzelprompt oder Skill-Upload.
- Die [Standalone-Downloads](#sofort-downloads-latest-release) verpacken beide Prompts jeweils als einzelne Markdown-Datei und als Cowork-ZIP mit `SKILL.md` an der ZIP-Wurzel.

## Betrieb und Governance

- Datenminimierung: Nur fallrelevante Unterlagen hochladen. Besonders sensible Anlagen vorher prüfen und, falls nötig, schwärzen.
- Rollenmodell: Renofa/Rechtsfachwirt arbeitet am Fall; Jurist oder externe Kanzlei gibt eskalationspflichtige Schritte frei.
- Vier-Augen-Prinzip: Klagen, Kündigungen, Vergleiche, Kostenanträge und Vollstreckungsaufträge erhalten eine getrennte Freigabekarte. Nur eine benannte reale Freigabeperson setzt `FREIGEGEBEN`; Änderungen an Betrag, Antrag, Partei, Frist, Beweis, Anlage oder Zustellweg heben die Freigabe auf.
- Versionierung: Releases werden getaggt. Für produktive Rollouts immer ein konkretes Release verwenden, nicht einen beliebigen Branch-Zustand.
- Nachvollziehbarkeit: Chronologie, Belegmatrix und Anlagenplan als Pflicht-Zwischenergebnisse speichern.
- Bedienbarkeit: Jede Ausgabe braucht Sofort-, Start- oder Änderungskarte beziehungsweise eine fachliche Matrix, Ampel, Rückfragen nur mit Grund und genau eine nächste Arbeitsaktion.
- Qualitätssicherung: Neue Skills, Prompts oder Manifeste erst nach grüner Validierung mergen.

## Abnahme vor Produktivstart

Vor einer Freigabe für eine Fachabteilung sollten mindestens diese Punkte abgehakt werden:

1. Aktuelles Release installieren und Plugin-ZIP laden.
2. `marketplace.json` und beide Dateien `.claude-plugin/plugin.json` auf gleiche Version prüfen.
3. Je Testakte das direkte Gesamt-PDF, Arbeits-ZIP und Einzel-PDF-ZIP bereitstellen.
4. Cloud-Co-Work-Fallback prüfen: Schnellstartprompt-ZIP entpackt exakt eine `SKILL.md` und bleibt unter 7.500 Zeichen.
5. Smoke-Tests in [`tests/smoke-tests.md`](./tests/smoke-tests.md) für Mietrückstand, Räumung, Mieterhöhung, Prozessreaktion und Vollstreckung durchgehen.
6. Eine Pilotakte vollständig von Intake bis nächster Maßnahme bearbeiten.
7. Datenschutz- und Freigabeprozess der Abteilung dokumentieren.
8. Ergebnis mit einer fachlichen Freigabeperson abnehmen.
9. Prüfen, dass außenwirksame Testentwürfe eine getrennte Freigabekarte tragen und ohne reale Freigabe nicht als versand- oder einreichungsbereit erscheinen.
10. Die beA-Werkstatt mit einem gemischten Ordner testen: DOCX-Hauptschrift, XLSX-Tabelle, EML samt Anhängen, Bildscan und Bestands-PDF müssen als getrennte geprüfte PDFs mit Manifest entstehen.

## Validatoren

Die vollständige Build- und Prüfumgebung ist in
[`requirements-release.txt`](./requirements-release.txt) festgeschrieben. Für
lokale Release-Prüfungen führt `uv run --with-requirements
requirements-release.txt` jeden Befehl reproduzierbar mit genau diesem Stand
aus; GitHub Actions installiert dieselbe Datei.

```
node scripts/validate-plugin-structure.mjs
python3 scripts/validate-yaml-frontmatter.py
python3 scripts/validate-legal-anchors.py
python3 scripts/validate-umlaut-prose.py
python3 scripts/validate-markdown-links.py --selftest
python3 scripts/validate-markdown-links.py
python3 scripts/validate-readme-navigation.py
python3 scripts/generate-skills-md.py --check
python3 scripts/validate-skill-frontmatter-parsers.py
uv run --with pypdf python3 schriftsatzwerkstatt-bea/scripts/validate_bea_package.py --selftest
python3 scripts/validate-testakten-gesamt-pdf.py
python3 scripts/validate-testakten-financial-consistency.py
python3 scripts/validate-testakten-stammdaten.py
python3 scripts/validate-testakten-document-quality.py
```

Alle Validatoren müssen grün sein, bevor commit erlaubt ist. Regeln: Skill-`description` maximal 1024 Zeichen, Plugin- und Marketplace-Plugin-`description` maximal 300 Zeichen, keine spitzen Klammern, keine Komma-Zahlen, keine eingebetteten doppelten Anführungszeichen, keine Emojis oder Symbolzeichen, Slug maximal 64 Zeichen. Jede Testakte enthält ein `gesamt-pdf/<slug>_gesamt.pdf`; Stammdaten wie Vertragsnummer, Vertragsbeginn und Geburtsdaten müssen aktenweit widerspruchsfrei sein.

Für ein Release werden zusätzlich die gebauten Artefakte geprüft:

```
uv run --with-requirements requirements-release.txt python3 scripts/validate-testakten-release-zips.py dist
uv run --with-requirements requirements-release.txt python3 scripts/validate-release-zips.py dist .claude-plugin/marketplace.json
uv run --with-requirements requirements-release.txt python3 scripts/validate-release-guardrails.py dist .claude-plugin/marketplace.json
```

Der GitHub-Workflow validiert nach dem Upload außerdem die tatsächlich veröffentlichten Assets per `scripts/validate-release-assets.py`. Bei einer manuellen Kontrolle nach Workflow-Ende zuerst die Release-Assets herunterladen und dann die beiden ZIP-Validatoren gegen dieses Download-Verzeichnis laufen lassen.

## Lizenz

Apache-2.0 OR MIT (Dual). Siehe [Lizenzübersicht](./LICENSE), [Apache-2.0](./LICENSE-APACHE), [MIT](./LICENSE-MIT) und [Hinweise](./NOTICE). Testakten sind frei erfundene Personen; jede Ähnlichkeit mit echten Personen ist Zufall.
