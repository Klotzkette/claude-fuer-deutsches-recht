# CLAUDE.md – Repository-Leitfaden für das Modell

Dieses Repository enthält zwei Plugins für die Immobilien-Rechtsabteilung eines deutschen Immobilienkonzerns: das **nicht-anwaltliche Forderungsmanagement** und eine fachlich neutrale **beA-Schriftsatzwerkstatt** für bereits inhaltlich fertige Unterlagen. Zielgruppe sind hochtrainierte **Rechtsanwalts- und Notarfachangestellte, Renofas, Rechtsfachwirt:innen und Forderungsmanagement-Spezialist:innen** ohne Anwaltszulassung, die im Konzern-Inhouse-Modell selbst gerichtlich auftreten — insbesondere vor dem Amtsgericht in Wohnraummietsachen (Paragraf 23 Nr. 2a GVG ohne Streitwertgrenze; Prozessvertretung nach Paragraf 79 ZPO; eigene Angelegenheit nach Paragraf 2 Abs. 1 RDG beziehungsweise Konzernverbund nach Paragraf 2 Abs. 3 Nr. 6 RDG).

Wenn du in diesem Repository arbeitest oder hieraus Skills lädst, halte dich an die folgenden Regeln.

## Repo-Spezifika

- **Keine RVG/Honorarvereinbarung in externer Kommunikation.** Renofas arbeiten im Inhouse-Konzernrechtsdienst, nicht auf Mandat; das RVG ist nicht einschlägig.
- **Keine "Mandantin" / "Mandant".** Es gibt im Forderungsmanagement keinen externen Mandanten; die Vermieterin ist die eigene Konzerngesellschaft. Verwende "Vermieterin", "Klägerin" oder "die Konzerngesellschaft".
- **Gerichtliche Vertretung im Parteiprozess** nach Paragraf 79 Abs. 2 S. 2 Nr. 1 ZPO. Bei Landgerichts-Zuständigkeit (insbesondere Gewerberaum-Streitwerte über 10.000 EUR) oder Berufungs- und Revisionsverfahren ist an einen Rechtsanwalt zu eskalieren (Skill `08-eskalation-an-anwalt`).
- **Bedienmodus für Fachangestellte:** Die Nutzer:innen sind keine Anwälte, aber fachlich stark. Führe sie mit kurzen Arbeitskarten, begründeten Entscheidungsfragen, kompakten Tabellen, Ampeln, Lückenlisten und genau einer nächsten Arbeitsaktion; nur echte Unternehmensentscheidungen erscheinen als kleine Auswahl. Keine professorale Anwaltsprosa; juristisch präzise, aber in Arbeitssprache.
- **Vorlagenstil:** Schriftsätze in Urteilsstil, kurz, sachlich, nummeriert nach Dezimalsystem.
- **Getrennte beA-Schriftsatzwerkstatt:** `schriftsatzwerkstatt-bea` bearbeitet ausschließlich die technische Endfertigung bereits fachlich freigegebener Unterlagen. Sie bleibt bei höchstens zehn Skills, verändert keine Quellen, enthält keine Rechtsprechungsanker, prüft keine Rechtsfrage und versendet nicht selbst. Inhaltlicher Änderungsbedarf führt zum Stopp und zur Rückgabe an die verantwortliche Person.
- **Anker-Rechtsprechung:** Maßgebliche Kontrollspur ist [`references/gepruefte-bgh-anker-mietrecht.md`](./references/gepruefte-bgh-anker-mietrecht.md). Der Schreib- und Beweisaufbau folgt zusätzlich [`references/schriftsatz-und-argumentationsstandard.md`](./references/schriftsatz-und-argumentationsstandard.md). Rechtzeitigkeit der Wohnraummietzahlung: BGH 05.10.2016 — VIII ZR 222/15; Sonnabend bei der Zahlungsfrist: BGH 13.07.2010 — VIII ZR 129/09 und VIII ZR 291/09. Kernlinie Zahlungsverzug/Kündigung: BGH 23.07.2025 — VIII ZR 287/23; BGH 09.04.2025 — VIII ZR 145/24; BGH 05.10.2022 — VIII ZR 307/21; BGH, Urteil vom 13.10.2021 — VIII ZR 91/20; BGH 16.02.2005 — VIII ZR 6/04; BGH 28.11.2007 — VIII ZR 145/07.
- **Prozesskosten-Anker:** BGH 18.04.2013 — III ZR 156/12 zur materiellen Kostenerstattungsklage nach Erledigung vor Rechtshängigkeit; BGH 28.01.2025 — VIII ZB 39/24 zur eingeschränkten Prüfung bei Paragraf 91a ZPO. Materiell-rechtliche Kostenerstattung als Verzugsschaden nur bei Vorverzug und aus damaliger Sicht erforderlichen, kausalen Klagekosten prüfen. Regelfall ist eine bei Einreichung noch offene Forderung; bei unmittelbar zuvor eingegangener, noch nicht erkennbarer Zahlung gilt gelbe Ampel und RA-Prüfung statt automatischer Freigabe.
- **Mieterhöhungs-Anker:** BGH 29.04.2020 — VIII ZR 355/18; BGH 28.04.2021 — VIII ZR 22/20; BGH 07.07.2021 — VIII ZR 167/20; BGH 06.04.2022 — VIII ZR 219/20; BGH 16.10.2019 — VIII ZR 340/18; BGH 15.07.2025 — VIII ZB 69/24.
- **Betriebskosten-, Räumungs- und Verteidigungs-Anker:** BGH 01.07.2026 — VIII ZR 4/23 zur Haftung wegen formell oder materiell fehlerhafter Kündigung und zur Begrenzung der Kostenerstattung auf gesetzliche Gebühren; BGH 20.05.2026 — VIII ZR 6/24, VIII ZR 46/25 und VIII ZR 47/25; BGH 18.06.2025 — VIII ZR 291/23; BGH 07.10.2025 — VIII ZR 11/24; BGH 28.01.2026 — VIII ZR 228/23; BGH 16.04.2025 — VIII ZR 270/22; BGH 26.08.2025 — VIII ZR 262/24; BGH 14.05.2025 — VIII ZR 256/23; BGH 06.08.2025 — VIII ZR 161/24; BGH 08.10.2025 — VIII ZR 18/24; BGH 17.12.2025 — VIII ZR 56/25; BGH 21.01.2026 — VIII ZR 247/24; BGH 29.01.2026 — I ZR 129/25 als Randanker für AGG-/Vermietungsverteidigung.
- **Quellenhygiene wie in [`claude-fuer-deutsches-recht`](https://github.com/Klotzkette/claude-fuer-deutsches-recht):** keine erfundenen Aktenzeichen, keine Kommentar-/Aufsatz-Fundstellen aus Modellwissen, Prüfe Live-Quellen wenn möglich.

## Sprache

- **Alle Ausgaben auf Deutsch.** Englische Begriffe nur, wenn etabliert (z. B. "Letter of Intent", "Term Sheet", "Due Diligence", "Discovery") – aber stets erklärt.
- **Fachangestellten-tauglich formulieren.** Keine abstrakten Theorieblöcke, wenn ein Arbeitsschritt reicht. Normen nennen, aber sofort in Prüffrage, Kontrollpunkt oder Handlung übersetzen.
- Du-Form gegenüber Mietern oder externen Beteiligten nur, wenn ausdrücklich vorgegeben; sonst Sie-Form.
- Behördensprache nüchtern, klar, prägnant.

## Methodik

- Standard ist der **Gutachtenstil** für interne Memos und begründete Mieter- oder Behördenkommunikation.
- **Urteilsstil** für Schriftsätze, Beschlüsse, knappe Vermerke.
- Anspruchsgrundlagenprüfung in der Reihenfolge: Vertrag – c.i.c. – GoA – dinglich – Delikt – Bereicherung.
- Auslegung nach den vier klassischen Methoden (grammatikalisch, systematisch, historisch, teleologisch) zzgl. verfassungs- und unionsrechtskonformer Auslegung.
- Siehe [`references/methodik-buergerliches-recht.md`](./references/methodik-buergerliches-recht.md).

## Quellen und Zitierweise

- **Verbindlich:** [`references/zitierweise.md`](./references/zitierweise.md).
- Jede juristische Aussage wird belegt.
- Rechtsprechung: Gericht, Entscheidungsform, Datum, Aktenzeichen, Fundstelle, Randnummer.
- Kommentare: Bearbeiter, "in:" Kommentar, Auflage, Jahr (ggf. Stand), Norm, Randnummer.
- Aufsätze: Autor, Zeitschrift, Jahrgang, Anfangsseite (konkrete Seite).
- Reihenfolge: Rspr. vor Lit., neueste zuerst.
- Keine Kommentar-, Handbuch- oder Aufsatzfundstellen aus Modellwissen zitieren. Literatur nur nutzen, wenn der Nutzer die Quelle bereitstellt oder ein lizenzierter Live-Zugriff sie verifiziert.
- **Leitentscheidungs-Anker:** [`references/leitentscheidungen-anker.md`](./references/leitentscheidungen-anker.md) ist die kuratierte Themen-Anker-Liste je Rechtsgebiet. Sie ersetzt nicht die Live-Verifikation, aber sie liefert sichere Sucheinstiege ohne Modellwissens-Halluzination.

## Gliederung und Nummerierung (verbindlich für alle Vorlagen und Verträge)

Diese Regel gilt **dauerhaft und für jedes Werkzeug**, das in diesem Repository arbeitet – Claude, Codex, Perplexity, Cloud und jedes weitere Modell. Sie ist nicht verhandelbar.

- **Ausschließlich dezimale Gliederung:** `1`, dann `1.1`, dann `1.1.1`, dann `1.1.1.1` und so weiter, beliebig tief.
- **Niemals** römische Ziffern (`I`, `II`), Großbuchstaben (`A`, `B`, `C`), Kleinbuchstaben (`a`, `b`) oder gemischte Verlags-Gliederungen (`A. I. 1. a) aa)`). Genau diese Schemata sind verboten, weil man sich darin nicht zurechtfindet.
- **Leerzeile zwischen Gliederungspunkt und seinem Inhalt sowie zwischen Gliederungsebenen.** Überschrift bzw. Nummer und der folgende Text/Unterpunkt werden durch eine Leerzeile getrennt, sonst ist es nicht lesbar.
- **Einrückung sparsam.** Nur leicht einrücken, gerade so viel, dass die Hierarchie sichtbar bleibt und es gut aussieht – nie so tief, dass das Dokument zerfleddert wirkt.
- **Hohe Priorität.** Bei Konflikt mit einer abweichenden Gliederung in einer Altvorlage gilt diese Regel; die Altvorlage ist anzupassen.

Gilt für alle Vorlagen, Verträge, Vertragsmuster, Memos, Schriftsätze und sonstigen formatierten Dokumente in diesem Repository.

## Verboten

- Präjudizienbindungs-Argumente. In Deutschland gibt es keine Präjudizienbindung (außer § 31 BVerfGG).
- Vorprozessuale Beweiserhebung im deutschen Recht ist auf eng begrenzte gesetzliche Instrumente beschränkt: §§ 142, 144, 421–432 ZPO, § 810 BGB, § 242 BGB, Art. 15 DSGVO, Auskunfts- und Stufenklage (§ 254 ZPO).
- Halluzinierte Aktenzeichen oder Fundstellen. Bei Unsicherheit: kennzeichnen und Verifizierung in amtliche oder frei zugängliche Quellen; lizenzierte Datenbanken nur bei vorhandenem Zugang empfehlen.
- Vertraulichkeitsverletzung bei Mieter-, Konzern- oder Prozessdaten. Personenbezogene Daten nur in rechtskonformen Tools mit AVV verarbeiten.

## Standardstruktur für Memos

1. Sachverhalt (knapp)
2. Frage(n)
3. Kurzantwort (1 Satz)
4. Rechtliche Bewertung (Gutachtenstil)
5. Gesamtergebnis
6. Risiken / offene Punkte
7. Quellenverzeichnis (gem. references/zitierweise.md)

## Standardstruktur für konzerninterne und Mieter-Kommunikation

- Anrede + Bezug ("In Sachen … / Zu dem Mietverhältnis …")
- Sachstand
- Empfehlung
- Nächste Schritte / Frist
- Interner Kosten- oder Gerichtskostenvorschuss-Hinweis nur, wenn einschlägig
- Unterschrift mit Berufsbezeichnung

## Ausformulierungspflicht für Verträge, Vorlagen und juristische Dokumente (verbindlich)

Diese Regel gilt **ausnahmslos und für alle Zeiten** für jedes Dokument, das ein Skill, ein Plugin oder ein anderes Werkzeug in diesem Repository als Endprodukt erzeugt — Verträge, Vertragsmuster, Klausel-Sets, Schriftsätze, Bescheide, Beschlüsse, Verfügungen, Memos, Mieterschreiben, Vollmachten, Anschreiben, Vermerke, Stellungnahmen, NDA-Texte, AGB-Entwürfe, Vereinbarungen, Anträge, Erwiderungen und alle vergleichbaren Endprodukte — unabhängig davon, welches Werkzeug es erzeugt (Claude, Perplexity, Codex oder andere).

- **Vollständig ausformuliert.** Endprodukte werden in vollständigen, grammatikalisch sauberen Sätzen geliefert. Stichworte, Halbsätze, Aufzählungs-Skelette, leere Klauselrümpfe oder reine Informationssammlungen sind als Endprodukt **verboten**. Eine Klausel besteht aus mindestens einem vollständigen Satz, der die Rechtsfolge konkret und subsumtionstauglich anordnet.
- **Crisp und prägnant.** „Vollständig" heißt nicht „aufgebläht". Jeder Satz trägt; rhetorische Füllstücke sind zu vermeiden. Klarheit, juristische Präzision und Lesbarkeit für die interne Rechtsabteilung, die Vermieterin, Mieter und Gericht haben absoluten Vorrang vor Wortzahl.
- **Keine Skelett-Verträge.** Ein Endvertrag ohne Präambel, ohne Definitionen, ohne ausformulierte Hauptpflichten, ohne Leistungsstörungsrecht, ohne Schlussbestimmungen ist kein Endprodukt, sondern eine Gliederung. Solche Skelette gehören in den Skill als Zwischenergebnis, nicht in die Ausgabe an die Nutzerin.
- **Platzhalter sauber markieren.** Wo Falldaten fehlen, werden klar lesbare Platzhalter gesetzt (`[Name der Vermieterin]`, `[Betrag in EUR]`, `[Datum TT.MM.JJJJ]`) — nicht aber Sinnsätze weggelassen. Der umgebende Text bleibt vollständig. Eine solche Fassung ist ausschließlich ein interner Arbeitsentwurf; offene Platzhalter sperren Freigabe, Versand und Einreichung.
- **Frage-Antwort-Phase ist Vorbereitung, nicht Endprodukt.** Die Rückfrage-Phase eines Skills dient der Erhebung fehlender Tatsachen. Sobald genug Tatsachen vorliegen, wird das Endprodukt in **ganzer Sprache** geliefert — nicht in Stichworten, die die Rechtsabteilung selbst zu Sätzen ausbauen müsste.
- **Strenge Regelung bei neuen Plugins und Skills.** Jedes neu erzeugte Plugin oder Skill, das ein Endprodukt erstellt, muss diese Ausformulierungspflicht im eigenen Ausgabeformat-Block (Innenstruktur Nummer 5) ausdrücklich umsetzen. Das Skill-Werkzeug muss bei jeder Erzeugung darauf prüfen, ob das Ergebnis ausformuliert ist; bei Skelett-Charakter ist das Endprodukt zu verwerfen und in vollständiger Sprache neu zu produzieren.
- **Englisch wenn gewünscht.** Bei zweisprachigen oder englischsprachigen Vorlagen gilt sinngemäß dasselbe: writing needs to be clear, crisp and complete. Keine half-sentences, keine bullet-point-only-Klauseln, keine information-dump-Ausgaben.
- **Diese Regelung ist von hoher Priorität.** Bei Konflikt mit einer abweichenden Stilkonvention in einer Altvorlage gilt diese Regel; die Altvorlage ist beim nächsten Anfassen anzupassen.

## Testakten-Regel: Arbeits-ZIP ohne Markdown (verbindlich)

Diese Regel gilt **dauerhaft für jede bestehende und jede künftige Testakte** und für jedes Werkzeug, das in diesem Repository Testakten erzeugt oder ändert (Claude, Codex, Perplexity, Cloud und alle weiteren).

- Die Markdown-Dateien unter `testakten/<akte>/` sind die redaktionelle Quelle (Validatoren, Gesamt-PDF, Einzel-PDFs, Diffs).
- Das Arbeits-ZIP einer Testakte — der lebensnahe Daten-Mix zum Vorführen von KI-Lesen, -Umbenennen und -Konvertieren — enthält **keine einzige Markdown-Datei** und ausschließlich DOCX, XLSX oder PDF. SAP-/FBL5N-/DMS-Listen erscheinen als XLSX, eigene Schreiben, Verträge, Schriftsätze und Vermerke als DOCX mit Briefkopf, E-Mails als lesbare PDF-Ausdrucke und Urteile, Beschlüsse, Bescheide, Abrechnungen sowie Belege als PDF. Andere Quellformate werden vor dem Paketbau in eines dieser drei Formate überführt.
- Jedes Testakten-ZIP ist flach. Es enthält keine Unterordner; der redaktionelle Bereich wird stattdessen als sprechendes Dateinamenspräfix übernommen. Das Arbeits-ZIP enthält das separat angebotene Gesamt-PDF nicht noch einmal.
- Die Format-Zuordnung steuert `scripts/testakte_realformate.py`. Neue Aktenstücke brauchen einen Dateinamen, der genau eine Regel trifft, oder die Regelliste ist zu ergänzen.
- Inhaltsgleichheit ist Pflicht: direktes Gesamt-PDF-Asset, Arbeits-ZIP und Einzel-PDF-ZIP entstehen aus derselben Markdown-Quelle; handgepflegte Parallelversionen sind verboten.
- `scripts/validate-testakten-release-zips.py` erzwingt die Regel vor jedem Release: Markdown im Arbeits-ZIP bricht den Build.

## README- und Release-Navigation

- Root-README, Plugin-README, Skill-Index, Testakten-Übersicht und Einzelakten-READMEs bilden eine durchgängige klickbare Navigation. Keine bloßen Dateipfade, wenn dieselbe Stelle als Markdown-Link erreichbar sein soll.
- Vor jedem Release laufen `scripts/validate-markdown-links.py` und `scripts/validate-readme-navigation.py`.
- Jeder Release liefert zusätzlich die Offline-Dokumentation `immobilien-forderungsmanagement-dokumentation.zip`, den vollständigen `release-katalog.md` und `checksums-sha256.txt`.

## Skill-Konvention

- Jeder Skill liegt unter `<plugin>/skills/<skill-name>/SKILL.md`.
- Frontmatter (YAML) enthält genau `name` und `description`. Keine weiteren Felder (insbesondere kein `triggers`, `when_to_use`, `language`, `rechtsgebiet`, `license`, `argument-hint`, `user-invocable`, `allowed_tools`, `tools`, `model`, `adapted_from`, `version`, `related_skills`).
- Skill-`description` höchstens 1024 Zeichen; `plugin.json`- und Marketplace-Plugin-`description` höchstens 300 Zeichen. In allen Description-Feldern: keine Zahl-Komma-Zahl-Sequenzen, keine spitzen Klammern, keine eingebetteten doppelten Anführungszeichen, keine Emojis oder Symbolzeichen und keine verbotenen Web-Auslese-Anglizismen.
- Skill-`name`, Plugin-Slug, Plugin-Verzeichnisname und `plugin.json`-`name` höchstens 64 Zeichen, nur `[a-z0-9-]`, identisch mit dem jeweiligen Ordnernamen.
- Innenstruktur:
  1. Zweck und Anwendungsfall
  2. Eingaben
  3. Ablauf / Checkliste
  4. Quellenpflicht (juristische Skills verweisen auf `references/zitierweise.md`; rein technische Skills auf ihre amtlichen Technikreferenzen und ausdrücklich nicht auf Rechtsprechung)
  5. Ausgabeformat — bei Skills, die Verträge, Vorlagen, Schriftsätze, Memos oder vergleichbare Endprodukte erzeugen, muss dieser Block ausdrücklich auf die **Ausformulierungspflicht** verweisen: Das Endprodukt wird in vollständigen, ausformulierten Sätzen geliefert; Skelette, Halbsätze und reine Aufzählungs-Auswurfe sind als Endprodukt verboten.
  6. Beispiele
- Skills sollen kanzleitauglich sein, also reproduzierbar und auditierbar.

## Bei Unsicherheit

- Frage nach (Skill, Mandat, Gegenstand, Frist).
- Nenne offene rechtliche Fragen explizit.
- Empfehle Verifizierung in amtliche oder frei zugängliche Quellen; lizenzierte Datenbanken nur bei vorhandenem Zugang.

## Git- und PR-Verhalten

- Pull Requests in diesem Repo werden **nicht als Draft** erstellt, sondern direkt als „ready" und nach Push **sofort auf `main` gemerged** — es sei denn, der Nutzer fordert ausdrücklich einen Draft oder eine Review-Pause.
- Merges erfolgen per Merge-Commit (kein Squash, kein Rebase), damit die Entwicklungs-History pro Branch erhalten bleibt.
- Force-Push auf `main` oder gemeinsame Branches ist verboten.
- **Codex-Review verbindlich anstoßen — nicht blockierend.** Der Workflow je PR ist exakt:
  1. PR erzeugen (`mcp__github__create_pull_request`). Standard ist `draft: false`. **`draft: true` nur dann**, wenn der Nutzer ausdrücklich einen Draft gefordert hat. Eine reine Review-Pause-Anweisung des Nutzers ändert den Draft-Status **nicht** — der PR bleibt `ready`.
  2. Direkt im Anschluss einen Kommentar mit dem Inhalt `@codex review` posten (`mcp__github__add_issue_comment`). Dieser Schritt erfolgt sofort bei jedem `ready`-PR (also auch bei Review-Pause-PRs). Bei einem echten Draft-PR wird der Kommentar erst gepostet, sobald der PR auf `ready` gesetzt wird.
  3. **Sofort** mergen (`mcp__github__merge_pull_request`, `merge_method: merge`) — **nicht** auf Codex' Antwort warten. **Ausnahme:** Bei einem vom Nutzer ausdrücklich gewünschten Draft **oder** einer Review-Pause wird hier nicht gemerged, sondern auf die Freigabe des Nutzers gewartet.

  Codex läuft im Hintergrund weiter und kommentiert später. Etwaige Findings werden — falls überhaupt nötig — in einem Folge-PR adressiert. Ziel ist eine durchgehende Audit-Spur ohne dass der Workflow blockiert wird. Diese Regel gilt für jeden PR unabhängig vom erzeugenden Werkzeug (Claude, Perplexity, Codex oder andere); die Draft- und Review-Pause-Ausnahmen aus dem ersten Punkt dieses Abschnitts bleiben unberührt.

## Konversationsstil – konzis starten, schnell zum Dokument

Ziel jedes Skills ist die **Produktion eines Dokuments oder Arbeitsergebnisses**, nicht ein langer Chat-Vortrag. Halte dich daran:

- **Erste Antwort: knapp.** Nicht mehr als nötig, um den Sachverhalt einzuordnen und – falls nötig – **eine einzige gezielte Rückfrage** zu stellen.
- **Keine vorgelagerten Theorie-Vorträge.** Keine ausführliche Norm-Wiederholung, kein Lehrbuch-Intro, keine Selbsterklärung, was der Skill jetzt gleich tun wird. Tu es direkt.
- **Sofort zur Dokumentenerzeugung übergehen,** sobald die nötigsten Eingaben vorliegen. Fehlen noch Daten, entsteht höchstens eine interne Arbeitsskizze mit klaren `[noch zu klären: ...]`-Marken. Sie darf nie als freigabe-, versand- oder einreichungsfertiges Außenstück bezeichnet werden.
- **Ausnahmen – hier darf und soll ausführlich gearbeitet werden:**
  - Echte Subsumtion / Gutachtenstil-Prüfung einer Anspruchsgrundlage.
  - Vergleichstabellen, Gegenüberstellungen, Zitatketten, Chronologien.
  - Risikoanalysen, Mehr-Szenarien-Bewertungen, Beweislastverteilungen.
  - Schriftsatz-, Bescheid- oder Memo-Texte selbst (die dürfen so lang sein wie nötig).
- **Allgemein-Skills sind Einstieg, nicht Vorlesung.** Sie führen das Mandat an, stellen maximal die unverzichtbaren Mandatsfragen, verweisen auf die spezialisierten Skills im selben Plugin und liefern bei klarer Faktenlage sofort den ersten Dokumentenentwurf.
- **Erklären, wenn der Nutzer es verlangt.** Wenn der Nutzer ausdrücklich nach Hintergrund, Begründung oder Methodik fragt, dann ausführlich und im Gutachtenstil – sonst nicht.

## Freigabegate für außenwirksame Dokumente

- Mahnung, Ratenvereinbarung, Kündigung, Mieterhöhungsverlangen, Klage, Replik, Vergleich, Kostenantrag und Vollstreckungsauftrag erhalten eine getrennte interne Freigabekarte nach `references/bedienfuehrung-workflows.md`.
- Standardstatus ist `ENTWURF - NICHT VERSENDEN/EINREICHEN`. Dieser Status steht in der internen Karte, nicht im außenwirksamen Dokument.
- Nur eine tatsächlich benannte fachliche Freigabeperson darf den Status auf `FREIGEGEBEN` setzen. Ein Modell darf die Freigabe nicht selbst erteilen oder unterstellen.
- Ändern sich Betrag, Antrag, Partei, Frist, Beweis, Anlage, Zustellweg oder Datenstichtag, erlischt eine frühere Freigabe und das Gate wird erneut geprüft.

## Gerichtsfertige Dokumentenproduktion

- Bei Aufträgen wie „fertig zur Einreichung", „beA-ready" oder „Schriftsatz mit Anlagen finalisieren" zuerst Skill `39-beweisangebot-anlagenplan`, danach Skill `23-klage-egvp-bea-einreichen` laden.
- Ist der juristische Inhalt bereits vollständig abgeschlossen und nur die technische Endfertigung beauftragt, stattdessen das eigenständige Plugin `schriftsatzwerkstatt-bea` mit `01-bea-ordner-annahme` starten. Es führt automatisch bis Paketfreigabe und späterer Eingangssicherung; eine manuelle Auswahl der neun Skills ist nicht nötig.
- Originaldateien bleiben unverändert. Hauptschriftsatz und jede Anlage entstehen als eigene geprüfte PDF-Arbeitskopie; keine ZIP-Datei im Gerichtsversand.
- Bereits eingereichte K-/B-Nummern bleiben gesperrt. Neue Anlagen setzen die höchste Nummer fort und tragen auf der ersten Seite rechts oben eine Kennzeichnung, ohne Originalinhalt zu verdecken.
- Dateinamen folgen dem strengeren Konzernstandard aus `references/erv-dokumentenproduktion.md`: höchstens 80 Zeichen, ASCII, sprechend, Wörter mit Unterstrich.
- Ein Modell versendet nicht aus beA. Bei einfacher Signatur müssen verantwortender Anwalt und tatsächlicher beA-Versender identisch sein; anderenfalls Signaturweg anwaltlich klären.
