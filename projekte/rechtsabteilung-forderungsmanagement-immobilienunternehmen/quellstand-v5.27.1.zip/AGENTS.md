# AGENTS.md – Repository-Regeln für alle Agenten

Dieses Repository enthält zwei Plugins für die Immobilien-Rechtsabteilung eines deutschen Immobilienkonzerns: das **nicht-anwaltliche Forderungsmanagement** und die fachlich neutrale **beA-Schriftsatzwerkstatt** für bereits inhaltlich fertige Unterlagen. Zielgruppe sind hochtrainierte Rechtsanwalts- und Notarfachangestellte, Renofas, Rechtsfachwirt:innen und Forderungsmanagement-Spezialist:innen ohne Anwaltszulassung. Diese Datei gilt für **jedes** Werkzeug, das hier arbeitet — Codex, Perplexity, Cloud, Claude und jedes weitere Modell. Der vollständige Leitfaden steht in [`CLAUDE.md`](./CLAUDE.md); halte dich an beide.

## Repo-Spezifika

- Keine RVG/Honorarvereinbarung in Korrespondenz — Renofas im Inhouse-Konzernrechtsdienst.
- Keine "Mandantin/Mandant"-Sprache — die Vermieterin ist die eigene Konzerngesellschaft.
- Eskalation an einen Anwalt, sobald die Sache das Amtsgericht verlässt oder Berufung/Revision ansteht (Skill `08-eskalation-an-anwalt`).
- Bedienmodus: klare Menüführung, kurze Entscheidungsfragen, Tabellen, Ampeln und nächste Schritte. Keine abgehobene Anwaltsprosa, aber volle juristische Korrektheit.
- Geprüfte Rechtsprechungsanker, Fünfjahres-Radar, Schriftsatzstandard und ERV-Dokumentenregeln stehen in `references/gepruefte-bgh-anker-mietrecht.md`, `references/rechtsprechungsradar-mietrecht-2021-2026.md`, `references/schriftsatz-und-argumentationsstandard.md` und `references/erv-dokumentenproduktion.md`; die Plugin-Kopien unter `forderungsmanagement-immobilien/references/` müssen synchron bleiben.
- Jede Testakte wird als direktes Gesamt-PDF, Arbeits-ZIP und Einzel-PDF-ZIP veröffentlicht. Sämtliche ZIPs sind flach und haben keine Unterordner. Arbeits-ZIPs enthalten weder Markdown noch eine Gesamt-PDF-Dublette, sondern ausschließlich DOCX, XLSX und PDF; Markdown bleibt nur redaktionelle Quelle. Verbindliche Regel in `CLAUDE.md` und `testakten/README.md`, technisch erzwungen durch `scripts/validate-testakten-release-zips.py`.
- README- und Markdown-Navigation muss lokal verlinkt bleiben. `scripts/validate-markdown-links.py` prüft vorhandene Repo-Links; `scripts/validate-readme-navigation.py` erzwingt zusätzlich Root-, Plugin-, Skill- und Testakten-Menüs sowie die zentralen Downloads. Beide laufen vor jedem Release.
- `scripts/validate-legal-anchors.py` sperrt bekannte Scheinzitate, veraltete Zuständigkeits- und RDG-Grundlagen, falsche Quellenstatus und Rechtsprechungsanker ohne Referenzzuordnung. Nach jeder Änderung an Normen, Urteilen, Skills oder juristischen Testakten muss dieser Validator laufen.
- Die neun fachlichen Testakten einschließlich `testakten/mieterklage-schimmel-schulz-verteidigung/` und die Mietspiegel-Referenzakte sind dauerhaftes Schulungs- und Release-Material; keine Akte ohne ausdrückliche Anweisung löschen oder aus den drei Downloadformen entfernen.
- Jeder Release enthält `immobilien-forderungsmanagement-dokumentation.zip`, `release-katalog.md` und `checksums-sha256.txt`. Der Katalog verlinkt jedes Asset; die Prüfsummendatei deckt jedes übrige Asset ab.
- Nach jedem Tag-Release muss der GitHub-Workflow grün sein, einschließlich `Release-Assets remote validieren`. Für manuelle Nachprüfung veröffentlichte Assets herunterladen und `validate-testakten-release-zips.py` sowie `validate-release-zips.py` gegen dieses Download-Verzeichnis ausführen.
- Außenwirksame Entwürfe brauchen eine getrennte Freigabekarte. Standardstatus ist `ENTWURF - NICHT VERSENDEN/EINREICHEN`; nur eine benannte fachliche Freigabeperson setzt `FREIGEGEBEN`. Bei geändertem Betrag, Antrag, Partei, Frist, Beweis, Anlage oder Zustellweg ist erneut zu prüfen.
- `schriftsatzwerkstatt-bea` bleibt fachlich neutral und bei höchstens zehn Skills. Sie verändert keine Quellen, prüft keine Rechtsfrage und versendet nicht selbst; inhaltlicher Änderungsbedarf ist ein Stoppbefund.

## Gliederung und Nummerierung (verbindlich für alle Vorlagen und Verträge)

Diese Regel gilt **dauerhaft und für jedes Werkzeug**. Sie ist nicht verhandelbar.

- **Ausschließlich dezimale Gliederung:** `1`, dann `1.1`, dann `1.1.1`, dann `1.1.1.1` und so weiter, beliebig tief.
- **Niemals** römische Ziffern (`I`, `II`), Großbuchstaben (`A`, `B`, `C`), Kleinbuchstaben (`a`, `b`) oder gemischte Verlags-Gliederungen (`A. I. 1. a) aa)`). Genau diese Schemata sind verboten, weil man sich darin nicht zurechtfindet.
- **Leerzeile zwischen Gliederungspunkt und seinem Inhalt sowie zwischen Gliederungsebenen.** Überschrift bzw. Nummer und der folgende Text/Unterpunkt werden durch eine Leerzeile getrennt, sonst ist es nicht lesbar.
- **Einrückung sparsam.** Nur leicht einrücken, gerade so viel, dass die Hierarchie sichtbar bleibt und es gut aussieht – nie so tief, dass das Dokument zerfleddert wirkt.

Gilt für alle Vorlagen, Verträge, Memos, Schriftsätze und sonstigen Dokumente in diesem Repository.
