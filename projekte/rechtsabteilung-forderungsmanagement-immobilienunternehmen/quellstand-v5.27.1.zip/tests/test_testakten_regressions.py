"""Regressionen aus Dokumentenreview und fehlerhaften Exporten."""

import contextlib
import importlib.util
import io
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))


def load_script(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


renderer = load_script("build-testakte-gesamt-pdf")
finance = load_script("validate-testakten-financial-consistency")
quality = load_script("validate-testakten-document-quality")


class DocumentRegressionTests(unittest.TestCase):
    def test_word_table_header_stays_with_first_row_and_repeats(self):
        from docx import Document
        from docx.oxml.ns import qn
        from testakte_realformate import nach_docx

        doc = Document(
            io.BytesIO(nach_docx("| Partei | Name |\n|---|---|\n| Mieter | Meier |"))
        )
        table = doc.tables[0]
        self.assertIsNotNone(table.rows[0]._tr.trPr.find(qn("w:tblHeader")))
        for cell in table.rows[0].cells:
            self.assertTrue(cell.paragraphs[0].paragraph_format.keep_with_next)
        for cell in table.rows[1].cells:
            self.assertFalse(cell.paragraphs[0].paragraph_format.keep_with_next)

    def test_contract_addenda_require_decimal_headings(self):
        valid = "# Mietvertrag\n\n## 1 Miete\n\nText.\n\n## 2 Nachtrag Nr. 1\n\n### 2.1 Mieterhöhung\n\nText."
        self.assertEqual(quality.contract_heading_errors(valid), [])
        for heading in (
            "## Nachtrag Nr. 1",
            "## Anlage 1",
            "## Mieterhöhung § 558 BGB",
            "# Nachtrag 1 zum Mietvertrag",
            "## II Nachtrag",
            "### 2 Mieterhöhung",
        ):
            with self.subTest(heading=heading):
                invalid = valid.replace("## 2 Nachtrag Nr. 1", heading)
                self.assertTrue(quality.contract_heading_errors(invalid))

    def test_contract_heading_needs_blank_line(self):
        self.assertTrue(
            quality.contract_heading_errors("# Mietvertrag\n\n## 1 Miete\nText.")
        )

    def test_unnumbered_addendum_fails_document_quality_check(self):
        slug = "mieterhoehung-becker-tempelhof"
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / slug
            shutil.copytree(ROOT / "testakten" / slug, target)
            source = target / "vertrag/mietvertrag.md"
            source.write_text(
                source.read_text().replace("## 12 Nachtrag", "## Nachtrag")
            )
            with (
                patch.object(quality, "ROOT", root),
                patch.object(quality, "TESTAKTEN", root),
            ):
                with contextlib.redirect_stderr(io.StringIO()) as errors:
                    with self.assertRaises(SystemExit):
                        quality.main()
                self.assertIn("dezimale Vertragsgliederung fehlt", errors.getvalue())

    def test_headings_do_not_orphan_at_page_bottom(self):
        from reportlab.platypus import SimpleDocTemplate, Spacer

        for prefix in ("#", "##", "###"):
            with self.subTest(prefix=prefix):
                buffer = io.BytesIO()
                doc = SimpleDocTemplate(
                    buffer, pagesize=(400, 260), topMargin=20, bottomMargin=20
                )
                doc.build(
                    [Spacer(1, 174)]
                    + renderer.md_to_flowables(
                        f"{prefix} Vertragsnummer 3.2\n\nDer folgende Vertragstext."
                    )
                )
                pages = [p.extract_text() for p in renderer.PdfReader(buffer).pages]
                page = next(p for p in pages if "Vertragsnummer" in p)
                self.assertIn("Der folgende Vertragstext.", page)

    def test_braun_does_not_require_paper_for_digital_inspection(self):
        case = ROOT / "testakten/nebenkosten-braun-nachzahlung-unbezahlt"
        for rel in (
            "aktennotiz/aktennotiz-01-nebenkostenwiderspruch-klagereife.md",
            "korrespondenz/klage-entwurf.md",
        ):
            text = (case / rel).read_text()
            self.assertIn("§ 556 Abs. 4", text)
            self.assertIn("elektronisch", text)
            self.assertNotIn("nur bei tragfähigem Grund oder Vereinbarung", text)

    def test_internal_note_keeps_its_date_and_subject_in_body(self):
        source = (
            ROOT
            / "testakten/nebenkosten-braun-nachzahlung-unbezahlt/aktennotiz/aktennotiz-01-nebenkostenwiderspruch-klagereife.md"
        )
        original = source.read_text()
        body, headers = renderer._extract_email_headers(original, source.stem)
        self.assertEqual(body, original)
        self.assertEqual(headers, [])
        self.assertEqual(
            renderer._document_kind(source.stem), "Interner Bearbeitungsvermerk"
        )

    def test_email_and_court_certificate_keep_their_types(self):
        self.assertEqual(
            renderer._document_kind("email-gerichtsvollzieher-termin"),
            "E-Mail-Ausdruck",
        )
        self.assertEqual(
            renderer._document_kind("rechtskraftvermerk-versaeumnisurteil"),
            "Gerichts- und Zustellungsdokument",
        )

    def test_hidden_bad_source_fails_quality_check(self):
        slug = "mietrueckstand-lange-zwei-raten-versehen"
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / slug
            shutil.copytree(ROOT / "testakten" / slug, target)
            source = target / "zahlung/zahlungsavis-teilrate-2026-07-20.md"
            source.write_text(
                source.read_text() + "\nDiese Akte eignet sich für Plugin-Tests.\n"
            )
            with (
                patch.object(quality, "ROOT", root),
                patch.object(quality, "TESTAKTEN", root),
            ):
                with contextlib.redirect_stderr(io.StringIO()) as errors:
                    with self.assertRaises(SystemExit):
                        quality.main()
                self.assertIn("zahlungsavis-teilrate", errors.getvalue())

    def test_matching_wrong_heating_totals_are_rejected(self):
        slug = "nebenkosten-braun-nachzahlung-unbezahlt"
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / slug
            shutil.copytree(ROOT / "testakten" / slug, target)
            # Zwei konsistente Endwerte kaschierten früher falsche Verteilungsquoten.
            for name in (
                "betriebskostenabrechnung-2025.md",
                "heizkosten-gesamtabrechnung-2025.md",
            ):
                source = target / "nebenkosten" / name
                text = source.read_text()
                for correct, wrong in (
                    ("249,04", "248,99"),
                    ("1712,50", "1712,47"),
                    ("1961,54", "1961,46"),
                    ("3924,28", "3924,20"),
                    ("761,54", "761,46"),
                    ("684,28", "684,20"),
                ):
                    text = text.replace(correct, wrong)
                source.write_text(text)
            with patch.object(finance, "TESTAKTEN", root):
                with contextlib.redirect_stderr(io.StringIO()) as errors:
                    with self.assertRaises(SystemExit):
                        finance.check_braun_operating_costs()
                self.assertIn("Wohnungsanteil Grundkosten", errors.getvalue())

    def test_renderer_reports_failed_build(self):
        with patch.object(sys, "argv", ["build", "mietspiegel-berlin"]):
            with patch.object(
                renderer, "build_gesamt_pdf", return_value=("error", "defekt")
            ):
                with contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaises(SystemExit) as error:
                        renderer.main()
                self.assertEqual(error.exception.code, 1)

    def test_unknown_case_is_not_a_successful_empty_build(self):
        with patch.object(sys, "argv", ["build", "versehentlicher-tippfehler"]):
            with self.assertRaisesRegex(SystemExit, "Unbekannte Testakten"):
                renderer.main()


if __name__ == "__main__":
    unittest.main()
