# SAP RE-FX / FI-CA Statusauszug

**System:** SAP S/4HANA RE-FX, Produktivmandant WBI-PRD
**Export:** 12.08.2026, 14:32 Uhr
**Export-ID:** REFX-FICA-20260812-RS61-EGL
**Sachbearbeitung:** Sandra Berger, Forderungsmanagement

## Vertragskopf

| Feld | Wert |
|---|---|
| Buchungskreis | WBI-DE-BER |
| Vertragsnummer | WBI-MV-2018-02704 |
| SAP-Vertragsobjekt | MV-081337-RI |
| Debitor | D-442018 |
| Objekt | 13347-B-RS61-EGL |
| Nutzungseinheit | Reinickendorfer Straße 61, EG links |
| Vermieterin | Wohnen Berlin Immobilien GmbH |
| Mieterin | Nora Riedel |
| Vertragsbeginn | 01.09.2018 |
| Status | Aktiv |

## Mietkonditionen laut Konditionsblatt

| Kondition | Betrag monatlich | Gültig ab | Quelle |
|---|---:|---|---|
| Nettokaltmiete | 610,00 EUR | 01.09.2018 | RE-FX Konditionssatz 100 |
| Betriebskostenvorauszahlung | 150,00 EUR | 01.09.2018 | RE-FX Konditionssatz 210 |
| Heizkostenvorauszahlung | 110,00 EUR | 01.09.2018 | RE-FX Konditionssatz 220 |
| **Bruttowarmmiete** | **870,00 EUR** | 01.09.2018 | Systemsumme |

## Ratenplan im System

| Feld | Wert |
|---|---|
| Ratenplan-ID | RP-2026-0442 |
| Ursprünglicher Rückstand | 2600,00 EUR |
| Vereinbarte Rate | 650,00 EUR monatlich |
| Raten 1 und 2 | Bezahlt |
| Raten 3 und 4 | Nicht bezahlt |
| Offener Ratenrest | 1300,00 EUR |
| Laufende Miete | August 2026 bezahlt |
| Mahnsperre | Bis 31.07.2026, inzwischen abgelaufen |

## Offene Posten

| OP-Nr. | Fälligkeit | Text | Soll | Ist | Offen | Status |
|---|---|---|---:|---:|---:|---|
| RP-0442-03 | 15.07.2026 | Rate 3 Ratenplan | 650,00 EUR | 0,00 EUR | 650,00 EUR | überfällig |
| RP-0442-04 | 15.08.2026 | Rate 4 Ratenplan | 650,00 EUR | 0,00 EUR | 650,00 EUR | überfällig |
| **Summe** | | | **1300,00 EUR** | **0,00 EUR** | **1300,00 EUR** | |

## Bearbeitungshinweis

Die laufende Miete ist wieder stabil, aber der ausdrücklich befristete Ratenplan wurde zweimal gebrochen. Vor Eskalation ist zu prüfen, ob die Ratenvereinbarung eine Fälligstellung des Restbetrags enthält und ob der ursprüngliche Rückstand aus kündigungsrelevanten Mietforderungen bestand. Akte auf rot setzen, Kulanzende dokumentieren und Entscheidungsvorlage für Klage oder Kündigungsprüfung erstellen.
