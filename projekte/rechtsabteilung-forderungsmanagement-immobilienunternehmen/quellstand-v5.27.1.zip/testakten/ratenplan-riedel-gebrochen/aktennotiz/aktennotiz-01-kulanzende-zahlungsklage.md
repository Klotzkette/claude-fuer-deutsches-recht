# Aktennotiz Nr. 1

Wohnen Berlin Immobilien GmbH
Abteilung Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Geschäftszeichen:    F-2026-00435
Mietverhältnis:      MV-081337-RI, Reinickendorfer Straße 61, 13347 Berlin, EG links
Mieterin:            Nora Riedel
Verfasserin:         Sandra Berger, Renofa, Tel. 030 2055 4810
Datum:               16.08.2026
Betreff:             Kulanzende nach Ratenbruch — Fälligstellung der Restforderung und Vorbereitung Zahlungsklage

## 1. Anlass

Der Ratenplan vom 02.05.2026 (vgl. korrespondenz/ratenvereinbarung.md) sah vier Raten zu je 650,00 EUR vor. Raten 1 und 2 wurden gezahlt. Rate 3 (Fälligkeit 15.07.2026) ist trotz Zahlungserinnerung vom 18.07.2026 (vgl. korrespondenz/zahlungserinnerung-rate.md) nicht eingegangen. Rate 4 (Fälligkeit 15.08.2026) fehlt ebenfalls. Die laufenden Mieten Juli und August 2026 sind bezahlt (vgl. konto/mietkonto-fbl5n.md).

## 2. Sachstand

### 2.1 Offene Forderung

Restforderung aus dem Ratenplan: 1.300,00 EUR (Rate 3 und Rate 4 à 650,00 EUR). Die laufende Miete ist nicht betroffen.

### 2.2 Vertragliche Grundlage

Die Ratenvereinbarung enthält eine ausdrückliche Klausel: Bei Ausfall einer Rate wird die Restforderung sofort fällig. Die Mieterin ist auf diese Bedingung hingewiesen worden.

### 2.3 Verhalten der Mieterin

Die Mieterin reagierte erst am 10.08.2026 mit einem neuen Drei-Raten-Vorschlag. Der Zwischenbescheid vom 12.08.2026 stellte ausdrücklich klar, dass hierin noch keine Annahme und keine neue Stundung liegt. Die bis 15.08.2026 angeforderten Nachweise und eine Zahlung des Bruders gingen nicht ein.

## 3. Rechtliche Bewertung

### 3.1 Fälligstellung

Nach Ziffer 1 des Abschnitts „Bedingungen“ der unterzeichneten Ratenvereinbarung wurde die bei Abschluss bereits bestehende Restforderung mit Ausfall der dritten Rate insgesamt fällig. Vor Verwendung der Klausel sind unterschriebene Fassung, ursprünglicher Forderungsgrund und die beiden Zahlungseingänge nochmals abzugleichen. Der gebrochene Ratenplan allein rechtfertigt keine schematische neue Kündigung. Eine Kündigung wäre nur anhand der ursprünglichen Mietrückstände, der seitdem eingegangenen Zahlungen und des aktuellen Mietkontos gesondert nach §§ 543, 569 und 573 BGB zu prüfen.

### 3.2 Zahlungsklage

Eine Zahlungsklage über 1.300,00 EUR kommt nach abschließendem Konten- und Vertragsabgleich in Betracht. Darzulegen und zu belegen sind der ursprüngliche Mietrückstand, Abschluss und Inhalt der Ratenvereinbarung, die Zahlung der ersten beiden Raten, Ausfall der dritten Rate, die Fälligstellungsklausel und der unveränderte Saldo. Wegen der kalendermäßig bestimmten Raten kann Verzug nach § 286 Abs. 2 Nr. 1 BGB ohne weitere Mahnung eintreten; Zinsen nach § 288 Abs. 1 BGB sind für Hauptforderungsteile und Zeiträume getrennt zu berechnen. Ob die Vereinbarung ein deklaratorisches Anerkenntnis enthält oder nur eine Zahlungsmodalität regelt, ist anhand ihres Wortlauts zu benennen und nicht zu unterstellen.

### 3.3 Vergleichsspielraum

Bei erster Kontaktaufnahme kann ein Vergleich über sofortige Zahlung von 1.300,00 EUR oder Ratenzahlung in zwei Raten à 650,00 EUR bis 01.09.2026 und 01.10.2026 erwogen werden. Eine weitere Kulanz ist nur nach belastbarem Zahlungsnachweis und fachlicher Freigabe zu gewähren.

## 4. Nächste Schritte

1. Unterzeichnete Vereinbarung, ursprüngliche Forderungsaufstellung, Avis der Raten 1 und 2 sowie Mietkonto mit Vier-Augen-Kontrolle abstimmen.
2. Letzte Zahlungsaufforderung mit Saldo 1.300,00 EUR und Frist 26.08.2026 absenden; neuen Ratenvorschlag ausdrücklich ablehnen oder gesondert entscheiden.
3. Nach Fristablauf Zahlungsklage mit monats- und ratenbezogener Forderungsaufstellung, Zinsblatt und Anlagenplan zur Freigabe vorlegen.
4. Kündigung nur nach neuer vollständiger Rückstandsmatrix prüfen; laufende Miete und Altrückstand nicht vermischen.

## 5. Eskalation / Vorlage

Für die Zahlungsklage ist wegen des Wohnraummietverhältnisses das Amtsgericht Wedding nach § 23 Nr. 2a GVG und § 29a ZPO zuständig. Vor Einreichung sind Vertretungsbefugnis, interne Freigabegrenze, Klageantrag, Zinslauf und vollständiger Anlagenbestand zu bestätigen. Bei Streit über Zustandekommen oder Reichweite der Ratenvereinbarung erfolgt Vorlage an die Rechtsabteilung.

(gez.) Sandra Berger
Renofa, Forderungsmanagement
