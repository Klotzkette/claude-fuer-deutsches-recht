# Aktennotiz 02 - Neuer Ratenwunsch

Wohnen Berlin Immobilien GmbH

Forderungsmanagement

Bearbeiterin: Sandra Berger

Datum: 11.08.2026

## 1. Eingang

Frau Riedel hat nach dem Rückruf einen neuen Drei-Raten-Vorschlag über insgesamt 1300,00 EUR übersandt. Die im ursprünglichen Plan offenen Raten werden damit zeitlich weiter nach hinten verschoben. Eine Zahlung des Bruders ist nicht eingegangen.

## 2. Kontostand

Die laufenden Mieten Juli und August 2026 sind laut Tagesabgleich vollständig gebucht. Die offene Restforderung aus dem ursprünglichen Ratenplan beträgt weiterhin 1300,00 EUR. Neue Mietrückstände bestehen am Stichtag nicht.

## 3. Entscheidungspunkte

| Punkt | Aktenstand |
|---|---|
| Bisheriger Plan | zwei von vier Raten gezahlt |
| Offene Restforderung | 1300,00 EUR |
| Neuer Vorschlag | 400,00 EUR, 450,00 EUR, 450,00 EUR |
| Laufende Miete | aktuell pünktlich |
| Früheste neue Rate | 31.08.2026 |
| Ansprechpartner | ausschließlich Nora Riedel |

## 4. Arbeitsstand

Bis zur Entscheidung der freigabeberechtigten Person wird weder eine weitere Stundung bestätigt noch auf den Klagepfad verzichtet. Eine Annahme müsste schriftlich erfolgen und den bisherigen Ratenplan, den unveränderten Forderungsstand, die laufende Miete und die Wiedervorlagen eindeutig regeln.

Wiedervorlage: 15.08.2026.

Sandra Berger
