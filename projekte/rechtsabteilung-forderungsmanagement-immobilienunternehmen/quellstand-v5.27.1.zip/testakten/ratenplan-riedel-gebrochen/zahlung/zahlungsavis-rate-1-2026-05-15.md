# Zahlungsavis Ratenplan Rate 1

## 1 Buchung

| Feld | Wert |
|---|---|
| Wertstellung | 15.05.2026 |
| Buchungstag | 15.05.2026 |
| Betrag | 650,00 EUR Haben |
| Auftraggeberin | Nora Riedel |
| Auftraggeberkonto | IBAN im Arbeitsauszug gekürzt |
| Verwendungszweck | RP 2026 0442 RATE 1 |
| Bankreferenz | EREF 150526-RI-77104 |
| SAP-Beleg | 85005115 |

## 2 Verarbeitung

Die Zahlung wurde am 15.05.2026 um 11:26 Uhr automatisch dem Ratenplan RP-2026-0442 zugeordnet. Eine manuelle Umbuchung war nicht erforderlich. Der verbleibende Ratenplan-Saldo betrug danach 1.950,00 EUR.

## 3 Kontrollabgleich

Die laufende Miete Mai 2026 über 870,00 EUR war bereits am 03.05.2026 mit dem Verwendungszweck `Miete Mai 2026` gebucht. Der zusätzliche Betrag von 650,00 EUR konnte deshalb nicht mit der laufenden Miete verwechselt werden. Betrag, Vertragspartei und eindeutige Ratenplanreferenz stimmen mit der Vereinbarung vom 02.05.2026 überein.

Der Zahlungseingang bestätigt nur Rate 1. Er enthält keine Vorauszahlung auf spätere Raten und keine Erklärung zu deren Fälligkeit. Die Wiedervorlagen für 16.06., 16.07. und 16.08.2026 bleiben bestehen.
