# Zahlungsavis Ratenplan Rate 2

## 1 Buchung

| Feld | Wert |
|---|---|
| Wertstellung | 15.06.2026 |
| Betrag | 650,00 EUR Haben |
| Auftraggeberin | Nora Riedel |
| Verwendungszweck | Miete Juni extra Rate |
| Bankreferenz | EREF 150626-RI-99172 |
| SAP-Beleg | 85006115 |

## 2 Klärung

Die laufende Juni-Miete von 870,00 EUR war bereits am 03.06.2026 mit eindeutiger Monatsangabe eingegangen. Der zusätzliche Betrag von 650,00 EUR wurde deshalb nach telefonischer Bestätigung vom 16.06.2026 als zweite Rate des Plans RP-2026-0442 verbucht.

Die Telefonbestätigung ist im DMS nur als Kurznotiz „650 = Rate 2, SB“ hinterlegt. Eine gesonderte E-Mail der Mieterin liegt nicht vor.
