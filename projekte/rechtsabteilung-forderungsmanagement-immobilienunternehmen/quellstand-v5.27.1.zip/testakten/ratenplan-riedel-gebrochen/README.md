# Testakte 7 — Gebrochener Ratenplan Riedel Wedding


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 58 KB) | PDF | [testakte-ratenplan-riedel-gebrochen-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-ratenplan-riedel-gebrochen-gesamt.pdf) | [`gesamt-pdf/ratenplan-riedel-gebrochen_gesamt.pdf`](gesamt-pdf/ratenplan-riedel-gebrochen_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-ratenplan-riedel-gebrochen.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-ratenplan-riedel-gebrochen.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-ratenplan-riedel-gebrochen-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-ratenplan-riedel-gebrochen-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Gebrochener Kulanz-Ratenplan, laufende Miete stabil, Kulanzende und Restforderung |
| Startskills | `10-zahlungsplan-stundungsvereinbarung`, `11-verzugsschaden-berechnen`, `12-vorgerichtliche-letzte-frist`, danach `20-zahlungsklage-mietrueckstand-erstellen` |
| Kernentscheidung | Wird der alte Rückstand aus dem Ratenplan eingeklagt oder ist noch eine letzte kontrollierte Frist sinnvoll? |
| Besonderheit | Der neue Drei-Raten-Vorschlag ist nur ein Angebot. Ohne dokumentierte Annahme, Fälligkeiten und Wiedervorlage ändert er weder Altplan noch Saldo; unklare Zahlungen bleiben gesondert zuzuordnen. |

Ein früherer Mietrückstand wurde durch Kulanz-Ratenplan abgefangen. Die laufende Miete wird wieder gezahlt, aber zwei Raten aus der Vereinbarung bleiben offen. Die Akte prüft, wann Kulanz endet und ob Klage auf Restforderung statt neue Kündigung im Vordergrund steht.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Bearbeiterin | Rechtsfachwirtin Sandra Berger |
| Mieterin | Nora Riedel, geb. 03.01.1984 |
| Mietobjekt | Reinickendorfer Straße 61, 13347 Berlin, EG links |
| Wohnfläche | 49,30 qm |
| Vertragsbeginn | 01.09.2018 |
| Bruttowarmmiete | 870,00 EUR |
| Restforderung aus Ratenplan | 1300,00 EUR |
| Aktenzeichen intern | F-2026-00435 |

## Sachverhalt

Im April 2026 bestand ein Rückstand von 2600,00 EUR. Die Abteilung genehmigte einen Ratenplan über vier Raten zu je 650,00 EUR. Zwei Raten wurden gezahlt, zwei Raten nicht. Die laufenden Mieten Juli und August 2026 sind bezahlt.

## Trainingsziel

Diese Akte testet Kulanzsteuerung, Überwachung von Ratenplänen, Verwirkung weiterer Stundung, Zahlungsklage auf Restforderung und klare Kommunikation ohne sofortige Überreaktion.

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Mietvertrag | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Mietkonto FBL5N | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Ratenvereinbarung | [korrespondenz/ratenvereinbarung.md](korrespondenz/ratenvereinbarung.md) |
| Zahlungserinnerung Rate | [korrespondenz/zahlungserinnerung-rate.md](korrespondenz/zahlungserinnerung-rate.md) |
| E-Mail Rate mit unklarem Verwendungszweck | [korrespondenz/mieter-antwort-rate-verwendungszweck.md](korrespondenz/mieter-antwort-rate-verwendungszweck.md) |
| Aktennotiz zu Kulanzende und Zahlungsklage | [aktennotiz/aktennotiz-01-kulanzende-zahlungsklage.md](aktennotiz/aktennotiz-01-kulanzende-zahlungsklage.md) |
| Interner Vermerk Kulanzende | [korrespondenz/vermerk-kulanzende.md](korrespondenz/vermerk-kulanzende.md) |
| DocuWeb-Exportliste mit unklarer Drittnachricht | [dms/dms-exportliste-ratenplan.md](dms/dms-exportliste-ratenplan.md) |
| Zahlungsavis Rate 1 | [zahlung/zahlungsavis-rate-1-2026-05-15.md](zahlung/zahlungsavis-rate-1-2026-05-15.md) |
| Zahlungsavis Rate 2 mit Klärungsvermerk | [zahlung/zahlungsavis-rate-2-2026-06-15.md](zahlung/zahlungsavis-rate-2-2026-06-15.md) |
| Ratenmonitoring mit getrennter laufender Miete | [konto/ratenmonitoring-kulanz.md](konto/ratenmonitoring-kulanz.md) |
| E-Mail der Mieterin zur Nachricht ihres Bruders | [korrespondenz/email-mieterin-schichtplan.md](korrespondenz/email-mieterin-schichtplan.md) |
| Telefonnotiz zum Rückruf und neuen Zahlungswunsch | [hausverwaltung/telefonnotiz-rueckruf.md](hausverwaltung/telefonnotiz-rueckruf.md) |
| E-Mail mit neuem Drei-Raten-Vorschlag | [korrespondenz/email-mieterin-neuer-ratenvorschlag.md](korrespondenz/email-mieterin-neuer-ratenvorschlag.md) |
| Zwischenbescheid ohne Annahme des neuen Ratenvorschlags | [korrespondenz/zwischenbescheid-neuer-ratenwunsch-2026-08-12.md](korrespondenz/zwischenbescheid-neuer-ratenwunsch-2026-08-12.md) |
| Aktennotiz zur offenen Kulanzentscheidung | [aktennotiz/aktennotiz-02-neuer-ratenwunsch.md](aktennotiz/aktennotiz-02-neuer-ratenwunsch.md) |
| Mieterin erläutert Finanzierung und bestätigt offene Annahme | [korrespondenz/email-mieterin-finanzierung-rate-2026-08-14.md](korrespondenz/email-mieterin-finanzierung-rate-2026-08-14.md) |

## Aufgabe für die Skills

Die [Antwort vom 14.08.2026](korrespondenz/email-mieterin-finanzierung-rate-2026-08-14.md) erklärt die geplante Finanzierung, belegt aber weder eine neue Zahlung noch eine angenommene Stundung. Die vorgeschlagenen Termine lauten 31.08., 20.09. und 20.10.2026. Bereits beantwortete Fragen zum Bruder und zur laufenden Miete nicht erneut stellen; die Kulanzentscheidung bleibt gesondert erforderlich.

1. Laufende Mietzahlungen von der offenen Restforderung aus dem Kulanzplan trennen.
2. Ratenvereinbarung, Zahlungseingänge und gebrochene Raten in eine Kontrolltabelle bringen.
3. Kulanzende, letzte Zahlungsfrist und Klagepfad ohne neue unnötige Kündigung vorschlagen.
4. Wiedervorlage, Vergleichsspielraum und Eskalationspunkte für die fachliche Freigabe festhalten.
