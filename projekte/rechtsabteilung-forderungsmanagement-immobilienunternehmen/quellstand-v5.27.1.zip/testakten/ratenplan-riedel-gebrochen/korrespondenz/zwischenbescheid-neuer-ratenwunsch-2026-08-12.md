# Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

Frau Nora Riedel

Reinickendorfer Straße 61

13347 Berlin

Berlin, 12.08.2026

**Vertragsnummer:** WBI-MV-2018-02704

**Ratenplan:** RP-2026-0442

**Ihr neuer Zahlungsvorschlag vom 10.08.2026**

Sehr geehrte Frau Riedel,

wir bestätigen den Eingang Ihrer E-Mail vom 10.08.2026. Sie schlagen vor, den offenen Betrag von 1300,00 EUR in drei neuen Teilbeträgen von 400,00 EUR, 450,00 EUR und 450,00 EUR am 31.08., 20.09. und 20.10.2026 zu zahlen.

Der Vorschlag ist noch nicht angenommen. Der bestehende Ratenplan vom 02.05.2026 sah vier Raten zu je 650,00 EUR vor. Die ersten beiden Raten sind eingegangen. Die am 15.07.2026 fällige dritte Rate fehlt; die vierte Rate wird am 15.08.2026 fällig. Nach dem Wortlaut der Vereinbarung ist die offene Restforderung seit dem Ausfall der dritten Rate fällig.

Für die interne Entscheidung benötigen wir bis zum **15.08.2026** folgende Unterlagen:

Ihre Mitteilung, dass Ihr Bruder keine Zahlung ausgelöst hat, und Ihre Zusage zur laufenden Miete haben wir aufgenommen. Bitte erläutern Sie noch kurz, aus welchem erwarteten Zahlungseingang Sie die erste Rate am 31.08.2026 finanzieren wollen. Soweit Sie einen Nachweis beifügen, können Sie nicht benötigte Kontodaten und andere Umsätze schwärzen.

Bitte geben Sie bei Zahlungen Ihre Vertragsnummer und den Zusatz `Rate RP-2026-0442` an. Eine Zahlung Ihres Bruders kann auch ohne Vertretungsvollmacht zugeordnet werden, sofern Zahlungseingang und Zweck feststehen. Vertragsänderungen stimmen wir mit Ihnen ab; Ihren Bruder führen wir entsprechend Ihrer Bitte nicht als Ansprechpartner.

Bis zu einer ausdrücklichen schriftlichen Annahme besteht keine neue Ratenvereinbarung und keine weitere Stundung. Schweigen, die Entgegennahme einer Teilzahlung oder eine technische Buchung im Mietkonto sind keine Bestätigung der von Ihnen vorgeschlagenen Termine. Die laufende Miete bleibt zum vertraglichen Termin fällig.

Nach Eingang der Unterlagen entscheiden wir kurzfristig, ob eine letzte Kulanzvereinbarung wirtschaftlich vertretbar ist. Gehen die Unterlagen oder die fällige Zahlung nicht fristgerecht ein, wird die offene Restforderung ohne weitere Ratenzusage weiterverfolgt.

Mit freundlichen Grüßen

Wohnen Berlin Immobilien GmbH
Sandra Berger
Forderungsmanagement
