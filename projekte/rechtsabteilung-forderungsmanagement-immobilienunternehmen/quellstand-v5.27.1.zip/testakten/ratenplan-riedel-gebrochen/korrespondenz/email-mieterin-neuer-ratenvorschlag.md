# E-Mail-Ausdruck

Von: nora.riedel@example.org

An: forderungsmanagement@wohnen-berlin.example

Datum: 10.08.2026, 18:42 Uhr

Betreff: Neuer Vorschlag für die beiden offenen Raten

Sehr geehrte Frau Berger,

wie heute am Telefon besprochen, schlage ich für die noch offenen 1300,00 EUR folgende Zahlung vor:

- 400,00 EUR am 31.08.2026,
- 450,00 EUR am 20.09.2026,
- 450,00 EUR am 20.10.2026.

Die laufende Miete wird weiterhin zum Monatsanfang überwiesen. Mein Bruder hat die von ihm angekündigte Zahlung nach meinem derzeitigen Kenntnisstand doch nicht ausgelöst. Bitte führen Sie ihn nicht als Ansprechpartner; ich kümmere mich selbst um die Sache.

Ich arbeite im Schichtdienst und bin telefonisch am besten zwischen 15 und 17 Uhr erreichbar. Eine erste Rate könnte ich nicht vor Ende August zahlen. Bitte teilen Sie mir schriftlich mit, ob der Vorschlag angenommen wird.

Mit freundlichen Grüßen

Nora Riedel
