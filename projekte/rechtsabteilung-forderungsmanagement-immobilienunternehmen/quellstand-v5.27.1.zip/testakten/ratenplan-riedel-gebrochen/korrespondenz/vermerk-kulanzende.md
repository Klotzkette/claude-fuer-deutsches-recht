# Interner Vermerk Kulanzende

**Akte:** WBI-MV-2018-02704 Riedel / Reinickendorfer Straße 61
**Bearbeitung:** Sandra Berger, Rechtsfachwirtin
**Stand:** 16.08.2026

## 1. Sachstand

Die Ratenzahlungsvereinbarung vom 02.05.2026 wurde zunächst erfüllt. Rate 1 und Rate 2 gingen pünktlich ein. Rate 3 und Rate 4 sind offen. Die laufende Miete August 2026 ist gezahlt.

| Position | Fälligkeit | Betrag | Status |
|---|---|---:|---|
| Rate 3 | 15.07.2026 | 650,00 EUR | offen |
| Rate 4 | 15.08.2026 | 650,00 EUR | offen |
| **Summe Raten offen** | | **1300,00 EUR** | |
| laufende Miete August | 04.08.2026 | 870,00 EUR | bezahlt |

Die Mieterin hat auf die Zahlungserinnerung vom 18.07.2026 nicht reagiert.

## 2. Bewertung

Die ursprüngliche Kulanz war vertretbar, weil die laufende Miete wieder stabil gezahlt wurde und der Rückstand kontrolliert abgebaut werden sollte. Nach zwei ausgefallenen Raten ist die Vereinbarung gescheitert. Der Restbetrag ist nach Ziffer 1 der Vereinbarung sofort fällig.

Eine erneute Stundung sollte nur nach belastbarem Zahlungsnachweis und Freigabe der Teamleitung angeboten werden.

## 3. Nächster Schritt

1. Letzte Frist zur Zahlung der **1300,00 EUR** bis 26.08.2026.
2. Bei Nichtzahlung Zahlungsklage auf Restforderung vorbereiten.
3. Kündigung nur erneut prüfen, wenn laufende Miete wieder ausfällt oder der Gesamtrückstand erneut kündigungsrelevant wird.
4. Wiedervorlage 27.08.2026 mit Kontoauszug.
