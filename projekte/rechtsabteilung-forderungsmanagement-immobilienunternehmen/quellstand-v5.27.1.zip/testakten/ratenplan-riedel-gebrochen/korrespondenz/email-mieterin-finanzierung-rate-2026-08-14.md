# E-Mail-Ausdruck

Von: nora.riedel@example.org

An: forderungsmanagement@wohnen-berlin.example

Datum: 14.08.2026, 16:27 Uhr

Betreff: Ihr Brief vom 12.08. / erste Rate Ende August

Sehr geehrte Frau Berger,

die 400,00 EUR für den 31. August möchte ich aus meinem Augustlohn bezahlen. Mein Arbeitgeber zahlt üblicherweise am letzten Bankarbeitstag. Ich habe keine Sonderzahlung zugesagt bekommen und kann deshalb heute noch keinen Zahlungsbeleg schicken. Die beiden weiteren Beträge von je 450,00 EUR habe ich für den 20. September und den 20. Oktober vorgeschlagen, weil dann die zusätzlichen Schichtstunden abgerechnet sein sollen.

Mir ist klar, dass Sie meinen Vorschlag noch prüfen. Eine neue Vereinbarung habe ich bislang nicht erhalten. Bitte teilen Sie mir mit, ob ich die erste Überweisung schon unter der bisherigen Ratenplannummer ausführen soll. Ich möchte nicht, dass sie wieder auf dem falschen Posten landet.

Die Augustmiete von 870,00 EUR wurde am 05.08.2026 überwiesen. Mein Bruder hat nichts gezahlt und wird auch keine Verhandlungen für mich führen. Über die laufende Miete möchte ich keinen neuen Plan abschließen; mein Dauerauftrag bleibt bestehen. Für die beiden alten offenen Raten kann ich vor Ende August keine weitere Zahlung anbieten.

Mit freundlichen Grüßen

Nora Riedel
