# E-Mail-Ausdruck Nora Riedel

## 1 Kopfzeilen

| Feld | Inhalt |
|---|---|
| Von | Nora Riedel, nora.riedel84@example.net |
| An | forderungsmanagement@wohnen-berlin-immobilien.de |
| Datum | 08.08.2026, 09:21 Uhr |
| Betreff | Ratenplan / Nachricht von meinem Bruder |

## 2 Nachricht

Guten Morgen,

mein Bruder Thomas hat Ihnen heute früh geschrieben, weil ich Nachtschicht hatte. Er wohnt nicht bei mir und ist nicht mein Vertragspartner. Er wollte mir nur helfen. Bitte besprechen Sie die Sache weiterhin mit mir.

Die laufende Augustmiete ist bezahlt. Die beiden alten Raten habe ich wegen einer unerwarteten Pfändung auf meinem Lohnkonto nicht geschafft. Ich kann 650 Euro zum Monatsende zahlen und die letzte Rate im September. Einen Beleg zur Pfändung möchte ich nicht per unverschlüsselter E-Mail schicken.

Bitte teilen Sie mir mit, ob Sie damit einverstanden sind. Falls mein Bruder bereits etwas überwiesen hat, muss ich das erst mit ihm klären.

Mit freundlichen Grüßen

Nora Riedel

## 3 Anlagen

Keine Anlagen. Die E-Mail enthält keine konkrete Tilgungsbestimmung für einen bereits eingegangenen Betrag.
