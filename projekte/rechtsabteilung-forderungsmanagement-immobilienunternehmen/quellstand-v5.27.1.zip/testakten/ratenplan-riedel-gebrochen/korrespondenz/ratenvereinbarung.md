# Ratenzahlungsvereinbarung

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99
10117 Berlin
Abteilung Forderungsmanagement
Bearbeitung: Sandra Berger, Rechtsfachwirtin

Frau
Nora Riedel
Reinickendorfer Straße 61
13347 Berlin

Berlin, 02.05.2026

**Mietverhältnis Reinickendorfer Straße 61, 13347 Berlin, EG links**
**Vertragsnummer WBI-MV-2018-02704**
**Ratenzahlungsvereinbarung über Mietrückstand 2600,00 EUR**

Sehr geehrte Frau Riedel,

wir bestätigen die ausnahmsweise Ratenzahlung für den Mietrückstand in Höhe von **2600,00 EUR**. Die laufende Miete bleibt unabhängig davon jeweils pünktlich und vollständig fällig.

## Ratenplan

| Rate | Fälligkeit | Betrag | Zweck |
|---|---|---:|---|
| 1 | 15.05.2026 | 650,00 EUR | Rückstand Januar 2026 |
| 2 | 15.06.2026 | 650,00 EUR | Rückstand Februar 2026 |
| 3 | 15.07.2026 | 650,00 EUR | Rückstand März 2026 |
| 4 | 15.08.2026 | 650,00 EUR | Rückstand April 2026 |

## Bedingungen

1. Gerät eine Rate ganz oder teilweise in Rückstand, wird der gesamte Restbetrag sofort fällig.
2. Die Vereinbarung begründet keinen Anspruch auf weitere Stundung.
3. Zahlungen werden zunächst auf die fälligen Raten verrechnet, soweit Sie keine wirksame andere Tilgungsbestimmung treffen.
4. Bei erneutem Ausfall der laufenden Miete prüfen wir Kündigung und Zahlungsklage.

Bitte bestätigen Sie die Vereinbarung durch Rücksendung einer unterschriebenen Kopie bis zum **09.05.2026**.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH

## Annahme durch die Mieterin

Ich nehme die Ratenzahlungsvereinbarung an.

Berlin, den 05.05.2026

| Mieterin |
|---|
| Nora Riedel |
