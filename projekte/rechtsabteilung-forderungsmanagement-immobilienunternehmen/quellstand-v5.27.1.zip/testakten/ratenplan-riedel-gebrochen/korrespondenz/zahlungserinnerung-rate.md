# Zahlungserinnerung Rate 3

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99
10117 Berlin
Abteilung Forderungsmanagement
Bearbeitung: Sandra Berger, Rechtsfachwirtin

Frau
Nora Riedel
Reinickendorfer Straße 61
13347 Berlin

Berlin, 18.07.2026

**Ratenzahlungsvereinbarung vom 02.05.2026**
**Rate 3 über 650,00 EUR offen**

Sehr geehrte Frau Riedel,

die dritte Rate aus der Vereinbarung vom 02.05.2026 war am **15.07.2026** fällig und ist nicht eingegangen.

| Fälligkeit | Betrag | Status |
|---|---:|---|
| 15.05.2026 | 650,00 EUR | bezahlt |
| 15.06.2026 | 650,00 EUR | bezahlt |
| 15.07.2026 | 650,00 EUR | offen |
| 15.08.2026 | 650,00 EUR | noch nicht fällig |

Bitte zahlen Sie Rate 3 bis spätestens **25.07.2026**. Andernfalls wird nach Ziffer 1 der Ratenzahlungsvereinbarung der gesamte Restbetrag fällig.

Die laufende Miete Juli 2026 ist nach unserem Konto eingegangen. Bitte vermeiden Sie, dass aus einem kontrollierbaren Ratenrückstand erneut ein kündigungsrelevanter Mietrückstand wird.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH
