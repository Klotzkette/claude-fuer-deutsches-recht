# DocuWeb Exportliste Ratenplan Riedel

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportzeitpunkt | 18.08.2026, 09:04 Uhr |
| Akte | F-2026-00435 |
| Vertragsnummer | WBI-MV-2018-02704 |
| Ratenplan | RP-2026-0442 |
| Treffer | 16 |

## 2 Dokumente

| DMS-ID | Datum | Klasse | Indexname | Version | Hinweis |
|---|---|---|---|---:|---|
| DW-620041 | 24.08.2018 | Vertrag | Mietvertrag_Riedel.pdf | 1 | vollständig |
| DW-895001 | 30.04.2026 | Konto | AltRückstand_2600.xlsx | 1 | vier Monate |
| DW-895220 | 02.05.2026 | Vereinbarung | Ratenplan_Riedel.pdf | 2 | unterschrieben |
| DW-896004 | 15.05.2026 | Zahlung | Avis_Rate_1.pdf | 1 | 650,00 EUR |
| DW-898117 | 15.06.2026 | Zahlung | Avis_Rate_2.pdf | 1 | 650,00 EUR |
| DW-901700 | 16.07.2026 | Ausgang | Erinnerung_Rate_3.pdf | 1 | per Brief |
| DW-902001 | 25.07.2026 | Notiz | Rückruf_Riedel.docx | 1 | nicht erreicht |
| DW-904410 | 05.08.2026 | Zahlung | Augustmiete_870.pdf | 1 | laufende Miete |
| DW-904788 | 08.08.2026 | Eingang | Mail_Thomas_Riedel.pdf | 1 | Person nicht im Vertrag |
| DW-904789 | 08.08.2026 | Eingang | Mail_Nora_Riedel.pdf | 1 | Schichtplan erwähnt |
| DW-904900 | 10.08.2026 | Eingang | Mail_Nora_Riedel_neuer_Ratenvorschlag.pdf | 1 | noch nicht angenommenes Angebot |
| DW-904980 | 11.08.2026 | Notiz | Aktennotiz_neuer_Ratenwunsch.docx | 1 | Freigabeentscheidung offen |
| DW-905001 | 12.08.2026 | Ausgang | Zwischenbescheid_neuer_Ratenwunsch.pdf | 1 | keine Annahme; Nachweise bis 15.08.2026 |
| DW-905113 | 12.08.2026 | Konto | Mietkonto_Riedel.xlsx | 3 | Rate 3 weiter offen |
| DW-905440 | 15.08.2026 | Ratenplan | Rate_4_faellig.xlsx | 1 | kein Eingang |
| DW-905771 | 17.08.2026 | Notiz | Kulanzende_Riedel.docx | 2 | Rest 1.300,00 EUR |

## 3 Zuordnungsproblem

Thomas Riedel ist weder Vertragspartei noch als Bevollmächtigter hinterlegt. Seine E-Mail vom 08.08.2026 kündigt eine Zahlung an; bis zum Export am 18.08.2026 ist kein passender Zahlungseingang sichtbar. Die Augustmiete von Nora Riedel ist getrennt und vollständig verbucht.

Der neue Drei-Raten-Vorschlag vom 10.08.2026 ist ein Angebot der Mieterin.
Ohne dokumentierte Annahme, neue Fälligkeitsregel und Wiedervorlage ändert er
den bestehenden Ratenplan oder den offenen Saldo nicht.
