# Telefonnotiz Rückruf Nora Riedel

## 1 Gesprächsdaten

| Feld | Inhalt |
|---|---|
| Datum | 10.08.2026, 16:05 bis 16:14 Uhr |
| Gesprächspartnerin | Nora Riedel |
| Bearbeitung | Sandra Berger |
| Akte | F-2026-00435 |

## 2 Gespräch

Frau Riedel bestätigt, dass Thomas Riedel ihr Bruder ist und nicht in der Wohnung lebt. Er habe am 08.08.2026 möglicherweise eine Überweisung von seinem Konto vorbereitet. Sie könne nicht sagen, ob er sie freigegeben habe. Eine Vollmacht für Gespräche oder Erklärungen habe sie ihm nicht erteilt.

Frau Riedel bittet um eine weitere Verschiebung der dritten Rate auf den 31.08.2026. Die vierte Rate wolle sie am 20.09.2026 zahlen. Die laufende Miete solle unverändert durch Dauerauftrag eingehen. Eine sofortige schriftliche Zusage der Vermieterin wurde nicht erteilt.

## 3 Nachlauf

Frau Riedel wurde darauf hingewiesen, dass zunächst der Zahlungseingang und die bisherige Vereinbarung geprüft werden. Rückmeldung der Abteilung wurde bis 19.08.2026 zugesagt. Der Bruder wird ohne Vollmacht nicht als Ansprechpartner geführt.
