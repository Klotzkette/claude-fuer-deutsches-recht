# Wohnraummietvertrag

**Vertragsnummer:** WBI-MV-2018-02704
**Objekt:** Reinickendorfer Straße 61, 13347 Berlin, EG links
**Ablage:** SAP RE-FX / DMS Vertragsakte

**Parteien**

**Vermieterin**
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin

**Mieterin**
Frau Nora Riedel, geboren am 03.01.1984
Reinickendorfer Straße 61
13347 Berlin

## 1 Mietsache

### 1.1

Vermietet wird die Wohnung Reinickendorfer Straße 61, 13347 Berlin, EG links, bestehend aus zwei Zimmern, Küche, Bad, Flur, Terrasse und Kellerraum Nr. 61-EG-L.

### 1.2

Die Wohnfläche beträgt **49,30 qm**.

## 2 Mietzeit

Das Mietverhältnis beginnt am **01.09.2018** und läuft auf unbestimmte Zeit.

## 3 Miete und Zahlung

| Position | Betrag |
|---|---:|
| Nettokaltmiete | 610,00 EUR |
| Betriebskostenvorauszahlung | 150,00 EUR |
| Heizkostenvorauszahlung | 110,00 EUR |
| **Bruttowarmmiete** | **870,00 EUR** |

### 3.1

Die Miete ist monatlich im Voraus spätestens am dritten Werktag des Monats zu zahlen.

### 3.2

Bankverbindung:

| Empfängerin | IBAN | BIC | Institut |
|---|---|---|---|
| Wohnen Berlin Immobilien GmbH | DE47 1009 0000 0123 4567 89 | BEVODEBB | Berliner Volksbank |

## 4 Betriebskosten

Die Mieterin trägt die umlagefähigen Betriebskosten gemäß § 2 BetrKV sowie Heizkosten nach der Heizkostenverordnung. Über die Vorauszahlungen wird jährlich abgerechnet.

## 5 Mietsicherheit

Die Kaution beträgt **1830,00 EUR** und entspricht drei Nettokaltmieten. Eine Geldsicherheit kann in drei gleichen monatlichen Raten erbracht werden; die erste Rate ist zu Mietbeginn, die weiteren Raten sind mit den beiden folgenden Mietzahlungen fällig. Die Vermieterin legt die Sicherheit getrennt von ihrem Vermögen an. Über geleistete Raten und die Anlage wird gesondert Nachweis erteilt.

## 6 Zahlungsstörungen und Stundungen

### 6.1

Stundungen, Ratenzahlungen oder Tilgungsvereinbarungen bedürfen einer gesonderten Vereinbarung. Sie ändern die Fälligkeit der laufenden Miete nur, wenn dies ausdrücklich und für einen bestimmten Zeitraum vereinbart wird.

### 6.2

Zahlungen sollen unter Angabe der Vertragsnummer erfolgen. Eine fehlende Angabe ändert die gesetzlichen Regeln über Tilgungsbestimmung und Anrechnung nicht. Die Vermieterin teilt der Mieterin auf Anfrage den gebuchten Forderungsstand mit.

## 7 Gebrauch der Wohnung

### 7.1

Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Die Aufnahme weiterer Personen, eine Untervermietung oder eine sonstige Gebrauchsüberlassung an Dritte richtet sich nach den gesetzlichen Vorschriften und ist der Vermieterin vorab anzuzeigen, soweit deren Erlaubnis erforderlich ist.

### 7.2

Die Terrasse gehört zur Mietsache. Bauliche Veränderungen, feste Aufbauten und Eingriffe in Fassade, Leitungen oder Abdichtung bedürfen der vorherigen Zustimmung. Übliche bewegliche Balkon- und Terrassenmöbel bleiben hiervon unberührt.

## 8 Erhaltung, Mängelanzeige und Zutritt

### 8.1

Die Vermieterin erhält die Mietsache während der Mietzeit im vertragsgemäßen Zustand. Auftretende Mängel, Leitungswasserschäden oder sonstige Gefahren sind unverzüglich unter möglichst genauer Angabe von Ort, Zeitpunkt und Erscheinungsbild mitzuteilen.

### 8.2

Bei angezeigten Mängeln sowie für angekündigte Wartungs-, Ablese- oder Erhaltungsmaßnahmen ist nach angemessener Terminabstimmung Zutritt zu gewähren. Notfälle bleiben unberührt. Die berechtigten Belange der Mieterin, insbesondere Arbeitszeiten, sind bei der Terminierung zu berücksichtigen.

## 9 Betrieb der Wohnung und Hausordnung

### 9.1

Die Räume sind in einem dem Gebäude und der Jahreszeit angemessenen Umfang zu beheizen und zu lüften. Starre Lüftungsintervalle werden nicht vereinbart.

### 9.2

Die beigefügte Hausordnung regelt insbesondere Ruhezeiten, Treppenhausnutzung, Mülltrennung und den Zugang zu Gemeinschaftsflächen. Gesetzliche Rechte gehen entgegenstehenden Regelungen vor.

## 10 Übergabe und Rückgabe

### 10.1

Die Übergabe erfolgt nach dem gesonderten Protokoll vom 29.08.2018. Dort verzeichnete Schlüssel, Zählerstände und Anfangsmängel sind Bestandteil der Vertragsakte.

### 10.2

Bei Beendigung ist die Wohnung geräumt, besenrein und mit sämtlichen überlassenen Schlüsseln zurückzugeben. Über Zustand, Zählerstände und Schlüssel wird ein Rückgabeprotokoll gefertigt. Ansprüche der Parteien werden durch die bloße Protokollaufnahme weder anerkannt noch ausgeschlossen.

## 11 Erklärungen und Vertragsunterlagen

### 11.1

Änderungen der Anschrift, E-Mail-Adresse oder Bankverbindung sind zeitnah mitzuteilen. Rechtlich formbedürftige Erklärungen richten sich nach der jeweils vorgeschriebenen Form; eine E-Mail ersetzt insbesondere keine gesetzlich erforderliche Schriftform.

### 11.2

Nebenabreden bestehen bei Unterzeichnung nicht. Spätere Änderungen werden als gesonderter Nachtrag oder in einer eindeutig bezeichneten Vereinbarung zur Vertragsakte genommen.

## 12 Anlagen

1. Übergabeprotokoll vom 29.08.2018 mit Schlüssel- und Zählerliste
2. Wohnflächenberechnung
3. Hausordnung
4. Betriebskostenkatalog
5. Energieausweis zur Einsichtnahme

**Unterschriften**

Berlin, den 27.08.2018

| Vermieterin | Mieterin |
|---|---|
| Wohnen Berlin Immobilien GmbH, Dr. Markus Lehmann | Nora Riedel |
