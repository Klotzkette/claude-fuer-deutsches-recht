# Mietkonto FBL5N

**Debitor:** D-442018
**Vertrag:** WBI-MV-2018-02704
**Zeitraum:** 30.04.2026 bis 15.08.2026
**Export:** FI-CA Einzelpostenliste, 12.08.2026, 14:36 Uhr

## Buchungsjournal

| Buchungsdatum | Beleg | Periode | Soll | Ist | Buchungstext | Saldo |
|---|---|---|---:|---:|---|---:|
| 30.04.2026 | 84004001 | Alt-Rückstand | 2600,00 | 0,00 | Rückstand bis April, in Ratenplan übernommen | 2600,00 |
| 15.05.2026 | 85005115 | Rate 1 | 0,00 | 650,00 | Rate 1 Ratenplan RP-2026-0442 | 1950,00 |
| 15.06.2026 | 85006115 | Rate 2 | 0,00 | 650,00 | Rate 2 Ratenplan RP-2026-0442 | 1300,00 |
| 15.07.2026 | 85007115 | Rate 3 | 650,00 | 0,00 | Rate 3 offen | 1300,00 |
| 05.08.2026 | 84008005 | 08 2026 | 870,00 | 870,00 | Laufende Miete August bezahlt | 1300,00 |
| 15.08.2026 | 85008115 | Rate 4 | 650,00 | 0,00 | Rate 4 offen | 1300,00 |

## OP-Status

| Prüffeld | Ergebnis |
|---|---|
| Offener Ratenrest | 1300,00 EUR |
| Laufende Miete | Ausgeglichen |
| Mahnsperre | Abgelaufen |
| Raten 1 und 2 | Bezahlt |
| Raten 3 und 4 | Nicht bezahlt |
| Kulanzvereinbarung | Ratenvereinbarung vom 02.05.2026 |

## Plausibilität

Offen sind nur zwei Raten aus der Kulanzvereinbarung. Die laufende Miete ist separat bezahlt und darf im Sachverhalt nicht als neuer Mietrückstand dargestellt werden. Für den nächsten Schritt sind Fälligstellungsklausel, Verzug mit den Raten und die wirtschaftliche Sinnhaftigkeit weiterer Kulanz zu prüfen.
