# Ratenmonitoring RP-2026-0442

## 1 Planstand

| Rate | Fälligkeit | Soll | Ist | Eingang | Status |
|---:|---|---:|---:|---|---|
| 1 | 15.05.2026 | 650,00 EUR | 650,00 EUR | 15.05.2026 | erfüllt |
| 2 | 15.06.2026 | 650,00 EUR | 650,00 EUR | 15.06.2026 | erfüllt nach Zuordnung |
| 3 | 15.07.2026 | 650,00 EUR | 0,00 EUR | keiner | überfällig |
| 4 | 15.08.2026 | 650,00 EUR | 0,00 EUR | keiner | überfällig |
| Summe | | 2600,00 EUR | 1300,00 EUR | | 1300,00 EUR offen |

## 2 Laufende Miete

| Monat | Fälligkeit | Eingang | Betrag | Status |
|---|---|---|---:|---|
| Juni 2026 | 05.06.2026 | 03.06.2026 | 870,00 EUR | erfüllt |
| Juli 2026 | 05.07.2026 | 03.07.2026 | 870,00 EUR | erfüllt |
| August 2026 | 05.08.2026 | 05.08.2026 | 870,00 EUR | erfüllt |

## 3 Kontakt- und Wiedervorlagen

| Datum | Vorgang | Ergebnis |
|---|---|---|
| 16.07.2026 | Erinnerung Rate 3 | versandt |
| 25.07.2026 | Rückrufversuch | Mailbox voll |
| 08.08.2026 | E-Mail Thomas Riedel | angekündigte Zahlung nicht sichtbar |
| 17.08.2026 | Kulanzprüfung | Restforderung 1.300,00 EUR |
| 19.08.2026 | Kontoabschluss vor letzter Frist | offen |
