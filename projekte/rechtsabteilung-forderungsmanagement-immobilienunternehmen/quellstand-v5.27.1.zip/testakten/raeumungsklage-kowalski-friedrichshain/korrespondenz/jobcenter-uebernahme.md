# Jobcenter Friedrichshain-Kreuzberg — Schuldübernahmeerklärung

**Jobcenter Friedrichshain-Kreuzberg**
Frankfurter Allee 35-37
10247 Berlin

Aktenzeichen: 81234BG0085437

An die
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin

Berlin, 27.07.2026

**Betr.: Übernahme von Mietrückständen / Frau Aleksandra Kowalska, Boxhagener Straße 47, 10245 Berlin**
Bezug: Antrag der Leistungsberechtigten vom 19.06.2026

Sehr geehrte Damen und Herren,

das Jobcenter Friedrichshain-Kreuzberg verpflichtet sich gemäß § 22 Abs. 8 SGB II zur Übernahme der Mietrückstände von Frau Aleksandra Kowalska in Höhe von

**5790,00 EUR** (4625,00 EUR Mietrückstand + 965,00 EUR Juli 2026 + 200,00 EUR Mahn- und Verzugskosten).

Die Zahlung erfolgt unverzüglich, spätestens jedoch bis zum 05.08.2026, auf das von Ihnen mitgeteilte Konto.

Diese Erklärung dient zugleich der Heilung der fristlosen Kündigung gemäß § 569 Abs. 3 Nr. 2 S. 1 BGB.

Mit freundlichen Grüßen

i.A. Petra Niemann
Sachbearbeiterin
Jobcenter Friedrichshain-Kreuzberg
