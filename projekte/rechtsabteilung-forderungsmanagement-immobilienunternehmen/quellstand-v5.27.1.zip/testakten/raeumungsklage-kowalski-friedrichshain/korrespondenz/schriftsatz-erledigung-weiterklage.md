# Schriftsatz nach Schonfristzahlung — Erledigterklärung Zahlungsantrag, Aufrechterhaltung Räumungsantrag

An das
Amtsgericht Kreuzberg
Möckernstraße 130
10963 Berlin

über den geprüften sicheren Übermittlungsweg

In dem Rechtsstreit

**Wohnen Berlin Immobilien GmbH ./. Aleksandra Kowalska**
Az. 12 C 187/26

Berlin, 30.07.2026

zeigen wir an, dass das Jobcenter Friedrichshain-Kreuzberg mit Schreiben vom 27.07.2026 die Übernahme der Mietrückstände nach § 22 Abs. 8 SGB II erklärt und am 29.07.2026 einen Betrag von 5790,00 EUR auf das Konto der Klägerin gezahlt hat.

Beweis: Erklärung Jobcenter vom 27.07.2026, Anlage K8; Kontoauszug der Klägerin vom 30.07.2026, Anlage K9.

Damit ist der eingeklagte Zahlungsanspruch der Klägerin in voller Höhe erfüllt. Wir **erklären den Zahlungsantrag in der Hauptsache für erledigt** und regen an, der Beklagten Gelegenheit zur Zustimmung nach § 91a Abs. 1 ZPO zu geben. Für den Fall eines Widerspruchs beantragen wir festzustellen, dass der Rechtsstreit hinsichtlich des Zahlungsantrags in der Hauptsache erledigt ist.

Im Übrigen halten wir die Klage aufrecht.

## Begründung Fortbestand Räumungsanspruch

Die mit Schreiben vom 10.04.2026 erklärte **fristlose** Kündigung ist gemäß § 569 Abs. 3 Nr. 2 S. 1 BGB unwirksam geworden, da das Jobcenter sich innerhalb der Zwei-Monats-Frist nach Rechtshängigkeit (02.07.2026) zur Befriedigung verpflichtet und gezahlt hat. Die Akte enthält keinen Hinweis auf eine bereits innerhalb der letzten zwei Jahre nach § 569 Abs. 3 Nr. 2 S. 2 BGB unwirksam gewordene Kündigung.

Die hilfsweise erklärte **ordentliche** Kündigung gemäß § 573 Abs. 2 Nr. 1 BGB wird durch die Schonfristzahlung nicht automatisch unwirksam. Nach gefestigter Rechtsprechung des Bundesgerichtshofs (BGH 23.07.2025 — VIII ZR 287/23; BGH 09.04.2025 — VIII ZR 145/24; BGH 05.10.2022 — VIII ZR 307/21; BGH, Urteil vom 13.10.2021 — VIII ZR 91/20; BGH 16.02.2005 — VIII ZR 6/04) erfasst die Schonfristregelung des § 569 Abs. 3 Nr. 2 BGB ausschließlich die fristlose Kündigung. Die Zahlung ist bei Verschulden und Erheblichkeit nach § 573 Abs. 2 Nr. 1 BGB zu würdigen. Arbeitsplatzverlust, Leistungsantrag, Zahlungsverhalten, Rückstandshöhe und vollständige Deckung sind dabei gegeneinander abzuwägen; die Klägerin hält den Räumungsantrag nach dieser gesonderten Prüfung aufrecht.

Der Räumungsanspruch beruht somit auf der hilfsweisen ordentlichen Kündigung. Das Mietverhältnis endet mit Ablauf des 31.01.2027 (§ 573c Abs. 1 S. 2 BGB; Mietdauer über acht Jahre = 9 Monate Frist, Wirksamwerden der Erklärung am 14.04.2026, Frist ab Mai 2026).

## Ergänzte Anträge

1. Es wird festgestellt, dass der Rechtsstreit hinsichtlich des Zahlungsantrags in der Hauptsache erledigt ist, sofern keine übereinstimmende Erledigung nach § 91a ZPO eintritt.

2. Die Beklagte wird verurteilt, die im Hause Boxhagener Straße 47, 10245 Berlin, im 4. OG rechts gelegene 3-Zimmer-Wohnung mit ca. 71,40 qm Wohnfläche und einem Kellerraum zum 31.01.2027 zu räumen und an die Klägerin geräumt herauszugeben.

3. Der Beklagten werden die Kosten des Rechtsstreits auferlegt.

## Anlagen

- K8 Erklärung Jobcenter Friedrichshain-Kreuzberg vom 27.07.2026
- K9 Kontoauszug der Klägerin vom 30.07.2026

Sandra Berger
Rechtsfachwirtin, Forderungsmanagement
Wohnen Berlin Immobilien GmbH
