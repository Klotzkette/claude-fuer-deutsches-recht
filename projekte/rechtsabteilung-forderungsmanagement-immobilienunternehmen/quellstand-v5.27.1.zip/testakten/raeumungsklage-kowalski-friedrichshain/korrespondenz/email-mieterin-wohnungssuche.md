# E-Mail-Ausdruck: Wohnungssuche und Jobcenter

## 1 Kopfzeilen

| Feld | Inhalt |
|---|---|
| Von | Aleksandra Kowalska, a.kowalska85@mailbox-beispiel.de |
| An | mietenservice@wohnen-berlin-immobilien.de |
| Kopie | sozialberatung@familienpunkt-beispiel.de |
| Datum | 08.07.2026, 21:37 Uhr |
| Betreff | Klage / ich suche schon, bitte Termin nicht in Ferien |

## 2 Nachricht

Sehr geehrte Damen und Herren,

ich habe die Klage heute gelesen. Das Jobcenter bearbeitet die Mietschulden und hat noch einmal Unterlagen von mir verlangt. Ich habe zwei Kinder und kann nicht innerhalb weniger Tage ausziehen. Ich suche seit Mai nach einer anderen Wohnung, bekomme aber nur Absagen oder gar keine Antwort.

Bitte teilen Sie mir mit, ob die Sache gestoppt wird, wenn das Jobcenter alles bezahlt. Ich habe Frau Scholz nur wegen des Kellerschlüssels gefragt. Ich habe keinen Wohnungsschlüssel abgegeben und werde auch nicht ohne Termin die Wohnung verlassen.

Vom 18.07. bis 24.07. bin ich mit den Kindern bei meiner Mutter. Post wird von meiner Nachbarin geleert. Bitte legen Sie in dieser Zeit nichts offen vor die Wohnungstür.

Mit freundlichen Grüßen

Aleksandra Kowalska

## 3 Anhänge

Die Nachricht nennt eine Liste von Wohnungsbewerbungen. Im exportierten Postfach ist kein Anhang vorhanden.
