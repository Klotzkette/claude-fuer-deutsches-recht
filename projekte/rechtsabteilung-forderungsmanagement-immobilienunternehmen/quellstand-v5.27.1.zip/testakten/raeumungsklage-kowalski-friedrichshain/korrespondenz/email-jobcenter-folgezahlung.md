# E-Mail-Ausdruck

Von: leistungsstelle-wohnen@jobcenter-fk.example

An: forderungsmanagement@wohnen-berlin.example

Datum: 28.07.2026, 08:17 Uhr

Betreff: WBI-MV-2017-04231 / Kowalska / Zahlung vom 27.07.2026

Sehr geehrte Frau Berger,

zu Ihrer gestrigen Rückfrage bestätigen wir, dass die Zahlung über 5790,00 EUR unter dem im Betreff genannten Vertragskonto angewiesen wurde. Die Zahlungsaufteilung ergibt sich aus unserem Berechnungsbogen. Bitte teilen Sie uns mit, falls die Zahlung nicht vollständig oder mit abweichendem Verwendungszweck eingegangen ist.

Die laufenden Aufwendungen für Unterkunft und Heizung sollen ab August 2026 nach dem derzeitigen Bewilligungsstand unmittelbar an die Vermieterin überwiesen werden. Der aktuelle Bewilligungsabschnitt endet am 31.12.2026. Diese Mitteilung steht unter dem Vorbehalt unveränderter leistungsrechtlicher Verhältnisse.

Eine Erklärung zur Übernahme künftiger Nutzungsentschädigung, Prozesskosten oder sonstiger Forderungen ist mit dieser E-Mail nicht verbunden. Über solche Positionen liegt hier keine Entscheidung vor.

Bitte verwenden Sie für Rückfragen das Bedarfsgemeinschaftszeichen BG-4711-26 und übermitteln Sie keine weiteren Gesundheits- oder Schuldendaten per unverschlüsselter E-Mail.

Mit freundlichen Grüßen

Im Auftrag

Nadine Fuchs

Jobcenter Friedrichshain-Kreuzberg
