# Kündigung des Mietverhältnisses

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99, 10117 Berlin
Abteilung Forderungsmanagement — Frau Sandra Berger, Rechtsfachwirtin
Tel. 030 2055 4810, s.berger@wohnen-berlin-immo.de

Vertragsnummer: WBI-MV-2017-04231

Frau
Aleksandra Kowalska
Boxhagener Straße 47
10245 Berlin

Per Gerichtsvollzieher zugestellt am 14.04.2026

Berlin, 10.04.2026

**Fristlose, hilfsweise ordentliche Kündigung des Wohnraummietverhältnisses Boxhagener Straße 47, 10245 Berlin, 4. OG rechts**

Sehr geehrte Frau Kowalska,

namens und in Vollmacht der Wohnen Berlin Immobilien GmbH kündigen wir hiermit das mit Ihnen bestehende Mietverhältnis über die im Betreff bezeichnete Wohnung

**fristlos**

aus wichtigem Grund gemäß § 543 Abs. 2 Nr. 3 lit. a, § 569 Abs. 3 BGB,

**hilfsweise ordentlich**

aus berechtigtem Interesse wegen erheblicher Pflichtverletzung gemäß § 573 Abs. 2 Nr. 1 BGB zum nächstmöglichen Termin, das ist nach § 573c Abs. 1 S. 2 BGB der 31.01.2027 (Mietdauer über 8 Jahre, 9 Monate Kündigungsfrist).

## Begründung

Sie sind mit der Miete für die Monate Februar 2026 (teilweise), März 2026, April 2026 in Höhe von insgesamt 2695,00 EUR in Rückstand. Der Rückstand übersteigt zwei volle Monatsmieten. Die Voraussetzungen für eine fristlose Kündigung nach § 543 Abs. 2 Nr. 3 lit. a, § 569 Abs. 3 Nr. 1 BGB sind damit erfüllt.

Sie wurden mit Mahnung vom 17.02.2026 und 05.03.2026 erfolglos zur Zahlung aufgefordert.

## Aufforderung zur Räumung

Wir fordern Sie auf, die Wohnung bis spätestens **30.04.2026** geräumt an uns zurückzugeben und die Schlüssel im Büro der Hausverwaltung, Friedrichstraße 99, 10117 Berlin, zu übergeben.

## Hinweis Schonfristzahlung

Wir weisen Sie ausdrücklich darauf hin, dass die **fristlose** Kündigung gemäß § 569 Abs. 3 Nr. 2 BGB unwirksam wird, wenn der Vermieter spätestens bis zum Ablauf von zwei Monaten nach Eintritt der Rechtshängigkeit des Räumungsanspruchs hinsichtlich der fälligen Miete und der fälligen Entschädigung befriedigt wird oder wenn sich eine öffentliche Stelle zur Befriedigung verpflichtet.

Die hilfsweise erklärte **ordentliche** Kündigung wird durch eine solche Nachzahlung nach gefestigter Rechtsprechung nicht automatisch beseitigt (BGH 23.07.2025 — VIII ZR 287/23; BGH 09.04.2025 — VIII ZR 145/24; BGH 16.02.2005 — VIII ZR 6/04). Eine spätere Zahlung bleibt bei Verschulden und Erheblichkeit nach § 573 Abs. 2 Nr. 1 BGB zu berücksichtigen.

## Widerspruch

Sie können der ordentlichen Kündigung gemäß § 574 BGB widersprechen, wenn die Beendigung des Mietverhältnisses für Sie eine nicht zu rechtfertigende Härte bedeuten würde. Der Widerspruch ist in Textform zu erklären und muss uns grundsätzlich spätestens zwei Monate vor Beendigung des Mietverhältnisses zugehen.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin, Forderungsmanagement
Wohnen Berlin Immobilien GmbH

Anlage: Mietkontoauszug Stand 08.04.2026
