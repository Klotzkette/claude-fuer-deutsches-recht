# Klage — Entwurf

An das
**Amtsgericht Kreuzberg**
Möckernstraße 130
10963 Berlin

über den vor Einreichung geprüften sicheren Übermittlungsweg

Berlin, 08.06.2026

**Klage**

**der Wohnen Berlin Immobilien GmbH**, vertreten durch den Geschäftsführer Dr. Markus Lehmann, Friedrichstraße 99, 10117 Berlin

- Klägerin -

Prozessführung im Parteibetrieb durch die Bearbeiterin der Klägerin gemäß § 79 Abs. 2 S. 2 Nr. 1 ZPO. Die Bearbeiterin ist Beschäftigte der Klägerin; Vollmacht und Beschäftigtenstatus werden als Anlage vorgelegt. Die Bearbeitung der eigenen Forderung ist keine fremde Angelegenheit im Sinne des § 2 Abs. 1 RDG.

Bearbeiterin: Sandra Berger, Rechtsfachwirtin, Tel. 030 2055 4810, s.berger@wohnen-berlin-immo.de

**gegen**

**Frau Aleksandra Kowalska**, geb. 22.07.1985, wohnhaft Boxhagener Straße 47, 10245 Berlin

- Beklagte -

wegen Zahlung und Räumung

**Streitwert: 11765,00 EUR**

(Zahlungsantrag 4625,00 EUR Mietrückstand zzgl. Räumungsstreitwert nach § 41 Abs. 2 S. 1 GKG in Höhe von 12 Nettokaltmieten = 12 x 595,00 EUR = 7140,00 EUR; Betriebs- und Heizkostenvorauszahlungen bleiben gemäß § 41 Abs. 1 S. 2 GKG außer Ansatz, da sie als Vorauszahlung und nicht als Pauschale vereinbart sind (vgl. BGH 05.10.2021 — VIII ZB 80/20). Addition Zahlungs- und Räumungsantrag gemäß § 5 ZPO.)

## Anträge

Wir beantragen,

1. die Beklagte zu verurteilen, an die Klägerin **4625,00 EUR** nebst Zinsen in Höhe von 5 Prozentpunkten über dem Basiszinssatz seit Rechtshängigkeit zu zahlen,

2. die Beklagte zu verurteilen, die im Hause Boxhagener Straße 47, 10245 Berlin, im 4. OG rechts gelegene 3-Zimmer-Wohnung mit ca. 71,40 qm Wohnfläche und einem Kellerraum **zu räumen und an die Klägerin geräumt herauszugeben**,

3. der Beklagten die Kosten des Rechtsstreits aufzuerlegen,

4. das Urteil hinsichtlich des Zahlungsantrages für vorläufig vollstreckbar zu erklären, gegebenenfalls gegen Sicherheitsleistung.

## Begründung

### I. Sachverhalt

Die Parteien sind durch Wohnraummietvertrag vom 14.04.2017 verbunden, geändert durch Nachtrag Nr. 1 vom 12.06.2022. Die Bruttowarmmiete beträgt 965,00 EUR (Nettokaltmiete 595,00 EUR, BK-Vorauszahlung 195,00 EUR, HK-Vorauszahlung 175,00 EUR).

Beweis: Mietvertrag, Anlage K1; Nachtrag Nr. 1, Anlage K2.

Die Beklagte ist seit Februar 2026 mit der Miete in Rückstand. Stand 08.06.2026 beträgt der Mietrückstand 4625,00 EUR (Februar 765,00 EUR Teilrest, März bis Juni je 965,00 EUR).

Beweis: Mietkontoauszug FBL5N Stand 08.06.2026, Anlage K3.

Die Klägerin hat die Beklagte mehrfach erfolglos zur Zahlung aufgefordert (Mahnungen vom 17.02.2026 und 05.03.2026).

Beweis: Mahnungen Anlage K4 und K5.

Mit Schreiben vom 10.04.2026, der Beklagten zugestellt am 14.04.2026 durch Gerichtsvollzieher, hat die Klägerin das Mietverhältnis **fristlos und hilfsweise ordentlich** gekündigt.

Beweis: Kündigungsschreiben mit Zustellungsurkunde, Anlage K6.

### II. Rechtliche Würdigung

### 1. Zuständigkeit

Das Amtsgericht Kreuzberg ist gemäß § 23 Nr. 2a GVG (Streitigkeiten über Wohnraummietverhältnisse stets Amtsgericht, ohne Streitwertgrenze) und § 29a ZPO (ausschließlicher Gerichtsstand der belegenen Sache) zuständig. Der aktuelle Berliner Gerichtsbezirk für Friedrichshain ist vor Einreichung nochmals amtlich geprüft worden.

### 2. Postulationsfähigkeit

Vor dem Amtsgericht können die Parteien den Rechtsstreit gemäß § 79 Abs. 1 ZPO selbst führen. Die Klägerin lässt sich gemäß § 79 Abs. 2 S. 2 Nr. 1 ZPO durch ihre Beschäftigte vertreten. Beschäftigtenstatus und Vollmacht sind belegt; eine zusätzliche gesetzliche Sachkundevoraussetzung wird nicht behauptet.

### 3. Zahlungsanspruch

Der Zahlungsanspruch folgt aus § 535 Abs. 2 BGB. Die Höhe ergibt sich aus dem Mietkonto.

### 4. Räumungsanspruch

Der Räumungsanspruch folgt aus § 546 Abs. 1 BGB nach wirksamer Beendigung des Mietverhältnisses.

Die fristlose Kündigung ist nach § 543 Abs. 2 Nr. 3 lit. a, § 569 Abs. 3 Nr. 1 BGB wirksam: Der Rückstand übersteigt zum Zeitpunkt der Kündigung zwei Monatsmieten.

Hilfsweise greift die ordentliche Kündigung nach § 573 Abs. 2 Nr. 1 BGB; die Nichtleistung der Miete in der hier vorliegenden Höhe stellt eine erhebliche schuldhafte Pflichtverletzung dar (BGH 28.11.2007 — VIII ZR 145/07).

### 5. Hinweis Schonfristzahlung

Auf einen möglicherweise eingreifenden Heilungstatbestand nach § 569 Abs. 3 Nr. 2 BGB wird hingewiesen. Eine etwaige Schonfristzahlung beseitigt nach gefestigter Rechtsprechung des BGH die hilfsweise erklärte ordentliche Kündigung **nicht automatisch** (BGH 23.07.2025 — VIII ZR 287/23; BGH 09.04.2025 — VIII ZR 145/24; BGH 16.02.2005 — VIII ZR 6/04). Die Zahlung ist bei Verschulden und Erheblichkeit nach § 573 Abs. 2 Nr. 1 BGB zu würdigen.

## Anlagenverzeichnis

- K1 Mietvertrag vom 14.04.2017
- K2 Nachtrag Nr. 1 vom 12.06.2022
- K3 Mietkontoauszug FBL5N Stand 08.06.2026
- K4 Mahnung Stufe 1 vom 17.02.2026
- K5 Mahnung Stufe 2 vom 05.03.2026
- K6 Kündigungsschreiben vom 10.04.2026 nebst Zustellungsurkunde GVZ
- K7 Handelsregisterauszug Klägerin HRB 198765 B

Sandra Berger
Rechtsfachwirtin, Forderungsmanagement
Wohnen Berlin Immobilien GmbH
