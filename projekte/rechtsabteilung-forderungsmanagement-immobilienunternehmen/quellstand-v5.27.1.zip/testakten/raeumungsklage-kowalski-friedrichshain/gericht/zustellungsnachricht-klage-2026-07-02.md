# Amtsgericht Kreuzberg

## 1 Verfahrensdaten

| Feld | Inhalt |
|---|---|
| Aktenzeichen | 12 C 187/26 |
| Klägerin | Wohnen Berlin Immobilien GmbH |
| Beklagte | Aleksandra Kowalska |
| Gegenstand | Zahlung und Räumung |
| Klageeingang | 12.06.2026 |
| Zustellung an Beklagte | 02.07.2026 |

## 2 Nachricht

Die Klageschrift nebst Anlagen K 1 bis K 7 ist der Beklagten am 02.07.2026 durch Einlegen in den zur Wohnung Boxhagener Straße 47, 4. OG rechts, gehörenden Briefkasten zugestellt worden.

Der Beklagten ist aufgegeben worden, binnen zwei Wochen nach Zustellung anzuzeigen, ob sie sich gegen die Klage verteidigen will. Für die Klageerwiderung wurde eine weitere Frist von zwei Wochen gesetzt. Die Verfügung enthält den Hinweis auf die Folgen einer Fristversäumung.

## 3 Eingang bei der Klägerin

Elektronischer Eingang der Zustellungsnachricht am 03.07.2026, 06:41 Uhr. Die Fristen wurden am selben Tag im Konzernfristenkalender erfasst. Ein gesondertes Empfangsbekenntnis der Klägerin war nicht angefordert.
