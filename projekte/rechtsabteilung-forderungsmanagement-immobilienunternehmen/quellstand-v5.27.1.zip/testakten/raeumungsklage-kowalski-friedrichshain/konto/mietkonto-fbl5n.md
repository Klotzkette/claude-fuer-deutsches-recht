# Mietkonto FBL5N — Kowalska, Aleksandra

Vertragsnummer: WBI-MV-2017-04231
Partnernummer: 4002187
Stand: 08.06.2026

| Datum | Buchungstext | Soll | Haben | Saldo |
|---|---|---|---|---|
| 05.01.2026 | Lastschrift Kowalska 01/2026 vorgemerkt | | 965,00 | -965,00 |
| 06.01.2026 | Miete 01/2026 fällig | 965,00 | | 0,00 |
| 04.02.2026 | Miete 02/2026 fällig | 965,00 | | 965,00 |
| 03.02.2026 | Teilzahlung Kowalska 02/2026 | | 200,00 | 765,00 |
| 04.03.2026 | Miete 03/2026 fällig | 965,00 | | 1730,00 |
| 07.04.2026 | Miete 04/2026 fällig | 965,00 | | 2695,00 |
| 06.05.2026 | Miete 05/2026 fällig | 965,00 | | 3660,00 |
| 03.06.2026 | Miete 06/2026 fällig | 965,00 | | 4625,00 |
| 08.06.2026 | Mahnkosten Stufe 1+2 | 12,50 | | 4637,50 |
| 08.06.2026 | Verzugszinsen 5%-Punkte über Basis | 47,50 | | 4685,00 |
| 08.06.2026 | Verfahrenskosten anteilig | 140,00 | | 4825,00 |

## Salden-Zusammenfassung

- Rückstand Mieten: 4625,00 EUR (Anteil 02/2026 i.H.v. 765,00 + 03 bis 06/2026 je 965,00)
- Mahnkosten: 12,50 EUR
- Verzugszinsen: 47,50 EUR
- Verfahrenskosten (anteilig): 140,00 EUR
- **Gesamtsaldo zum 08.06.2026: 4825,00 EUR**

## Verzugskennzeichnung

- Verzugsbeginn des Februarrestes: 05.02.2026 (Tag nach Fälligkeit; Teilzahlung am 03.02.2026 unter dem Sollbetrag)
- Verzugszinsatz: 5 Prozentpunkte über Basiszinssatz (§ 288 Abs. 1 BGB)
- Verbraucher: ja

## Kündigungsrelevanz

- Rückstand übersteigt zwei Monatsmieten (1930,00 EUR) nach Fälligkeit der Aprilmiete am 07.04.2026
- Voraussetzung § 543 Abs. 2 Nr. 3 lit. a BGB erfüllt
- Voraussetzung § 569 Abs. 3 Nr. 1 BGB erfüllt
- Fristlose Kündigung am 14.04.2026 zugestellt
- Hilfsweise ordentliche Kündigung nach § 573 Abs. 2 Nr. 1 BGB

## Schonfristzahlung — Hinweis

Bei Zahlung des gesamten Rückstandes oder Verpflichtungserklärung einer öffentlichen Stelle (z.B. Jobcenter nach § 22 Abs. 8 SGB II) innerhalb von zwei Monaten ab Rechtshängigkeit der Räumungsklage wird die **fristlose** Kündigung gemäß § 569 Abs. 3 Nr. 2 BGB unwirksam.

Die hilfsweise erklärte **ordentliche** Kündigung wird durch Schonfristzahlung nach gefestigter BGH-Rechtsprechung (BGH 23.07.2025 — VIII ZR 287/23; BGH 09.04.2025 — VIII ZR 145/24; BGH 16.02.2005 — VIII ZR 6/04) **nicht automatisch** geheilt; die Zahlung ist bei Verschulden und Erheblichkeit zu würdigen.
