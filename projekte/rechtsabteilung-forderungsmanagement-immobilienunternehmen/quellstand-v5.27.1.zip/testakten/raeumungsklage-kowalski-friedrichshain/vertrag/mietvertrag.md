# Wohnraummietvertrag

zwischen

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99, 10117 Berlin
vertreten durch den Geschäftsführer Dr. Markus Lehmann
- Vermieterin -

und

**Frau Aleksandra Kowalska**, geb. 22.07.1985
Boxhagener Straße 47, 10245 Berlin (Anschrift nach Einzug)
- Mieterin -

## 1 Mietsache

### 1.1

Die Vermieterin vermietet der Mieterin die im Hause Boxhagener Straße 47, 10245 Berlin, im 4. OG rechts gelegene 3-Zimmer-Wohnung mit 71,40 qm Wohnfläche nebst Küche, Bad, Flur, Balkon und Kellerraum Nr. 14.

### 1.2

Die Wohnfläche beruht auf der zur Vertragsakte genommenen Berechnung und ist die vereinbarte Bezugsgröße, soweit Betriebskosten nach Wohnfläche verteilt werden. Der Balkon ist mit einem Viertel seiner Grundfläche berücksichtigt.

### 1.3

Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Die Mieterin bezieht sie mit ihren zwei minderjährigen Kindern. Eine spätere Änderung der Haushaltsangehörigen ist anzuzeigen, soweit berechtigte Interessen der Vermieterin berührt sind.

## 2 Mietzeit

### 2.1

Das Mietverhältnis beginnt am 01.05.2017. Es ist auf unbestimmte Zeit geschlossen.

### 2.2

Die ordentliche Kündigung richtet sich nach den gesetzlichen Vorschriften, insbesondere § 573, 573c BGB.

## 3 Miete

### 3.1

Die monatliche Miete beträgt zum Vertragsbeginn:

- Nettokaltmiete: 530,00 EUR
- Betriebskostenvorauszahlung: 150,00 EUR
- Heizkostenvorauszahlung: 130,00 EUR
- Gesamtmiete: 810,00 EUR

### 3.2

Die Miete ist monatlich im Voraus, spätestens bis zum 3. Werktag des Monats, auf das Konto der Vermieterin zu zahlen.

### 3.3

Bankverbindung Vermieterin:
Berliner Volksbank, IBAN DE 47 1009 0000 0123 4567 89
Verwendungszweck: WBI-MV-2017-04231 Kowalska Boxhagener 47

## 4 Betriebskosten und Heizkosten

### 4.1

Die Mieterin trägt die Betriebskosten gemäß Anlage 1 (Betriebskostenverordnung) und die Heizkosten gemäß Heizkostenverordnung.

### 4.2

Abrechnung jährlich bis spätestens 31.12. des Folgejahres.

## 5 Kaution

### 5.1

Die Mieterin leistet eine Kaution in Höhe von 1590,00 EUR (3 Nettokaltmieten).

### 5.2

Die Kaution ist auf einem Mietkautionskonto separat von dem Vermögen der Vermieterin anzulegen.

## 6 Hausordnung

Die als Anlage beigefügte Hausordnung ist Bestandteil dieses Vertrages.

## 7 Erhaltung, Mängelanzeige und Zutritt

### 7.1

Die Vermieterin erhält die Mietsache im vertragsgemäßen Zustand. Mängel, Schäden und sonstige Gefahren sind unverzüglich mit einer möglichst genauen Beschreibung anzuzeigen.

### 7.2

Bei einem konkreten sachlichen Grund, insbesondere Mängelprüfung, Ablesung, Wartung oder Erhaltungsmaßnahme, gewährt die Mieterin nach angemessener Ankündigung Zutritt. Bei der Terminabstimmung sind Betreuungspflichten, Arbeitszeiten und sonstige berechtigte Belange zu berücksichtigen.

### 7.3

Bauliche Veränderungen sowie Eingriffe in Fassade, Leitungen oder Gebäudetechnik bedürfen der vorherigen Zustimmung. Übliche bewegliche Einrichtungen auf dem Balkon bleiben hiervon unberührt.

## 8 Zahlungsverkehr und Mitteilungen

### 8.1

Als Verwendungszweck soll die Vertragsnummer angegeben werden. Eine fehlende Angabe lässt die gesetzlichen Regeln über Tilgungsbestimmung und Anrechnung unberührt.

### 8.2

Änderungen von Zustellanschrift, Bankverbindung oder den für laufende Mitteilungen genutzten Kontaktdaten sollen zeitnah mitgeteilt werden. Gesetzlich vorgeschriebene Formen, insbesondere für Kündigungen, bleiben maßgeblich.

### 8.3

Stundungen und Ratenzahlungen gelten nur für die in der jeweiligen Vereinbarung bezeichneten Forderungen. Die laufende Miete bleibt fällig, sofern nicht ausdrücklich etwas anderes geregelt wird.

## 9 Übergabe, Schlüssel und Rückgabe

### 9.1

Anfangszustand, Zählerstände und Schlüssel sind im Übergabeprotokoll vom 28.04.2017 festgehalten. Übergeben wurden drei Haus- und Wohnungsschlüssel, zwei Briefkastenschlüssel und ein Kellerschlüssel.

### 9.2

Bei Vertragsende ist die Wohnung geräumt, besenrein und mit sämtlichen überlassenen und nachgefertigten Schlüsseln zurückzugeben. Besitzaufgabe und Schlüsselrückgabe sind zu dokumentieren; die bloße Abwesenheit der Mieterin ersetzt keine Rückgabe.

### 9.3

Über Zustand, Zählerstände und Schlüssel wird ein Rückgabeprotokoll erstellt. Ansprüche wegen Schäden, Nutzungsentschädigung oder offener Forderungen werden durch die Protokollaufnahme weder anerkannt noch ausgeschlossen.

## 10 Anlagen und Nebenabreden

### 10.1

Bestandteile der Vertragsakte sind Wohnflächenberechnung, Übergabeprotokoll, Hausordnung, Betriebskostenkatalog und Energieausweis zur Einsichtnahme.

### 10.2

Nebenabreden bestehen bei Unterzeichnung nicht. Spätere Änderungen der Miethöhe oder sonstiger Vertragsbedingungen werden in einer eindeutig bezeichneten Erklärung oder einem Nachtrag dokumentiert.

Berlin, den 14.04.2017

________________________               ________________________
Wohnen Berlin Immobilien GmbH         Aleksandra Kowalska
Dr. Markus Lehmann                    Mieterin
Geschäftsführer

---

## 11 Nachtrag Nr. 1 vom 12.06.2022

Mietanpassung nach § 558 BGB zum 01.07.2022:

- Nettokaltmiete neu: 595,00 EUR
- Betriebskostenvorauszahlung neu: 195,00 EUR
- Heizkostenvorauszahlung neu: 175,00 EUR
- Gesamtmiete neu: 965,00 EUR

Begründung: Berliner Mietspiegel 2021, Mietspiegelfeld H1 (Altbau bis 1918, mittlere Wohnlage, saniert), Mittelwert 7,98 EUR/qm.

Im Übrigen bleibt der Mietvertrag vom 14.04.2017 unverändert bestehen.

Berlin, den 12.06.2022

________________________               ________________________
Wohnen Berlin Immobilien GmbH         Aleksandra Kowalska

---

## 12 Anlage 1: Betriebskostenverordnung (Auszug der umlagefähigen Positionen)

Grundsteuer, Wasserversorgung, Entwässerung, Heizung, Warmwasser, Aufzug (entfällt), Straßenreinigung, Müllabfuhr, Gebäudereinigung, Gartenpflege, Beleuchtung, Schornsteinreinigung, Sach- und Haftpflichtversicherung, Hauswart, Antenne/Kabel, sonstige Betriebskosten gemäß § 2 Nr. 17 BetrKV.
