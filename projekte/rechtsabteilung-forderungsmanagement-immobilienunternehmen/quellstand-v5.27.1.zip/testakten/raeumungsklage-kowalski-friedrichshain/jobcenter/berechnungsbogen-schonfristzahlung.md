# Berechnungsbogen Direktzahlung

## 1 Bedarfsgemeinschaft

| Feld | Wert |
|---|---|
| BG-Nummer | 81234BG0085437 |
| Leistungsberechtigte | Aleksandra Kowalska |
| Unterkunft | Boxhagener Straße 47, 10245 Berlin |
| Personen | 3 |
| Bearbeitungsstand | 22.07.2026 |

## 2 Berechnung

| Zeitraum oder Position | Vom Vermieter gemeldet | Anerkannt | Zahlbetrag |
|---|---:|---:|---:|
| Rest Februar 2026 | 765,00 EUR | 765,00 EUR | 765,00 EUR |
| März 2026 | 965,00 EUR | 965,00 EUR | 965,00 EUR |
| April 2026 | 965,00 EUR | 965,00 EUR | 965,00 EUR |
| Mai 2026 | 965,00 EUR | 965,00 EUR | 965,00 EUR |
| Juni 2026 | 965,00 EUR | 965,00 EUR | 965,00 EUR |
| Juli 2026 | 965,00 EUR | 965,00 EUR | 965,00 EUR |
| Nebenkosten des Verfahrens | 200,00 EUR | vorläufig 200,00 EUR | 200,00 EUR |
| Summe | 5790,00 EUR | 5790,00 EUR | 5790,00 EUR |

## 3 Vermerk

Direktzahlung an die Vermieterin. Die laufenden Kosten der Unterkunft sollen ab August 2026 nach Abschluss der Kontoumstellung unmittelbar überwiesen werden. Die abschließende Prüfung des als Verfahrenskosten bezeichneten Teilbetrags bleibt vorbehalten.
