# Telefonnotiz zum Objektbesuch

## 1 Gespräch

| Feld | Inhalt |
|---|---|
| Datum | 28.07.2026, 15:22 Uhr |
| Gesprächspartnerin | Maren Scholz, Hausverwaltung Friedrichshain |
| Aufgenommen von | Sandra Berger |
| Akte | F-2026-00412 |

## 2 Angaben der Hausverwaltung

Frau Scholz war am 26.07.2026 wegen eines klemmenden Kellerzugangs im Haus. Frau Kowalska öffnete die Wohnungstür und erklärte, sie habe inzwischen Kontakt zum Jobcenter. In der Wohnung seien Kinderstimmen zu hören gewesen. Umzugskartons oder Anzeichen einer bereits laufenden Räumung habe Frau Scholz nicht gesehen.

Frau Kowalska habe nach einem Termin für eine freiwillige Wohnungsabnahme gefragt, zugleich aber erklärt, sie habe noch keine Ersatzwohnung. Einen Schlüssel habe sie nicht übergeben. Die Hausverwaltung habe auch keinen Schlüssel verlangt. Ein in einer älteren DMS-Notiz verwendeter Satz „Schlüssel kommt Freitag“ beziehe sich nach Auskunft von Frau Scholz auf den Kellerschlüssel, nicht auf die Wohnung.

Im Treppenhaus habe ein Nachbar ungefragt gesagt, die Familie wolle „bald weg“. Name und Wohnung des Nachbarn wurden nicht aufgenommen. Diese Äußerung ist nicht weiter verifiziert.

## 3 Rücklauf

Die Hausverwaltung meldet jede tatsächliche Schlüsselübergabe sofort und erstellt dann ein gesondertes Übergabeprotokoll. Bis dahin bleibt der Besitzstand unverändert.
