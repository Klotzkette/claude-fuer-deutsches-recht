# Objektbesuchsprotokoll

Wohnen Berlin Immobilien GmbH

Hausverwaltung Friedrichshain

Friedrichstraße 99, 10117 Berlin

**Objektbetreuung:** Maren Scholz

**Vorgang:** F-2026-00412

**Protokoll erstellt:** 26.07.2026, 12:10 Uhr

## 1. Auftrag und Termin

| Feld | Inhalt |
|---|---|
| Datum | 26.07.2026 |
| Zeit | 10:35 bis 10:48 Uhr |
| Objekt | Boxhagener Straße 47, 10245 Berlin |
| Wohnung | 4. OG rechts |
| Vertragsnummer | WBI-MV-2017-04231 |
| Anlass | Gemeldeter klemmender Kellerzugang; keine Wohnungsabnahme |
| Mitarbeiterin | Maren Scholz |

Der Termin war am 22.07.2026 telefonisch ausschließlich zur Prüfung des Kellerzugangs vereinbart worden. Eine Besichtigung der Wohnung, Vorabnahme oder Schlüsselübergabe war weder angekündigt noch beauftragt. Frau Kowalska wurde zu Beginn des Gesprächs darauf hingewiesen.

## 2. Wahrnehmungen

Frau Kowalska öffnete nach zweimaligem Klingeln die Wohnungstür. Das Gespräch fand an der geöffneten Tür statt; die Wohnung wurde nicht besichtigt.

Im sichtbaren Flurbereich standen ein Kinderwagen, zwei Schulranzen und mehrere Paar Schuhe. Umzugskartons waren dort nicht erkennbar. Aus der Wohnung waren Kinderstimmen zu hören. Frau Kowalska erklärte, die Familie wohne weiterhin vollständig in der Wohnung.

Frau Kowalska fragte, ob im Fall eines späteren Auszugs eine Vorabnahme möglich sei. Sie erklärte zugleich, bislang weder einen neuen Mietvertrag noch einen festen Umzugstermin zu haben. Ein Wohnungsschlüssel wurde nicht angeboten oder übergeben.

Auf Nachfrage erklärte Frau Kowalska, sie habe beim Jobcenter Unterlagen zur Übernahme des Rückstands eingereicht und warte auf eine schriftliche Entscheidung. Einen Bescheid oder Zahlungsnachweis zeigte sie nicht vor. Sie bat darum, behördliche Schreiben weiterhin an die Wohnanschrift zu senden. Eine Erklärung zum laufenden Gerichtsverfahren gab sie nicht ab.

## 3. Kellerzugang

Der klemmende Schlüssel betraf ausschließlich die Kellertür im Erdgeschoss. Nach Schmierung des Schlosses ließ sich die Tür öffnen. Frau Kowalska behielt ihren Keller- und Wohnungsschlüssel.

Die Tür und das Schloss wiesen keine frischen Beschädigungen auf. Der Zylinder wurde nicht gewechselt. Materialverbrauch: ein Sprühstoß Graphit-Schmiermittel aus dem Fahrzeugbestand. Ein kostenpflichtiger Fremdauftrag wurde nicht ausgelöst.

## 4. Abgrenzung des Protokolls

Das Protokoll gibt ausschließlich die eigenen Wahrnehmungen der Objektbetreuerin und die im Türgespräch wiedergegebenen Erklärungen wieder. Die Innenräume wurden nicht betreten. Der dokumentierte Kinderwagen, die Schulranzen und die hörbaren Stimmen belegen keine vollständige Bestandsaufnahme, sprechen am Terminstag aber gegen eine bereits vollzogene Besitzaufgabe. Eine rechtliche Bewertung des Mietverhältnisses oder des Gerichtsverfahrens war nicht Gegenstand des Termins.

Das Protokoll wurde am 26.07.2026 um 12:16 Uhr als PDF im DocuWeb-Vorgang F-2026-00412 abgelegt. Nachträgliche Ergänzungen sind als neue Version zu speichern.

## 5. Unterschrift

Berlin, 26.07.2026

Maren Scholz

Hausverwaltung Friedrichshain
