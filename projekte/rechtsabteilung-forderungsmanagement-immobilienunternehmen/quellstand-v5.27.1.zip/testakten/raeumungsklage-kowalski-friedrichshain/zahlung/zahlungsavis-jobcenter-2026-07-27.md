# Zahlungsavis Jobcenter Friedrichshain-Kreuzberg

## 1 Bankdaten

| Feld | Wert |
|---|---|
| Buchungstag | 27.07.2026 |
| Wertstellung | 27.07.2026 |
| Betrag | 5790,00 EUR Haben |
| Auftraggeber | Jobcenter Berlin Friedrichshain-Kreuzberg |
| Verwendungszweck | 81234BG0085437 KOWALSKA MIETE 02-07/26 ÜBERN |
| Bankreferenz | JC-FK-2026-0727-009144 |
| Empfängerkonto | Wohnen Berlin Immobilien GmbH, Mietkonto |

## 2 Maschinelle Zuordnung

| Teilbetrag | Vorschlag Zahlungslauf | Status |
|---:|---|---|
| 4625,00 EUR | Mietrückstand Februar bis Juni 2026 | automatisch zugeordnet |
| 965,00 EUR | laufende Miete Juli 2026 | automatisch zugeordnet |
| 200,00 EUR | Neben- und Verfahrenskosten | manuelle Prüfung |

## 3 Bearbeitungsvermerk

Der Gesamtbetrag wurde in einer Buchung überwiesen. SAP hat den Teilbetrag von 200,00 EUR zunächst auf das ungesicherte Kostenkonto gebucht. Eine konkrete Kostenaufstellung des Jobcenters liegt nicht vor. Die Buchung ist nicht mit einem Anerkenntnis der Beklagten verknüpft.
