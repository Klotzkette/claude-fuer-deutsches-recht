# Aktennotiz Nr. 1

Wohnen Berlin Immobilien GmbH
Abteilung Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Geschäftszeichen:    F-2026-00412
Mietverhältnis:      WBI-MV-2017-04231, Boxhagener Straße 47, 10245 Berlin-Friedrichshain, 4. OG rechts
Mieterin:            Aleksandra Kowalska
Verfasserin:         Sandra Berger, Renofa, Tel. 030 2055 4810
Datum:               30.07.2026
Betreff:             Schonfristzahlung Jobcenter — Konsequenzen für das laufende Räumungsverfahren (Az. 12 C 187/26)

## 1. Anlass

Das Jobcenter Friedrichshain-Kreuzberg hat mit Schreiben vom 27.07.2026 die Übernahme der Mietrückstände nach § 22 Absatz 8 SGB II erklärt und am 29.07.2026 einen Betrag von 5.790,00 EUR überwiesen. Davon entfallen 4.625,00 EUR auf die bis Juni eingeklagte Miete, 965,00 EUR auf Juli und 200,00 EUR auf Neben- und Verfahrenskosten. Die Klage wurde am 12.06.2026 eingereicht; Rechtshängigkeit trat mit Zustellung am 02.07.2026 ein. Die Zwei-Monats-Frist nach § 569 Absatz 3 Nummer 2 BGB läuft bis zum 02.09.2026. Erklärung und Zahlung erfolgten innerhalb dieser Frist.

## 2. Sachstand

### 2.1 Wirkung auf die fristlose Kündigung

Die fristlose Kündigung vom 10.04.2026 wird nach § 569 Absatz 3 Nummer 2 Satz 1 BGB unwirksam, wenn die Zahlung sämtliche bis dahin fällige Miete und Entschädigung abdeckt und in den letzten zwei Jahren keine Kündigung bereits auf diesem Weg unwirksam geworden ist. Diese beiden Punkte sind vor dem Schriftsatz abschließend zu bestätigen; Betrag und Zeitpunkt sind nach Aktenlage erfüllt.

### 2.2 Wirkung auf die hilfsweise ordentliche Kündigung

Die ordentliche Kündigung nach § 573 Absatz 2 Nummer 1 BGB wird durch die Schonfristzahlung nach der BGH-Rechtsprechung nicht automatisch unwirksam (BGH 23.07.2025 — VIII ZR 287/23; BGH 09.04.2025 — VIII ZR 145/24; BGH, Urteil vom 13.10.2021 — VIII ZR 91/20). Verschulden und Erheblichkeit sind dennoch unter Einbeziehung von Arbeitsplatzverlust, Leistungsantrag, Zahlungsverhalten, Rückstandshöhe und späterer Deckung vollständig zu würdigen. Die ordentliche Kündigung bleibt Prozessgrundlage, ihre Wirksamkeit ist aber keine automatische Folge des früheren Rückstands.

### 2.3 Prozessuale Konsequenz

Der Zahlungsantrag ist nach vollständiger Kontenprüfung in der Hauptsache für erledigt zu erklären. Stimmt die Beklagte zu oder widerspricht sie der Erledigungserklärung nicht binnen der gerichtlichen Frist nach § 91a Absatz 1 Satz 2 ZPO, entscheidet das Gericht über die Kosten nach billigem Ermessen. Widerspricht sie, ist der Antrag auf Feststellung der Erledigung weiterzuverfolgen. Der Räumungsantrag wird auf Grundlage der hilfsweise erklärten ordentlichen Kündigung aufrechterhalten, sofern die gesonderte Verschuldens- und Erheblichkeitsprüfung trägt.

## 3. Rechtliche Bewertung

Die prozessuale Reaktion hängt von der Erklärung der Beklagten ab. Bei übereinstimmender Erledigung gilt § 91a ZPO; bei Widerspruch wird die einseitige Erledigungserklärung als privilegierte Antragsänderung behandelt und die Erledigung des Zahlungsbegehrens festgestellt, wenn die Klage ursprünglich zulässig und begründet war und später gegenstandslos wurde. Beweis- und Kostenrisiko sind vor Einreichung in einer Matrix auszuweisen; BGH VIII ZB 39/24 warnt davor, bei § 91a ZPO eine vollständige Klärung schwieriger Fragen zu erwarten.

Sozialklausel-Risiko: Die Mieterin ist alleinerziehend mit zwei minderjährigen Kindern. Ein Widerspruch nach § 574 BGB ist möglich; dieser ist nach § 574b Absatz 1 BGB in Textform zu erklären und kann nach ordnungsgemäßem Hinweis grundsätzlich bis spätestens 30.11.2026 zugehen. Bei Eingang sind Härtegründe, Belege und Interessenabwägung zu dokumentieren.

## 4. Nächste Schritte

1. Schriftsatz Erledigterklärung Zahlungsantrag und Aufrechterhaltung Räumungsantrag unverzüglich einreichen (vgl. korrespondenz/schriftsatz-erledigung-weiterklage.md).
2. Wiedervorlage 30.11.2026: Widerspruch nach § 574 BGB eingegangen?
3. Falls kein Widerspruch: Vollstreckungsvorbereitung ab 01.02.2027.

## 5. Eskalation / Vorlage

Bei Eingang eines Widerspruchs nach § 574 BGB ist die Sache dem Hausjuristen vorzulegen, da die Sozialklausel-Abwägung bei alleinerziehenden Müttern mit Kindern besondere Sorgfalt erfordert.

(gez.) Sandra Berger
Renofa, Forderungsmanagement
