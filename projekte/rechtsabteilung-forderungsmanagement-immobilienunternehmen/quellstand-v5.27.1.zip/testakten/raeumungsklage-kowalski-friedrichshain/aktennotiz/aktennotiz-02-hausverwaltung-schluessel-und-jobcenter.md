# Aktennotiz 02 - Rückruf Hausverwaltung und Jobcenter-Bezug

Wohnen Berlin Immobilien GmbH

Forderungsmanagement

Bearbeiterin: Sandra Berger

Datum: 29.07.2026

## Rückruf Hausverwaltung

Frau Nickel aus der Hausverwaltung meldet telefonisch, dass Herr Kowalski seit zwei Wochen nur unregelmäßig erreichbar sei. Im Treppenhaus sei kein Auszug erkennbar. Briefkasten werde geleert. Klingelschild und Namensschild an der Wohnungstür seien unverändert vorhanden.

Die Hausverwaltung hat außerdem mitgeteilt, dass am 24.07.2026 ein Gespräch mit einer Mitarbeiterin des Jobcenters erwähnt worden sei. Eine schriftliche Bestätigung liege der Hausverwaltung nicht vor.

## Dokumentenabgleich

Das Objektbesuchsprotokoll vom 26.07.2026 und die Telefonnotiz der Hausverwaltung betreffen denselben Kellertermin, haben aber unterschiedliche Beweisqualität. Das unterzeichnete Protokoll enthält eigene Wahrnehmungen von Frau Scholz. Die Telefonnotiz gibt den späteren Rückruf von Frau Nickel wieder. Beide Dokumente belegen weder eine Wohnungsrückgabe noch eine Schlüsselübergabe.

Die Jobcenter-E-Mail, das Zahlungsavis und das SAP-Clearing sind getrennt abzulegen. Die E-Mail kündigt die Übernahme an, das Avis belegt den tatsächlichen Eingang des Sammelbetrags und das Clearing zeigt dessen interne Zuordnung. Keine dieser Unterlagen enthält eine Erklärung der Mieterin zum Räumungsantrag.

## Arbeitsstand

Schonfristzahlung und ordentliche Kündigung getrennt weiter prüfen. Eine Besitzaufgabe darf erst nach dokumentierter Schlüsselrückgabe, eindeutiger Rückgabeerklärung und tatsächlicher Zugangsmöglichkeit angenommen werden. Bis dahin bleiben Zustellanschrift, Nutzungsstatus und laufende Zahlungen auf Wiedervorlage.
