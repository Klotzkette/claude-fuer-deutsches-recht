# SAP Statusauszug — Mietkonto Kowalska

Stand: 08.06.2026 / 09:14 Uhr
Auszug aus SAP RE-FX, Transaktion FBL5N

## Geschäftspartner

- Partnernummer: 4002187
- Name: Kowalska, Aleksandra
- Geboren: 22.07.1985
- Familienstand: alleinerziehend, zwei Kinder (Jakub geb. 2014, Maja geb. 2018)
- Beruf laut Selbstauskunft 2017: Verkäuferin im Einzelhandel
- Aktueller Stand: seit 09.2025 ohne Anstellung, Arbeitslosengeld II / Bürgergeld
- Jobcenter: Friedrichshain-Kreuzberg, Frankfurter Allee 35-37, 10247 Berlin
- Aktenzeichen Jobcenter: 81234BG0085437
- Telefon: 030 5512 4499
- E-Mail: a.kowalska1985@gmx.de

## Mietobjekt

- Objektnummer: WBI-FRI-047-04R
- Adresse: Boxhagener Straße 47, 10245 Berlin-Friedrichshain
- Lage: 4. OG rechts
- Wohnfläche: 71,40 qm
- Zimmer: 3
- Baujahr Gebäude: 1908, Sanierung 2014
- Heizung: Zentral, Gas
- Warmwasser: zentral

## Vertragsdaten

- Vertragsnummer: WBI-MV-2017-04231
- Mietbeginn: 01.05.2017
- Befristung: unbefristet
- Letzte Mietanpassung: 01.07.2022 nach § 558 BGB
- Kaution: 1785,00 EUR (3 Nettokaltmieten von damals 595)
- Kautionsverwahrung: Berliner Sparkasse, Mietkautionskonto Nr. 1100789432

## Mietzins aktuell

- Nettokaltmiete: 595,00 EUR
- Betriebskostenvorauszahlung: 195,00 EUR
- Heizkostenvorauszahlung: 175,00 EUR
- Bruttowarmmiete gesamt: 965,00 EUR
- Fälligkeit: 3. Werktag des Monats

## Saldo Mietkonto

- Saldo zum 08.06.2026: 4825,00 EUR Soll
- Letzter Zahlungseingang: 03.02.2026, 200,00 EUR Teilzahlung
- Rückständige Monate: 02/2026 (Teil), 03/2026, 04/2026, 05/2026, 06/2026 = 5 Monate
- Nicht beglichene Verzugszinsen auf den Februarrest seit 05.02.2026

## Aktuelle Vorgänge

- 17.02.2026 Mahnstufe 1 versandt
- 05.03.2026 Mahnstufe 2 versandt
- 14.04.2026 Fristlose und hilfsweise ordentliche Kündigung zugestellt
- 12.06.2026 Räumungs- und Zahlungsklage eingereicht
- 02.07.2026 Rechtshängigkeit, Az. AG Kreuzberg 12 C 187/26

## Bemerkungen

- Mieterin hat am 28.05.2026 telefonisch mitgeteilt, sie habe einen Antrag beim Jobcenter auf Übernahme der Mietrückstände nach § 22 Abs. 8 SGB II gestellt
- Mietdauer aktuell 9 Jahre, daher Kündigungsfrist § 573c Abs. 1 S. 2 BGB: 9 Monate
- Ordentliche Kündigung wirksam zum 31.01.2027
