# DocuWeb Exportliste F-2026-00412

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportzeitpunkt | 29.07.2026, 08:03 Uhr |
| Interne Akte | F-2026-00412 |
| Gerichtsaktenzeichen | 12 C 187/26 |
| Vertragsnummer | WBI-MV-2017-04231 |
| Dokumente | 19 |

## 2 Trefferliste

| DMS-ID | Datum | Klasse | Indexname | Version | Statushinweis |
|---|---|---|---|---:|---|
| DW-771204 | 14.04.2017 | Vertrag | Mietvertrag_Kowalska.pdf | 1 | vollständig |
| DW-771205 | 12.06.2022 | Nachtrag | Nachtrag_1_BKV.pdf | 1 | vollständig |
| DW-889210 | 17.02.2026 | Ausgang | Mahnung_Stufe_1.pdf | 1 | Versandnachweis nicht verknüpft |
| DW-891177 | 05.03.2026 | Ausgang | Mahnung_Stufe_2.pdf | 2 | Version 1 ohne Betrag |
| DW-897731 | 14.04.2026 | Ausgang | Kuendigung_Kowalska.pdf | 3 | unterschrieben |
| DW-897732 | 14.04.2026 | Zustellung | Botenprotokoll_Kuendigung.pdf | 1 | Original im Objektbüro |
| DW-903442 | 08.06.2026 | Entwurf | Klage_12062026.docx | 7 | eingereichte Fassung gesondert |
| DW-904118 | 12.06.2026 | Gericht | Klage_eingereicht.pdf | 1 | Prüfsumme vorhanden |
| DW-906907 | 02.07.2026 | Gericht | Zustellungsnachricht_12C187-26.pdf | 1 | Frist erfasst |
| DW-908011 | 08.07.2026 | Eingang | Schreiben_Kowalska_ohne_Anlagen.pdf | 1 | Wohnungssuche erwähnt |
| DW-909371 | 22.07.2026 | Behörde | Jobcenter_Ankuendigung.pdf | 1 | Betrag im Betreff 5.790 EUR |
| DW-909880 | 26.07.2026 | Objekt | Objektbesuchsprotokoll_Kellerzugang.pdf | 1 | unterschrieben; keine Wohnungsübergabe |
| DW-910004 | 27.07.2026 | Zahlung | Bankavis_5790.pdf | 1 | Sammelbetrag |
| DW-910005 | 27.07.2026 | SAP | Clearingliste_5790.xlsx | 2 | 200 EUR auf Kostenkonto |
| DW-910188 | 28.07.2026 | Notiz | Hausverwaltung_Rueckruf.docx | 1 | Schlüsselthema unklar |
| DW-910191 | 28.07.2026 | Behörde | Mail_Jobcenter_Folgezahlung.pdf | 1 | laufende Direktzahlung nur vorläufig |
| DW-910242 | 29.07.2026 | Entwurf | Schriftsatz_Erledigung.docx | 4 | Freigabe ausstehend |
| DW-910243 | 29.07.2026 | Sonstiges | scan-neu-2.pdf | 1 | Dublette DW-909371 |
| DW-910244 | 29.07.2026 | Tabelle | Fristenblatt_12C187-26.xlsx | 1 | gelbe Wiedervorlage |

## 3 Indexabweichung

Der Dateiname DW-903442 trägt das Datum 12.06.2026, obwohl das Dokument am 08.06.2026 erstellt wurde. Maßgeblich für die Einreichung ist der Prüfvermerk vom 12.06.2026. DW-910243 ist nach Hashvergleich inhaltsgleich mit DW-909371.

Das Objektbesuchsprotokoll vom 26.07.2026 belegt weder Besitzaufgabe noch
Schlüsselrückgabe. Die Jobcenter-E-Mail vom 28.07.2026 erläutert Zahlung und
vorläufige Direktzahlung, enthält aber keine Übernahme von Prozesskosten oder
künftiger Nutzungsentschädigung.
