# Testakte 2 — Räumungsklage Kowalski Friedrichshain mit Schonfristzahlung


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 66 KB) | PDF | [testakte-raeumungsklage-kowalski-friedrichshain-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-raeumungsklage-kowalski-friedrichshain-gesamt.pdf) | [`gesamt-pdf/raeumungsklage-kowalski-friedrichshain_gesamt.pdf`](gesamt-pdf/raeumungsklage-kowalski-friedrichshain_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-raeumungsklage-kowalski-friedrichshain.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-raeumungsklage-kowalski-friedrichshain.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-raeumungsklage-kowalski-friedrichshain-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-raeumungsklage-kowalski-friedrichshain-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Kündigung, Räumungsklage, Schonfristzahlung, teilweise Erledigung und Fortführung der ordentlichen Kündigung |
| Startskills | `13-fristlose-kuendigung-zahlungsverzug`, `15-kuendigung-zustellung-nachweis`, `24-raeumungsklage-erstellen`, `27-schonfristzahlung-erkennen` |
| Kernentscheidung | Welche Anträge bleiben nach Jobcenter-Zahlung bestehen und welcher Kostenweg ist rechtlich tragfähig? |
| Besonderheit | Jobcenter-Zahlung, angekündigte Direktzahlung, Schlüsselstand und Besitzlage sind getrennte Spuren. Weder die Behördenmail noch der Objektbesuch belegen vollständige Räumung oder Prozesskostenübernahme. |

Eskalierter Fall: Mietrückstand, Kündigung, Räumungsklage. **Im laufenden Verfahren leistet das Jobcenter eine Schonfristzahlung** — die fristlose Kündigung wird unwirksam, die ordentliche Kündigung ist nach Verschulden, Erheblichkeit und Sozialklausel-Risiko weiter zu prüfen. Rechtsfachwirtin muss den Schriftsatz umstellen.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Mieterin | Aleksandra Kowalska, geb. 22.07.1985, alleinerziehend, 2 Kinder |
| Mietobjekt | Boxhagener Straße 47, 10245 Berlin-Friedrichshain, 4. OG rechts |
| Wohnfläche | 71,40 qm |
| Vertragsabschluss | 14.04.2017 |
| Mietbeginn | 01.05.2017 |
| Nettokaltmiete | 595,00 EUR |
| BK-VZ | 195,00 EUR |
| HK-VZ | 175,00 EUR |
| Bruttowarmmiete | 965,00 EUR |
| Aktenzeichen | F-2026-00412 |

## Sachverhalt-Skizze

- Mieterin verlor Arbeit Januar 2026, beantragte Bürgergeld
- Februar 2026 teilweise sowie März bis Juni 2026 vollständig offen: **4625,00 EUR Mietrückstand**; mit 200,00 EUR gesondert gebuchten Mahn-, Zins- und Verfahrenskosten beträgt der SAP-Gesamtsaldo 4825,00 EUR
- Mahnungen 17.02.2026 (Stufe 1) und 05.03.2026 (Stufe 2) fruchtlos
- Fristlose und hilfsweise ordentliche Kündigung am 14.04.2026 zugestellt; ordentliches Mietverhältnis endet zum **31.01.2027** (Mietdauer über 8 Jahre = 9 Monate Frist nach § 573c Abs. 1 S. 2 BGB; Kündigung im April 2026 zugegangen, daher Frist ab Mai 2026 und Wirksamkeit zum 31.01.2027)
- Klage am 12.06.2026 eingereicht, Zustellung an die Mieterin am 02.07.2026 (Rechtshängigkeit)
- **27.07.2026**: Jobcenter Friedrichshain-Kreuzberg übernimmt **5790,00 EUR** (4625,00 EUR Mietrückstand bis Juni, 965,00 EUR Juli und 200,00 EUR Neben- und Verfahrenskosten) und kündigt schriftlich an, laufende Mieten zu zahlen (§ 22 Abs. 8 SGB II)
- Innerhalb 2-Monats-Schonfristfenster § 569 Abs. 3 Nr. 2 BGB

## Bearbeiterin

Rechtsfachwirtin Sandra Berger.

## Skill-Lauf

01-05 Aktenintake → 06-08 Triage (Rechtsfachwirtin selbst, Streitwert AG-Sache stets) → 09-12 Mahnungen → 13-16 Kündigung mit Sozialklausel-Risiko → 17-23 Klage → **27 Schonfristzahlung erkennen** → Schriftsatz Erledigung Hauptsache fristlose Kündigung + Weiterverfolgung ordentliche Kündigung.

## Akte

- [sap/sap-statusauszug.md](sap/sap-statusauszug.md)
- [vertrag/mietvertrag.md](vertrag/mietvertrag.md)
- [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md)
- [aktennotiz/aktennotiz-01-schonfristzahlung-schriftsatzumstellung.md](aktennotiz/aktennotiz-01-schonfristzahlung-schriftsatzumstellung.md)
- [aktennotiz/aktennotiz-02-hausverwaltung-schluessel-und-jobcenter.md](aktennotiz/aktennotiz-02-hausverwaltung-schluessel-und-jobcenter.md)
- [korrespondenz/kündigung.md](korrespondenz/kuendigung.md)
- [korrespondenz/klage-entwurf.md](korrespondenz/klage-entwurf.md)
- [korrespondenz/jobcenter-übernahme.md](korrespondenz/jobcenter-uebernahme.md)
- [korrespondenz/schriftsatz-erledigung-weiterklage.md](korrespondenz/schriftsatz-erledigung-weiterklage.md)
- [dms/dms-exportliste-verfahrensstand.md](dms/dms-exportliste-verfahrensstand.md)
- [gericht/zustellungsnachricht-klage-2026-07-02.md](gericht/zustellungsnachricht-klage-2026-07-02.md)
- [zahlung/zahlungsavis-jobcenter-2026-07-27.md](zahlung/zahlungsavis-jobcenter-2026-07-27.md)
- [jobcenter/berechnungsbogen-schonfristzahlung.md](jobcenter/berechnungsbogen-schonfristzahlung.md)
- [hausverwaltung/telefonnotiz-wohnungsbesuch.md](hausverwaltung/telefonnotiz-wohnungsbesuch.md)
- [korrespondenz/email-mieterin-wohnungssuche.md](korrespondenz/email-mieterin-wohnungssuche.md)
- [hausverwaltung/objektbesuchsprotokoll-2026-07-26.md](hausverwaltung/objektbesuchsprotokoll-2026-07-26.md)
- [korrespondenz/email-jobcenter-folgezahlung.md](korrespondenz/email-jobcenter-folgezahlung.md)
