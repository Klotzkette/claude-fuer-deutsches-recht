# Kündigung fristlos und hilfsweise ordentlich

```
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99, 10117 Berlin


                                                Herrn
                                                Thomas Meier
                                                Wilhelmstraße 14
                                                10963 Berlin
                                                3. OG links

                                                Berlin, 04.05.2026

Mietverhältnis Wilhelmstraße 14, 10963 Berlin, 3. OG links
Vertragsnummer MV-2019-04217


Außerordentliche fristlose Kündigung wegen Mietzahlungsverzug
Hilfsweise ordentliche Kündigung


Sehr geehrter Herr Meier,

namens und im Auftrag der Wohnen Berlin Immobilien GmbH erkläre ich
hiermit gegenüber Ihnen

  die außerordentliche fristlose Kündigung
  des Mietverhältnisses über die Wohnung Wilhelmstraße 14,
  10963 Berlin, 3. OG links, mit sofortiger Wirkung
  (§ 543 Abs. 2 S. 1 Nr. 3 BGB i.V.m. § 569 Abs. 3 Nr. 1 BGB),

  hilfsweise die ordentliche Kündigung zum Ablauf des
  31.10.2026 (Frist § 573c Abs. 1 BGB; Mietdauer
  über 5, aber unter 8 Jahre = 6 Monate Kündigungsfrist).
  Zugang 04.05.2026 liegt innerhalb der ersten drei Werktage des
  Mai 2026; der Samstag ist bei § 573c Abs. 1 BGB mitzuzählen,
  wenn er nicht letzter Tag der Karenzfrist ist (BGH 27.04.2005 —
  VIII ZR 206/04). Mai zählt mit.


Begründung

Sie befinden sich mit den Mieten Februar bis April 2026 in einem
nicht unerheblichen Mietrückstand. Der offene Saldo beträgt zum
heutigen Tage EUR 3040,00 (Februar EUR 680,00 nach Verrechnung der
Teilzahlung, März EUR 1180,00 und April EUR 1180,00). Die Miete für
Mai 2026 ist am 04.05.2026 noch nicht fällig und wird nicht als
Kündigungsrückstand angesetzt.

Damit liegen die Voraussetzungen des § 543 Abs. 2 S. 1 Nr. 3
Buchst. b BGB i.V.m. § 569 Abs. 3 Nr. 1 BGB vor: Rückstand
in Höhe von mehr als zwei Monatsmieten (EUR 3040 > 2 x EUR 1180) bei einem
länger als einen Termin sich erstreckenden Zeitraum. Auch § 543
Abs. 2 S. 1 Nr. 3 Buchst. a BGB ist erfüllt (Verzug über zwei
aufeinander folgende Termine in nicht unerheblicher Höhe).

Trotz zweier Mahnungen (16.03.2026 und 08.04.2026) und mehrfach
gesetzter Fristen haben Sie weder gezahlt noch sich gemeldet.

Mit der hilfsweise ausgesprochenen ordentlichen Kündigung verfolgen
wir das berechtigte Interesse § 573 Abs. 1, Abs. 2 Nr. 1 BGB
wegen schuldhafter, nicht unerheblicher Pflichtverletzung. Diese
Kündigung wird nach gefestigter Rechtsprechung (BGH 23.07.2025 —
VIII ZR 287/23; BGH 09.04.2025 — VIII ZR 145/24; BGH 16.02.2005 —
VIII ZR 6/04) durch eine etwaige spätere Schonfristzahlung nach
§ 569 Abs. 3 Nr. 2 BGB nicht automatisch unwirksam. Eine
spätere Zahlung ist bei Verschulden und Erheblichkeit nach §
573 Abs. 2 Nr. 1 BGB zu würdigen.


HINWEIS PARAGRAF 568 ABS. 2 BGB

Sie können der ordentlichen Kündigung nach § 574 BGB
widersprechen, wenn die Beendigung des Mietverhältnisses für Sie
oder Ihre Familie eine Härte bedeuten würde, die auch unter
Würdigung der berechtigten Interessen der Vermieterin nicht zu
rechtfertigen wäre. Der Widerspruch ist in Textform zu erklären,
spätestens zwei Monate vor dem Beendigungstermin (31.10.2026), also
bis 31.08.2026.


HINWEIS PARAGRAF 569 ABS. 3 NR. 2 BGB

Die fristlose Kündigung wird unwirksam, wenn Sie spätestens zwei
Monate nach Eintritt der Rechtshängigkeit einer etwaigen
Räumungsklage durch Zahlung oder durch Erklärung einer öffentlichen
Stelle die rückständige Forderung vollständig ausgleichen. Diese
Heilung gilt nur einmal innerhalb von zwei Jahren.


HERAUSGABEAUFFORDERUNG

Sie sind verpflichtet, die Wohnung spätestens am 11.05.2026 vollständig
geräumt an die Vermieterin herauszugeben. Vereinbaren Sie hierzu bitte
einen Übergabetermin mit unserem Hausmeisterservice unter
030/123456-12 (Frau Berger).


WEITERE SCHRITTE

Sollten Sie weder zahlen noch räumen, werden wir kombinierte
Zahlungs- und Räumungsklage zum Amtsgericht Kreuzberg erheben
(§ 23 Nr. 2a GVG, § 29a ZPO).

Mit freundlichen Grüßen
Wohnen Berlin Immobilien GmbH

Dr. Markus Lehmann (gez.)
Geschäftsführer
```

Zustellung: Bote (Hausmeisterservice Mitte) am 04.05.2026 14:30 Uhr in den Briefkasten Wilhelmstraße 14. Botenversicherung schriftlich. Zusätzlich Einwurf-Einschreiben RR3456789012DE Einwurf 06.05.2026.
