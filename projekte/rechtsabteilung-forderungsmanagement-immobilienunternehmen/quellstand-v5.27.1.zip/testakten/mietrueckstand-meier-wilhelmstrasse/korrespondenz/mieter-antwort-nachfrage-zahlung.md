# E-Mail des Mieters zur angeblichen Zahlung

Von: thomas.meier.private@example.net

An: forderungsmanagement@wohnen-berlin-immobilien.de

Datum: 18.06.2026, 22:41 Uhr

Betreff: Re: Ihr Schreiben wegen Rückstand

Guten Abend Frau Berger,

ich habe die Zahlung eigentlich schon angewiesen. Meine Schwester hatte mir dabei geholfen, weil ich im Onlinebanking nicht mehr reinkam. Ich finde den Beleg gerade nicht, vermutlich ist er auf dem alten Handy.

Bitte warten Sie noch ein paar Tage. Ich will keinen Ärger und ich melde mich morgen noch einmal, wenn ich in der Filiale war. Falls doch nichts angekommen ist, können wir eventuell eine Rate vereinbaren.

Mit freundlichen Grüßen

Thomas Meier

---

Weitergeleitete Notiz aus dem Posteingang:

Scanqualität der angehängten Bildschirmaufnahme schlecht. Angezeigter Betrag nicht lesbar. Kein Zahlungsempfänger erkennbar.
