# Entwurf Kombinierte Zahlungs- und Räumungsklage

```
An das
Amtsgericht Kreuzberg
Möckernstraße 130
10963 Berlin


                                                Berlin, 19.06.2026

Klage


der Wohnen Berlin Immobilien GmbH
   Friedrichstraße 99, 10117 Berlin
   vertreten durch den Geschäftsführer Dr. Markus Lehmann
                                                Klägerin
   prozessbevollmächtigt vertreten durch die
   Rechtsfachwirtin Frau Sandra Berger
   nach § 79 Abs. 2 S. 2 Nr. 1 ZPO

                gegen

Herrn Thomas Meier
   Wilhelmstraße 14, 10963 Berlin, 3. OG links
                                                Beklagter


wegen Mietrückstand und Räumung


Vorläufiger Streitwert
- Zahlungsforderung:                    EUR  4 220,00
- Räumung (1 Jahresnettomiete):        EUR  8 640,00
- gesamt:                               EUR 12 860,00


Klageanträge

1. Der Beklagte wird verurteilt, an die Klägerin EUR 4 220,00
   nebst Zinsen in Höhe von 5 Prozentpunkten über dem Basiszinssatz
   aus EUR  680,00 seit dem 05.02.2026,
   aus EUR 1 180,00 seit dem 05.03.2026,
   aus EUR 1 180,00 seit dem 08.04.2026 und
   aus EUR 1 180,00 seit dem 07.05.2026
   zu zahlen.

2. Der Beklagte wird verurteilt, die im 3. Obergeschoss links des
   Hauses Wilhelmstraße 14, 10963 Berlin, gelegene Wohnung,
   bestehend aus 3 Zimmern, Küche, Bad, WC, Diele, Balkon und
   Kellerabteil Nr. 14L, mit einer Wohnfläche von 64,80 qm, zu
   räumen und vollständig geräumt an die Klägerin
   herauszugeben.

3. Die Kosten des Rechtsstreits trägt der Beklagte.

4. Das Urteil ist vorläufig vollstreckbar; der Beklagte darf die
   Vollstreckung durch Sicherheitsleistung abwenden.


Begründung

I. Sachverhalt

Die Klägerin ist eingetragene Eigentümerin des Mehrfamilienhauses
Wilhelmstraße 14, 10963 Berlin. Die im Antrag bezeichnete Wohnung
hat sie mit Wohnraummietvertrag vom 17.07.2019 (Anlage K1) an den
Beklagten zu einer Bruttowarmmiete von zuletzt EUR 1180,00 (davon
Netto-Kalt EUR 720,00, BK EUR 240,00, HK EUR 220,00) vermietet.

Nachtrag 1 zum Mietvertrag vom 02.09.2021 (Anlage K2) hob die
Nettokaltmiete im Wege einer einvernehmlichen Mieterhöhung nach
§ 558 BGB ab dem 01.10.2021 von EUR 660,00 auf EUR 720,00 an.

Die Miete ist nach § 3 des Mietvertrages und § 556b
BGB monatlich im Voraus, spätestens am 3. Werktag des Monats, zu
zahlen.

Seit Februar 2026 ist der Beklagte mit Mietzahlungen in Verzug. Die
einzelnen Mietzahlungen ergeben sich aus der nachfolgenden Aufstellung
und dem Mietkontoauszug (Anlage K3):

  Monat   Soll         Ist         Saldo        Verzugsbeginn
  02 2026 EUR 1180,00  EUR  500,00 EUR  680,00  05.02.2026 [1]
  03 2026 EUR 1180,00  EUR    0,00 EUR 1180,00  05.03.2026 [1]
  04 2026 EUR 1180,00  EUR    0,00 EUR 1180,00  08.04.2026
  05 2026 EUR 1180,00  EUR    0,00 EUR 1180,00  07.05.2026

  [1] Verrechnung der Teilzahlung 15.03.2026 in Höhe von EUR 500,00
      nach § 366 Abs. 2 BGB auf die älteste fällige Schuld
      (Februar 2026).

  Beweis: Anlage K3 (Mietkonto-Auszug FBL5N vom 18.06.2026).

Die Klägerin hat den Beklagten mit Schreiben vom 16.03.2026
(Anlage K4) und 08.04.2026 (Anlage K5) gemahnt. Die zweite Mahnung
enthielt eine Klageandrohung und Hinweise auf Sozialleistungsträger.

Der Beklagte hat bis zu seiner E-Mail vom 18.06.2026 nicht reagiert.
Die dort behauptete weitere Zahlung ist weder im Mietkonto eingegangen
noch durch einen lesbaren Zahlungsbeleg nachgewiesen.

Mit Schreiben vom 04.05.2026 (Anlage K6) hat die Klägerin gegenüber
dem Beklagten die außerordentliche fristlose Kündigung des
Mietverhältnisses nach § 543 Abs. 2 S. 1 Nr. 3 BGB i.V.m.
§ 569 Abs. 3 Nr. 1 BGB erklärt und hilfsweise die ordentliche
Kündigung zum Ablauf des 31.10.2026 ausgesprochen (Frist 6 Monate
bei Mietdauer über 5, aber unter 8 Jahren, § 573c Abs. 1
BGB; Zugang 04.05.2026 innerhalb der ersten drei Werktage des Mai
2026, BGH 27.04.2005 — VIII ZR 206/04).

Das Kündigungsschreiben ist dem Beklagten am 04.05.2026 über den
Boten zugegangen (Anlage K7 Botenbescheinigung) sowie zusätzlich
durch Einwurf-Einschreiben am 06.05.2026.

Der Beklagte hat die Wohnung trotz Aufforderung zum 11.05.2026 nicht
geräumt und nichts auf den Rückstand gezahlt.


II. Rechtliche Würdigung

1. Zahlungsanspruch

Der Anspruch auf Zahlung der rückständigen Miete ergibt sich aus
§ 535 Abs. 2 BGB. Die Miete ist nach § 4 Mietvertrag
i.V.m. § 556b BGB jeweils zum 3. Werktag des Monats fällig.

Der Verzug tritt nach § 286 Abs. 2 Nr. 1 BGB kraft Gesetzes
ein.

Die Verzugszinsen sind nach § 288 Abs. 1 BGB in Höhe von
5 Prozentpunkten über dem Basiszinssatz geschuldet.

2. Wirksamkeit der fristlosen Kündigung

Die fristlose Kündigung ist nach § 543 Abs. 2 S. 1 Nr. 3
Buchst. b BGB i.V.m. § 569 Abs. 3 Nr. 1 BGB wirksam. Der
Rückstand belief sich zum Kündigungszeitpunkt 04.05.2026 auf
EUR 3 040,00 und damit auf mehr als zwei Monatsmieten
(2 x EUR 1 180,00 = EUR 2 360,00) bei einem länger als einen Termin
sich erstreckenden Zeitraum. Daneben sind zugleich auch die
Voraussetzungen des § 543 Abs. 2 S. 1 Nr. 3 Buchst. a BGB
erfüllt (Verzug an zwei aufeinander folgenden Terminen mit einem
nicht unerheblichen Teil der Miete).

Die Kündigung ist formgerecht § 568 Abs. 1 BGB schriftlich
unter Hinweis auf das Widerspruchsrecht nach § 574 BGB
erklärt worden.

3. Hilfsweise ordentliche Kündigung

Die hilfsweise ausgesprochene ordentliche Kündigung § 573
Abs. 2 Nr. 1 BGB greift mangels Erfüllung. Die Klägerin verfolgt
ein berechtigtes Interesse, da der Beklagte seine Hauptpflicht aus
dem Mietvertrag schuldhaft und nicht unerheblich verletzt.

Eine etwaige spätere Schonfristzahlung nach § 569 Abs. 3 Nr. 2
BGB beseitigt nur die fristlose, nicht automatisch die hilfsweise
erklärte ordentliche Kündigung (BGH 23.07.2025 — VIII ZR 287/23;
BGH 09.04.2025 — VIII ZR 145/24; BGH 16.02.2005 — VIII ZR 6/04).
Die Zahlung bleibt bei Verschulden und Erheblichkeit nach §
573 Abs. 2 Nr. 1 BGB zu würdigen.

4. Räumungsanspruch

Der Räumungsanspruch ergibt sich aus § 546 Abs. 1 BGB.


III. Zuständigkeit

Sachlich § 23 Nr. 2a GVG (Wohnraummiete stets Amtsgericht).
Örtlich § 29a ZPO (ausschließlich Lageort).


IV. Anlagen

K1 Mietvertrag vom 17.07.2019
K2 Nachtrag 1 vom 02.09.2021
K3 Mietkonto FBL5N Stand 18.06.2026
K4 Mahnung 1 vom 16.03.2026
K5 Mahnung 2 vom 08.04.2026
K5a E-Mail des Beklagten vom 18.06.2026
K6 Kündigungsschreiben vom 04.05.2026
K7 Botenbescheinigung vom 04.05.2026


Sandra Berger
Rechtsfachwirtin
Vollmacht beigefügt (Anlage K0)
```
