# Mahnung 1

```
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin


                                                Herrn
                                                Thomas Meier
                                                Wilhelmstraße 14
                                                10963 Berlin
                                                3. OG links

                                                Berlin, 16.03.2026

Mietverhältnis Wilhelmstraße 14, 10963 Berlin, 3. OG links
Vertragsnummer MV-2019-04217
Zahlungserinnerung Mieten 02 und 03 2026


Sehr geehrter Herr Meier,

wir bedauern feststellen zu müssen, dass folgende Mieten nicht
vollständig auf unserem Konto eingegangen sind:

  Februar 2026   EUR 1180,00 offen
  März 2026     EUR  680,00 offen (nach Berücksichtigung
                                    Ihrer Teilzahlung am 15.03.2026)
  -------------------------------
  Summe          EUR 1860,00 offen

Wir bitten Sie, den offenen Betrag bis zum **30.03.2026** auf unser
Konto

  IBAN: DE89 1001 0010 0987 6543 21
  BIC:  BELADEBEXXX
  bei der Berliner Sparkasse,
  Verwendungszweck: MV-2019-04217 Mietrückstand 02-03 2026

zu überweisen.

Sollten Sie sich in einer Zahlungsschwierigkeit befinden, kontaktieren
Sie uns bitte unter der Telefonnummer 030/123456-12 (Frau Berger). Wir
sind grundsätzlich zu einer Ratenvereinbarung bereit.

Wir bitten Sie freundlich, der Sache umgehend abzuhelfen.

Mit freundlichen Grüßen
Wohnen Berlin Immobilien GmbH

Sandra Berger
Rechtsfachwirtin
Abteilung Forderungsmanagement
```

Zustellung: Einwurf-Einschreiben Sendungsnummer RR1234567890DE, Einwurf am 18.03.2026 um 11:42 Uhr in den Briefkasten Wilhelmstraße 14 (Zustellnachweis Deutsche Post DHL).
