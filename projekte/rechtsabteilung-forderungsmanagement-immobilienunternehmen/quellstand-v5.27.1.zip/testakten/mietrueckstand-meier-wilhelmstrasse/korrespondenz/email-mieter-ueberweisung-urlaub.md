# E-Mail-Ausdruck: Überweisung müsste angekommen sein

## 1 Kopfzeilen

| Feld | Inhalt |
|---|---|
| Von | Thomas Meier, th.meier72@posteo-beispiel.de |
| An | forderungsmanagement@wohnen-berlin-immobilien.de |
| Datum | 19.06.2026, 06:12 Uhr |
| Betreff | AW: Nachfrage Zahlung / bin unterwegs |
| Nachrichten-ID | 202606190612.7719@mail.posteo-beispiel.de |

## 2 Nachricht

Guten Morgen Frau Berger,

ich bin bis Sonntag bei meiner Schwester in Rostock und komme nicht an die Unterlagen. Das Geld müsste aber raus sein. Ich hatte gestern geschrieben, dass ich den Screenshot mitschicke. Offenbar hat mein Handy den Anhang nicht hochgeladen. In der Banking-App steht bei mir nur „vorgemerkt“. Den genauen Betrag kann ich gerade nicht sehen, ich meine aber 1.180 Euro.

Bitte reichen Sie noch nichts beim Gericht ein. Ich rufe am Montag gegen Mittag an und schicke dann den Kontoauszug. Die Juni-Miete ist jedenfalls bezahlt worden.

Viele Grüße

Thomas Meier

## 3 Anlagenstatus

Im DMS ist zu dieser Nachricht kein Anhang gespeichert. Der in der Nachricht erwähnte Screenshot liegt weder im Posteingang noch im Spam-Quarantäneexport vor.
