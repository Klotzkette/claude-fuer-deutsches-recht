# Mahnung 2 mit Klageandrohung

```
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99, 10117 Berlin


                                                Herrn
                                                Thomas Meier
                                                Wilhelmstraße 14
                                                10963 Berlin
                                                3. OG links

                                                Berlin, 08.04.2026

Mietverhältnis Wilhelmstraße 14, 10963 Berlin, 3. OG links
Vertragsnummer MV-2019-04217

ZWEITE MAHNUNG - KLAGEANDROHUNG


Sehr geehrter Herr Meier,

auf unsere Zahlungserinnerung vom 16.03.2026 haben wir bisher weder
eine Reaktion noch den dort genannten Betrag erhalten. Mittlerweile
ist die Miete für April 2026 ebenfalls vollständig fällig und
unbeglichen.

Offene Forderungen Stand 08.04.2026 nach gesetzlicher Verrechnung:

  Februar 2026   EUR  680,00 offen (nach Teilzahlung EUR 500,00)
  März 2026      EUR 1180,00 offen
  April 2026     EUR 1180,00 offen
  -------------------------------
  Summe          EUR 3040,00 offen
                       zzgl. Verzugszinsen 5 Prozentpunkte über
                       Basiszinssatz seit Verzugseintritt

Sie befinden sich mit der Mietzahlung in Verzug § 286 Abs. 2
Nr. 1 BGB i.V.m. § 556b BGB.

Wir setzen Ihnen letzte Frist bis zum **22.04.2026**, den
Gesamtbetrag auszugleichen.

Sollte der Betrag bis dahin nicht vollständig auf unserem Konto sein,
werden wir:

  1. das Mietverhältnis fristlos kündigen
     (§ 543 Abs. 2 S. 1 Nr. 3 BGB, § 569 Abs. 3 Nr. 1 BGB),
  2. hilfsweise ordentlich kündigen wegen Pflichtverletzung
     (§ 573 Abs. 2 Nr. 1 BGB),
  3. Zahlungs- und Räumungsklage erheben.

Hinweise auf Folgekosten:
  - Gerichtskosten nach dem bei Klageeinreichung geltenden GKG
  - Vollstreckungskosten, falls erforderlich
  - Laufende Verzugszinsen

Sollten Sie unverschuldet in Zahlungsschwierigkeiten sein, können
Sie sich an das Jobcenter (Mietübernahme nach § 22 Abs. 8
SGB II) oder das Sozialamt wenden. Wir sind grundsätzlich auch
weiterhin zu einer Ratenvereinbarung bereit.

Mit freundlichen Grüßen
Wohnen Berlin Immobilien GmbH

Sandra Berger
Rechtsfachwirtin, Abteilung Forderungsmanagement
```

Zustellung: Einwurf-Einschreiben RR2345678901DE und Bote (Hausmeisterservice Mitte), Zustellbeleg 10.04.2026 um 09:55 Uhr.
