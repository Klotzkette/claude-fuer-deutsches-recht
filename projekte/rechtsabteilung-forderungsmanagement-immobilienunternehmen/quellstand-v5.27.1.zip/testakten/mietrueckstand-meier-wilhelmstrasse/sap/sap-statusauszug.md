# SAP-Statusauszug (PDF-Replik)

```
=========================================================================
WOHNEN BERLIN IMMOBILIEN GMBH                          SAP-Status RE-FX
Vertragsstatus per 18.06.2026                          Druck 18.06.2026
=========================================================================

OBJ-Nr.        : OBJ-10963-WIL-014-03L
Objektadresse  : Wilhelmstraße 14, 10963 Berlin, 3. OG links
Objekttyp      : Wohnung Mietwohnraum

VERTRAGSDATEN
Vertragsnummer : MV-2019-04217
Mietbeginn     : 01.08.2019
Befristung     : unbefristet
Schriftform    : Vertrag vom 17.07.2019 + Nachtrag 1 vom 02.09.2021
Mietzweck      : ausschließlich Wohnzwecke

VERMIETERIN
Name           : Wohnen Berlin Immobilien GmbH
Anschrift      : Friedrichstraße 99, 10117 Berlin
HRB            : Amtsgericht Charlottenburg HRB 198765 B
USt-ID         : DE314159265
Vertretungsorg : Dr. Markus Lehmann, einzelvertretungsberechtigt

MIETER
Debitor-Nr     : DK-2019-08812
Name           : Meier, Thomas
Geburtsdatum  : 14.03.1972
Beruf          : Lagermitarbeiter Logistikkonzern Mitte
Anschrift      : Wilhelmstraße 14, 10963 Berlin, 3. OG links

KONDITIONEN
Wohnfläche    : 64.80 qm (Wohnflächenberechnung 17.07.2019)
Grundmiete     : EUR 720.00 monatlich
BK-VZ          : EUR 240.00 monatlich
HK-VZ          : EUR 220.00 monatlich
SUMME          : EUR 1180.00 monatlich Bruttowarmmiete

Letzte Anpassung: 01.10.2021 (Mieterhöhung von EUR 660 auf EUR 720
                  Nettokalt, Berliner Mietspiegel 2021 Feld D3)

KAUTION
Höhe          : EUR 1980.00 = 3 Nettokaltmieten bei Vertragsschluss
Form           : Sparbuch verpfändet bei Berliner Sparkasse Filiale Mitte
Quittung       : Anlage Mietvertrag

KONTO
Sollstellung gesamt    : EUR 84840.00 (Stand 18.06.2026, seit 01.08.2019)
Ist-Zahlung gesamt    : EUR 80620.00
Offene Posten          : EUR  4220.00

OFFENE POSTEN (Monatsübersicht)
Monat   Sollstellung   Ist-Zahlung   Saldo
02 2026 EUR 1180.00    EUR    0.00   EUR 1180.00
03 2026 EUR 1180.00    EUR  500.00   EUR  680.00
04 2026 EUR 1180.00    EUR    0.00   EUR 1180.00
05 2026 EUR 1180.00    EUR    0.00   EUR 1180.00

SUMME OFFEN: EUR 4220.00

VERZUGSDATEN
Verzug ab     : 05.02.2026 (Fälligkeit 04.02.2026 verstrichen)
Verzugszinssatz: Basiszins + 5 Prozentpunkte § 288 Abs. 1 BGB

KORRESPONDENZ
Mahnung 1     : 16.03.2026 (Einwurf-Einschreiben, Zugang 18.03.2026)
Mahnung 2     : 08.04.2026 (Einwurf-Einschreiben + Bote, Zugang 10.04.2026)
Letzte Frist  : 22.04.2026, fruchtlos verstrichen

WIEDERVORLAGE
Fristlauf     : Rechtsfachwirtin-Vorlage 18.06.2026
Nächster Schritt: Letzte Frist setzen oder direkte Kündigung prüfen

=========================================================================
ENDE STATUSAUSZUG
=========================================================================
```
