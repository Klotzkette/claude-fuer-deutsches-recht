# Mieterdatenblatt Abgleich

## 1 Stammdaten aus drei Systemen

| Feld | SAP RE-FX | DocuWeb Index | Hausverwaltung |
|---|---|---|---|
| Name | Thomas Meier | Thomas Meier | T. Meier |
| Geburtsdatum | 14.03.1972 | 14.03.1972 | nicht geführt |
| Vertragsnummer | MV-2019-04217 | MV-2019-04217 | 04217 |
| Wohnung | Wilhelmstraße 14, 3. OG links | Wilhelmstr. 14 / 3OL | Whg. 12 |
| Mobilnummer | 0176 4819 2207 | 0176 4819 2207 | 0176 4819 2270 |
| E-Mail | thomas.meier72@posteo-beispiel.de | th.meier72@posteo-beispiel.de | leer |
| Bankeinzug | nein | Altindex: ja | nein |
| Briefkastenschild | nicht geführt | nicht geführt | T. Meier |

## 2 Prüfvermerk

Die abweichende Mobilnummer der Hausverwaltung endet auf 2270 statt 2207. Ein Rückruf am 19.06.2026 unter 2270 führte zu einer fremden Mailbox ohne Namensansage. Für Schriftverkehr bleibt die Vertragsanschrift maßgeblich. Der DocuWeb-Index „Bankeinzug: ja“ stammt aus der Migrationsdatei von 2019; ein SEPA-Mandat ist in der Vertragsakte nicht vorhanden.
