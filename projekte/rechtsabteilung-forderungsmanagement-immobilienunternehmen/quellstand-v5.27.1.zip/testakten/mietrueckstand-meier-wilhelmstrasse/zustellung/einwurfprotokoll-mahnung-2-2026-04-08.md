# Einwurfprotokoll

Wohnen Berlin Immobilien GmbH

Forderungsmanagement

## 1. Sendung

| Feld | Inhalt |
|---|---|
| Akte | F-2026-00347 |
| Empfänger | Thomas Meier |
| Anschrift | Wilhelmstraße 14, 10963 Berlin |
| Dokument | Zweite Mahnung vom 08.04.2026 |
| Umschlag | verschlossen, Fensterumschlag C5 |
| Anlagen | Forderungsaufstellung mit Stand 08.04.2026 |

## 2. Einwurf

Ich, Leyla Yilmaz, Mitarbeiterin des Hausmeisterservice Mitte, habe den verschlossenen Umschlag am 08.04.2026 um 17:46 Uhr in den zur Wohnung 3. Obergeschoss links gehörenden Hausbriefkasten eingeworfen.

Am Briefkasten befand sich ein gut lesbares Namensschild „Meier“. Der Umschlag glitt vollständig durch den Einwurfschlitz. Er blieb weder sichtbar im Schlitz stecken noch wurde er mir zurückgegeben.

Die Hausnummer 14 und die Briefkastenanlage im Erdgeschoss wurden vor dem Einwurf mit dem internen Mobilgerät fotografiert. Das Foto trägt die Dateibezeichnung `IMG_20260408_174559.jpg`. Es zeigt nicht den Inhalt des Umschlags.

## 3. Anwesenheit

Ralf Nowak, Objektbetreuer Süd, war beim Einwurf anwesend. Eine persönliche Übergabe oder ein Gespräch mit Herrn Meier fand nicht statt.

Berlin, 08.04.2026

Leyla Yilmaz

Ralf Nowak
