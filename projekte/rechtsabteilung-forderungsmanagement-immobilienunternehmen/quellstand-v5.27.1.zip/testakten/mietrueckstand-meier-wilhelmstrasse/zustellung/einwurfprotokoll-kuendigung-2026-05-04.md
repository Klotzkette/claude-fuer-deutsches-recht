# Einwurfprotokoll Kündigung

## 1 Sendung

| Feld | Inhalt |
|---|---|
| Auftraggeberin | Wohnen Berlin Immobilien GmbH |
| Empfänger | Thomas Meier |
| Anschrift | Wilhelmstraße 14, 10963 Berlin, 3. OG links |
| Dokument | Kündigung vom 04.05.2026, sechs Blatt |
| Umschlag | weiß, C4, verschlossen, Sichtfenster |

## 2 Durchführung

Ich, Aylin Yilmaz, Mitarbeiterin des Hausmeisterservice Mitte, habe den oben bezeichneten Umschlag am 04.05.2026 um 14:30 Uhr in den zur Wohnung 3. OG links gehörenden Briefkasten eingeworfen. Der Briefkasten war mit „T. Meier“ beschriftet. Der Umschlag fiel vollständig in den Briefkasten und war von außen nicht mehr greifbar.

Beim Einwurf war Herr Ralf Nowak, Objektbetreuer der Wohnen Berlin Immobilien GmbH, anwesend. Die Haustür war über den Verwaltungszylinder geöffnet worden. Ein persönlicher Kontakt mit dem Empfänger fand nicht statt.

## 3 Bestätigung

Berlin, 04.05.2026

Aylin Yilmaz

Ralf Nowak, Zeuge

Scanvermerk: Das Original befindet sich laut Hausverwaltung im roten Objektordner Wilhelmstraße 14. Der vorliegende Scan wurde am 22.06.2026 aus einer Mobiltelefonaufnahme erzeugt; die Unterschriften sind erkennbar, der untere rechte Rand ist abgeschnitten.
