# Wohnraummietvertrag

**Vertragsnummer:** MV-2019-04217

**Objekt:** Wilhelmstraße 14, 10963 Berlin, 3. OG links

**Wohnraummietvertrag** zwischen

**Vermieterin**: Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin, vertreten durch den Geschäftsführer Dr. Markus Lehmann

und

**Mieter**: Herr Thomas Meier, geb. 14.03.1972, ledig

über die Wohnung Wilhelmstraße 14, 10963 Berlin, 3. OG links, bestehend aus 3 Zimmern, Küche, Bad mit Wanne und Dusche, WC, Diele, Balkon, Kellerabteil Nr. 14L.

## 1 Mietsache

Die Wohnfläche beträgt 64,80 qm laut Wohnflächenberechnung vom 17.07.2019 (Anlage 1). Der Balkon ist dort mit einem Viertel seiner Grundfläche berücksichtigt. Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Der Kellerraum ist für übliche Lagerzwecke bestimmt; eine besondere Trockenheit wird nicht zugesichert.

## 2 Mietzeit

Mietverhältnis beginnt am 01.08.2019. Es läuft unbefristet. Ordentliche Kündigung nach den gesetzlichen Bestimmungen § 573, § 573c BGB.

## 3 Miete

Grundmiete (Netto-Kalt) ............ EUR 660,00
Betriebskostenvorauszahlung ........ EUR 220,00
Heizkostenvorauszahlung ............ EUR 200,00
**Summe Bruttowarmmiete ........... EUR 1080,00**

Fälligkeit: monatlich im Voraus, spätestens am 3. Werktag des laufenden Kalendermonats auf das Konto DE89 1001 0010 0987 6543 21 bei Berliner Sparkasse zugunsten Wohnen Berlin Immobilien GmbH.

## 4 Mietsicherheit (Kaution)

Mieter leistet eine Kaution in Höhe von **EUR 1980,00** (entspricht drei Nettokaltmieten bei Vertragsschluss). Form: Sparbuch verpfändet, Quittung Anlage 2. Die Sicherheit bleibt von späteren Mieterhöhungen unberührt.

## 5 Betriebskosten

Es gelten die in Anlage 3 aufgelisteten umlagefähigen Betriebskosten gemäß § 2 BetrKV. Soweit kein anderer gesetzlicher oder vereinbarter Maßstab gilt, werden sie nach Wohnfläche verteilt. Heiz- und Warmwasserkosten werden nach der Heizkostenverordnung abgerechnet. Der Abrechnungszeitraum ist das Kalenderjahr; Abrechnung, Anpassung der Vorauszahlungen und Belegeinsicht richten sich nach den gesetzlichen Vorschriften.

## 6 Schönheitsreparaturen

Die Wohnung wird nach dem Übergabeprotokoll renoviert übergeben. Schönheitsreparaturen sind nur bei tatsächlichem Renovierungsbedarf und nur im Umfang einer wirksamen vertraglichen oder gesetzlichen Verpflichtung auszuführen. Starre Fristen, eine Endrenovierung unabhängig vom Zustand oder eine bestimmte Farbvorgabe während der Mietzeit werden nicht vereinbart.

## 7 Gebrauch und Untervermietung

Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Die Aufnahme weiterer Haushaltsangehöriger ist anzuzeigen, soweit berechtigte Interessen der Vermieterin berührt sind. Eine Gebrauchsüberlassung an Dritte und Untervermietung richten sich nach den gesetzlichen Vorschriften.

## 8 Erhaltung, Mängel und Gefahren

### 8.1

Die Vermieterin erhält die Mietsache im vertragsgemäßen Zustand. Mängel, Schäden und nicht vorhergesehene Gefahren sind unverzüglich unter Angabe von Ort, Zeitpunkt und Erscheinungsbild mitzuteilen, soweit dies möglich ist.

### 8.2

Zur Prüfung angezeigter Mängel sowie für angekündigte Ablese-, Wartungs- und Erhaltungsmaßnahmen ist nach angemessener Terminabstimmung Zutritt zu gewähren. Notfälle bleiben unberührt.

### 8.3

Bauliche Veränderungen und Eingriffe in Fassade, Leitungen oder Gebäudetechnik bedürfen der vorherigen Zustimmung. Übliche Dübel- und Befestigungslöcher für eine vertragsgemäße Nutzung bleiben hiervon unberührt.

## 9 Hausordnung und Gemeinschaftsflächen

Die Hausordnung regelt insbesondere Ruhezeiten, Treppenhaus, Müllplätze, Fahrradabstellflächen und den Gemeinschaftshof. Flucht- und Rettungswege sind freizuhalten. Zwingende gesetzliche Rechte gehen entgegenstehenden Bestimmungen vor.

## 10 Zahlungsverkehr

### 10.1

Bei Überweisungen soll die Vertragsnummer **MV-2019-04217** angegeben werden. Eine fehlende Angabe ändert die gesetzlichen Regeln über Tilgungsbestimmung und Anrechnung nicht.

### 10.2

Stundungen, Ratenzahlungen oder sonstige Kulanzabreden gelten nur für die ausdrücklich bezeichneten Forderungen und Zeiträume. Die laufende Miete bleibt fällig, wenn keine abweichende Vereinbarung getroffen wird.

### 10.3

Änderungen der eigenen Bankverbindung sind mitzuteilen, soweit ein erteiltes Lastschriftmandat oder eine Erstattung betroffen ist. Der Mieter bleibt für die rechtzeitige Zahlung verantwortlich.

## 11 Übergabe, Schlüssel und Rückgabe

### 11.1

Anfangszustand, Zählerstände und Schlüssel ergeben sich aus dem Übergabeprotokoll vom 30.07.2019. Übergeben wurden drei Haus- und Wohnungsschlüssel, zwei Briefkastenschlüssel und ein Kellerschlüssel.

### 11.2

Bei Beendigung ist die Wohnung geräumt, besenrein und mit sämtlichen Schlüsseln zurückzugeben. Über Zustand, Zählerstände und Schlüssel wird ein gesondertes Protokoll gefertigt. Ansprüche werden durch die bloße Protokollaufnahme weder anerkannt noch ausgeschlossen.

## 12 Anlagen

1. Wohnflächenberechnung vom 17.07.2019
2. Kautionsquittung und Verpfändungsanzeige
3. Betriebskostenkatalog
4. Übergabeprotokoll vom 30.07.2019
5. Hausordnung
6. Energieausweis zur Einsichtnahme

## 13 Nebenabreden

Nebenabreden bestehen bei Unterzeichnung nicht. Spätere Änderungen werden in einer eindeutig bezeichneten Erklärung oder einem Nachtrag zur Vertragsakte genommen. Gesetzlich vorgeschriebene Formen bleiben maßgeblich.

## 14 Schriftform

Kündigungen bedürfen der gesetzlich vorgeschriebenen Form. Für sonstige Änderungen gilt die jeweils gesetzlich erforderliche Form; die Parteien dokumentieren dauerhafte Vertragsänderungen aus Beweisgründen in Textform oder in einem unterzeichneten Nachtrag.

**Unterschriften**

Berlin, den 17.07.2019

| Vermieterin | Mieter |
|---|---|
| Dr. Markus Lehmann (gez.) | Thomas Meier (gez.) |

---

## 15 Nachtrag 1 zum Mietvertrag

vom **02.09.2021**

### 15.1 Mieterhöhung § 558 BGB

Aufgrund Mieterhöhungsverlangen vom 28.05.2021 (begründet mit Berliner Mietspiegel 2021 Feld D3) und nachfolgender Zustimmung des Mieters vom 12.07.2021 wird die Nettokaltmiete ab dem **01.10.2021** angehoben:

- Bisherige Nettokaltmiete: EUR 660,00
- Neue Nettokaltmiete: **EUR 720,00**
- Erhöhung: EUR 60,00 = 9,09 Prozent (Kappungsgrenze 15 Prozent gewahrt)

Gleichzeitig werden die BK- und HK-Vorauszahlungen aktualisiert (BK 240, HK 220), so dass die Bruttowarmmiete ab 01.10.2021 EUR 1180,00 beträgt.

Die Mietsicherheit aus dem ursprünglichen Mietvertrag bleibt unverändert.

**Unterschriften**

Berlin, den 02.09.2021

| Vermieterin | Mieter |
|---|---|
| Dr. Markus Lehmann (gez.) | Thomas Meier (gez.) |
