# Telefonnotiz Hausverwaltung

## 1 Gesprächsdaten

| Feld | Inhalt |
|---|---|
| Datum | 19.06.2026, 11:08 bis 11:17 Uhr |
| Gesprächspartner | Ralf Nowak, Objektbetreuer Süd |
| Aufgenommen von | Sandra Berger |
| Akte | F-2026-00347 |

## 2 Gesprächsinhalt

Herr Nowak bestätigt, dass am Briefkasten der Wohnung im 3. Obergeschoss links weiterhin das Schild „Meier“ angebracht ist. Er habe Herrn Meier am 17.06.2026 gegen 18 Uhr im Hof gesehen. Eine Wohnungsaufgabe sei der Hausverwaltung nicht bekannt.

Zum Botenweg der Kündigung vom 04.05.2026 erinnert sich Herr Nowak, dass der Umschlag vollständig in den Briefkastenschlitz eingeworfen worden sei. Der Einwurf sei durch Frau Yilmaz vom Hausmeisterservice vorgenommen worden; Herr Nowak habe daneben gestanden. Das unterschriebene Originalprotokoll liege nach seiner Erinnerung „im roten Objektordner“, sei aber noch nicht an die Zentrale geschickt worden.

Herr Nowak weist außerdem auf eine ältere Meldung über Feuchtigkeit im Kellerabteil hin. Die Meldung stammt aus November 2024 und betrifft nach seiner Erinnerung nicht die Wohnung. Im DMS ist dazu nur ein unscharfer Fotoausdruck vorhanden.

## 3 Offener Rücklauf

Herr Nowak sendet das Original des Einwurfprotokolls und prüft, ob die Kelleranzeige versehentlich unter dem Mietvertrag abgelegt wurde. Rückmeldung zugesagt bis 22.06.2026.
