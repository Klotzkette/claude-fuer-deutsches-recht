# Aktennotiz Nr. 1

Wohnen Berlin Immobilien GmbH
Abteilung Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Geschäftszeichen:    F-2026-00347
Mietverhältnis:      MV-2019-04217, Wilhelmstraße 14, 10963 Berlin, 3. OG links
Mieter:              Thomas Meier
Verfasserin:         Sandra Berger, Renofa, Tel. 030 2055 4810
Datum:               18.06.2026
Betreff:             Tilgungsreihenfolge Teilzahlung 15.03.2026 und Verzugsbeginn

## 1. Anlass

Am 15.03.2026 ging eine Teilzahlung von 500,00 EUR ein, ohne Verwendungszweck. Im SAP-System ist die Buchung dem Monat März 2026 zugeordnet. Vor Klageerhebung ist die verbindliche Verrechnungsreihenfolge festzulegen.

## 2. Sachstand

### 2.1 Zahlungseingang

- Fällige Miete Februar 2026: 1.180,00 EUR — nicht gezahlt
- Fällige Miete März 2026: 1.180,00 EUR — nicht gezahlt
- Teilzahlung 15.03.2026: 500,00 EUR ohne Tilgungsbestimmung des Schuldners
- SAP-Buchung: Betrag ist SAP-intern als März-Zahlung erfasst

### 2.2 Anwendung § 366 BGB

Der Mieter hat bei der Leistung keine Tilgungsbestimmung nach § 366 Absatz 1 BGB getroffen. Nach § 366 Absatz 2 BGB ist zunächst die fällige, unter mehreren fälligen die weniger gesicherte, dann die für den Schuldner lästigere und danach die ältere Schuld zu tilgen; erst bei gleichem Rang wird verhältnismäßig verteilt. Die Monatsmieten Februar und März sind gleichartig, fällig und gleich gesichert. Deshalb wird die ältere Februarmiete getilgt. Innerhalb dieser Schuld wäre § 367 BGB zu beachten, falls Kosten oder Zinsen mitverrechnet werden sollen.

Ergebnis nach Verrechnung:
- Februar 2026 verbleibt offen: 1.180,00 − 500,00 = 680,00 EUR
- März 2026 verbleibt vollständig offen: 1.180,00 EUR

Gesamtrückstand nach Verrechnung: 680,00 + 1.180,00 + 1.180,00 (April) + 1.180,00 (Mai) = 4.220,00 EUR.

### 2.3 Verhältnis zur SAP-Buchung

SAP hat die Teilzahlung als März-Buchung erfasst. Das führt zu keinem anderen Ergebnis auf Klagebene, weil der Gesamtrückstand identisch bleibt. Im Schriftsatz ist jedoch die Verrechnung nach § 366 Absatz 2 BGB ausdrücklich darzustellen, damit der Verzugsbeginn pro Monatsmiete nachvollziehbar ist.

## 3. Rechtliche Bewertung

Die Verrechnung nach § 366 Absatz 2 BGB auf die ältere Februarschuld ist die gesetzliche Regelfolge und im Schriftsatz so darzustellen. Fälligkeit und Verzugsbeginn sind zu trennen. Die Mieten waren spätestens am 04.02.2026, 04.03.2026, 07.04.2026 und 06.05.2026 zu leisten; Verzug begann jeweils am Folgetag, also am 05.02.2026, 05.03.2026, 08.04.2026 und 07.05.2026. Sonnabende zählen für die Zahlungsfrist des § 556b Absatz 1 BGB nicht. Die Zinsforderung ist kurz vor Klageerhebung mit dem dann geltenden Basiszinssatz zu berechnen (§ 288 Absatz 1 BGB, fünf Prozentpunkte über dem Basiszinssatz).

## 4. Nächste Schritte

1. In der Klageschrift die Tilgungsverrechnung nach § 366 Abs. 2 BGB explizit ausführen.
2. Zinslauf pro Monatsmiete tabellarisch darstellen.
3. SAP-Buchungstext vor Einreichung prüfen; ggf. Buchungskorrektur anfordern.

## 5. Eskalation / Vorlage

Die gesetzliche Tilgungsfolge und die Zinsstaffel sind vor Einreichung im Vier-Augen-Prinzip freizugeben. Weicht die Buchhaltung nicht auf die Februarschuld um oder legt der Mieter nachträglich eine Tilgungsbestimmung vor, ist die Forderungsaufstellung zu stoppen und der Rechtsabteilung zur Entscheidung vorzulegen.

(gez.) Sandra Berger
Renofa, Forderungsmanagement
