# Buchungsklärung Mieterkonto

Wohnen Berlin Immobilien GmbH

Debitorenbuchhaltung Wohnen

Vorgang: BK-2026-0316-447

Erstellt am: 16.03.2026, 09:42 Uhr

## 1. Zuordnung

| Feld | Wert |
|---|---|
| Vertragsnummer | MV-2019-04217 |
| Debitor | 10038472 |
| Mieter | Thomas Meier |
| Objekt | Wilhelmstraße 14, 10963 Berlin, 3. OG links |
| Bearbeitung | Aylin Kaya |

## 2. Zahlungseingang

| Buchungstag | Wertstellung | Betrag | Auftraggeber | Verwendungszweck Bank | SAP-Beleg |
|---|---|---:|---|---|---|
| 15.03.2026 | 15.03.2026 | 500,00 EUR | Thomas Meier | Miete Meier | 1900048841 |

Der Verwendungszweck nennt weder Vertragsnummer noch Mietmonat. Ein telefonischer oder schriftlicher Tilgungswunsch des Zahlers liegt der Buchhaltung nicht vor.

## 3. Systemlauf

Die Zahlung wurde im automatischen Suchlauf zunächst dem Debitor zugeordnet und am 16.03.2026 manuell freigegeben. Der offene Posten Februar 2026 war zu diesem Zeitpunkt der älteste fällige Mietposten. Das System hat die Zahlung dort als Teilzahlung verbucht.

| Offener Posten | Soll vor Zahlung | Zahlung | Rest nach Zahlung |
|---|---:|---:|---:|
| Miete Februar 2026 | 1180,00 EUR | 500,00 EUR | 680,00 EUR |

## 4. Rückfragen und Abschluss

Die Bankdatei enthält keine weitere Nachricht des Zahlers. Ein zweiter Zahlungseingang über denselben Betrag wurde im Zeitraum 15.03. bis 16.03.2026 nicht festgestellt.

Status: Zuordnung abgeschlossen. Bei späterem belegtem Tilgungswunsch ist die rechtliche und buchhalterische Umbuchung gesondert zu prüfen.

Aylin Kaya

Debitorenbuchhaltung Wohnen
