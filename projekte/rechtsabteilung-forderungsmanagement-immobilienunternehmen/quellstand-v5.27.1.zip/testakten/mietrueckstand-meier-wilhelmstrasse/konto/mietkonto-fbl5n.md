# Mietkonto FBL5N (SAP-Auszug)

```
SAP FBL5N - Einzelposten Kreditor                       Druckdatum 18.06.2026
Debitor: DK-2019-08812 Meier, Thomas
Mietverhältnis: MV-2019-04217
Zeitraum: 01.01.2026 bis 18.06.2026

Bel.Dat.   Bel.Nr.        Buchungstext               Soll EUR    Haben EUR    Saldo EUR
01.01.2026 KS-2026-00037  Sollstellung 01 2026       1180,00                  1180,00
02.01.2026 BA-2026-001    Mietzahlung                            1180,00         0,00
01.02.2026 KS-2026-00347  Sollstellung 02 2026       1180,00                  1180,00
01.03.2026 KS-2026-00721  Sollstellung 03 2026       1180,00                  2360,00
15.03.2026 BA-2026-014    Teilzahlung (kein Verw.)               500,00      1860,00
01.04.2026 KS-2026-01095  Sollstellung 04 2026       1180,00                  3040,00
01.05.2026 KS-2026-01446  Sollstellung 05 2026       1180,00                  4220,00
01.06.2026 KS-2026-01802  Sollstellung 06 2026       1180,00                  5400,00
04.06.2026 BA-2026-027    Eingang, Verwendungszweck Miete 06/26  1180,00      4220,00

------------------------------------------------------------------------------
Saldo per 18.06.2026                                                          4220,00 H
Davon Hauptforderung                                                          4220,00
Davon Zinsen (zu berechnen)                                                      0,00
------------------------------------------------------------------------------
```

## Buchungslogik

Mieter hat:
- Januar voll bezahlt
- Februar nicht bezahlt
- März mit 500 EUR teilbezahlt (ohne Verwendungszweck, Verrechnung nach § 366 BGB)
- April und Mai nichts
- Juni voll bezahlt; Verwendungszweck `Miete 06/26` ist als Tilgungsbestimmung nach § 366 Abs. 1 BGB dokumentiert

## Verrechnungsreihenfolge

Da Teilzahlungen 15.03.2026 EUR 500 ohne Tilgungsbestimmung kommt § 366 Abs. 2 BGB:
- Februar (älteste fällige Schuld) wird mit 500 EUR verrechnet
- Februar dann noch offen: 1180 - 500 = 680 EUR
- März unbeglichen 1180 EUR

Alternative Sichtweise: SAP hat die Teilzahlung als März-Zahlung gebucht. Vor Klageeinreichung ist festzulegen, welche Tilgungslogik im Schriftsatz vertreten wird; beide Varianten sind aktenkundig zu machen.

## Verzugsbeginn pro Monatsmiete

| Monat | Saldo (mit § 366 BGB) | Verzugsbeginn |
|---|---|---|
| 02 2026 | 680,00 | 05.02.2026 |
| 03 2026 | 1180,00 | 05.03.2026 |
| 04 2026 | 1180,00 | 08.04.2026 |
| 05 2026 | 1180,00 | 07.05.2026 |
| **Summe** | **4220,00** | |

## Zinsen Basiszins + 5 Prozentpunkte (zur Information)

Berechnung erst kurz vor Klage mit aktuellem Basiszinssatz (Bundesbank Stand 01.07.2026).
