# Berliner Sparkasse

PrivatkundenService

Alexanderplatz 2

10178 Berlin

Herrn Thomas Meier

Wilhelmstraße 14

10963 Berlin

Berlin, 19.06.2026

**Kundenreferenz:** KS-2026-0619-44718

## Bestätigung zu Ihrem Überweisungsversuch

Sehr geehrter Herr Meier,

auf Ihren Wunsch bestätigen wir das Ergebnis der Prüfung in unserer Filiale. Am 16.06.2026 wurde um 19:42 Uhr im Onlinebanking ein Überweisungsentwurf über **4220,00 EUR** zugunsten der Wohnen Berlin Immobilien GmbH erfasst. Als Verwendungszweck war `Miete Wilhelmstrasse Rueckstand` eingegeben.

Der Auftrag wurde nicht ausgeführt. Die zur Freigabe angeforderte Bestätigung in der pushTAN-App wurde innerhalb des vorgesehenen Zeitfensters nicht erteilt. Die Sitzung endete ohne Autorisierung. Es wurden weder eine Auftragsnummer noch eine Vormerkung erzeugt; das Konto wurde nicht belastet.

## Prüfergebnis

| Merkmal | Feststellung |
|---|---|
| Erfassung des Entwurfs | 16.06.2026, 19:42:17 Uhr |
| Empfängername | Wohnen Berlin Immobilien GmbH |
| Betrag | 4220,00 EUR |
| Autorisierung | nicht erfolgt |
| Buchung oder Vormerkung | keine |
| Stornierung | nicht erforderlich, da kein Auftrag erteilt |

Die in der Filiale vorgelegte Bildschirmaufnahme zeigt den Erfassungsdialog vor Abschluss der Freigabe. Sie ist kein Zahlungsbeleg. Ein Kontoauszug mit Belastung oder eine bankseitige Ausführungsbestätigung kann deshalb nicht erstellt werden.

Für künftige Aufträge wurde die pushTAN-Verbindung auf dem neuen Mobilgerät am 19.06.2026 neu eingerichtet. Diese technische Freischaltung löst den oben genannten Entwurf nicht nachträglich aus. Eine neue Überweisung muss gesondert erfasst und freigegeben werden.

Mit freundlichen Grüßen

Berliner Sparkasse

Serviceberatung Privatkunden

Dieses Schreiben enthält keine Aussage zur Fälligkeit oder zum Bestand der zugrunde liegenden Mietforderung.
