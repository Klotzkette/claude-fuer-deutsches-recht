# Zahlungsavis Mietkonto Thomas Meier

## 1 Buchungsdaten

| Feld | Wert |
|---|---|
| Hausbank | Berliner Handelsbank AG |
| Kontoauszug | 056/2026 |
| Wertstellung | 15.03.2026 |
| Buchungstag | 15.03.2026 |
| Betrag | 500,00 EUR Haben |
| Auftraggeber | Thomas Meier |
| Auftraggeber-IBAN | DE44 1002 0500 7718 4630 09 |
| Empfänger-IBAN | DE89 1001 0010 0987 6543 21 |
| Verwendungszweck | TH MEIER WILHELMSTR 14 |
| Bankreferenz | EREF 2026031500791182 |

## 2 Buchungstext

SEPA-Überweisung, Eingang ohne Monatsangabe und ohne Vertragsnummer. Der maschinelle Zuordnungslauf hat den Betrag zunächst als Zahlung für März 2026 markiert. Eine ausdrückliche Tilgungsbestimmung ist im Verwendungszweck nicht enthalten.

## 3 Systemvermerk

Importiert am 16.03.2026 um 02:14 Uhr. Automatische Trefferquote 71 Prozent. Manuelle Nachbearbeitung am 18.06.2026 vorgemerkt.
