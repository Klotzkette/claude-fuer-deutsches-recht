# Testakte 1 — Mietrückstand Meier Wilhelmstraße


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 77 KB) | PDF | [testakte-mietrueckstand-meier-wilhelmstrasse-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-meier-wilhelmstrasse-gesamt.pdf) | [`gesamt-pdf/mietrueckstand-meier-wilhelmstrasse_gesamt.pdf`](gesamt-pdf/mietrueckstand-meier-wilhelmstrasse_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-mietrueckstand-meier-wilhelmstrasse.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-meier-wilhelmstrasse.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-mietrueckstand-meier-wilhelmstrasse-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-meier-wilhelmstrasse-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | SAP-/Mietkonto-Intake, Belegmatrix, Mahnung, Kündigungsoption und Zahlungsklage |
| Startskills | `01-sap-akte-importieren`, `03-kontoauszug-mietkonto-auslesen`, `04-belegmatrix-aufbauen`, danach `20-zahlungsklage-mietrueckstand-erstellen` |
| Kernentscheidung | Ist die Forderung in Höhe, Zeitraum und Belegen klagereif oder müssen Zahlung, Tilgung und Zugang noch geklärt werden? |
| Besonderheit | Zwei Zustellvermerke nennen für die zweite Mahnung den 08. und 10.04.2026. Dieser Quellenkonflikt ist vor jedem konkreten Zugangsvortrag zu klären; die Mieter-E-Mail ersetzt weiterhin keinen Zahlungsbeleg. |

Klassischer Mahnfall mit drei vollständig offenen Monatsmieten und einem Rest aus Februar, hilfsweiser ordentlicher Kündigung und kombinierter Zahlungs- und Räumungsklage.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Geschäftsführer | Dr. Markus Lehmann |
| Mieter | Thomas Meier, geb. 14.03.1972 |
| Mietobjekt | Wilhelmstraße 14, 10963 Berlin, 3. OG links |
| Wohnfläche | 64,80 qm |
| Vertragsbeginn | 01.08.2019 |
| Nettokaltmiete | 720,00 EUR |
| BK-Vorauszahlung | 240,00 EUR |
| HK-Vorauszahlung | 220,00 EUR |
| Bruttowarmmiete | 1180,00 EUR |
| Fälligkeit | 3. Werktag des Monats § 556b BGB |
| Mietkonto | DE89 1001 0010 0987 6543 21 |
| Aktenzeichen intern | F-2026-00347 |

## Sachverhalt

Seit Februar 2026 zahlt Meier die Miete unregelmäßig. SAP zeigt die Zahlung von 500 EUR im März; mangels Tilgungsbestimmung wird sie nach § 366 Abs. 2 BGB auf die ältere Februarmiete angerechnet. April und Mai blieben unbezahlt.

Stand 18.06.2026:

| Monat | Soll | Ist | Saldo |
|---|---|---|---|
| 02 2026 | 1180,00 | 500,00 | 680,00 |
| 03 2026 | 1180,00 | 0,00 | 1180,00 |
| 04 2026 | 1180,00 | 0,00 | 1180,00 |
| 05 2026 | 1180,00 | 0,00 | 1180,00 |
| **Summe** | | | **4220,00** |

Erste Mahnung am 16.03.2026, zweite Mahnung am 08.04.2026 mit Klageandrohung. Am 18.06.2026 behauptet der Mieter eine weitere Zahlung, legt aber keinen prüffähigen Zahlungsbeleg vor.

## Bearbeiterin

Rechtsfachwirtin Sandra Berger (Abteilung Forderungsmanagement Wohnen Berlin Immobilien GmbH).

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Mietvertrag | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Mietkonto FBL5N | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Aktennotiz zur Tilgungsreihenfolge | [aktennotiz/aktennotiz-01-mietkonto-tilgungsreihenfolge.md](aktennotiz/aktennotiz-01-mietkonto-tilgungsreihenfolge.md) |
| Mahnung 1 | [korrespondenz/mahnung-1.md](korrespondenz/mahnung-1.md) |
| Mahnung 2 mit Klageandrohung | [korrespondenz/mahnung-2.md](korrespondenz/mahnung-2.md) |
| E-Mail des Mieters zur angeblichen Zahlung | [korrespondenz/mieter-antwort-nachfrage-zahlung.md](korrespondenz/mieter-antwort-nachfrage-zahlung.md) |
| Kündigung fristlos und hilfsweise ordentlich | [korrespondenz/kündigung.md](korrespondenz/kuendigung.md) |
| Entwurf Klageschrift | [korrespondenz/klage-entwurf.md](korrespondenz/klage-entwurf.md) |
| DocuWeb-Exportliste mit Dubletten und Versionsständen | [dms/dms-exportliste-2026-06-20.md](dms/dms-exportliste-2026-06-20.md) |
| Zahlungsavis der Teilzahlung über 500,00 EUR | [zahlung/zahlungsavis-teilzahlung-500-2026-03-15.md](zahlung/zahlungsavis-teilzahlung-500-2026-03-15.md) |
| Bankbestätigung zum nicht ausgeführten Überweisungsentwurf | [zahlung/bank-avis-ueberweisungsauftrag-abgelehnt-2026-06-19.md](zahlung/bank-avis-ueberweisungsauftrag-abgelehnt-2026-06-19.md) |
| Zweiter E-Mail-Ausdruck zur angeblichen Überweisung | [korrespondenz/email-mieter-ueberweisung-urlaub.md](korrespondenz/email-mieter-ueberweisung-urlaub.md) |
| Telefonnotiz zu Klingelschild, Anwesenheit und Kellerbeifang | [hausverwaltung/telefonnotiz-klingelschild-und-keller.md](hausverwaltung/telefonnotiz-klingelschild-und-keller.md) |
| Einwurfprotokoll der Kündigung | [zustellung/einwurfprotokoll-kuendigung-2026-05-04.md](zustellung/einwurfprotokoll-kuendigung-2026-05-04.md) |
| Mieterdatenblatt mit Systemabweichungen | [objekt/mieterdatenblatt-abgleich.md](objekt/mieterdatenblatt-abgleich.md) |
| Buchungsklärung zur Teilzahlung ohne Monatsangabe | [konto/buchungsklaerung-teilzahlung-2026-03-16.md](konto/buchungsklaerung-teilzahlung-2026-03-16.md) |
| Einwurfprotokoll der zweiten Mahnung | [zustellung/einwurfprotokoll-mahnung-2-2026-04-08.md](zustellung/einwurfprotokoll-mahnung-2-2026-04-08.md) |

## Aufgabe für die Skills

Bearbeite den Fall nach dem Forderungsmanagement Immobilien - Vollworkflow-Prompt: SAP-Akte, Mietakte, Belegmatrix, Mahnwesen, Kündigung, gerichtliches Mahnverfahren als optionale Abzweigung oder direkte Klage.
