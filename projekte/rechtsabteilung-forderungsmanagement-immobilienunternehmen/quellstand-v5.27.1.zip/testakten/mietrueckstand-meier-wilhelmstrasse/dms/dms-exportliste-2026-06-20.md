# DocuWeb Exportliste F-2026-00347

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportzeitpunkt | 20.06.2026, 07:46 Uhr |
| Akte | F-2026-00347 |
| Vertragsnummer | MV-2019-04217 |
| Sachbearbeitung | S. Berger |
| Treffer | 16 |

## 2 Dokumentenbestand

| DMS-ID | Eingangsdatum | Dokumentklasse | Dateiname im DMS | Version | OCR | Bemerkung |
|---|---|---|---|---:|---|---|
| DW-884102 | 06.08.2019 | Vertrag | MV_2019_04217_scan.pdf | 1 | 97 Prozent | unterschriebene Fassung |
| DW-884103 | 06.08.2019 | Anlage | hausordnung_2019.pdf | 1 | 92 Prozent | Rückseite schief gescannt |
| DW-901700 | 16.03.2026 | Buchhaltung | Buchungsklaerung_Teilzahlung.pdf | 1 | 100 Prozent | Tilgung auf Februarmiete dokumentiert |
| DW-901771 | 18.03.2026 | Ausgang | Mahnung_1_Meier.pdf | 1 | 100 Prozent | Versandstück |
| DW-901772 | 18.03.2026 | Zustellung | RR1234567890DE.pdf | 1 | 84 Prozent | Trackingausdruck |
| DW-906430 | 08.04.2026 | Zustellung | Einwurfprotokoll_Mahnung_2.pdf | 1 | 96 Prozent | nennt Einwurf am 08.04.2026 |
| DW-906441 | 10.04.2026 | Ausgang | Mahnung_2_Meier_final.pdf | 3 | 100 Prozent | Version 2 trägt falsches Datum |
| DW-906442 | 10.04.2026 | Zustellung | Botenvermerk_10042026.pdf | 1 | 89 Prozent | Handschrift teilweise blass |
| DW-910009 | 04.05.2026 | Ausgang | Kündigung_Meier_unterschrieben.pdf | 4 | 100 Prozent | freigegebene Fassung |
| DW-910010 | 04.05.2026 | Zustellung | Einwurfprotokoll_04052026.pdf | 1 | 96 Prozent | Original bei Hausverwaltung |
| DW-910011 | 06.05.2026 | Zustellung | RR3456789012DE.pdf | 1 | 87 Prozent | zusätzlicher Postnachweis |
| DW-914552 | 18.06.2026 | Eingang | Mail_Meier_angeblich_überwiesen.pdf | 1 | 100 Prozent | genannter Screenshot fehlt |
| DW-914557 | 19.06.2026 | Bankbeleg | Sparkasse_Ueberweisungsversuch.pdf | 1 | 100 Prozent | Entwurf nicht autorisiert; keine Belastung |
| DW-914554 | 19.06.2026 | Entwurf | Klage_Meier_19062026.docx | 5 | entfällt | noch nicht eingereicht |
| DW-914555 | 19.06.2026 | Tabelle | Forderungsaufstellung_Meier.xlsx | 2 | entfällt | SAP-Saldo 4.220,00 EUR |
| DW-914556 | 19.06.2026 | Notiz | Rückfrage_Tilgung.docx | 1 | entfällt | fachliche Freigabe offen |

## 3 Exporthinweis

Die Dateien DW-906441 und DW-910009 haben mehrere Versionen; für die Akte wurden nur die jeweils als final markierten Fassungen exportiert. DW-914557 bestätigt, dass der vom Mieter erwähnte Überweisungsentwurf nicht autorisiert und nicht ausgeführt wurde.

DW-906430 nennt einen Boteneinwurf am 08.04.2026. Der ältere
Zustellungsvermerk bei DW-906442 und der SAP-Status nennen dagegen den
10.04.2026. Beide Nachweise bleiben unverändert erhalten; vor Verwendung eines
konkreten Zugangsdatums sind Bote, Original und Sendungsbezug abzugleichen.
