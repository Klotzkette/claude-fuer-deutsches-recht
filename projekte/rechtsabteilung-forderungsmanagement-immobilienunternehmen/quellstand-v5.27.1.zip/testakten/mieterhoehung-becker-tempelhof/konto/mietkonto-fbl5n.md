# Mietkonto FBL5N — Becker, Wolfgang / Heike

Vertragsnummer: WBI-MV-2014-02185
Partnernummer: 4001354
Stand: 02.06.2026

| Datum | Buchungstext | Soll | Haben | Saldo |
|---|---|---|---|---|
| 02.01.2026 | Sollstellung Miete 01/2026 | 875,20 | | 875,20 |
| 03.01.2026 | Dauerauftrag Becker 01/2026 | | 875,20 | 0,00 |
| 02.02.2026 | Sollstellung Miete 02/2026 | 875,20 | | 875,20 |
| 03.02.2026 | Dauerauftrag Becker 02/2026 | | 875,20 | 0,00 |
| 02.03.2026 | Sollstellung Miete 03/2026 | 875,20 | | 875,20 |
| 03.03.2026 | Dauerauftrag Becker 03/2026 | | 875,20 | 0,00 |
| 02.04.2026 | Sollstellung Miete 04/2026 | 875,20 | | 875,20 |
| 02.04.2026 | Dauerauftrag Becker 04/2026 | | 875,20 | 0,00 |
| 04.05.2026 | Sollstellung Miete 05/2026 | 875,20 | | 875,20 |
| 05.05.2026 | Dauerauftrag Becker 05/2026 | | 875,20 | 0,00 |
| 02.06.2026 | Sollstellung Miete 06/2026 | 875,20 | | 875,20 |
| 02.06.2026 | Dauerauftrag Becker 06/2026 | | 875,20 | 0,00 |

## Salden-Zusammenfassung

- Aktueller Saldo: **0,00 EUR**
- Zahlungsverhalten der letzten 24 Monate: einwandfrei, ohne Verzug
- Dauerauftrag: läuft seit 11/2014 ohne Unterbrechung
- Buchungsdaten der Sollstellungen sind SAP-Postingdaten und nicht mit der gesetzlichen Fälligkeit nach § 556b Abs. 1 BGB gleichzusetzen.

## Sachstandsnotiz

- Akte ist ungestört, keine Forderung offen
- Vorgang betrifft die Vorbereitung einer Mieterhöhung
- Mietspiegel-Eckdaten liegen in der Mietspiegel-Akte
