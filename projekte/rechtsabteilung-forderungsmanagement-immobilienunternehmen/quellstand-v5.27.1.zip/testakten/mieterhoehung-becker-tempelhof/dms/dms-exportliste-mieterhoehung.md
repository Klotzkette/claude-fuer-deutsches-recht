# DocuWeb Exportliste Mieterhöhung Becker

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportdatum | 16.10.2026, 09:18 Uhr |
| Vertragsnummer | WBI-MV-2014-02185 |
| Objekt | WBI-TEM-018-02L |
| Vorgang | ME-2026-00184 |
| Ergebnis | 19 Dokumenttreffer |

## 2 Dokumente und Versionen

| DMS-ID | Datum | Klasse | Indexname | Version | Hinweis |
|---|---|---|---|---:|---|
| DW-551001 | 15.09.2014 | Vertrag | Mietvertrag_Becker.pdf | 1 | Unterschriften vollständig |
| DW-551002 | 15.09.2014 | Objekt | Flächenberechnung_2OG_links.pdf | 1 | Balkon mit 50 Prozent angesetzt |
| DW-602145 | 19.08.2017 | Instandhaltung | Fensterauftrag_2017.pdf | 2 | nur zwei Räume bezeichnet |
| DW-711982 | 04.07.2023 | Mieterhöhung | Zustimmung_2023.pdf | 1 | Wirksamkeit 01.10.2023 |
| DW-902771 | 02.06.2026 | Notiz | Prüfung_558_Becker.docx | 3 | Zielmiete 613,87 EUR |
| DW-903002 | 10.06.2026 | Tabelle | Merkmalmatrix_Becker.xlsx | 5 | mehrere Felder offen |
| DW-903113 | 15.06.2026 | Ausgang | Mieterhöhung_Becker_final.pdf | 4 | freigegebene Fassung |
| DW-903114 | 15.06.2026 | Ausgang | Mieterhöhung_Becker_final_neu.pdf | 4 | bytegleiche Dublette |
| DW-903741 | 18.06.2026 | Zustellung | Einwurfprotokoll_Becker.pdf | 1 | beide Namen am Briefkasten |
| DW-905004 | 12.07.2026 | Eingang | Mail_Becker_Vorbehalt.pdf | 1 | keine gemeinsame Unterschrift |
| DW-907822 | 24.08.2026 | Eingang | Teilzustimmung_Becker.pdf | 1 | beide Mieter unterschrieben |
| DW-907823 | 24.08.2026 | Eingang | Teilzustimmung_Becker_scan2.pdf | 1 | schlechterer Graustufenscan |
| DW-909801 | 18.09.2026 | Objekt | Begehung_Merkmalgruppen_Becker.pdf | 1 | Badfenster und Balkonfläche offen |
| DW-909802 | 18.09.2026 | Objekt | Aufmass_Wohnflaeche_Becker.pdf | 1 | 78,50 qm; Balkon neu vermessen |
| DW-909940 | 21.09.2026 | Eingang | Mail_Becker_Wohnflaeche_Balkon.pdf | 1 | Wohnfläche und Ausstattung bestritten |
| DW-911170 | 10.10.2026 | Objekt | Merkmalmatrix_fortgeschrieben.xlsx | 7 | Fotoliste ohne Bilddateien |
| DW-911171 | 10.10.2026 | Objekt | Hausmeistervermerk_Aufzug.docx | 1 | Aufzug nie vorhanden |
| DW-912003 | 15.10.2026 | Entwurf | Zustimmungsklage_Becker.docx | 6 | Einreichungsfreigabe offen |
| DW-912004 | 15.10.2026 | Tabelle | Anlagenplan_Becker.xlsx | 2 | K 6 gelb markiert |

## 3 Dublettenvermerk

DW-903113 und DW-903114 haben dieselbe Prüfsumme. DW-907823 ist eine schlechter lesbare Zweitkopie von DW-907822. Beide Dubletten bleiben im DMS sichtbar, wurden für die Arbeitsakte aber nur einmal fachlich gewertet.

Das versandte Mieterhöhungsverlangen bezeichnet ein Badfenster. Das spätere
Begehungsprotokoll dokumentiert dagegen nur eine Lüftungsöffnung. Dieser
Quellenkonflikt wird nicht durch Überschreiben des historischen Versandstücks
bereinigt, sondern in der fortgeschriebenen Merkmalmatrix gesondert geprüft.
