# Aktennotiz Nr. 1

Wohnen Berlin Immobilien GmbH
Abteilung Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Geschäftszeichen:    F-2026-00389
Mietverhältnis:      WBI-MV-2014-02185, Manfred-von-Richthofen-Straße 18, 12101 Berlin-Tempelhof, 2. OG links
Mieter:              Wolfgang und Heike Becker
Verfasserin:         Sandra Berger, Renofa, Tel. 030 2055 4810
Datum:               02.06.2026
Betreff:             Mieterhöhungsprüfung nach § 558 BGB — Kappungsgrenze und Mietspiegeltabelle

## 1. Anlass

Das Mietverhältnis besteht seit Oktober 2014. Die letzte Mietanpassung erfolgte zum 01.10.2023 (von 6,80 auf 7,20 EUR/qm). Die Vorbereitungsarbeiten für ein erneutes Mieterhöhungsverlangen sind angelaufen. Vor Versand des Verlangens ist die Kappungsgrenze zu überprüfen, da beide Erhöhungen innerhalb eines Drei-Jahres-Zeitraums liegen könnten.

## 2. Sachstand

### 2.1 Mietentwicklung

| Zeitpunkt | Nettokaltmiete | Steigerung |
|---|---|---|
| 01.10.2014 | 5,40 EUR/qm (Vertragsbeginn) | — |
| 01.08.2018 | 6,80 EUR/qm (Nachtrag Nr. 1) | +25,9% |
| 01.10.2023 | 7,20 EUR/qm (Nachtrag Nr. 2) | +10,8% |
| Ziel 06/2026 | 7,82 EUR/qm | +8,6% |

### 2.2 Kappungsgrenze Berlin

Für Berlin gilt nach der Kappungsgrenzen-Verordnung vom 14.03.2023, in Kraft vom 11.05.2023 bis zum 10.05.2028, eine Kappungsgrenze von 15% innerhalb von drei Jahren (§ 558 Abs. 3 Satz 2 BGB). Maßgeblich ist die Ausgangsmiete zu Beginn des vom Wirksamkeitszeitpunkt der neuen Erhöhung zurückgerechneten Drei-Jahres-Zeitraums; alle nicht nach Modernisierung vorgenommenen Erhöhungen in diesem Zeitraum sind einzubeziehen.

Relevanter Drei-Jahres-Zeitraum: 01.09.2023 bis 01.09.2026.

Letzte Miete im Vergleichszeitraum: 7,20 EUR/qm (seit 01.10.2023).
Angestrebte neue Miete: 7,82 EUR/qm.
Steigerung: (7,82 − 7,20) / 7,20 = 8,6% — isoliert betrachtet unterhalb der Kappungsgrenze.

Allerdings ist die gesamte Mietsteigerung des relevanten Zeitraums zu beachten: Die vorherige Miete vor der letzten Erhöhung im Oktober 2023 lag bei 6,80 EUR/qm. Die kumulierte Steigerung von 6,80 auf 7,82 EUR beträgt genau 15,0%. Das Verlangen darf daher nicht über 7,82 EUR/qm hinausgehen. Im Mieterhöhungsverlangen ist dieser Punkt ausdrücklich darzustellen.

### 2.3 Sperrfrist

§ 558 Absatz 1 BGB enthält zwei getrennte Zeitgates. Das Erhöhungsverlangen darf frühestens ein Jahr nach der letzten Mieterhöhung gestellt werden; die Miete muss bei Wirksamwerden der neuen Erhöhung seit 15 Monaten unverändert sein. Die letzte Erhöhung wurde am 01.10.2023 wirksam, das neue Verlangen soll im Juni 2026 zugehen und die neue Miete ab 01.09.2026 gelten. Beide Gates sind eingehalten.

### 2.4 Mietspiegeltabelle 9.2, Zeile 85

Der Berliner Mietspiegel 2026 ist am 28.05.2026 in Kraft getreten und hat den Mietspiegel 2024 abgelöst. Die Manfred-von-Richthofen-Straße ist im amtlichen Straßenverzeichnis 2026 der mittleren Wohnlage zugeordnet. Für die 1964 bezugsfertige, 78,50 qm große und voll ausgestattete Wohnung gilt Mietspiegeltabelle 9.2, Zeile 85: untere Spanne 5,90 EUR/qm, Mittelwert 7,08 EUR/qm, obere Spanne 9,25 EUR/qm. Die geforderten 7,82 EUR/qm liegen innerhalb der Spanne, aber 0,74 EUR/qm über dem Mittelwert. Sie sind nur tragfähig, wenn die Merkmalgruppen der amtlichen Orientierungshilfe diese Spanneneinordnung belegen; Balkon und Badangaben genügen nicht ohne Prüfung der übrigen Gruppen.

## 3. Rechtliche Bewertung

Das Verlangen auf 7,82 EUR/qm hält die Kappungsgrenze ein und überschreitet die Tabellenobergrenze nicht. Damit ist die konkrete ortsübliche Vergleichsmiete noch nicht bewiesen. Vor Freigabe sind alle Merkmalgruppen der Orientierungshilfe mit Objektbelegen zu bewerten; bis dahin bleibt die materielle Ampel gelb. Die formellen Anforderungen des § 558a BGB (Textform und nachvollziehbare Begründung mit qualifiziertem Mietspiegel) sind daneben eigenständig zu wahren.

Zum Streitwert bei Zustimmungsklage: § 41 Absatz 5 Satz 1 GKG; maßgeblich ist der Jahresbetrag der streitigen Differenz.

## 4. Nächste Schritte

1. Merkmalgruppen aus Objektakte und Übergabeprotokoll vervollständigen; danach Mieterhöhungsverlangen mit Mietspiegeltabelle 9.2, Zeile 85, und konkreter Spanneneinordnung auf höchstens 7,82 EUR/qm freigeben.
2. Zustimmungsfrist bis 31.08.2026 notieren (§ 558b Absatz 1 BGB).
3. Wiedervorlage 01.09.2026: Zustimmung eingegangen? Falls nicht, Zustimmungsklage innerhalb der drei weiteren Monate bis einschließlich 30.11.2026 erheben (§ 558b Absatz 2 BGB); Eingang und demnächst erfolgende Zustellung gesondert absichern.

## 5. Eskalation / Vorlage

Die sachliche Zuständigkeit des Amtsgerichts folgt bei Wohnraummietsachen unabhängig vom Streitwert aus § 23 Nr. 2a GVG. Die interne Vorlagegrenze bleibt davon getrennt. Bei vollständiger Zustimmungsverweigerung beträgt der Streitwert 12 × 48,67 EUR = 584,04 EUR; bei der später erklärten Teilzustimmung ist nur die verbleibende Monatsdifferenz maßgeblich.

(gez.) Sandra Berger
Renofa, Forderungsmanagement
