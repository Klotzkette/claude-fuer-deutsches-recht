# Wohnraummietvertrag

zwischen

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99, 10117 Berlin
- Vermieterin -

und

**Herrn Wolfgang Becker**, geb. 14.03.1962
**Frau Heike Becker**, geb. 09.11.1964
gemeinsame Anschrift Manfred-von-Richthofen-Straße 18, 12101 Berlin
- Mieter -

## 1 Mietsache

### 1.1

Die Vermieterin vermietet den Mietern die im Hause Manfred-von-Richthofen-Straße 18, 12101 Berlin-Tempelhof, im 2. OG links gelegene 3-Zimmer-Wohnung mit 78,50 qm Wohnfläche nebst Küche, Bad, Flur, Balkon und Kellerraum Nr. 8.

### 1.2

Die Wohnfläche beruht auf der zur Vertragsakte genommenen Bestandsberechnung. Der Balkon ist dort mit einem Viertel seiner Grundfläche berücksichtigt. Die Flächenangabe dient zugleich als vereinbarter Umlagemaßstab, soweit Betriebskosten nach Wohnfläche verteilt werden.

### 1.3

Zur gemeinschaftlichen Nutzung stehen Fahrradkeller und Trockenraum nach Maßgabe der Hausordnung zur Verfügung. Ein Aufzug ist im Gebäude nicht vorhanden.

## 2 Mietzeit

### 2.1

Das Mietverhältnis beginnt am 01.10.2014. Es ist auf unbestimmte Zeit geschlossen.

## 3 Miete

### 3.1

Die monatliche Miete beträgt zum Vertragsbeginn:

- Nettokaltmiete: 423,90 EUR (entspricht 5,40 EUR/qm)
- Betriebskostenvorauszahlung: 130,00 EUR
- Heizkostenvorauszahlung: 110,00 EUR
- Gesamtmiete: 663,90 EUR

### 3.2

Die Miete ist monatlich im Voraus, spätestens bis zum 3. Werktag des Monats zu zahlen.

### 3.3

Bankverbindung Vermieterin:
Berliner Volksbank, IBAN DE 47 1009 0000 0123 4567 89
Verwendungszweck: WBI-MV-2014-02185 Becker Tempelhof

## 4 Betriebskosten und Heizkosten

### 4.1

Die Mieter tragen die in Anlage 1 bezeichneten umlagefähigen Betriebskosten. Soweit kein anderer gesetzlicher oder vereinbarter Maßstab gilt, werden die Kosten nach Wohnfläche verteilt.

### 4.2

Heiz- und Warmwasserkosten werden nach der Heizkostenverordnung abgerechnet. Über die Vorauszahlungen wird kalenderjährlich abgerechnet; Anpassungen nach einer Abrechnung richten sich nach den gesetzlichen Vorschriften.

### 4.3

Die Mieter können nach Zugang der Abrechnung Einsicht in die für deren Prüfung erforderlichen Belege verlangen. Gesetzliche Abrechnungs- und Einwendungsfristen bleiben unberührt.

## 5 Kaution

### 5.1

Die Mieter leisten eine Kaution in Höhe von 1271,70 EUR (3 Nettokaltmieten).

### 5.2

Eine als Geldsumme geleistete Sicherheit kann in drei gleichen monatlichen Raten erbracht werden. Die erste Rate ist zu Mietbeginn, die beiden weiteren Raten sind mit den folgenden Mietzahlungen fällig.

### 5.3

Die Vermieterin legt die Sicherheit getrennt von ihrem Vermögen an. Über geleistete Raten und die Anlage wird gesondert Nachweis erteilt.

## 6 Mieteranzahl

Die Wohnung darf von den Mietern und den haushaltsangehörigen Personen genutzt werden. Eine Überlassung an Dritte bedarf der schriftlichen Zustimmung der Vermieterin.

## 7 Erhaltung und Mängelanzeige

### 7.1

Die Vermieterin erhält die Wohnung während der Mietzeit im vertragsgemäßen Zustand. Mängel und Schäden sind unverzüglich mit einer möglichst genauen Orts- und Zustandsbeschreibung anzuzeigen.

### 7.2

Zur Prüfung angezeigter Mängel, für Ablesungen und für erforderliche Erhaltungsmaßnahmen ist nach angemessener Ankündigung Zutritt zu gewähren. Auf Arbeitszeiten, Krankheit und sonstige berechtigte Belange der Mieter ist bei der Terminabstimmung Rücksicht zu nehmen.

### 7.3

Bauliche Veränderungen, insbesondere an Fenstern, Balkon, Leitungen und der äußeren Gestaltung, bedürfen der vorherigen Zustimmung. Die von den Mietern eingebrachte Küche bleibt deren Eigentum; Anschlüsse und Rückbaupflichten richten sich nach der gesonderten Übergabevereinbarung.

## 8 Beschaffenheit bei Übergabe

### 8.1

Die Übergabe ist für den 29.09.2014 vereinbart. Die Wohnung verfügt über Parkett in Wohn- und Schlafräumen, Fliesen in Küche und Bad, ein innenliegendes Bad mit mechanischer Entlüftung sowie einen südwestlich ausgerichteten Balkon. Der Zustand wird bei Übergabe protokolliert.

### 8.2

Die Wohnung ist mit Holzverbundfenstern ausgestattet.

## 9 Hausordnung und Gemeinschaftsflächen

Die Hausordnung regelt Ruhezeiten, Treppenhaus, Müllstandplatz, Fahrradkeller und Trockenraum. Flucht- und Rettungswege sind freizuhalten. Zwingende gesetzliche Rechte bleiben unberührt.

## 10 Rückgabe und Schlüssel

Bei Beendigung ist die Wohnung geräumt, besenrein und mit allen überlassenen sowie nachgefertigten Schlüsseln zurückzugeben. Über Zustand, Zählerstände und Schlüssel wird ein Protokoll gefertigt; dieses enthält ohne ausdrückliche Erklärung kein Schuldanerkenntnis.

## 11 Vertragsänderungen und Anlagen

### 11.1

Nebenabreden bestehen bei Unterzeichnung nicht. Änderungen der Miethöhe, Vorauszahlungen oder Ausstattung werden in einem eindeutig bezeichneten Nachtrag dokumentiert.

### 11.2

Bestandteile der Vertragsakte sind die Wohnflächenberechnung, das Übergabeprotokoll vom 29.09.2014, die Hausordnung, der Betriebskostenkatalog und der Energieausweis zur Einsichtnahme.

Berlin, den 15.09.2014

________________________               ________________________
Wohnen Berlin Immobilien GmbH         Wolfgang Becker / Heike Becker

---

## 12 Nachtrag Nr. 1 vom 12.07.2018

Mietanpassung nach § 558 BGB zum 01.08.2018:

- Nettokaltmiete neu: 533,80 EUR (6,80 EUR/qm)
- BK-Vorauszahlung neu: 150,00 EUR
- HK-Vorauszahlung neu: 125,00 EUR

Begründung: Berliner Mietspiegel 2017, einschlägige Tabellenzeile für mittlere Wohnlage und Baualtersklasse.

Die bei Übergabe vorhandenen Holzverbundfenster wurden in den im Modernisierungsnachtrag dokumentierten Räumen im September 2017 gegen isolierverglaste Kunststofffenster ausgetauscht. Der Fensteraustausch änderte die vertragliche Wohnfläche nicht.

## 13 Nachtrag Nr. 2 vom 18.07.2023

Mietanpassung nach § 558 BGB zum 01.10.2023:

- Nettokaltmiete neu: 565,20 EUR (7,20 EUR/qm)
- BK-Vorauszahlung neu: 165,00 EUR
- HK-Vorauszahlung neu: 145,00 EUR

Begründung: Berliner Mietspiegel 2023, einschlägige Tabellenzeile für mittlere Wohnlage und Baualtersklasse. Erhöhung von 6,80 EUR auf 7,20 EUR je Quadratmeter (Steigerung 5,9%, Kappungsgrenze 15% nicht überschritten).

Im Übrigen bleibt der Mietvertrag vom 15.09.2014 unverändert.

Berlin, den 18.07.2023

________________________               ________________________
Wohnen Berlin Immobilien GmbH         Wolfgang Becker / Heike Becker
