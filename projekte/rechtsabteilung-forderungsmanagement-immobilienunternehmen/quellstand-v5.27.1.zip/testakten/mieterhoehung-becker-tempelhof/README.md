# Testakte 3 — Mieterhöhungsverlangen Becker Tempelhof


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 71 KB) | PDF | [testakte-mieterhoehung-becker-tempelhof-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterhoehung-becker-tempelhof-gesamt.pdf) | [`gesamt-pdf/mieterhoehung-becker-tempelhof_gesamt.pdf`](gesamt-pdf/mieterhoehung-becker-tempelhof_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-mieterhoehung-becker-tempelhof.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterhoehung-becker-tempelhof.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-mieterhoehung-becker-tempelhof-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterhoehung-becker-tempelhof-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Bestandsmieterhöhung, Mietspiegel-Begründung, Teilzustimmung und Zustimmungsklage |
| Startskills | `28-mieterhoehung-bgb-558-vorbereiten`, `29-mieterhoehungsverlangen-text`, `30-zustimmungsklage-mieterhoehung`, `31-kappungsgrenze-mietpreisbremse` |
| Kernentscheidung | Welche Zielmiete ist nach Mietspiegel, Sperrfrist, Kappungsgrenze und Teilzustimmung noch streitig? |
| Besonderheit | Das versandte Verlangen nennt ein Badfenster; Begehung und Mieter-E-Mail sprechen später nur von einer Lüftungsöffnung. Historisches Versandstück nicht umschreiben, sondern Spanneneinordnung und Klagebetrag neu prüfen. |

## Sachverhalt in Stichworten

- Vermieterin: Wohnen Berlin Immobilien GmbH (siehe Konzern-Stammdaten)
- Mieter: Eheleute Wolfgang und Heike Becker
- Wohnung: Manfred-von-Richthofen-Straße 18, 12101 Berlin-Tempelhof, 2. OG links
- 78,50 qm, 3 Zimmer, Bj. 1964, mittlere Lage, Standard (Bad mit Wanne, kein Aufzug)
- Vertragsbeginn: 01.10.2014
- Mietdauer 11 Jahre 8 Monate
- Aktuelle Nettokaltmiete: 7,20 EUR/qm = 565,20 EUR
- BK-Vorauszahlung: 165,00 EUR
- HK-Vorauszahlung: 145,00 EUR
- Gesamtmiete brutto: 875,20 EUR
- Letzte Mietanpassung: 01.10.2023 (Erhöhung von 6,80 auf 7,20 EUR/qm)
- Mieter zahlen pünktlich, kein Rückstand

## Mieterhöhungsziel

- Begründung über den bei Zugang geltenden Berliner Mietspiegel 2026 und dokumentierte Spanneneinordnung
- Mietspiegeltabelle 9.2, Zeile 85: Baualtersklasse 1950-1964, ab 45 qm, mittlere Wohnlage
- Spanne laut amtlichem Berliner Mietspiegel 2026: 5,90 bis 9,25 EUR/qm; Mittelwert 7,08 EUR/qm
- Neue Soll-Nettokaltmiete: 7,82 EUR/qm = 613,87 EUR
- Erhöhung: 48,67 EUR / 8,6%; zusammen mit der Erhöhung von 2023 wird die Berliner Kappungsgrenze von 15% ausgeschöpft
- Sperrfrist nach letzter Erhöhung: 12 Monate (§ 558 Abs. 1 S. 2 BGB) erfüllt (10/2023 → 10/2024 früheste Wirkung; Verlangen 06/2026 weit innerhalb erlaubter Frist)
- Wirkungszeitpunkt: 01.09.2026 (§ 558b Abs. 1 BGB)

## Fallstrick

- Das versandte Verlangen bezeichnet ein Badfenster. Die spätere Begehung und die Mieter-E-Mail dokumentieren dagegen nur eine Lüftungsöffnung. Dieser Quellenkonflikt sperrt jede ungeprüfte Übernahme des Merkmals in die Zustimmungsklage.
- Nach Ablauf der Überlegungsfrist ist die Dreimonatsfrist für die Zustimmungsklage nach § 558b Abs. 2 BGB zu überwachen
- Eine Miete innerhalb der Spanne ist nicht automatisch in dieser Höhe bewiesen; die K6-Matrix bleibt gelb, bis die fünf Merkmalgruppen durch Objektbelege geklärt sind
- Streitwert nach § 41 Abs. 5 S. 1 GKG = 12 x **streitiger** Differenzbetrag.
  - Bei Vollwiderspruch: 12 x 48,67 EUR = 584,04 EUR
  - Bei Teilwiderspruch (Mieter stimmen z.B. 7,55 EUR/qm zu, Vermieterin will 7,82 EUR/qm = 0,27 EUR/qm streitig): 12 x 21,19 EUR = 254,28 EUR (so im Klage-Entwurf, da Mieter mit Schreiben vom 24.08.2026 teilweise zugestimmt haben)
- Amtsgericht Kreuzberg, zuständig nach § 23 Nr. 2a GVG und § 29a ZPO

## Skills, die diese Akte abdeckt

- 28-mieterhoehung-bgb-558-vorbereiten
- 29-mieterhoehungsverlangen-text
- 30-zustimmungsklage-mieterhoehung
- 31-kappungsgrenze-mietpreisbremse
- 01-sap-akte-importieren
- 04-belegmatrix-aufbauen

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Aktennotiz zur Mieterhöhungsprüfung | [aktennotiz/aktennotiz-01-mieterhöhungsprüfung.md](aktennotiz/aktennotiz-01-mieterhöhungsprüfung.md) |
| Mietvertrag und Nachträge | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Mietkonto ohne Rückstände | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Merkmalbewertung und Beweislücken | [objekt/merkmalbewertung-mietspiegel-2026.md](objekt/merkmalbewertung-mietspiegel-2026.md) |
| Mieterhöhungsverlangen | [korrespondenz/mieterhöhungsverlangen.md](korrespondenz/mieterhoehungsverlangen.md) |
| Widerspruch der Mieter | [korrespondenz/widerspruch-mieter.md](korrespondenz/widerspruch-mieter.md) |
| E-Mail mit Zustimmungsvorbehalt und DocuWeb-Dublette | [korrespondenz/mieter-antwort-zustimmung-unter-vorbehalt.md](korrespondenz/mieter-antwort-zustimmung-unter-vorbehalt.md) |
| Zustimmungsklage-Entwurf | [korrespondenz/zustimmungsklage.md](korrespondenz/zustimmungsklage.md) |
| DocuWeb-Exportliste mit Versions- und Dublettenspur | [dms/dms-exportliste-mieterhoehung.md](dms/dms-exportliste-mieterhoehung.md) |
| Objektdatenbogen und Modernisierungshistorie | [objekt/objektdatenbogen-modernisierungen.md](objekt/objektdatenbogen-modernisierungen.md) |
| Archivierte Wohnflächenberechnung | [objekt/wohnflaechenberechnung-bestand.md](objekt/wohnflaechenberechnung-bestand.md) |
| Fotoliste mit fehlenden Originaldateien | [objekt/fotoliste-ausstattung-beweisluecken.md](objekt/fotoliste-ausstattung-beweisluecken.md) |
| Einwurfprotokoll des Mieterhöhungsverlangens | [zustellung/einwurfprotokoll-mieterhoehungsverlangen.md](zustellung/einwurfprotokoll-mieterhoehungsverlangen.md) |
| Telefonnotiz zu Aufzug, Balkon, Bad und Fenstern | [hausverwaltung/telefonnotiz-aufzug-balkon.md](hausverwaltung/telefonnotiz-aufzug-balkon.md) |
| Begehungsprotokoll zu den fünf Merkmalgruppen | [objekt/begehungsprotokoll-merkmalgruppen-2026-09-18.md](objekt/begehungsprotokoll-merkmalgruppen-2026-09-18.md) |
| Neues Wohnflächen-Aufmaß mit Balkonberechnung | [objekt/messprotokoll-wohnflaeche-2026-09-18.md](objekt/messprotokoll-wohnflaeche-2026-09-18.md) |
| E-Mail der Mieter zu Wohnfläche, Balkon und Teilzustimmung | [korrespondenz/email-mieter-balkon-wohnflaeche.md](korrespondenz/email-mieter-balkon-wohnflaeche.md) |
