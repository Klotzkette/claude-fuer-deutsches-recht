# E-Mail des Mieters zur Mieterhöhung

Von: wolfgang.becker@example.net

An: forderungsmanagement@wohnen-berlin-immobilien.de

Datum: 12.07.2026, 07:18 Uhr

Betreff: Mieterhöhung Manfred-von-Richthofen-Straße

Guten Morgen,

ich habe Ihr Schreiben bekommen. Ich kann die Berechnung nicht nachvollziehen, weil in meiner Wohnung die Küche alt ist und die Fenster schon lange ziehen. Außerdem steht im Mietspiegel doch nicht einfach nur eine Zahl, sondern eine Spanne.

Ich stimme daher nicht einfach zu. Wenn Sie mir die Berechnung mit den wohnwerterhöhenden und wohnwertmindernden Merkmalen schicken, sehe ich mir das noch einmal an. Ich will keinen Rechtsstreit, aber ich unterschreibe nicht blind.

Mit freundlichen Grüßen

Wolfgang Becker

---

Interner Eingangsstempel: E-Mail wurde am 13.07.2026 zusätzlich als PDF in DocuWeb abgelegt; Dublette erkannt.
