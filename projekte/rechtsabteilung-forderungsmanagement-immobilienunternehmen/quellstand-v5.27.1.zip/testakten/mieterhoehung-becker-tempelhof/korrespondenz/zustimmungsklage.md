# Zustimmungsklage — Entwurf

**ARBEITSSTAND - NICHT EINREICHEN.** Die materielle Spanneneinordnung ist nach Anlage K6 noch nicht freigegeben. Vor Einreichung sind die Objektbelege zu vervollständigen oder der Antrag nach dokumentierter Freigabe zu reduzieren.

An das
**Amtsgericht Kreuzberg**
Möckernstraße 130
10963 Berlin

über den vor Einreichung geprüften sicheren Übermittlungsweg

Berlin, 15.10.2026

**Klage**

der **Wohnen Berlin Immobilien GmbH**, vertreten durch den Geschäftsführer Dr. Markus Lehmann, Friedrichstraße 99, 10117 Berlin

- Klägerin -

Prozessführung im Parteibetrieb durch eine Beschäftigte der Klägerin gemäß § 79 Abs. 2 S. 2 Nr. 1 ZPO. Beschäftigtenstatus und Vollmacht werden belegt; die Bearbeitung der eigenen Forderung ist keine fremde Angelegenheit im Sinne des § 2 Abs. 1 RDG.

Bearbeiterin: Sandra Berger, Rechtsfachwirtin, Tel. 030 2055 4810

**gegen**

1. **Herrn Wolfgang Becker**, geb. 14.03.1962
2. **Frau Heike Becker** geb. Schubert, geb. 09.11.1964

beide wohnhaft Manfred-von-Richthofen-Straße 18, 12101 Berlin

- Beklagte zu 1 und 2 -

wegen Zustimmung zur Mieterhöhung

**Streitwert: 254,28 EUR**

Maßgeblich ist gemäß § 41 Abs. 5 S. 1 GKG der Jahresbetrag der **zusätzlich geforderten** und noch streitigen Miete. Die Beklagten haben mit Schreiben vom 24.08.2026 (Anlage K3) einer Erhöhung auf monatlich 592,68 EUR zugestimmt; verlangt werden monatlich 613,87 EUR. Die Differenz der auf Cent festgelegten Monatsmieten beträgt 21,19 EUR, jährlich 254,28 EUR.

## Anträge

Wir beantragen,

1. die Beklagten zu verurteilen, der mit Verlangen vom 15.06.2026 begehrten, über die bereits erklärte Teilzustimmung hinausgehenden Erhöhung der Nettokaltmiete für die im Hause Manfred-von-Richthofen-Straße 18, 12101 Berlin, im 2. OG links gelegene Wohnung **von monatlich 592,68 EUR auf monatlich 613,87 EUR mit Wirkung ab 01.09.2026 zuzustimmen**,

2. den Beklagten die Kosten des Rechtsstreits aufzuerlegen,

3. das Urteil für vorläufig vollstreckbar zu erklären.

## Begründung

### I. Zuständigkeit

Das Amtsgericht Kreuzberg ist gemäß § 23 Nr. 2a GVG (Wohnraummietstreitigkeiten stets Amtsgericht) und § 29a ZPO (ausschließlicher Gerichtsstand der belegenen Sache) zuständig.

### II. Postulationsfähigkeit

Vor dem Amtsgericht können die Parteien den Rechtsstreit gemäß § 79 Abs. 1 ZPO selbst führen. Die Klägerin lässt sich gemäß § 79 Abs. 2 S. 2 Nr. 1 ZPO durch ihre Beschäftigte, Rechtsfachwirtin Sandra Berger, vertreten.

### III. Sachverhalt

Die Parteien sind durch Wohnraummietvertrag vom 15.09.2014, geändert durch Nachträge Nr. 1 und 2, miteinander verbunden. Aktuelle Nettokaltmiete: 565,20 EUR (7,20 EUR/qm bei 78,50 qm). Letzte Mietanpassung 01.10.2023.

Beweis: Mietvertrag und Nachträge, Anlage K1.

Mit Schreiben vom 15.06.2026 (Anlage K2) hat die Klägerin gemäß § 558 BGB die Zustimmung zur Erhöhung der Nettokaltmiete von 7,20 auf 7,82 EUR/qm (mtl. 613,87 EUR) ab 01.09.2026 verlangt. Die Beklagten haben mit Schreiben vom 24.08.2026 (Anlage K3) ihre teilweise Zustimmung erklärt (Erhöhung auf 7,55 EUR/qm, mtl. 592,68 EUR) und im Übrigen die Zustimmung verweigert.

### IV. Rechtliche Würdigung

### 1. Formelle Wirksamkeit des Verlangens

- Textform gemäß § 558a Abs. 1 BGB: erfüllt
- Begründung mit Berliner Mietspiegel 2026 (qualifiziert nach § 558d BGB): erfüllt
- Einordnung in Mietspiegeltabelle 9.2, Zeile 85 (Baujahr 1950-1964, ab 45 qm, mittlere Lage)
- Sperrfrist § 558 Abs. 1 S. 2 BGB: 12 Monate seit 01.10.2023 erfüllt
- Kappungsgrenze § 558 Abs. 3 S. 2 BGB / Berliner Kappungsgrenzenverordnung: kumulierte Steigerung 6,80 auf 7,82 EUR = 15% in 3 Jahren — gerade noch eingehalten

### 2. Materielle Berechtigung — ortsübliche Vergleichsmiete

Die geforderte Miete in Höhe von 7,82 EUR/qm liegt innerhalb der Spanne von 5,90 bis 9,25 EUR/qm der Mietspiegeltabelle 9.2, Zeile 85, jedoch oberhalb des Mittelwerts von 7,08 EUR/qm. Die konkrete Einordnung richtet sich nach den tatsächlich feststellbaren Merkmalen der amtlichen Orientierungshilfe. Anlage K6 weist derzeit offene und widersprüchliche Tatsachen aus; insbesondere Fensterbestand, Küchenumfang, energetischer Zustand und behauptete besondere Lärmbelastung sind noch beweisbedürftig. Der Entwurf darf deshalb erst nach Belegschluss, Neuberechnung und Freigabe eingereicht werden.

Beweis: Sachverständigengutachten

### 3. Wirkungszeitpunkt

Das Verlangen ist den Beklagten am 18.06.2026 zugegangen. Wirksamkeitsbeginn nach § 558b Abs. 1 BGB: Beginn des dritten Kalendermonats nach Zugang, also 01.09.2026 (Juli und August sind Überlegungsmonate).

## Anlagen

- K1 Mietvertrag vom 15.09.2014 nebst Nachträgen
- K2 Mieterhöhungsverlangen vom 15.06.2026
- K3 Antwortschreiben Mieter vom 24.08.2026
- K4 Berliner Mietspiegel 2026, Tabelle 9.2, Zeile 85 (Auszug)
- K5 Berliner Wohnlagenkarte, Auszug Tempelhof
- K6 Merkmalbewertung mit Objektbelegen

Sandra Berger
Rechtsfachwirtin, Forderungsmanagement
Wohnen Berlin Immobilien GmbH
