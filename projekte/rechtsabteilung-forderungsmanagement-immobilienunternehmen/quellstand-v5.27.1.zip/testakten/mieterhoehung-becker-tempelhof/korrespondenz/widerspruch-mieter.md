# Antwortschreiben der Mieter — Teilzustimmung mit Begründung

Eheleute Wolfgang und Heike Becker
Manfred-von-Richthofen-Straße 18
12101 Berlin

An die
Wohnen Berlin Immobilien GmbH
Frau Sandra Berger
Friedrichstraße 99
10117 Berlin

Berlin, 24.08.2026

**Ihr Mieterhöhungsverlangen vom 15.06.2026**

Sehr geehrte Frau Berger,

wir haben Ihr Mieterhöhungsverlangen erhalten und mit dem Berliner Mieterverein eingehend besprochen.

Aus unserer Sicht ist die geforderte Erhöhung von 0,62 EUR/qm zu hoch. Die Wohnung weist mehrere Negativmerkmale auf, die wir bei der Einordnung in die Mietspiegelspanne berücksichtigt sehen wollen:

- kein Aufzug (4-stöckiges Gebäude, wir wohnen im 2. OG)
- Bad ohne separate Lüftung, Lichtschacht nur klein
- einfach verglaste Fenster auf der Hofseite
- keine Modernisierung in den letzten 15 Jahren
- die Straße weist Verkehrslärm auf

Wir sind ungeachtet unserer Einwände bereit, einer Mieterhöhung auf **7,55 EUR/qm** zuzustimmen. Dieser Betrag liegt bereits über dem Mittelwert von 7,08 EUR/qm der von Ihnen herangezogenen Tabelle. Das ergibt eine neue Nettokaltmiete von 592,68 EUR (Erhöhung 27,48 EUR / 4,86%).

Sollten Sie dem nicht zustimmen, sehen wir uns leider gezwungen, eine mögliche Zustimmungsklage abzuwarten.

Mit freundlichen Grüßen

Wolfgang Becker / Heike Becker
