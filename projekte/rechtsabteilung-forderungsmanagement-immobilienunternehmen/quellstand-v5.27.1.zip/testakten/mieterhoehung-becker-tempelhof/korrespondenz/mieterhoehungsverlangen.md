# Mieterhöhungsverlangen nach § 558 BGB

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99, 10117 Berlin
Abteilung Forderungsmanagement — Frau Sandra Berger, Rechtsfachwirtin
Tel. 030 2055 4810

Eheleute
Wolfgang und Heike Becker
Manfred-von-Richthofen-Straße 18
12101 Berlin

Berlin, 15.06.2026

**Verlangen der Zustimmung zur Erhöhung der Nettokaltmiete (§ 558 BGB)**

Sehr geehrte Eheleute Becker,

unter Bezugnahme auf den Wohnraummietvertrag vom 15.09.2014 nebst Nachträgen, die Sie über die im Hause Manfred-von-Richthofen-Straße 18, 12101 Berlin, im 2. OG links gelegene 3-Zimmer-Wohnung (Wohnfläche ca. 78,50 qm) angemietet haben, verlangen wir Ihre Zustimmung zur Erhöhung der Nettokaltmiete.

## 1. Aktuelle und künftige Miete

| Position | Bisher | Künftig |
|---|---|---|
| Wohnfläche | 78,50 qm | 78,50 qm |
| Nettokaltmiete je qm | 7,20 EUR | 7,82 EUR |
| Nettokaltmiete monatlich | 565,20 EUR | 613,87 EUR |
| Erhöhung absolut | | 48,67 EUR |
| Erhöhung in Prozent | | 8,61% |

Betriebskosten- und Heizkostenvorauszahlung bleiben unverändert.

Neue Bruttowarmmiete: 923,87 EUR.

Wirksamkeit: ab dem **1. September 2026** (Beginn des dritten Kalendermonats nach Zugang dieses Verlangens, § 558b Abs. 1 BGB).

## 2. Begründung — Berliner Mietspiegel 2026

Die geforderte Miete liegt innerhalb der Spanne des Berliner Mietspiegels 2026. Begründet wird das Verlangen mit diesem qualifizierten Mietspiegel gemäß § 558d BGB, veröffentlicht und in Kraft getreten am 28.05.2026.

### Einordnung der Wohnung in die Mietspiegeltabelle

- Baualtersklasse: 1950-1964 (Baujahr 1964)
- Wohnflächenklasse: ab 45 qm
- Wohnlage nach amtlichem Straßenverzeichnis 2026: **mittel**
- Mietspiegeltabelle: **9.2, Zeile 85**
- Spannenwerte: Unterwert 5,90 EUR, Mittelwert 7,08 EUR, Oberwert 9,25 EUR (Nettokaltmiete pro qm)

### Sondermerkmale / Spanneneinordnung

Innerhalb der Spanne wird die geforderte Miete in Höhe von 7,82 EUR/qm angesetzt. Sie liegt oberhalb des Mittelwerts. Die Einordnung ist anhand der amtlichen Orientierungshilfe und der Objektbelege zu prüfen; berücksichtigt werden insbesondere:

- Standard-Ausstattung (Bad mit Wanne und Fenster, Sammelheizung)
- kein Aufzug (Negativmerkmal)
- Balkon (positives Merkmal)
- weitere Merkmale aus Küche, Wohnung, Gebäude und Wohnumfeld gemäß beigefügter Merkmalbewertung; offene oder streitige Merkmale sind dort kenntlich gemacht

## 3. Kappungsgrenze Berlin (15% in 3 Jahren)

Letzte Mietanpassung: 01.10.2023, von 6,80 auf 7,20 EUR/qm (Steigerung 5,9%).
Aktuelle Forderung: von 7,20 auf 7,82 EUR/qm (Steigerung 8,6%).
Kumulierte Steigerung der letzten 3 Jahre: von 6,80 auf 7,82 EUR/qm = **15,0%**.

Damit ist die Kappungsgrenze von 15% innerhalb von 3 Jahren genau eingehalten (Berliner Kappungsgrenzen-Verordnung vom 14.03.2023, in Kraft vom 11.05.2023 bis zum 10.05.2028; § 558 Abs. 3 S. 2 BGB).

## 4. Sperrfrist (§ 558 Abs. 1 BGB)

Die letzte Erhöhung wurde zum 01.10.2023 wirksam. Das neue Verlangen wird mehr als ein Jahr später erklärt; die Erhöhung soll zum 01.09.2026 wirksam werden, zu diesem Zeitpunkt ist die Miete deutlich länger als 15 Monate unverändert. Damit sind das Einjahres-Gate für das Verlangen und das 15-Monats-Gate für die Wirksamkeit nach § 558 Abs. 1 BGB gewahrt.

## 5. Bitte um Zustimmung

Wir bitten Sie, der oben genannten Mieterhöhung **bis spätestens 31.08.2026** zuzustimmen (§ 558b Abs. 1 BGB). Zur eindeutigen Dokumentation bitten wir um eine Erklärung in Textform; die Zustimmung ist gesetzlich nicht an diese Form gebunden.

Sollten Sie nicht oder nicht vollständig zustimmen, kann die Vermieterin gemäß § 558b Abs. 2 BGB innerhalb von drei weiteren Monaten Klage auf Zustimmung erheben; bei Fristablauf am 31.08.2026 endet diese Klagefrist am 30.11.2026.

## 6. Hinweis

Nach § 561 BGB steht Ihnen ein Sonderkündigungsrecht zu: Sie können das Mietverhältnis bis zum Ablauf des zweiten Monats nach Zugang dieses Verlangens spätestens zum Ablauf des übernächsten Monats kündigen. In diesem Fall wird die Mieterhöhung nicht wirksam.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin, Forderungsmanagement
Wohnen Berlin Immobilien GmbH

Anlagen:
- Auszug Berliner Mietspiegel 2026, Tabelle 9.2, Zeile 85
- Merkmalbewertung zur Spanneneinordnung
- Berliner Wohnlagenkarte, Auszug Tempelhof
