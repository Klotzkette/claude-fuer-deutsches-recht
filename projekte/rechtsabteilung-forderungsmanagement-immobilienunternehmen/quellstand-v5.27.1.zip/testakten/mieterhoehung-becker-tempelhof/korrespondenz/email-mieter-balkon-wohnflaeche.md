# E-Mail-Ausdruck

Von: heike.becker@example.org

An: mietenanpassung@wohnen-berlin.example

Datum: 21.09.2026, 19:33 Uhr

Betreff: Begehung am 18.09. / Wohnfläche und Balkon

Sehr geehrte Frau Vogt,

vielen Dank für den Termin. Ich möchte festhalten, dass wir der Vermessung des Balkons nicht als Anerkennung der Wohnfläche oder der verlangten Miete zugestimmt haben.

In unseren alten Unterlagen steht einmal 78,50 qm. Mein Mann hat außerdem eine handschriftliche Berechnung des Vormieters gefunden, die auf ungefähr 76 qm kommt. Wir wissen nicht, welche Fläche richtig ist. Bitte schicken Sie uns die Berechnung, auf die Sie sich stützen.

Der Balkon ist schmal und wegen des Verkehrs für uns nur eingeschränkt nutzbar. Das Küchenfenster ist deutlich älter als die anderen Fenster. Die Küchenmöbel und Geräte haben wir selbst gekauft. Im Bad gibt es nach unserer Wahrnehmung kein richtiges Fenster, sondern nur den kleinen Lüftungsschacht.

Unsere Teilzustimmung vom 24.08.2026 bleibt bestehen. Einer weitergehenden Erhöhung stimmen wir derzeit nicht zu.

Mit freundlichen Grüßen

Heike Becker
