# Anlage K6 - Merkmalbewertung Berliner Mietspiegel 2026

Wohnen Berlin Immobilien GmbH

Objekt: Manfred-von-Richthofen-Straße 18, 12101 Berlin

Wohnung: 2. OG links, Wolfgang und Heike Becker

Versionsstand: Erstfassung 10.06.2026; nach Mietervortrag fortgeschrieben am 10.10.2026

Status: **ARBEITSSTAND - NICHT ZUR EINREICHUNG FREIGEGEBEN**

## 1. Tabellenbasis

| Merkmal | Zuordnung |
|---|---|
| Wohnlage | mittel, Straßenverzeichnis 2026 |
| Bezugsfertigkeit | 1964 |
| Wohnfläche | 78,50 m² |
| Tabelle | 9.2, Zeile 85 |
| Spanne | 5,90 bis 9,25 EUR/m² |
| Mittelwert | 7,08 EUR/m² |
| verlangte Miete | 7,82 EUR/m² |

## 2. Tatsachen- und Beweismatrix nach Fortschreibung

| Merkmalgruppe | Aktenkonflikt und fehlender Beleg | Ergebnis |
|---|---|---|
| Bad/WC | Vermieterin nennt Wanne und Fenster; die Mieter nennen nur einen kleinen Lichtschacht und keine separate Lüftung. Mietvertrag, aktuelle Fotos und Modernisierungsrechnung belegen die Ausstattung nicht. | offen |
| Küche | Der Vermieterangabe zu Heizung und Warmwasser steht der Einwand einer alten Küche gegenüber. Eigentum und Umfang der Einbauküche, Boden, Wandschutz und Geräte sind nicht dokumentiert. | offen |
| Wohnung | Ein Balkon ist vorhanden. Balkongröße, Fensterbaujahr und Flächenanteil der behaupteten Einfachverglasung fehlen. | offen |
| Gebäude | Kellerraum und Gegensprechanlage sind angegeben. Energieausweis, Rechnungen und aktueller Treppenhauszustand fehlen. Ein fehlender Aufzug im 2. OG ist kein Merkmal der Orientierungshilfe. | offen |
| Wohnumfeld | Das Straßenverzeichnis belegt die mittlere Tabellenlage. Für die behauptete besondere Verkehrslärmbelastung fehlen Lärmkarte oder objektbezogene Mess- und Kartendaten. | offen |

## 3. Rechenkontrolle

Die amtliche Orientierungshilfe gewichtet jede der fünf Merkmalgruppen mit 20 Prozent. Für Zeile 85 beträgt die Differenz zwischen Mittelwert und Oberwert 2,17 EUR/m². Die verlangten 7,82 EUR/m² liegen 0,74 EUR/m² über dem Mittelwert. Dafür müssten die festgestellten Gruppen im Ergebnis mindestens eine ausreichend positive Spanneneinordnung tragen; zugleich begrenzt die Kappungsgrenze die Zielmiete auf 7,82 EUR/m².

Der aktuelle Aktenstand trägt keine abschließende Gruppensaldierung. Weder die Vermieterangaben noch der Mietervortrag dürfen ohne Beleg als erwiesen übernommen werden.

## 4. Nachforderung vor Freigabe

1. Übergabeprotokoll und aktuelle, datierte Raumfotos anfordern.
2. Balkongröße und Fensterbestand je Raum dokumentieren.
3. Vermieterseitig gestellte Küchenausstattung vom Mietereigentum trennen.
4. Energieausweis und Rechnungen zu Heizung, Fassade, Dach und Fenstern beiziehen.
5. Behauptete besondere Lärmbelastung anhand der amtlichen Lärmkarte objektbezogen prüfen.
6. Danach jede Merkmalgruppe mit Einzelmerkmal, Quelle und Ergebnis neu bewerten.

## 5. Freigabeentscheidung

**Ampel gelb.** Das Mieterhöhungsverlangen ist versandt, die materielle Höhe von 7,82 EUR/m² ist aber noch nicht klagereif belegt. Die Zustimmungsklage bleibt Entwurf. Vor Einreichung sind entweder die fehlenden Belege zu beschaffen und die Spanneneinordnung neu zu rechnen oder der Antrag nach dokumentierter Freigabe auf den tragfähigen Betrag zu reduzieren.
