# Wohnflächenberechnung 2. OG links

## 1 Archivblatt

Objekt: Manfred-von-Richthofen-Straße 18, 12101 Berlin

Wohnung: 2. Obergeschoss links

Aufmaß laut Planrevision: 17.08.1994

| Raum | Länge | Breite oder Teilfläche | Wohnfläche |
|---|---:|---:|---:|
| Wohnzimmer | 5,68 m | 3,75 m | 21,30 qm |
| Schlafzimmer | 4,00 m | 3,95 m | 15,80 qm |
| Zimmer | Teilflächen | 11,95 qm | 11,95 qm |
| Küche | Teilflächen | 9,20 qm | 9,20 qm |
| Bad | Teilflächen | 5,10 qm | 5,10 qm |
| Flur und Abstellnische | Teilflächen | 9,15 qm | 9,15 qm |
| Balkon | Grundfläche 12,00 qm | Ansatz 50 Prozent | 6,00 qm |
| Gesamt | | | 78,50 qm |

## 2 Randvermerke des Archivscans

Auf dem Blatt steht handschriftlich „Balkon nach Bauakte, nicht nachgemessen“. Ein Namenskürzel ist vorhanden, aber nicht lesbar. Ein jüngeres Aufmaß oder ein wohnungsbezogenes Übergabeprotokoll wurde im Export nicht gefunden.

## 3 Scanstatus

Vier Blattecken sind sichtbar. Der Maßstab des eingescannten Plans ist wegen nachträglicher Verkleinerung nicht verlässlich. Die Rechenwerte sind lesbar; die zugrunde liegenden Maßlinien sind teilweise blass.
