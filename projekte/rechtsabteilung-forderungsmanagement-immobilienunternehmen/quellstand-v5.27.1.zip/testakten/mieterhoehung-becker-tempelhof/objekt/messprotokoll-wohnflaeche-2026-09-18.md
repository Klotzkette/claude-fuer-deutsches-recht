# Aufmaßprotokoll Wohnung Becker

Wohnen Berlin Immobilien GmbH

Technisches Bestandsmanagement

**Objekt:** Manfred-von-Richthofen-Straße 18, 12101 Berlin

**Wohnung:** 2. OG links

**Vertragsnummer:** WBI-MV-2014-02185

**Aufmaß:** 18.09.2026, 09:15 bis 10:26 Uhr

**Anwesend:** Wolfgang Becker, Heike Becker, Bauzeichnerin Julia Conrad

## 1. Anlass und Methode

Anlass war die E-Mail der Mieter zur Wohnfläche und zur Anrechnung des Balkons. Gemessen wurde mit Laserdistanzmessgerät Leica Disto D2, Gerätenummer TD-0417, letzte interne Kontrollmessung 02.08.2026. Nischen, Vormauerungen und Teilflächen wurden vor Ort skizziert. Die Berechnung folgt der Wohnflächenverordnung; Raumhöhen unter zwei Metern lagen nicht vor.

## 2. Raumflächen

| Raum | Erfasste Teilflächen | Anrechenbare Wohnfläche |
|---|---|---:|
| Wohnzimmer | Rechteck abzüglich Schornsteinzug | 22,84 qm |
| Schlafzimmer | Rechteck abzüglich Vormauerung | 16,35 qm |
| Zimmer | Rechteck | 12,10 qm |
| Küche | Rechteck und Fensternische | 9,42 qm |
| Bad | Rechteck abzüglich Installationsschacht | 5,20 qm |
| Flur | drei Teilrechtecke | 8,71 qm |
| Abstellnische | Grundfläche | 1,88 qm |
| **Innenräume** |  | **76,50 qm** |
| Balkon | Grundfläche 8,00 qm, Ansatz 25 Prozent | 2,00 qm |
| **Gesamtwohnfläche** |  | **78,50 qm** |

## 3. Abweichung zum Archivblatt

Das Archivblatt von 1994 weist ebenfalls 78,50 qm aus, setzt jedoch eine nicht nachgemessene Balkongrundfläche von 12,00 qm zur Hälfte an. Das aktuelle Aufmaß ergibt eine Balkongrundfläche von 8,00 qm und berücksichtigt diese wegen Ausrichtung, Tiefe und normaler Nutzbarkeit mit 25 Prozent. Zugleich sind die Innenraumflächen im Archivblatt um insgesamt 4,00 qm niedriger als im aktuellen Aufmaß. Beide gegenläufigen Abweichungen führen zufällig zum gleichen Gesamtergebnis.

Die Balkonaußenkante war frei zugänglich. Gemessen wurde bis zur Innenseite der Brüstung und bis zur Außenkante der Wohnungstrennwand. Ein ausschließlich zur Fassade gehörender Sims wurde nicht einbezogen.

## 4. Freigabe und Anlagen

Herr und Frau Becker waren bei den Messungen anwesend. Sie erhielten Gelegenheit, die Messpunkte zu zeigen und wiesen auf die abweichende Balkonangabe des Altplans hin. Mit ihrer Unterschrift bestätigen sie nur Anwesenheit und Erhalt einer Kopie, nicht die rechtliche Bewertung.

Zum Protokoll gehören die handschriftliche Aufmaßskizze A-2026-184-1, vier Fotos der Messpunkte und das Geräteprüfblatt TD-0417. Die Quelldateien liegen im technischen Objektordner; für eine gerichtliche Anlage ist eine unveränderte PDF-Fassung mit Anlagenbezeichnung zu erzeugen.

Berlin, 18.09.2026

Julia Conrad — Technisches Bestandsmanagement

Wolfgang Becker — Kopie erhalten

Heike Becker — Kopie erhalten
