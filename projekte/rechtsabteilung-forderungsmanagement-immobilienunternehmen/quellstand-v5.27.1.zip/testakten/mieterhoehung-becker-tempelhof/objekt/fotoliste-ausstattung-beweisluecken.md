# Fotoliste Wohnung Becker

## 1 DMS-Index

| Bild-ID | Angegebenes Motiv | Aufnahmedatum | Dateistatus | Bemerkung |
|---|---|---|---|---|
| IMG-2014-02185-01 | Wohnzimmer Fenster | 22.09.2014 | Vorschaubild vorhanden | Originaldatei fehlt |
| IMG-2014-02185-02 | Küche | 22.09.2014 | nicht exportiert | angeblich Mieter-Einbauküche |
| IMG-2014-02185-03 | Bad | 22.09.2014 | Vorschaubild stark komprimiert | Lichtöffnung nicht erkennbar |
| IMG-2014-02185-04 | Balkon | 22.09.2014 | Original vorhanden, aber ohne Maßstab | Bodenbelag sichtbar |
| IMG-2017-018-77 | neues Fenster Schlafzimmer | 04.09.2017 | Original vorhanden | Raum nicht beschriftet |
| IMG-2017-018-78 | neues Fenster | 04.09.2017 | Original vorhanden | zweiter Raum unklar |
| IMG-2026-02185-01 | Treppenhaus 2. OG | 08.06.2026 | Mobilfoto vorhanden | kein Wohnungsmerkmal |

## 2 Exportbefund

Der angeforderte Bildexport enthält nur die Dateiliste. Die Bilddateien IMG-2014-02185-01 bis -03 wurden bei der Altsystemmigration nicht übernommen. Für das Bad, die Küchenausstattung und die genaue Balkongröße liegt damit kein aktuelles Foto vor.
