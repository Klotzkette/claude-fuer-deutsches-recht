# Objektdatenbogen Manfred-von-Richthofen-Straße 18

## 1 Grunddaten

| Feld | Bestand |
|---|---|
| Wirtschaftseinheit | WBI-TEM-018 |
| Bezugsfertigkeit | 1964 |
| Gebäudeteile | Vorderhaus, fünf Vollgeschosse |
| Aufzug | nein |
| Zentralheizung | ja |
| Warmwasser | zentral |
| Energieausweis | DMS-Index vorhanden, Datei im Export nicht enthalten |

## 2 Maßnahmenhistorie

| Jahr | Maßnahme | Umfang | Beleglage |
|---:|---|---|---|
| 1998 | Heizzentrale erneuert | Gesamtobjekt | Schlussrechnung vorhanden |
| 2006 | Strangsanierung Bad | Wohnungen links | Abnahmeprotokoll ohne Wohnungsliste |
| 2011 | Gegensprechanlage | Gesamtobjekt | Sammelrechnung vorhanden |
| 2017 | Fensteraustausch | laut Auftrag Schlaf- und Kinderzimmer 2. OG links | Rechnung nennt nur Objekt, nicht Räume |
| 2019 | Fassadenanstrich Hof | Hofseite | Wartungsbudget |
| 2024 | Kellerbeleuchtung LED | Gemeinschaftsflächen | Rechnung vorhanden |

## 3 Wohnung 2. OG links

| Merkmal | Verwaltungsangabe | Stand |
|---|---|---|
| Bad | Wanne, Fenster oder Lichtschacht nicht eindeutig | offen |
| Küche | Anschluss für Elektroherd, Einbauten nicht vermieterseits erfasst | offen |
| Balkon | hofseitig, Grundfläche laut Altplan 12,00 qm | Plan ungeprüft |
| Fenster | zwei Räume 2017, übriger Bestand unbekannt | teilweise belegt |
| Keller | Kellerraum Nr. 18-L | zugeordnet |

## 4 Systemhinweis

Der Datensatz wurde 2022 aus einem Altsystem übernommen. Felder mit dem Wert „ja“ können aus damaligen Sammelmaßnahmen stammen und ersetzen keinen wohnungsbezogenen Beleg.
