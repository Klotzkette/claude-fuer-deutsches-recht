# Begehungsprotokoll Wohnung

Wohnen Berlin Immobilien GmbH

Objektmanagement Tempelhof

## 1. Termin

| Feld | Inhalt |
|---|---|
| Datum | 18.09.2026 |
| Zeit | 14:00 bis 14:42 Uhr |
| Objekt | Manfred-von-Richthofen-Straße 18, 12101 Berlin |
| Wohnung | 2. OG links |
| Mieter | Wolfgang und Heike Becker |
| Vertragsnummer | WBI-MV-2014-02185 |
| Anwesend | Heike Becker, Maren Vogt Objektmanagement |

## 2. Bad und WC

Das Bad verfügt über eine Badewanne, ein Handwaschbecken und ein WC. Ein unmittelbar ins Freie führendes Fenster ist nicht vorhanden. Oberhalb der Tür befindet sich eine mechanische Abluftöffnung; deren Funktion wurde im Termin nicht technisch gemessen. Die Wandflächen sind im Nassbereich teilweise gefliest.

## 3. Küche

Warm- und Kaltwasseranschluss sowie ein Anschluss für einen Elektroherd sind vorhanden. Die sichtbaren Unterschränke und Elektrogeräte wurden von Frau Becker als Mietereigentum bezeichnet. Ein Übergabeprotokoll zur ursprünglichen Küchenausstattung wurde beim Termin nicht vorgelegt.

## 4. Wohnung

Der Balkon ist vom Wohnzimmer zugänglich. Die nutzbare Bodenfläche wurde überschlägig mit 1,45 m mal 3,10 m gemessen. Die Messung ist keine förmliche Wohnflächenberechnung.

Im Wohnzimmer und Schlafzimmer befinden sich zweifach verglaste Kunststofffenster. In der Küche ist ein älteres Holzfenster vorhanden. Baujahre oder Rechnungsbelege waren vor Ort nicht feststellbar.

## 5. Gebäude und Wohnumfeld

Ein Personenaufzug ist nicht vorhanden. Kellerraum und Gegensprechanlage sind vorhanden. Der Hauseingang und das Treppenhaus waren am Termin gereinigt; Schäden an zwei Wandflächen im ersten Obergeschoss waren sichtbar.

Straßenverkehr war bei geschlossenem Wohnzimmerfenster hörbar. Eine Lärmmessung wurde nicht durchgeführt.

## 6. Unterlagen

Frau Becker gestattete fünf Übersichtsaufnahmen ohne persönliche Gegenstände. Die Originaldateien wurden unter den Bildnummern OV-TF-260918-01 bis -05 auf dem Dienstgerät gespeichert.

Berlin, 18.09.2026

Maren Vogt

Objektmanagement Tempelhof
