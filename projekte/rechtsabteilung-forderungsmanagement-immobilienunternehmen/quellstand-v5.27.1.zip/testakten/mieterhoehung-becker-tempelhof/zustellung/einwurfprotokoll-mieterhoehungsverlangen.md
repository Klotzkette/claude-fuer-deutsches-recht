# Einwurfprotokoll Mieterhöhungsverlangen

## 1 Empfänger und Sendung

| Feld | Inhalt |
|---|---|
| Empfänger | Wolfgang Becker und Heike Becker |
| Anschrift | Manfred-von-Richthofen-Straße 18, 12101 Berlin, 2. OG links |
| Dokument | Mieterhöhungsverlangen vom 15.06.2026, neun Seiten |
| Einwurf | 18.06.2026, 10:06 Uhr |
| Zustellerin | Kathrin Seidel, Hauspost Süd |

## 2 Wahrnehmung

Der Briefkasten befindet sich im Hausflur links neben der Haustür und war mit „W. + H. Becker“ beschriftet. Der verschlossene C4-Umschlag wurde vollständig durch den Einwurfschlitz geschoben. Er fiel hörbar in den Briefkasten und war anschließend nicht mehr greifbar.

Die Hauspostzustellerin hatte den Inhalt des Umschlags unmittelbar vor dem Verschließen mit der Versandliste abgeglichen. Auf der Liste sind Vertragsnummer WBI-MV-2014-02185 und neun Seiten vermerkt.

## 3 Bestätigung

Berlin, 18.06.2026

Kathrin Seidel

Scanvermerk: Original der Tagesliste im Poststellenordner 2026-06-18; Einzelprotokoll am 20.06.2026 eingescannt.
