# SAP Statusauszug — Mietkonto Becker

Stand: 02.06.2026 / 11:45 Uhr
Auszug aus SAP RE-FX, Transaktion FBL5N

## Geschäftspartner

- Partnernummer: 4001354
- Hauptmieter: Becker, Wolfgang, geb. 14.03.1962
- Mitmieterin: Becker, Heike geb. Schubert, geb. 09.11.1964
- Familienstand: verheiratet
- Beruf Wolfgang Becker: Lagerist (Berliner Verkehrsbetriebe BVG)
- Beruf Heike Becker: Bürokauffrau (Senatsverwaltung Berlin)
- Telefon: 030 7515 1144
- E-Mail: w.becker62@web.de

## Mietobjekt

- Objektnummer: WBI-TEM-018-02L
- Adresse: Manfred-von-Richthofen-Straße 18, 12101 Berlin-Tempelhof
- Lage: 2. OG links
- Wohnfläche: 78,50 qm
- Zimmer: 3
- Baujahr Gebäude: 1964
- Wohnlage nach Berliner Mietspiegel 2026: mittel
- Ausstattung: Standard (Bad mit Wanne und Fenster, Sammelheizung, kein Aufzug, Balkon)
- Heizung: Zentral, Gas
- Warmwasser: zentral

## Vertragsdaten

- Vertragsnummer: WBI-MV-2014-02185
- Mietbeginn: 01.10.2014
- Befristung: unbefristet
- Letzte Mietanpassung: 01.10.2023 nach § 558 BGB (6,80 auf 7,20 EUR/qm)
- Kaution: 1500,00 EUR (Sparbuch)

## Mietzins aktuell

- Nettokaltmiete: 565,20 EUR (7,20 EUR/qm x 78,50 qm)
- Betriebskostenvorauszahlung: 165,00 EUR
- Heizkostenvorauszahlung: 145,00 EUR
- Bruttowarmmiete gesamt: 875,20 EUR
- Fälligkeit: 3. Werktag des Monats
- Zahlungsverhalten: einwandfrei, seit Vertragsbeginn keine Rückstände

## Saldo Mietkonto

- Saldo zum 02.06.2026: 0,00 EUR
- Letzter Zahlungseingang: 02.06.2026, 875,20 EUR (Miete 06/2026)

## Aktuelle Vorgänge

- 02.06.2026 Mieterhöhungsverlangen vorbereitet (Begründung Berliner Mietspiegel 2026)
- Verfasserin: Rechtsfachwirtin Sandra Berger
- Versandziel: 15.06.2026

## Bemerkungen

- Sperrfrist § 558 Abs. 1 S. 2 BGB: 12 Monate seit letzter Mieterhöhung (01.10.2023). Früheste Wirkung der nächsten Erhöhung war 01.10.2024, daher problemlos.
- Kappungsgrenze Berlin: 15% in 3 Jahren nach der Kappungsgrenzen-Verordnung vom 14.03.2023. Letzte Erhöhung 6,80 auf 7,20 EUR je Quadratmeter = 5,9%. Mieterhöhung auf 7,82 EUR je Quadratmeter beschränken; damit beträgt die Gesamtsteigerung gegenüber 6,80 EUR zu Beginn des relevanten Drei-Jahres-Zeitraums 15%.
- Korrigierter neuer Mietzins: 7,82 EUR/qm = 613,87 EUR.
- Differenz alt zu neu: 48,67 EUR / 8,6%.
