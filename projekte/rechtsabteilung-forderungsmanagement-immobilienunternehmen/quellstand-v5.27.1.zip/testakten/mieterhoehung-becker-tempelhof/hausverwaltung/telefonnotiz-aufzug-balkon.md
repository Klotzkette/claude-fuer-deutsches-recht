# Telefonnotiz Objektmerkmale

## 1 Gesprächsdaten

| Feld | Inhalt |
|---|---|
| Datum | 09.10.2026, 10:42 bis 10:58 Uhr |
| Gesprächspartner | Jens Wuttke, technischer Objektbetreuer |
| Bearbeitung | Sandra Berger |
| Vorgang | ME-2026-00184 |

## 2 Angaben

Herr Wuttke bestätigt, dass das Gebäude keinen Aufzug hat und nach seiner Kenntnis auch nie einen hatte. Der hofseitige Balkon der Wohnung sei „ungefähr zwölf Quadratmeter groß“. Er habe ihn nicht nachgemessen. Die Brüstung sei 2019 gestrichen worden.

Zu den Fenstern könne Herr Wuttke nur sagen, dass im Jahr 2017 in mehreren Wohnungen einzelne Fenster getauscht wurden. Ob in der Wohnung Becker alle oder nur zwei Fenster erneuert wurden, ergebe sich aus seiner Liste nicht. Das Badezimmer habe nach Erinnerung des früheren Hausmeisters einen kleinen Lichtschacht; ein normal zu öffnendes Fenster könne er nicht bestätigen.

Im Keller befinde sich ein der Wohnung zugeordneter Raum. Die Gegensprechanlage sei funktionsfähig. Die Einbauküche habe das Ehepaar nach seiner Erinnerung selbst eingebracht; ein Übergabeprotokoll liege ihm nicht vor.

## 3 Nachlauf

Herr Wuttke sucht im Papierarchiv nach der Wohnungsliste zum Fensterauftrag 2017. Rückmeldung bis 14.10.2026 zugesagt.
