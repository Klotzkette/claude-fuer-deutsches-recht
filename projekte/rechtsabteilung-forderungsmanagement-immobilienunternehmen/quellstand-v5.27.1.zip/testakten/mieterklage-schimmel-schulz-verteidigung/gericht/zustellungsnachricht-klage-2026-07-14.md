# Amtsgericht Charlottenburg

## Elektronische Zustellungsnachricht

| Feld | Inhalt |
|---|---|
| Geschäftsnummer | 217 C 166/26 |
| Absender | Amtsgericht Charlottenburg |
| Empfängerin | Wohnen Berlin Immobilien GmbH |
| Nachrichtentyp | Zustellung gegen elektronisches Empfangsbekenntnis |
| Eingang im Gesellschaftspostfach | 14.07.2026, 10:16 Uhr |
| Zur Kenntnis genommen | 14.07.2026, 10:41 Uhr |
| Zustellungsdatum laut Empfangsbekenntnis | 14.07.2026 |
| Anlagen | Klageschrift vom 08.07.2026; gerichtliche Verfügung vom 14.07.2026 |

**Interne Weiterleitung:** 14.07.2026, 11:03 Uhr an Forderungsmanagement und Zentrale Fristenstelle.

**Fristenstelle:** Verteidigungsanzeige 28.07.2026; Klageerwiderung 11.08.2026. Erfasst durch S. Arndt am 14.07.2026, 11:22 Uhr; Gegenkontrolle durch P. Yilmaz am 14.07.2026, 11:35 Uhr.
