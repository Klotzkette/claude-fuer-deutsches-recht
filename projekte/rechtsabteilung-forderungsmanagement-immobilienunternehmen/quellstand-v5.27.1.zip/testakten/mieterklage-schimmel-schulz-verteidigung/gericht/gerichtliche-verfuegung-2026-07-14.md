# Amtsgericht Charlottenburg

Amtsgerichtsplatz 1
14057 Berlin

## Verfügung

**Geschäftsnummer:** 217 C 166/26
**Datum:** 14.07.2026

In dem Rechtsstreit

**Schulz u. a. gegen Wohnen Berlin Immobilien GmbH**

wird das schriftliche Vorverfahren angeordnet.

Die Beklagte wird gemäß § 276 Abs. 1 Satz 1 ZPO aufgefordert, innerhalb einer Notfrist von zwei Wochen nach Zustellung der Klageschrift schriftlich anzuzeigen, dass sie sich gegen die Klage verteidigen will. Die Frist zur Anzeige der Verteidigungsbereitschaft kann nicht verlängert werden.

Die Beklagte wird ferner aufgefordert, innerhalb von weiteren zwei Wochen auf die Klage schriftlich zu erwidern. Bei einer Zustellung am 14.07.2026 endet die Notfrist zur Verteidigungsanzeige am 28.07.2026. Die Klageerwiderung ist bis zum 11.08.2026 einzureichen.

Die Verteidigungsmittel sind vollständig und geordnet vorzutragen. Urkunden, auf die Bezug genommen wird, sollen in lesbarer Form beigefügt werden. Die Parteien werden auf die Folgen verspäteten Vorbringens und auf die Möglichkeit eines Versäumnisurteils hingewiesen.

Der Streitwert wird vorläufig auf 4060,00 EUR festgesetzt.

Richterin am Amtsgericht
Dr. Seidel
