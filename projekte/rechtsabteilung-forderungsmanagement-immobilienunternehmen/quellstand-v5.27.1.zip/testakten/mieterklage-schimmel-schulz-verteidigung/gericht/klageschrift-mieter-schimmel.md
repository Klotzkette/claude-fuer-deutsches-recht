# Rechtsanwältin Dr. Miriam Feld

Kantstraße 102
10627 Berlin

An das
Amtsgericht Charlottenburg
Amtsgerichtsplatz 1
14057 Berlin

Berlin, 08.07.2026

## Klage

der Frau Lisa Schulz, geb. 12.02.1990, und des Herrn Daniel Schulz, geb. 04.07.1988, beide Kaiserdamm 117, 14057 Berlin,

**Kläger,**

Prozessbevollmächtigte: Rechtsanwältin Dr. Miriam Feld, Kantstraße 102, 10627 Berlin,

gegen

die Wohnen Berlin Immobilien GmbH, vertreten durch die Geschäftsführung, Friedrichstraße 99, 10117 Berlin,

**Beklagte,**

wegen Mangelbeseitigung und Rückzahlung von Miete.

Namens und in Vollmacht der Kläger wird beantragt,

1. die Beklagte zu verurteilen, den Schimmelpilzbefall an der nordöstlichen Außenwandecke und auf der Außenwandfläche hinter dem Kleiderschrank im Schlafzimmer der Wohnung Kaiserdamm 117, 14057 Berlin, 2. Obergeschoss rechts, fachgerecht zu beseitigen und die Ursache des dortigen Feuchtigkeitseintrags zu beheben;
2. die Beklagte zu verurteilen, an die Kläger 1260,00 EUR nebst Zinsen in Höhe von fünf Prozentpunkten über dem Basiszinssatz seit Rechtshängigkeit zu zahlen;
3. der Beklagten die Kosten des Rechtsstreits aufzuerlegen.

## Begründung

Die Parteien sind durch den Wohnraummietvertrag vom 18.05.2021 verbunden. Die monatliche Bruttowarmmiete beträgt 1260,00 EUR.

**Beweis:** Mietvertrag, Anlage K 1

Seit Anfang Januar 2026 befindet sich im Schlafzimmer ein sichtbarer dunkler Schimmelbefall. Betroffen sind die nordöstliche Außenecke und die Wandfläche hinter dem dort aufgestellten Kleiderschrank. Es besteht ein modriger Geruch; die Kläger nutzen den Raum nur noch eingeschränkt.

**Beweis:** Fotografien, Anlage K 2; Zeugnis Jana Reimann, zu laden über den Berliner Mieterschutzverein e. V.

Die Kläger zeigten den Mangel mit Schreiben vom 08.01.2026 an. Die Beklagte bestätigte einen Ortstermin zunächst für den 12.01.2026. Dieser Termin konnte wegen einer kurzfristigen Änderung des Schichtdienstes des Klägers zu 2 nicht stattfinden. Beim nachgeholten Termin am 18.02.2026 stellte der technische Dienst der Beklagten den sichtbaren Befall fest.

**Beweis:** Mängelanzeige, Anlage K 3; Terminverkehr, Anlage K 4; Messprotokoll der Beklagten, Anlage K 5

Im September 2025 ließ die Beklagte die Fenster der Wohnung austauschen. Die neuen Fenster schließen erheblich dichter. Die Kläger lüften morgens und abends sowie nach Bedarf. Ein vertragswidriges Wohnverhalten liegt nicht vor. Die Ursache des Feuchtigkeitseintrags liegt nach Auffassung der Kläger im Verantwortungsbereich der Beklagten.

**Beweis:** Sachverständigengutachten

Die Kläger zahlten die Miete von Januar bis Mai 2026 vollständig unter Vorbehalt. Wegen der Beeinträchtigung halten sie eine Minderung von 20 Prozent für angemessen.

| Zeitraum | Bruttowarmmiete | Quote | Monatsbetrag | Monate | Rückforderung |
|---|---:|---:|---:|---:|---:|
| Januar bis Mai 2026 | 1260,00 EUR | 20 Prozent | 252,00 EUR | 5 | 1260,00 EUR |

**Beweis:** Kontoauszüge, Anlage K 6

Die Beklagte wurde mit Schreiben des Berliner Mieterschutzvereins vom 12.03.2026 erfolglos zur Mangelbeseitigung und Rückzahlung aufgefordert.

**Beweis:** Schreiben vom 12.03.2026, Anlage K 7

Der vorläufige Streitwert wird für den Beseitigungsantrag mit 2800,00 EUR und für den Zahlungsantrag mit 1260,00 EUR, insgesamt mit 4060,00 EUR, angegeben.

Dr. Miriam Feld
Rechtsanwältin
