# Mietkonto FBL5N

**Debitor:** D-621409
**Vertrag:** WBI-MV-2021-02109
**Zeitraum:** 01.01.2026 bis 30.06.2026
**Export:** FI-CA Einzelpostenliste, 20.07.2026, 08:39 Uhr

## Buchungsjournal

| Periode | Soll | Ist | Wertstellung | Buchungstext | Saldo |
|---|---:|---:|---|---|---:|
| 01 2026 | 1260,00 | 1260,00 | 02.01.2026 | Miete Januar, Verwendungszweck unter Vorbehalt | 0,00 |
| 02 2026 | 1260,00 | 1260,00 | 03.02.2026 | Miete Februar, Verwendungszweck unter Vorbehalt | 0,00 |
| 03 2026 | 1260,00 | 1260,00 | 03.03.2026 | Miete März, Verwendungszweck unter Vorbehalt | 0,00 |
| 04 2026 | 1260,00 | 1260,00 | 02.04.2026 | Miete April, Verwendungszweck unter Vorbehalt | 0,00 |
| 05 2026 | 1260,00 | 1260,00 | 04.05.2026 | Miete Mai, Verwendungszweck unter Vorbehalt | 0,00 |
| 06 2026 | 1260,00 | 1260,00 | 02.06.2026 | Miete Juni ohne Vorbehaltszusatz | 0,00 |

## OP-Status

| Prüffeld | Ergebnis |
|---|---|
| Offene Mietforderung | 0,00 EUR |
| Offene Nebenforderung | 0,00 EUR |
| Zahlungsausfälle | keine |
| Vorbehaltsvermerke | Januar bis Mai 2026 |
| Separate Anspruchsakte | Rückforderung aus behaupteter Minderung |

## Buchhaltungshinweis

Die Vorbehaltsangabe im Verwendungszweck verändert die Zahlungshöhe und den Kontosaldo nicht. Eine Rückzahlung darf nur aufgrund einer fachlich freigegebenen Einigung, eines Anerkenntnisses oder eines vollstreckbaren Titels gebucht werden.
