# SAP RE-FX Statusauszug

**Auszug erstellt:** 20.07.2026, 08:42 Uhr
**Buchungskreis:** WBI Berlin
**Bearbeitungsgruppe:** Forderungsmanagement Wohnraum 2

## Vertrags- und Partnerdaten

| Feld | Wert |
|---|---|
| Vertragsnummer | WBI-MV-2021-02109 |
| Debitor | D-621409 |
| Hauptmieterin | Lisa Schulz, geb. 12.02.1990 |
| Mitmieter | Daniel Schulz, geb. 04.07.1988 |
| Vertragsbeginn | 01.06.2021 |
| Objekt | Kaiserdamm 117, 14057 Berlin |
| Einheit | 2. OG rechts, WE 117-2R |
| Wohnfläche | 68,40 qm |
| Interne Akte | F-2026-00602 |

## Mietkonditionen

| Kondition | Monatsbetrag |
|---|---:|
| Nettokaltmiete | 920,00 EUR |
| Betriebskostenvorauszahlung | 210,00 EUR |
| Heizkostenvorauszahlung | 130,00 EUR |
| Bruttowarmmiete | 1260,00 EUR |

## Saldo und Sperren

| Prüffeld | Stand |
|---|---|
| Mietkonto per 30.06.2026 | 0,00 EUR |
| Offene Hauptforderung Vermieterin | 0,00 EUR |
| Zahlungen Januar bis Juni | vollständig |
| Zahlungstext Januar bis Mai | Miete unter Vorbehalt |
| Mahnsperre | keine |
| Rechtsfallkennzeichen | Mieterklage Mangel/Rückzahlung |
| Gericht | Amtsgericht Charlottenburg |
| Gerichtsaktenzeichen | 217 C 166/26 |
| Zustellung | 14.07.2026 |
| Frist Verteidigungsanzeige | 28.07.2026 |
| Frist Klageerwiderung | 11.08.2026 |

## DMS-Verknüpfung

DocuWeb-Vorgang `DW-OBJ-117-2026-0048` ist verknüpft. Die Register enthalten drei als Foto bezeichnete PDF-Ausdrucke, aber keine Originalbilddateien. Der Export meldet außerdem zwei Fassungen des Fenster-Abnahmeprotokolls und eine unterbrochene Logger-Datei.
