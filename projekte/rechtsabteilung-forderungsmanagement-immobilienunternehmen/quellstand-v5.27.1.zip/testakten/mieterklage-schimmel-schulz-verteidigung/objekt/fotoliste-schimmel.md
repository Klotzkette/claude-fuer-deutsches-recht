# Wohnen Berlin Immobilien GmbH

## Fotoliste Feuchtigkeit und Schimmel

**Objekt:** Kaiserdamm 117, 14057 Berlin, 2. OG rechts
**Vorgang:** F-2026-00602
**Stand:** 20.02.2026

| Nr. | Aufnahmedatum | Motiv | Herkunft | Originalstatus | Dateiname / Prüfsumme |
|---:|---|---|---|---|---|
| 1 | laut Mieterin 06.01.2026 | dunkle Flecken in der nordöstlichen Schlafzimmerecke | Vorschau im Mieterbrief | Original fehlt; EXIF nicht prüfbar | `foto_1_vorschau.jpg` |
| 2 | laut Mieterin 06.01.2026 | Wandfläche hinter Kleiderschrank | Ausdruck des Mietervereins | Original fehlt; Ausschnitt unbekannt | `foto_2_vorschau.jpg` |
| 3 | laut Mieterin 08.01.2026 | Nahaufnahme eines dunklen Belags | PDF-Anlage der Mängelanzeige | Original fehlt; Maßstab fehlt | `foto_3_vorschau.jpg` |
| 4 | 18.02.2026, 15:31 Uhr | Gesamtansicht Außenwand und Schrank | KlimaBau Service GmbH | Original vorhanden | `IMG_8421.jpg`; SHA-256 im DMS |
| 5 | 18.02.2026, 15:33 Uhr | Befallsfläche mit Zollstock | KlimaBau Service GmbH | Original vorhanden | `IMG_8422.jpg`; SHA-256 im DMS |
| 6 | 18.02.2026, 15:37 Uhr | Fensteranschluss nordöstlich | KlimaBau Service GmbH | Original vorhanden | `IMG_8423.jpg`; SHA-256 im DMS |
| 7 | 18.02.2026, 15:41 Uhr | Abstand Schrank zur Außenwand | KlimaBau Service GmbH | Original vorhanden | `IMG_8424.jpg`; SHA-256 im DMS |
| 8 | 18.02.2026, 15:48 Uhr | Messgerätepositionen | KlimaBau Service GmbH | Original vorhanden | `IMG_8425.jpg`; SHA-256 im DMS |

## Offene Beschaffung

Die drei von den Mietern eingereichten Vorschauen sind für eine technische Auswertung nicht ausreichend. Mit Schreiben vom 19.02.2026 wurden die unveränderten Originaldateien einschließlich Aufnahmedaten angefordert. Ein Eingang ist bis zum Stand dieser Liste nicht dokumentiert.

## Ablage

Die Originaldateien 4 bis 8 liegen im DocuWeb-Vorgang unter `Technik/Ortstermin_2026-02-18/Originale`. In der allgemeinen Exportmappe befinden sich zusätzlich verkleinerte PDF-Abzüge; diese sind nicht mit den Originaldateien zu verwechseln.
