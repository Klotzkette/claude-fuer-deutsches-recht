# Wohnen Berlin Immobilien GmbH

## Grundrissnotiz Schlafzimmer

**Objekt:** Kaiserdamm 117, 14057 Berlin
**Einheit:** 2. Obergeschoss rechts
**Vertragsnummer:** WBI-MV-2021-02109
**Stand:** Ortstermin vom 18.02.2026
**Erstellt von:** Objektbetreuung Charlottenburg, M. Novak

## Raumdaten

| Merkmal | Feststellung |
|---|---|
| Raum | Schlafzimmer |
| Innenmaß | ca. 4,20 m x 3,45 m |
| Raumhöhe | ca. 2,82 m |
| Außenwand | Nordseite, ca. 4,20 m |
| Fenster | ein zweiflügeliges Kunststofffenster, erneuert im September 2025 |
| Heizkörper | unterhalb des Fensters |
| Befall | nordöstliche Außenecke und Wandzone hinter dem Kleiderschrank |
| Wandabstand Schrank | beim Ortstermin zwischen ca. 3 cm und 5 cm |

## Skizze

```text
                        NORD / AUSSENWAND
        +------------------------------------------------+
        |  Befall ca. 0,8 qm         Fenster             |
        |  XXXXXXXX                 +-----------+         |
        |  XXXXXXXX                 |           |         |
        |  +------------------+     +-----------+         |
        |  | Kleiderschrank   |       Heizkörper          |
WESTEN  |  | ca. 2,40 x 0,60 |                         | OSTEN
        |  +------------------+                           |
        |                                                |
        |                         Doppelbett              |
        |                  +----------------------+       |
        |                  |                      |       |
        |                  +----------------------+       |
        | Tür                                            |
        +------------------------------------------------+
                        SÜD / FLURSEITE
```

## Vermerke

- Maße wurden mit Handlaser aufgenommen und auf volle Zentimeter gerundet.
- Die Skizze ist keine maßstäbliche Bauzeichnung.
- Nach Aussage von Frau Schulz stand der Schrank vor dem Ortstermin unmittelbar an der Außenwand. Beim Ortstermin war er bereits vorgezogen.
- Der frühere Wandabstand wurde nicht fotografisch dokumentiert.
- Eine Bestandszeichnung aus der Bauakte lag beim Ortstermin nicht vor.
