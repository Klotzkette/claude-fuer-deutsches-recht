# Freigabekarte Klageerwiderung

**Vorgang:** F-2026-00602
**Gericht:** Amtsgericht Charlottenburg
**Geschäftsnummer:** 217 C 166/26
**Stand:** 15.07.2026
**Versandstatus:** ROT - NICHT VERSENDEN/EINREICHEN

## Frist und Antrag

| Prüfpunkt | Stand | Freigabe |
|---|---|---|
| Verteidigungsanzeige bis 28.07.2026 | doppelt notiert | offen |
| Klageerwiderung bis 11.08.2026 | Vorfrist 04.08.2026 | offen |
| Zahlungsantrag 1260,00 EUR | Antragsspiegel erstellt | offen |
| Beseitigungsantrag | Wortlaut übernommen; Bestimmtheit und Reaktionslinie prüfen | Rechtsabteilung |
| Vorläufiger Streitwert 4060,00 EUR | Verfügung vorhanden | beobachten |

## Tatsachen- und Beweisfreigabe

| Punkt | Ampel | Erforderliche Freigabehandlung |
|---|---|---|
| Sichtbarer Befall am 18.02.2026 | grün | zugestehbaren Umfang exakt bestätigen |
| Befallsbeginn Anfang Januar | gelb | Originalfotos mit Metadaten nachfordern |
| Ursache des Befalls | rot | keine Alleinursache behaupten; Sachverständigenstrategie festlegen |
| Fensteranschluss | rot | Montageunterlagen und technische Nachprüfung beschaffen |
| Loggerauswertung | gelb | Rohdaten, Kalibrierung und 61-Stunden-Lücke dokumentieren |
| Möblierung und Wandabstand | gelb | nur Wahrnehmung am Ortstermin verwenden |
| Minderungsquote und Zeitraum | rot | monatsgenaue Beeinträchtigung bestreiten und bewerten |
| Sanierungsangebot | gelb | Leistungsumfang, Termin und Zutrittsanforderung freigeben |

## Anlagenkontrolle

- [ ] Jede Anlage liegt in der richtigen, endgültigen Fassung vor.
- [ ] Altversion des Messprotokolls und Logger-Dublette sind ausgesondert.
- [ ] Fotovorschauen der Mieter sind nicht als Originale bezeichnet.
- [ ] Anlagenbezeichnungen im Schriftsatz und in den PDF-Dateinamen stimmen überein.
- [ ] Schriftsatz und Anlagen sind durchsuchbar, lesbar und technisch geprüft.

## Vertretung und Versand

- [ ] Beschäftigtenstatus, Vollmacht und Vertretungsbefugnis nach § 79 ZPO sind dokumentiert.
- [ ] Rechtsabteilung hat entschieden, ob externe anwaltliche Vertretung eingeschaltet wird.
- [ ] Zulässiger elektronischer Einreichungsweg und verantwortliche versendende Person stehen fest.
- [ ] Einreichungsfassung enthält keine internen Kommentare oder Platzhalter.
- [ ] Versandprotokoll und gerichtliche Eingangsbestätigung werden zur Akte genommen.

## Entscheidung

| Rolle | Name | Datum | Entscheidung |
|---|---|---|---|
| Fachbearbeitung | Sandra Berger |  |  |
| Objekttechnik |  |  |  |
| Rechtsabteilung |  |  |  |
| Versandverantwortung |  |  |  |

Bis zur vollständigen Freigabe aller roten Punkte bleibt der Status `ENTWURF - NICHT VERSENDEN/EINREICHEN`.
