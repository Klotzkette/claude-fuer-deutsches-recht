# E-Mail-Ausdruck

Von: maria.novak@wohnen-berlin.example

An: sandra.berger@wohnen-berlin.example

Datum: 20.07.2026, 16:11 Uhr

Betreff: Kaiserdamm 117 / 2. OG rechts / Archivsuche vor Klageerwiderung

Hallo Frau Berger,

ich habe heute das Objektarchiv und die alten Tickets zur Wohnung durchsucht.

Für die Zeit seit Mietbeginn der Eheleute Schulz finde ich vor Januar 2026 keine wohnungsbezogene Schimmelmeldung. Das bedeutet nur, dass in den von mir geprüften Registern nichts abgelegt ist. Der Papierordner des früheren Hausmeisters endet 2020 und enthält mehrere lose, nicht nach Wohnungen sortierte Notizzettel.

Zum Vormietverhältnis liegt ein Übergabeprotokoll vom 18.05.2021 vor. Dort sind im Schlafzimmer zwei Dübellöcher und eine beschädigte Sockelleiste vermerkt, aber keine Feuchte. Die zugehörigen Fotos fehlen im DMS.

Außerdem habe ich das Fassaden-Wartungsprotokoll von 2024 gefunden. Darin werden Haarrisse und einzelne Anschlussfugen erwähnt, jedoch ohne Wohnungszuordnung und ohne Innenbesichtigung. Ich habe das Protokoll unter DMS-ID OBJ-7719-24 neu abgelegt. Die zwölf Originalfotos habe ich beim Dienstleister angefordert.

Den Auftrag zur Fenstererneuerung 2025 und das Abnahmeprotokoll habe ich nochmals geprüft. Eine Luftdichtheitsmessung ist dort nicht dokumentiert.

Viele Grüße

Maria Novak

Objektbetreuung Charlottenburg
