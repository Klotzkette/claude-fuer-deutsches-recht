# E-Mail

**Von:** Maria Novak, Objektbetreuung Charlottenburg
**An:** Sandra Berger, Forderungsmanagement
**Gesendet:** 20.02.2026, 08:43 Uhr
**Betreff:** Kaiserdamm 117 / Schulz / Zutritt und Schlafzimmermöbel

Guten Morgen Frau Berger,

für die Chronologie:

Den Termin am 12.01. hatte Frau Neumann am 09.01. schriftlich bestätigt. Herr Schulz sagte am Abend des 11.01. wegen eines geänderten Nachtdienstes ab. Nach der Übergabe des Vorgangs an mich habe ich mit den Mietern zweimal telefoniert. Der nächste Termin, an dem beide Seiten und die Firma KlimaBau konnten, war der 18.02.

Beim Termin war der große Kleiderschrank bereits etwas von der Nordwand abgerückt. Ich habe an den beiden Seiten ungefähr drei bis fünf Zentimeter gemessen. Frau Schulz sagte, der Schrank habe vorher „fast direkt“ an der Wand gestanden. Sie konnte nicht mehr sagen, seit wann er dort so stand. Hinter dem Schrank waren dunkle Flecken und ein modriger Geruch feststellbar.

Das Fenster ließ sich öffnen und schließen. Am Anschluss oben rechts war die Fuge aus meiner Sicht ungleichmäßig. Ob das technisch ursächlich ist, kann ich nicht beurteilen. Die Monteurfirma hat das Fenster im September ausgetauscht. Die Abnahmeunterlagen habe ich in DocuWeb abgelegt.

Frau Schulz war mit der Aufstellung eines Datenloggers einverstanden. Herr Schulz wollte erst Rücksprache mit dem Mieterverein halten. Das Gerät wurde am Folgetag angebracht.

Viele Grüße

Maria Novak
Objektbetreuung Charlottenburg
Wohnen Berlin Immobilien GmbH
