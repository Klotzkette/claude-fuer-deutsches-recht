# Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

Frau Lisa Schulz und Herrn Daniel Schulz

Kaiserdamm 117

14057 Berlin

Berlin, 06.03.2026

**Vertragsnummer:** WBI-MV-2021-02109

**Vorgang:** F-2026-00602

## Feuchtigkeits- und Schimmelbefund im Schlafzimmer — Zwischenmaßnahmen und Terminabstimmung

Sehr geehrte Frau Schulz, sehr geehrter Herr Schulz,

bei dem gemeinsamen Termin am 18.02.2026 wurde in der nordöstlichen Schlafzimmerecke hinter dem Kleiderschrank ein dunkler Oberflächenbefall auf einer Fläche von ungefähr 0,8 qm festgestellt. Die Raumklimamessung ist inzwischen beendet. Die Auswertung weist eine Datenunterbrechung vom 24.02.2026, 18:10 Uhr, bis 27.02.2026, 07:14 Uhr auf. Aus den bisher vorliegenden Daten lässt sich die technische Ursache nicht abschließend bestimmen.

Unabhängig von der noch offenen Ursachenprüfung bieten wir folgende Zwischenmaßnahmen an:

1. fachgerechte Oberflächenreinigung der befallenen Stelle unter Abschottung des Arbeitsbereichs,
2. Kontrolle von Fensteranschluss, Laibung und Oberflächentemperaturen,
3. vorübergehendes Abrücken des Kleiderschranks für Untersuchung und Trocknung,
4. erneute Sichtkontrolle vier Wochen nach Abschluss der Arbeiten.

Die Maßnahmen erfolgen ohne Anerkennung einer bestimmten Ursache oder Minderungsquote. Gesetzliche Rechte beider Seiten bleiben unberührt. Das Angebot dient dazu, den sichtbaren Befall zeitnah zu begrenzen und weitere Anknüpfungstatsachen zu sichern.

## Terminvorschläge

Bitte teilen Sie uns bis zum 10.03.2026 mit, welcher der folgenden Termine möglich ist:

- Donnerstag, 12.03.2026, 08:00 bis 11:00 Uhr,
- Freitag, 13.03.2026, 13:00 bis 16:00 Uhr,
- Dienstag, 17.03.2026, 09:00 bis 12:00 Uhr.

Für die Arbeiten muss die nordöstliche Schlafzimmerecke auf etwa 1,5 Meter Breite zugänglich sein. Falls Sie den Schrank nicht selbst bewegen können, übernimmt der Dienstleister das gemeinsame Leerräumen und Versetzen nach vorheriger Abstimmung. Persönliche Gegenstände werden nicht ohne Ihre Anwesenheit bewegt.

Bitte übersenden Sie außerdem die unveränderten Originaldateien der drei mit Ihrer Mängelanzeige eingereichten Fotos. Die bislang vorliegenden verkleinerten Abzüge enthalten weder prüfbare Aufnahmedaten noch das vollständige Bildformat. Die Originale können über den gesicherten Upload-Link im Serviceportal oder auf einem Datenträger im Verwaltungsbüro abgegeben werden.

Mit freundlichen Grüßen

Wohnen Berlin Immobilien GmbH

Maren Scholz

Objektbetreuung Charlottenburg

**Anlage:** Rückmeldebogen zur Terminabstimmung
