# Mängelanzeige

Lisa und Daniel Schulz

Kaiserdamm 117

14057 Berlin

Wohnen Berlin Immobilien GmbH

Hausverwaltung Charlottenburg

Friedrichstraße 99

10117 Berlin

Berlin, 08.01.2026

**Wohnung Kaiserdamm 117, 2. OG rechts**

**Dunkle Flecken und Feuchtigkeit im Schlafzimmer**

Sehr geehrte Damen und Herren,

gestern haben wir den großen Kleiderschrank im Schlafzimmer vorgezogen. An der Außenwand hinter der linken Schrankhälfte befinden sich dunkle Flecken. Die Tapete fühlt sich dort kalt und stellenweise feucht an. Seit Ende Dezember riecht es morgens in dem Zimmer muffig.

Der betroffene Bereich beginnt ungefähr 20 Zentimeter über der Sockelleiste und zieht sich bis etwa einen Meter Höhe. Wir haben drei Fotos mit dem Mobiltelefon aufgenommen und dieser Nachricht beigefügt. Bitte lassen Sie kurzfristig prüfen, woher die Feuchtigkeit kommt und was gemacht werden muss.

Im September wurden die Fenster ausgetauscht. Seitdem beschlagen die Schlafzimmerfenster morgens häufiger als vorher. Wir lüften morgens und abends und heizen das Schlafzimmer.

Für einen Termin erreichen Sie Lisa Schulz unter 0176 4839 1207. In der kommenden Woche arbeitet sie Frühschicht; am späten Nachmittag wäre der Zutritt am einfachsten.

Mit freundlichen Grüßen

Lisa Schulz

Daniel Schulz

---

**Eingang Hausverwaltung:** 08.01.2026, 11:14 Uhr per E-Mail

**Anlagen laut Nachricht:** 3 Bilddateien

**DMS-Stand:** Nur ein PDF-Ausdruck der E-Mail und drei verkleinerte Messenger-Vorschaubilder vorhanden; Originaldateien nicht im Export.
