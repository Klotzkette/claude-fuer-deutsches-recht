# Berliner Mieterschutzverein e. V.

Kantstraße 88
10627 Berlin

Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin

Berlin, 12.03.2026

## Lisa und Daniel Schulz, Kaiserdamm 117, 14057 Berlin

Sehr geehrte Damen und Herren,

wir vertreten Frau Lisa Schulz und Herrn Daniel Schulz. Eine Bevollmächtigung unserer Mitglieder liegt vor.

Unsere Mitglieder zeigten Ihnen am 08.01.2026 Schimmelbefall im Schlafzimmer an. Bei Ihrem Ortstermin am 18.02.2026 wurde der Befall festgestellt. Trotz der zwischenzeitlichen Messung liegt unseren Mitgliedern weder ein Sanierungsplan noch eine verbindliche Terminzusage vor.

Wir fordern Sie auf,

1. den Schimmelbefall und seine Ursache bis zum 31.03.2026 fachgerecht beseitigen zu lassen und
2. für Januar bis Mai 2026 jeweils 20 Prozent der Bruttowarmmiete von 1260,00 EUR, insgesamt 1260,00 EUR, zu erstatten.

Die Zahlungen unserer Mitglieder erfolgten unter Vorbehalt. Die im September 2025 eingebauten, dichter schließenden Fenster haben nach unserer vorläufigen Einschätzung die Feuchteverhältnisse verändert. Den Einwand eines angeblich unzureichenden Lüftens weisen unsere Mitglieder zurück.

Bitte überweisen Sie den Rückforderungsbetrag auf das Ihnen bekannte Mietkonto. Nach fruchtlosem Fristablauf werden unsere Mitglieder gerichtliche Hilfe in Anspruch nehmen.

Mit freundlichen Grüßen

Jana Reimann
Rechtsberaterin
