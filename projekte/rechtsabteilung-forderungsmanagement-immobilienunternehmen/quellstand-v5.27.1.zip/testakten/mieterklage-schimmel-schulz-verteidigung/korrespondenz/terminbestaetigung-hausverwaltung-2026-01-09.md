# Terminbestätigung zur Mängelprüfung

**Wohnen Berlin Immobilien GmbH**

Friedrichstraße 99

10117 Berlin

Abteilung Hausverwaltung Charlottenburg

Frau Lisa Schulz

Herrn Daniel Schulz

Kaiserdamm 117

14057 Berlin

Berlin, 09.01.2026

**Mietvertrag WBI-MV-2021-02109**

**Prüfung der gemeldeten Feuchtigkeit im Schlafzimmer**

Sehr geehrte Frau Schulz,

sehr geehrter Herr Schulz,

wir bestätigen den Ortstermin am **12.01.2026 zwischen 16:30 Uhr und 17:00 Uhr**. Teilnehmen werden unsere Objektbetreuerin Frau Neumann und ein Mitarbeiter der KlimaBau Service GmbH.

Bitte ermöglichen Sie den Zugang zum Schlafzimmer und zur Fensterlaibung. Soweit ohne Beschädigung möglich, halten Sie den Bereich vor der betroffenen Außenwand frei. Die vorhandenen Flecken sollen vor dem Termin nicht überstrichen oder mit chemischen Mitteln behandelt werden, damit der Zustand dokumentiert werden kann.

Bitte senden Sie uns außerdem die drei Bilddateien aus Ihrer Mängelanzeige im Original und teilen Sie mit, seit wann der Geruch und die Flecken jeweils wahrgenommen wurden.

Sollte der Termin nicht möglich sein, melden Sie sich bitte unverzüglich unter 030 2055 4722.

Mit freundlichen Grüßen

Katharina Neumann

Objektbetreuung Charlottenburg

Wohnen Berlin Immobilien GmbH
