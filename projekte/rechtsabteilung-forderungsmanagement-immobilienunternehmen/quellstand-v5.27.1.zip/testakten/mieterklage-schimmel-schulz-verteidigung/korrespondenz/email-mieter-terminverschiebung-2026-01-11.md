# E-Mail zur Terminverschiebung

Von: lisa.schulz@example.net

An: hausverwaltung@wohnen-berlin-immobilien.de

Datum: 11.01.2026, 20:47 Uhr

Betreff: Termin morgen Kaiserdamm 117

Guten Abend Frau Neumann,

ich muss den Termin morgen leider absagen. Meine Kollegin ist krank und ich muss die Spätschicht übernehmen. Mein Mann ist beruflich in Potsdam und schafft es ebenfalls nicht.

In der Woche ab 26. Januar können wir Dienstag oder Donnerstag ab 15 Uhr. Der Schrank steht inzwischen ungefähr 40 Zentimeter von der Wand ab. Wir haben die Stellen nicht überstrichen, nur einmal vorsichtig mit einem trockenen Tuch abgewischt.

Die Fotos hatte ich über das Portal hochgeladen. Ich finde auf dem neuen Handy gerade nur noch die Bilder im Chat und versuche, die Originale aus der Sicherung zu holen.

Viele Grüße

Lisa Schulz

---

Automatischer Eingangsvermerk: 11.01.2026, 20:48 Uhr

Weitergeleitet an Objektbetreuung am 12.01.2026, 07:36 Uhr.
