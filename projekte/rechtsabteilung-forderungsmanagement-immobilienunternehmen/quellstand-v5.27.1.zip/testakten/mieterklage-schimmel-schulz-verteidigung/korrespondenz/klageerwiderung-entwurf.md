# ENTWURF - NICHT VERSENDEN/EINREICHEN

Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin

An das
Amtsgericht Charlottenburg
Amtsgerichtsplatz 1
14057 Berlin

Berlin, [Freigabedatum]

## In dem Rechtsstreit Schulz u. a. gegen Wohnen Berlin Immobilien GmbH

**Geschäftsnummer:** 217 C 166/26

zeigt die Beklagte an, dass sie sich gegen die Klage verteidigen wird.

Für die Klageerwiderung wird nach derzeitiger Prüfung beantragt,

1. die Klage abzuweisen;
2. den Klägern die Kosten des Rechtsstreits aufzuerlegen.

## Begründung

### 1. Vertrag und Zahlungen

Der Wohnraummietvertrag, die vereinbarte Bruttowarmmiete von 1260,00 EUR und die vollständigen Zahlungen von Januar bis Mai 2026 sind unstreitig. Aus den Zahlungen allein folgen weder Dauer noch Ausmaß eines Mangels oder eine Minderungsquote von 20 Prozent.

### 2. Feststellungen zum Schlafzimmer

Die Beklagte bestreitet nicht, dass ihr technischer Dienst beim Ortstermin am 18.02.2026 in der nordöstlichen Ecke und auf einem Teil der Außenwand des Schlafzimmers einen dunklen Befall von ungefähr 0,8 qm wahrnahm. Bestritten werden, soweit nicht noch durch Originalunterlagen belegt, ein durchgehend gleichartiger Befall bereits seit Anfang Januar, die behauptete dauerhafte Einschränkung der Raumnutzung und eine Minderungsquote von 20 Prozent für jeden der fünf Monate.

**Beweis:** Messprotokoll vom 18.02.2026, Anlage B 4; Fotodokumentation des technischen Dienstes, Anlage B 5

### 3. Anzeige, Zutritt und Reaktion

Die Anzeige vom 08.01.2026 ging bei der Beklagten ein. Die Beklagte bestätigte am folgenden Tag einen Termin für den 12.01.2026. Diesen Termin sagte die Mieterseite am Abend des 11.01.2026 wegen einer Änderung des Schichtdienstes ab. Der gemeinsame Ortstermin fand am 18.02.2026 statt. Die Beklagte beruft sich aus der Absage nicht auf einen pauschalen Anspruchsausschluss; der Ablauf ist jedoch bei Dauer, Abhilfemöglichkeit und Zurechnung einer Verzögerung zu berücksichtigen.

**Beweis:** Terminbestätigung und E-Mail vom 11.01.2026, Anlagen B 3a und B 3b; Zeugnis Maria Novak, zu laden über die Beklagte

### 4. Ursache

Die technische Ursache ist offen. Im September 2025 wurden Fenster erneuert. Beim Ortstermin befand sich ein großer Kleiderschrank in einem Abstand von etwa drei bis fünf Zentimetern vor der betroffenen Außenwand. Die Loggerauswertung enthält eine Datenlücke von 61 Stunden und bildet erst einen Zeitraum nach dem Ortstermin ab. Keine dieser Tatsachen belegt für sich allein eine ausschließlich bauliche oder ausschließlich nutzungsbedingte Ursache.

**Beweis:** Arbeitsauftrag und Abnahmeprotokoll, Anlage B 6; Grundrissnotiz, Anlage B 7; Loggerauswertung, Anlage B 8; Sachverständigengutachten

Die Entscheidungen des Bundesgerichtshofs vom 05.12.2018 zu den Aktenzeichen VIII ZR 67/18 und VIII ZR 271/17 betreffen bauzeitübliche Wärmebrücken und die Gefahr einer Schimmelbildung. Die Beklagte leitet daraus wegen des hier festgestellten tatsächlichen Befalls keine automatische Mangelfreiheit ab. Entscheidend bleiben die konkrete vereinbarte Beschaffenheit, der bauliche Zustand, das zumutbare Heiz- und Lüftungsverhalten und die sachverständig zu klärende Ursache.

### 5. Zahlungsantrag

Die Kläger legen weder für jeden Monat einen identischen Befallsumfang noch eine identische konkrete Gebrauchsbeeinträchtigung dar. Die Vorschaufotos enthalten keine prüfbaren Originaldaten. Die pauschale Quote von 20 Prozent für Januar bis Mai 2026 wird daher bestritten. Der Zahlungsantrag ist nach dem derzeit belegten Sachstand unbegründet.

### 6. Beseitigungsantrag

Die Beklagte ist bereit, nach kurzfristiger Terminabstimmung eine ergänzende Untersuchung der Fensteranschlüsse und der betroffenen Außenwand durchführen und den sichtbaren Befall fachgerecht behandeln zu lassen. Dafür ist Zutritt zur Wohnung und zur freigeräumten Wandfläche erforderlich. Mit diesem Angebot wird keine bestimmte technische Ursache anerkannt.

[Nach Vorliegen des Sanierungsplans prüfen: Erledigung, Anerkenntnis, Vergleichsvorschlag oder fortgeführte Verteidigung.]

## Anlagen

- B 1 Mietvertrag
- B 2 Mietkonto Januar bis Juni 2026
- B 3a Terminbestätigung vom 09.01.2026
- B 3b E-Mail vom 11.01.2026
- B 4 Messprotokoll vom 18.02.2026
- B 5 Fotodokumentation technischer Dienst
- B 6 Arbeitsauftrag und Abnahmeprotokoll Fenstererneuerung
- B 7 Grundrissnotiz Schlafzimmer
- B 8 Loggerauswertung

Wohnen Berlin Immobilien GmbH
[vertretungsberechtigte und freigebende Person]
