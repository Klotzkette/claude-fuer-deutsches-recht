# Interne Aktennotiz

**Vorgang:** F-2026-00602
**Gericht:** Amtsgericht Charlottenburg, 217 C 166/26
**Bearbeiterin:** Sandra Berger
**Datum:** 15.07.2026
**Status:** Verteidigung wird vorbereitet; keine Versandfreigabe

## Fristen

| Handlung | Frist | Status |
|---|---|---|
| Verteidigungsanzeige | 28.07.2026, nicht verlängerbare Notfrist | doppelt notiert; Entwurf erforderlich |
| Klageerwiderung | 11.08.2026 | Vorfrist 04.08.2026 |

## Erste Einordnung

1. Sichtbarer Schimmel am 18.02.2026 wird nicht bestritten. Beginn, Dauer, Ausdehnung in den Vormonaten, Ursache und behauptete Gebrauchsbeeinträchtigung sind dagegen nicht vollständig geklärt.
2. Die Mängelanzeige vom 08.01.2026 liegt vor. Der zunächst bestätigte Termin wurde von Mieterseite abgesagt; daraus folgt weder automatisch ein Anspruchsausschluss noch eine sichere Zuordnung der Verzögerung. Der weitere Terminverlauf ist monatsgenau darzustellen.
3. Die Fenstererneuerung, eine mögliche bauliche Wärmebrücke, die Anschlussfuge, der geringe Abstand des Schranks und das Heiz- und Lüftungsverhalten kommen als Anknüpfungstatsachen in Betracht. Eine alleinige Ursache ist mit den vorhandenen Unterlagen nicht bewiesen.
4. Die Entscheidungen BGH VIII ZR 67/18 und VIII ZR 271/17 betreffen bauzeitübliche Wärmebrücken und die bloße Schimmelgefahr. Hier liegt tatsächlicher Befall vor. Die Entscheidungen tragen deshalb keine pauschale Verneinung eines Mangels.
5. Nach BGH VIII ZR 155/11 dürfen an den Vortrag zu konkreten Mangelerscheinungen keine Anforderungen gestellt werden, die bereits eine technische Ursachenanalyse oder eine bestimmte Minderungsquote verlangen. Die Klage ist nicht allein deshalb unschlüssig, weil die Kläger keine technische Ursache bewiesen haben.
6. Die Quote von 20 Prozent und der Zeitraum Januar bis Mai 2026 sind eigenständig zu prüfen. Das SAP-Konto bestätigt Zahlung und Vorbehalt, nicht Ausmaß, Dauer oder Ursache des Mangels.

## Beweis- und Beschaffungsauftrag

- Originalfotos der Kläger mit Metadaten über die Prozessbevollmächtigte anfordern.
- Logger-Rohdatei, Gerätestammblatt und Ausleseprotokoll beim technischen Dienst sichern.
- Fensterfirma zur verwendeten Anschlussausführung, Montageanleitung und etwaigen Nacharbeiten befragen.
- Objektbetreuerin Maria Novak und Techniker Jan Mertens zu eigenen Wahrnehmungen schriftlich befragen.
- Bauzeichnung und Angaben zum Außenwandaufbau aus dem Objektarchiv beschaffen.
- Entscheidung der Rechtsabteilung einholen, ob vor Erwiderung eine externe sachverständige Kurzprüfung veranlasst wird.

## Verteidigungslinie

Der Zahlungsantrag wird der Höhe und dem Zeitraum nach bestritten. Der sichtbare Zustand am 18.02.2026 wird zugestanden; ein früherer Beginn, die behauptete dauerhafte Einschränkung und eine ausschließlich bauliche Ursache werden mangels eigener Erkenntnis nicht zugestanden. Zum Beseitigungsantrag ist ein konkreter Sanierungs- und Zutrittsvorschlag vorzubereiten, ohne eine ungeklärte Ursache vorwegzunehmen.

## Freigabe

Vor Einreichung sind Antragsspiegel, Tatsachenmatrix, Anlagenstand, Vertretungsbefugnis nach § 79 ZPO, Fristen und die Frage externer anwaltlicher beziehungsweise sachverständiger Unterstützung durch die Rechtsabteilung freizugeben.
