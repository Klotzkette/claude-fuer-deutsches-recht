# Abnahmeprotokoll Fenstererneuerung

**Objekt:** Kaiserdamm 117, 14057 Berlin

**Wohnung:** 2. OG rechts

**Auftrag:** HT-2025-4418

**Montage:** 15.09.2025

**Abnahme:** 16.09.2025, 08:10 Uhr

## Beteiligte

| Rolle | Name |
|---|---|
| Auftraggeberin | Katharina Neumann, Wohnen Berlin Immobilien GmbH |
| Auftragnehmerin | Sven Martens, Havel Fenstertechnik GmbH |
| Mieterin | Lisa Schulz |

## Prüfpositionen

| Prüfpunkt | Schlafzimmer | Wohnzimmer | Vermerk |
|---|---|---|---|
| Flügel öffnet und schließt | ohne Beanstandung | ohne Beanstandung | geprüft |
| Dichtungen umlaufend | augenscheinlich vollständig | augenscheinlich vollständig | geprüft |
| Anschlussfugen innen | geschlossen | geschlossen | Sichtprüfung |
| Anschlussfugen außen | vom Hof aus nicht vollständig einsehbar | vom Hof aus nicht vollständig einsehbar | keine Hebebühne |
| Entwässerungsöffnungen | frei | frei | geprüft |
| Putzschäden | kleine Abplatzung links unten | keine | Nacharbeit zugesagt |
| Feuchtespuren bei Abnahme | keine sichtbar | keine sichtbar | Wand nicht freigemessen |

## Restpunkt

Kleine Putzabplatzung an der inneren Schlafzimmerlaibung bis 30.09.2025 schließen. Laut Auftragnehmer am 29.09.2025 erledigt; gesondertes Foto ist im aktuellen DMS-Export nicht enthalten.

## Unterschriften

| Auftraggeberin | Auftragnehmerin | Mieterin |
|---|---|---|
| K. Neumann | S. Martens | L. Schulz |

---

**Versionshinweis:** Im DocuWeb liegen die Fassungen `V1_SCAN` und `V2_KONTRAST`. Inhalt und Unterschriften wirken gleich; nur `V1_SCAN` trägt den maschinellen Eingangsstempel vom 17.09.2025.
