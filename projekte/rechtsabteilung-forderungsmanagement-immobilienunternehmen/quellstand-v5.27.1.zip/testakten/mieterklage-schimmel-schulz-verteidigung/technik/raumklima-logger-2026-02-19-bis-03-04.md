# Raumklima-Logger Schlafzimmer

**Gerät:** KL-2048

**Messort:** Regal neben der Schlafzimmertür, Höhe etwa 1,40 m

**Messbeginn:** 19.02.2026, 18:00 Uhr

**Messende:** 04.03.2026, 08:00 Uhr

**Intervall:** 30 Minuten

## Tagesübersicht

| Datum | Temperatur Minimum | Temperatur Maximum | Feuchte Minimum | Feuchte Maximum | Datensätze | Hinweis |
|---|---:|---:|---:|---:|---:|---|
| 19.02.2026 | 18,2 °C | 19,4 °C | 59 Prozent | 69 Prozent | 12 | Teilmessung |
| 20.02.2026 | 17,9 °C | 20,1 °C | 56 Prozent | 72 Prozent | 48 | zwei schnelle Feuchteabfälle |
| 21.02.2026 | 18,1 °C | 19,8 °C | 58 Prozent | 71 Prozent | 48 | vollständig |
| 22.02.2026 | 17,6 °C | 19,2 °C | 61 Prozent | 74 Prozent | 48 | hohe Nachtwerte |
| 23.02.2026 | 18,0 °C | 20,0 °C | 55 Prozent | 70 Prozent | 48 | vollständig |
| 24.02.2026 | 18,3 °C | 19,7 °C | 57 Prozent | 68 Prozent | 48 | vollständig |
| 25.02.2026 | 18,1 °C | 19,9 °C | 58 Prozent | 73 Prozent | 48 | vollständig |
| 26.02.2026 | 17,8 °C | 19,6 °C | 60 Prozent | 75 Prozent | 48 | hohe Nachtwerte |
| 27.02.2026 | 18,4 °C | 19,8 °C | 57 Prozent | 69 Prozent | 48 | vollständig |
| 28.02.2026 | 18,0 °C | 19,5 °C | 59 Prozent | 72 Prozent | 48 | vollständig |
| 01.03.2026 | 18,2 °C | 19,3 °C | 60 Prozent | 71 Prozent | 22 | Aufzeichnung endet 10:30 Uhr |
| 02.03.2026 | - | - | - | - | 0 | Datenlücke |
| 03.03.2026 | 18,5 °C | 18,5 °C | 62 Prozent | 62 Prozent | 1 | Aufzeichnung ab 23:30 Uhr |
| 04.03.2026 | 18,1 °C | 19,0 °C | 60 Prozent | 68 Prozent | 17 | Teilmessung |

## Exportvermerk

Zwischen 01.03.2026, 10:30 Uhr, und 03.03.2026, 23:30 Uhr fehlen 61 Stunden. Im Gerätelog steht `battery removed`. Wer die Batterie entnommen hat, ist nicht dokumentiert. Die vorhandene CSV-Rohdatei trägt den Hash `7af2...19c4`; im DMS-Export ist nur diese Tagesübersicht enthalten.

## Einordnung des Messdienstes

Die Messreihe zeigt wiederholt erhöhte Raumluftfeuchte. Sie erlaubt ohne Lageplan, Oberflächentemperaturverlauf, Außenklima und Nutzerprotokoll keine abschließende Aussage zur Ursache des Schimmelbefalls. Kurze Feuchteabfälle können mit Lüftung zusammenhängen, sind aber keinem sicheren Ereignis zugeordnet.
