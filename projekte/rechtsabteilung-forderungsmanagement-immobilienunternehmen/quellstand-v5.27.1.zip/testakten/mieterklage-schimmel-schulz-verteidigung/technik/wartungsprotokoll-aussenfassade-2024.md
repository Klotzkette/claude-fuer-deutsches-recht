# Wartungsprotokoll Außenfassade

Fassadenservice Berlin GmbH

Auftrag: FS-24-7719

Objekt: Kaiserdamm 117, 14057 Berlin

Datum der Begehung: 16.10.2024

## 1. Prüfbereich

Die straßen- und hofseitigen Fassadenflächen wurden vom öffentlichen Raum, vom Innenhof und aus dem Treppenhaus visuell geprüft. Eine Öffnung von Bauteilen, Wärmebildaufnahme oder Wohnungsbegehung war nicht beauftragt.

## 2. Feststellungen

| Bereich | Feststellung | Empfehlung |
|---|---|---|
| Straßenfassade 2. OG | einzelne Haarrisse im Oberputz, trocken wirkend | bei nächster Fassadenwartung beobachten |
| Fensterbänke | zwei Anschlussfugen mit beginnender Versprödung | Fugenprüfung bei Fensterarbeiten |
| Hofseite | keine sichtbaren Abplatzungen | keine Sofortmaßnahme |
| Fallrohre | Sichtprüfung ohne erkennbaren Austritt | turnusmäßig reinigen |
| Dachanschlüsse | vom Boden nicht vollständig einsehbar | gesonderte Dachprüfung nur bei Schadenshinweis |

## 3. Wohnungsbezug

Eine Zuordnung einzelner Fassadenstellen zu Wohnungen wurde nicht dokumentiert. Die Wohnung 2. OG rechts wurde nicht betreten. Aussagen zu Innenraumfeuchte, Schimmel, Wärmebrücken oder Luftwechsel sind aus dieser Begehung nicht möglich.

## 4. Abschluss

Akute Verkehrssicherungsmaßnahmen wurden nicht veranlasst. Die Fotoübersicht FS-24-7719 umfasst zwölf Außenaufnahmen; im aktuellen DMS-Export sind nur verkleinerte Vorschaubilder vorhanden.

Fassadenservice Berlin GmbH

Matthias Kern
