# Messprotokoll Ortstermin Feuchte

**Auftragnehmerin:** KlimaBau Service GmbH

**Auftrag:** KB-26-1184

**Objekt:** Kaiserdamm 117, 14057 Berlin, 2. OG rechts

**Termin:** 18.02.2026, 15:25 bis 16:18 Uhr

**Teilnehmer:** Jan Mertens, KlimaBau; Maria Novak, Objektbetreuung; Lisa und Daniel Schulz

## Feststellungen

| Mess- oder Sichtpunkt | Ergebnis | Messmittel oder Quelle |
|---|---|---|
| Raumtemperatur Schlafzimmer | 18,7 °C | Testo 635, Geräte-ID T635-228 |
| Relative Luftfeuchte | 68 Prozent | Testo 635 |
| Außenluft | 4,2 °C / 81 Prozent | Wetterfühler |
| Oberflächentemperatur Außenwandecke | 12,1 °C | Infrarot, Emissionsgrad 0,95 |
| Oberflächentemperatur Wandmitte | 14,8 °C | Infrarot |
| Materialfeuchte Tapete Ecke | erhöht, Vergleichswert 79 Digits | kapazitiv, kein Masseprozentwert |
| Sichtbarer dunkler Befall | etwa 0,8 qm, unregelmäßig | Fotodokumentation KB-26-1184 |
| Abstand Kleiderschrank zur Außenwand | etwa 3 bis 5 cm beim Eintreffen | Zollstock |
| Fensteranschluss innen | optisch geschlossen | Sichtprüfung |
| Fensteranschluss außen | vom Raum aus nicht prüfbar | weitere Prüfung erforderlich |

## Angaben der Beteiligten

Frau Schulz erklärt, der Schrank habe vor dem 11.01.2026 ungefähr 5 cm von der Wand gestanden und sei danach vorgezogen worden. Herr Schulz gibt an, morgens und abends jeweils fünf bis zehn Minuten zu lüften. Frau Novak verweist auf die abgesagte Erstbesichtigung vom 12.01.2026.

## Vorläufige Bewertung

Der sichtbare Befall ist zu behandeln. Aus der Einzelmessung lässt sich die Ursache nicht sicher bestimmen. In Betracht kommen ein ungünstiger Wärmebrückenbereich, verringerter Luftwechsel nach Fenstertausch, Möblierung nahe der Außenwand und zeitweise erhöhte Raumluftfeuchte. Eine Undichtigkeit der äußeren Anschlussfuge wurde nicht ausgeschlossen.

## Empfehlung

1. Raumklima über mindestens 14 Tage protokollieren.
2. Originalfotos und Zeitpunkt der ersten Wahrnehmung sichern.
3. Fensteranschluss außen bei geeigneter Witterung prüfen.
4. Vor Sanierungsentscheidung Oberflächentemperaturen und Bauteilzustand fachlich bewerten.
5. Befall bis zur Ursachenklärung nicht überstreichen; Nutzungshinweise gesondert abstimmen.

Jan Mertens

KlimaBau Service GmbH
