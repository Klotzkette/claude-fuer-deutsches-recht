# Arbeitsauftrag Fenstererneuerung

**Auftraggeberin:** Wohnen Berlin Immobilien GmbH

**Auftragnehmerin:** Havel Fenstertechnik GmbH, Freiheit 18, 13597 Berlin

**Auftragsnummer:** HT-2025-4418

**Objekt:** Kaiserdamm 117, 14057 Berlin

**Wohnung:** 2. OG rechts, Mietvertrag WBI-MV-2021-02109

**Ausführung vorgesehen:** 15.09.2025

## Leistungsumfang

| Position | Menge | Beschreibung |
|---|---:|---|
| 1 | 1 | Schlafzimmerfenster, Kunststoff, dreifach verglast, weiß |
| 2 | 1 | Wohnzimmerfenster, Kunststoff, dreifach verglast, weiß |
| 3 | 2 | Ausbau und Entsorgung der Holzfenster |
| 4 | 2 | Innen- und Außenanschluss, Dichtbänder und Anschlussfugen |
| 5 | 1 | Funktionsprüfung und Einweisung der Mieter |

## Technische Vorgaben

- Anschlussfugen nach dem freigegebenen Montageschema des Herstellers ausführen.
- Vorhandene Außenlaibungen nicht dämmen; Beschädigungen fotografisch dokumentieren.
- Fensterfalzlüfter sind nach Aufmaß nicht vorgesehen.
- Nach Montage sind Flügelandruck, Entwässerungsöffnungen und Anschlussfugen zu prüfen.
- Abweichungen vom Aufmaß oder Feuchtespuren sind der Auftraggeberin vor Verschließen anzuzeigen.

## Auftragsvermerk

Das Montageschema `HT-MONT-3E-2024` ist im DMS unter der Objektakte abgelegt. Im Export vom 20.07.2026 ist nur das Deckblatt, nicht die technische Anlage enthalten.

Freigabe: M. Roth, Technisches Objektmanagement

Datum: 02.09.2025
