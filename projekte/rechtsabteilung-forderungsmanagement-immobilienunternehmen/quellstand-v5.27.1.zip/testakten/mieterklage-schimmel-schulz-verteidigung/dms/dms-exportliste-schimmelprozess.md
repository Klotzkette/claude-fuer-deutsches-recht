# DocuWeb-Exportliste

**Exportauftrag:** DW-EXP-2026-0714-117
**Vorgang:** F-2026-00602
**Erstellt:** 14.07.2026, 15:42 Uhr
**Filter:** Vertragsnummer WBI-MV-2021-02109; Zeitraum 01.09.2025 bis 14.07.2026

| DMS-ID | Dokumenttyp | Dokumentdatum | Version | Exportname | Status / Auffälligkeit |
|---|---|---|---:|---|---|
| 884103 | Arbeitsauftrag | 28.08.2025 | 2 | `Arbeitsauftrag_Fenster_2025.pdf` | freigegebene Fassung |
| 884119 | Abnahmeprotokoll | 17.09.2025 | 1 | `Abnahme_Fenster_2025.pdf` | Unterschrift Monteur vorhanden |
| 901771 | Mieterbrief | 08.01.2026 | 1 | `Maengelanzeige_Schulz.pdf` | enthält drei verkleinerte Bildvorschauen |
| 901772 | Fotoanlage | 08.01.2026 | 1 | `Fotos_Mieter_Vorschau.pdf` | Originaldateien fehlen |
| 902026 | Terminbestätigung | 09.01.2026 | 1 | `Termin_2026-01-12.pdf` | erledigt |
| 902061 | E-Mail | 11.01.2026 | 1 | `Absage_Mieter_2026-01-11.pdf` | Eingang |
| 908554 | Messprotokoll | 18.02.2026 | 3 | `Ortstermin_Feuchte_v3.pdf` | Version 3 freigegeben |
| 908552 | Messprotokoll | 18.02.2026 | 1 | `Ortstermin_Feuchte_v1.pdf` | Altversion, nicht verwenden |
| 908559 | Fotodokumentation | 18.02.2026 | 2 | `Fotos_Ortstermin_Abzuege.pdf` | Originale in gesondertem Medienordner |
| 909012 | Logger-Auswertung | 04.03.2026 | 1 | `Logger_Auswertung.pdf` | Rohdatei im Export nicht enthalten |
| 909013 | Logger-Auswertung | 04.03.2026 | 1 | `Logger_Auswertung_Kopie.pdf` | Dublette von DMS-ID 909012 |
| 909118 | Ausgangsschreiben | 06.03.2026 | 1 | `Sanierungsangebot_Termine_Schulz.pdf` | drei Termine; Ursache ausdrücklich offen |
| 911447 | Mieterverein | 12.03.2026 | 1 | `Mieterverein_2026-03-12.pdf` | Eingang |
| 928881 | Klageschrift | 14.07.2026 | 1 | `Klage_Schulz.pdf` | Gerichtseingang |
| 928882 | Gerichtliche Verfügung | 14.07.2026 | 1 | `Verfuegung_AG_Charlottenburg.pdf` | Fristen noch nicht bestätigt |

## Nicht im Export enthalten

- unveränderte Originalfotos der Mieter einschließlich Metadaten,
- Rohdatei und Gerätestammblatt des Raumklima-Loggers,
- Montageanleitung und Fugenschema des eingebauten Fensters,
- historische Bauzeichnung mit Außenwandaufbau,
- Zustellnachweis mit dokumentiertem Eingangszeitpunkt der Klage.

## Technischer Hinweis

Die Altversion DMS-ID 908552 und die Dublette DMS-ID 909013 wurden vom Exportfilter nicht automatisch ausgesondert. Für eine Gerichtsakte dürfen nur die geprüften Fassungen mit einer eindeutigen Anlagenbezeichnung verwendet werden.

## Aktennachlauf nach dem Export

Die E-Mail zur Objektarchivsuche vom 20.07.2026 und das dabei aufgefundene
Wartungsprotokoll zur Außenfassade vom 16.10.2024 waren im Export vom
14.07.2026 noch nicht enthalten. Beide Dokumente sind als Nachlauf mit eigener
Herkunft und eigenem Prüfstatus in die Arbeitsakte aufzunehmen. Das
Wartungsprotokoll ersetzt weder eine Wohnungsbegehung noch eine technische
Ursachenfeststellung.
