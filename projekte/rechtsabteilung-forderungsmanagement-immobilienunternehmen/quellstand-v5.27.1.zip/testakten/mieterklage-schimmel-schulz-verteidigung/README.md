# Testakte 9 — Mieterklage Schulz wegen Feuchtigkeit und Schimmel


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 93 KB) | PDF | [testakte-mieterklage-schimmel-schulz-verteidigung-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterklage-schimmel-schulz-verteidigung-gesamt.pdf) | [`gesamt-pdf/mieterklage-schimmel-schulz-verteidigung_gesamt.pdf`](gesamt-pdf/mieterklage-schimmel-schulz-verteidigung_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-mieterklage-schimmel-schulz-verteidigung.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterklage-schimmel-schulz-verteidigung.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-mieterklage-schimmel-schulz-verteidigung-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterklage-schimmel-schulz-verteidigung-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Mieterklage, Fristensicherung, Mangel- und Rückforderungsprüfung, technische Ursachenklärung, Beweisplan und Klageerwiderung |
| Startskills | `33-dokumentenmix-ocr-sichten`, `42-mieterklage-verteidigen`, `39-beweisangebot-anlagenplan`, `45-hausverwaltung-schnittstelle`, danach `23-klage-egvp-bea-einreichen` |
| Kernentscheidung | Welche Tatsachen werden zugestanden oder bestritten, welche Ursachenfrage braucht Sachverständigenbeweis und welche Unterlagen fehlen vor der Verteidigungsfreigabe? |
| Besonderheit | Der DocuWeb-Export endet am 14.07.2026; Archivmail und Fassadenprotokoll kamen erst als Nachlauf hinzu. Tatsächlicher Schimmel, lückenhafte Messdaten und fehlende Originalfotos bleiben getrennt zu bewerten. |

Die Mieter haben die Bruttowarmmiete vollständig unter Vorbehalt gezahlt und verlangen wegen Schimmel im Schlafzimmer 1260,00 EUR zurück. Zusätzlich begehren sie Mangelbeseitigung. Die Akte enthält echte Anknüpfungstatsachen für mehrere Ursachen, aber keinen tragfähigen Alleinbeweis: bauzeitbedingte Wärmebrücke, Fenstererneuerung, Möblierung, Lüftung, verzögerter Zutritt und eine unterbrochene Messreihe müssen getrennt bewertet werden.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Bearbeiterin | Rechtsfachwirtin Sandra Berger |
| Mieterin | Lisa Schulz, geb. 12.02.1990 |
| Mieter | Daniel Schulz, geb. 04.07.1988 |
| Mietobjekt | Kaiserdamm 117, 14057 Berlin, 2. OG rechts |
| Wohnfläche | 68,40 qm |
| Vertragsnummer | WBI-MV-2021-02109 |
| Vertragsbeginn | 01.06.2021 |
| Nettokaltmiete | 920,00 EUR |
| BK-Vorauszahlung | 210,00 EUR |
| HK-Vorauszahlung | 130,00 EUR |
| Bruttowarmmiete | 1260,00 EUR |
| Gericht | Amtsgericht Charlottenburg |
| Gerichtsaktenzeichen | 217 C 166/26 |
| Zustellung der Klage | 14.07.2026 |
| Verteidigungsanzeige | Notfrist bis 28.07.2026 |
| Klageerwiderung | Gerichtlich gesetzte Frist bis 11.08.2026 |
| Aktenzeichen intern | F-2026-00602 |

## Sachverhalt

| Datum | Ereignis | Quellenstatus |
|---|---|---|
| 15.09.2025 | Austausch der Schlafzimmer- und Wohnzimmerfenster | Arbeitsauftrag und Abnahmeprotokoll vorhanden |
| 08.01.2026 | Erste schriftliche Anzeige von dunklen Flecken und Geruch hinter dem Schlafzimmerschrank | Mieterbrief vorhanden; drei Foto-Originale fehlen |
| 12.01.2026 | Erster Ortstermin vorgesehen | Von Mieterseite am Vorabend wegen Schichtdienst abgesagt |
| 18.02.2026 | Gemeinsamer Ortstermin | Sichtbarer Befall von rund 0,8 qm; Ursache offen |
| 19.02. bis 04.03.2026 | Raumklimamessung | Messreihe mit 61 Stunden Datenlücke |
| 12.03.2026 | Mieterverein verlangt Beseitigung und 20 Prozent Rückzahlung | Schreiben vorhanden |
| Januar bis Mai 2026 | Mieten vollständig unter Vorbehalt gezahlt | SAP-Mietkonto ausgeglichen |
| 14.07.2026 | Klage und Verfügung zugestellt | Gerichtliche Zustellungsnachricht vorhanden |

Die Klage beziffert die Rückforderung mit 20 Prozent der Bruttowarmmiete für fünf Monate: 252,00 EUR je Monat, insgesamt 1260,00 EUR. Für den Mangelbeseitigungsantrag geben die Kläger einen vorläufigen Wert von 2800,00 EUR an; der Gesamtwert wird mit 4060,00 EUR vorgeschlagen. Die gerichtliche Wertfestsetzung bleibt abzuwarten.

## Rechtliche Kontrollpunkte

- Anspruchsgruppen getrennt prüfen: Erhaltung nach § 535 Abs. 1 S. 2 BGB, Minderung nach § 536 BGB, Rückzahlung nach § 812 Abs. 1 S. 1 Alt. 1 BGB, möglicher Schadensersatz nach § 536a BGB und Folgen der Anzeige beziehungsweise Zutrittslage nach § 536c BGB.
- Nach BGH, Urteil vom 29.02.2012 — VIII ZR 155/11, genügen grundsätzlich konkrete Mangelerscheinungen und Auswirkungen. Technische Ursache und bestimmte Minderungsquote sind keine allgemeinen Anforderungen an den Tatsachenvortrag des Mieters.
- BGH, Urteile vom 05.12.2018 — VIII ZR 67/18 und VIII ZR 271/17, betreffen bauzeitübliche Wärmebrücken und die bloße Gefahr von Schimmel. Die Akte enthält dagegen tatsächlichen Befall; die Entscheidungen dürfen deshalb nicht als automatische Klageabweisung missverstanden werden. Sie sind für Bauzustand, Beschaffenheitsvereinbarung sowie zumutbares Heiz- und Lüftungsverhalten fallbezogene Prüfanker.
- Die Minderungsquote ist Rechtsfolge. Dauer, räumliche Ausdehnung, Gebrauchsbeeinträchtigung und Bemessungsgrundlage müssen trotzdem beweisbar und monatsgenau geprüft werden.
- Die Ursache ist beweisoffen. Technikervermerk, Raumklimadaten, Fensterunterlagen, Möblierung und Zugang werden in einem Sachverständigen- und Zeugenplan zusammengeführt; ein einzelner Loggerwert ersetzt kein Gutachten.
- Für die Zustellung am 14.07.2026 gilt die zweiwöchige Notfrist der Verteidigungsanzeige nach § 276 Abs. 1 S. 1 ZPO. Die Klageerwiderungsfrist wird getrennt geführt.

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Wohnraummietvertrag | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Mietkonto FBL5N mit Vorbehaltszahlungen | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Mängelanzeige der Mieter | [korrespondenz/mieter-maengelanzeige-2026-01-08.md](korrespondenz/mieter-maengelanzeige-2026-01-08.md) |
| Terminbestätigung der Hausverwaltung | [korrespondenz/terminbestaetigung-hausverwaltung-2026-01-09.md](korrespondenz/terminbestaetigung-hausverwaltung-2026-01-09.md) |
| E-Mail zur Terminverschiebung | [korrespondenz/email-mieter-terminverschiebung-2026-01-11.md](korrespondenz/email-mieter-terminverschiebung-2026-01-11.md) |
| Arbeitsauftrag zur Fenstererneuerung | [technik/arbeitsauftrag-fenstererneuerung-2025.md](technik/arbeitsauftrag-fenstererneuerung-2025.md) |
| Abnahmeprotokoll der Fenstererneuerung | [technik/abnahmeprotokoll-fenstererneuerung-2025.md](technik/abnahmeprotokoll-fenstererneuerung-2025.md) |
| Messprotokoll des Ortstermins | [technik/messprotokoll-ortstermin-feuchte-2026-02-18.md](technik/messprotokoll-ortstermin-feuchte-2026-02-18.md) |
| Raumklima-Logger mit Datenlücke | [technik/raumklima-logger-2026-02-19-bis-03-04.md](technik/raumklima-logger-2026-02-19-bis-03-04.md) |
| Sanierungsangebot mit drei Zutrittsterminen | [korrespondenz/sanierungsangebot-zutrittsabstimmung-2026-03-06.md](korrespondenz/sanierungsangebot-zutrittsabstimmung-2026-03-06.md) |
| Grundrissnotiz zum Schlafzimmer | [objekt/grundriss-notiz-schlafzimmer.md](objekt/grundriss-notiz-schlafzimmer.md) |
| Fotoliste mit fehlenden Originalen | [objekt/fotoliste-schimmel.md](objekt/fotoliste-schimmel.md) |
| E-Mail der Objektbetreuerin | [hausverwaltung/email-objektbetreuerin-zutritt-und-moebel.md](hausverwaltung/email-objektbetreuerin-zutritt-und-moebel.md) |
| Schreiben des Mietervereins | [korrespondenz/mieterverein-schreiben-2026-03-12.md](korrespondenz/mieterverein-schreiben-2026-03-12.md) |
| DocuWeb-Exportliste mit Dubletten und Lücken | [dms/dms-exportliste-schimmelprozess.md](dms/dms-exportliste-schimmelprozess.md) |
| Klageschrift der Mieter | [gericht/klageschrift-mieter-schimmel.md](gericht/klageschrift-mieter-schimmel.md) |
| Zustellungsnachricht zur Klage | [gericht/zustellungsnachricht-klage-2026-07-14.md](gericht/zustellungsnachricht-klage-2026-07-14.md) |
| Gerichtliche Verfügung | [gericht/gerichtliche-verfuegung-2026-07-14.md](gericht/gerichtliche-verfuegung-2026-07-14.md) |
| Interne Aktennotiz zu Verteidigung und Beweis | [aktennotiz/aktennotiz-01-verteidigung-und-beweis.md](aktennotiz/aktennotiz-01-verteidigung-und-beweis.md) |
| Beweismatrix | [beweis/beweismatrix-schimmel.md](beweis/beweismatrix-schimmel.md) |
| Klageerwiderungsentwurf | [korrespondenz/klageerwiderung-entwurf.md](korrespondenz/klageerwiderung-entwurf.md) |
| Freigabekarte zur Klageerwiderung | [freigabe/freigabekarte-klageerwiderung.md](freigabe/freigabekarte-klageerwiderung.md) |
| Wartungsprotokoll der Außenfassade aus 2024 | [technik/wartungsprotokoll-aussenfassade-2024.md](technik/wartungsprotokoll-aussenfassade-2024.md) |
| E-Mail zur Vorschaden- und Archivsuche | [hausverwaltung/email-objektarchiv-vorschadenrecherche.md](hausverwaltung/email-objektarchiv-vorschadenrecherche.md) |

## Aufgabe für die Skills

1. Gerichtspost und beide Fristen vor jeder Tiefenprüfung sichern.
2. Zahlungs-, Beseitigungs- und etwaige Schadensersatzspur getrennt in eine Anspruchsmatrix übernehmen.
3. Unstreitige Tatsachen, bestreitbare Behauptungen, eigene Wahrnehmungen und sachverständigenbedürftige Ursachenfragen trennen.
4. Hausverwaltung, Technik, DMS und Mieterunterlagen in einen Beweis- und Anlagenplan überführen; fehlende Originalfotos und Logger-Rohdaten nachfordern.
5. Klageerwiderung nur nach Freigabekarte finalisieren und anschließend als getrennte PDFs mit Anlagenmanifest technisch einreichungsfertig machen.
