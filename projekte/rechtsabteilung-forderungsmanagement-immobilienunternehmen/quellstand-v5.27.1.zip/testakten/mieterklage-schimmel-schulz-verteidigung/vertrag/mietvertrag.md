# Wohnraummietvertrag

**Vertragsnummer:** WBI-MV-2021-02109
**Objekt:** Kaiserdamm 117, 14057 Berlin, 2. OG rechts
**Ablage:** SAP RE-FX / DocuWeb Vertragsakte

**Parteien**

**Vermieterin**

Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

vertreten durch den Geschäftsführer Dr. Markus Lehmann

**Mieter**

Frau Lisa Schulz, geboren am 12.02.1990

Herr Daniel Schulz, geboren am 04.07.1988

Kaiserdamm 117

14057 Berlin

## 1 Mietsache

### 1.1

Vermietet wird die Wohnung im 2. Obergeschoss rechts des Hauses Kaiserdamm 117, 14057 Berlin. Sie besteht aus drei Zimmern, Küche, Bad, Flur, Abstellkammer, Balkon und Kellerraum Nr. 117-2R.

### 1.2

Die Wohnfläche beträgt **68,40 qm**. Das Gebäude wurde 1964 errichtet. Die Wohnung wird ausschließlich zu Wohnzwecken überlassen.

### 1.3

Zur Wohnung gehören die im Übergabeprotokoll bezeichneten Heizkörper, Fenster, Innentüren und Sanitäreinrichtungen. Eine bestimmte Bauphysik oder ein Neubaustandard wird nicht vereinbart.

## 2 Mietzeit

### 2.1

Das Mietverhältnis beginnt am **01.06.2021** und läuft auf unbestimmte Zeit.

### 2.2

Die ordentliche Kündigung richtet sich nach den gesetzlichen Vorschriften.

## 3 Miete und Zahlung

| Position | Betrag |
|---|---:|
| Nettokaltmiete | 920,00 EUR |
| Betriebskostenvorauszahlung | 210,00 EUR |
| Heizkostenvorauszahlung | 130,00 EUR |
| **Bruttowarmmiete** | **1260,00 EUR** |

### 3.1

Die Miete ist monatlich im Voraus, spätestens bis zum dritten Werktag des Monats, auf das mitgeteilte Mietkonto zu zahlen.

### 3.2

Verwendungszweck: **WBI-MV-2021-02109 Schulz Kaiserdamm 117**.

## 4 Betriebskosten und Heizung

### 4.1

Die Mieter tragen die umlagefähigen Betriebskosten gemäß § 2 BetrKV und die Heiz- und Warmwasserkosten nach der Heizkostenverordnung.

### 4.2

Über die Vorauszahlungen wird jährlich abgerechnet. Anpassungen richten sich nach den gesetzlichen Vorschriften.

## 5 Mietsicherheit

### 5.1

Die Mietsicherheit beträgt **2760,00 EUR** und entspricht drei Nettokaltmieten.

### 5.2

Die Mieter dürfen eine Geldsicherheit in drei gleichen monatlichen Raten leisten. Die erste Rate ist zu Mietbeginn, die weiteren Raten sind mit den beiden folgenden Mietzahlungen fällig.

### 5.3

Die Vermieterin legt die Sicherheit getrennt von ihrem Vermögen an. Über geleistete Raten und die Anlage wird gesondert Nachweis erteilt.

## 6 Erhaltung, Mängel und Zutritt

### 6.1

Die Vermieterin erhält die Mietsache im vertragsgemäßen Zustand.

### 6.2

Während der Mietzeit auftretende Mängel oder nicht vorhergesehene Gefahren sind der Vermieterin unverzüglich anzuzeigen. Die gesetzlichen Rechte beider Seiten bleiben unberührt.

### 6.3

Die Mieter ermöglichen nach rechtzeitiger Ankündigung Zutritt, soweit ein konkreter sachlicher Grund besteht, insbesondere zur Prüfung angezeigter Mängel oder zur Durchführung erforderlicher Arbeiten. Auf berechtigte Belange der Mieter ist Rücksicht zu nehmen.

## 7 Nutzung und Lüftung

### 7.1

Die Wohnung ist angemessen zu beheizen und zu lüften. Starre Lüftungsintervalle werden nicht vereinbart.

### 7.2

Möbel dürfen vertragsgemäß aufgestellt werden. Bei erkennbaren Feuchteproblemen stimmen die Parteien erforderliche Prüf- und Schutzmaßnahmen anhand der konkreten Situation ab.

## 8 Anlagen

1. Übergabeprotokoll vom 28.05.2021
2. Wohnflächenberechnung
3. Betriebskostenkatalog
4. Hausordnung
5. Energieausweis

## 9 Bauliche Veränderungen und Einbauten

### 9.1

Eingriffe in Fenster, Außenwände, Fassade, Leitungen oder Gebäudetechnik bedürfen der vorherigen Zustimmung. Übliche bewegliche Möbel und Einrichtungsgegenstände dürfen vertragsgemäß aufgestellt werden.

### 9.2

Bei großflächigen Möbeln an Außenwänden berücksichtigen die Mieter erkennbare Feuchte- und Luftzirkulationsverhältnisse. Diese Regelung legt keine feste Möblierungsweise fest und verschiebt nicht die Verantwortung für bauliche Mängel.

### 9.3

Eigene Einbauten sind bei Vertragsende nur zurückzubauen, wenn dies wirksam vereinbart oder nach den gesetzlichen Umständen verlangt werden kann. Erforderliche Arbeiten werden vorab abgestimmt.

## 10 Hausordnung und Gemeinschaftsflächen

### 10.1

Die Hausordnung regelt Treppenhaus, Hof, Müllplätze, Fahrradabstellflächen und Ruhezeiten. Flucht- und Rettungswege sind freizuhalten.

### 10.2

Der Kellerraum ist für übliche Lagerzwecke bestimmt. Wasserempfindliche Sachen sind erhöht und mit Abstand zu Außenwänden zu lagern. Eine besondere Trockenheit des Kellerraums wird nicht zugesichert.

## 11 Übergabe, Schlüssel und Dokumentation

### 11.1

Das Übergabeprotokoll vom 28.05.2021 hält Zustand, Zählerstände und Schlüssel fest. Im Schlafzimmer sind tapezierte Außenwände ohne sichtbare Feuchtespuren dokumentiert. Die damaligen Holzfenster wurden als funktionsfähig aufgenommen; ihr späterer Austausch wird in der technischen Objektakte gesondert dokumentiert.

### 11.2

Übergeben wurden drei Haus- und Wohnungsschlüssel, zwei Briefkastenschlüssel und ein Kellerschlüssel. Nachfertigungen für die Schließanlage sind mit der Hausverwaltung abzustimmen und bei Vertragsende vollständig zurückzugeben.

### 11.3

Bei Beendigung wird ein Rückgabeprotokoll über Zustand, Zählerstände und Schlüssel gefertigt. Ansprüche werden durch die bloße Aufnahme eines Befunds weder anerkannt noch ausgeschlossen.

## 12 Kommunikation und Vertragsänderungen

### 12.1

Änderungen von Zustellanschrift und Kontaktdaten sollen zeitnah mitgeteilt werden. Mängelanzeigen können über das Serviceportal, per E-Mail, schriftlich oder in dringenden Fällen telefonisch erfolgen; eine telefonische Meldung wird durch die Hausverwaltung dokumentiert.

### 12.2

Nebenabreden bestehen bei Unterzeichnung nicht. Dauerhafte Änderungen werden in einer eindeutig bezeichneten Erklärung oder einem Nachtrag festgehalten. Gesetzlich vorgeschriebene Formen bleiben maßgeblich.

**Unterschriften**

Berlin, den 25.05.2021

| Vermieterin | Mieterin | Mieter |
|---|---|---|
| Wohnen Berlin Immobilien GmbH, Dr. Markus Lehmann | Lisa Schulz | Daniel Schulz |
