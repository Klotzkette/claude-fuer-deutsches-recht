# Beweismatrix Feuchtigkeit und Schimmel

**Vorgang:** F-2026-00602
**Stand:** 15.07.2026

| Tatsachenpunkt | Prozessuale Rolle | Vorhandene Quelle | Status | Nächste Maßnahme |
|---|---|---|---|---|
| Mietvertrag und Bruttowarmmiete 1260,00 EUR | unstreitige Vertragsgrundlage | Mietvertrag, SAP | grün | Anlagenfassung festlegen |
| Vollständige Zahlungen Januar bis Mai 2026 | Grundlage Rückforderungsantrag | Mietkonto, SAP | grün | Buchungsauszug als Anlage sichern |
| Vorbehalt der Zahlungen | von Klägerseite behauptet; im SAP vermerkt | Mieterbrief, SAP-Vermerk | gelb | Eingang und Wortlaut je Monat prüfen |
| Sichtbarer Befall am 18.02.2026 | Mangelerscheinung | Messprotokoll, Fotos 4 bis 8, Zeugin Novak, Zeuge Zander | grün | nicht pauschal bestreiten |
| Sichtbarer Befall bereits Anfang Januar | Dauer und Rückforderungszeitraum | Mieterbrief, drei Vorschaufotos | gelb | Originalfotos und Metadaten anfordern |
| Umfang von rund 0,8 qm | Ausmaß am Ortstermin | Messprotokoll, Foto mit Zollstock | grün für 18.02.2026 | Veränderungen davor und danach offenhalten |
| Modriger Geruch und eingeschränkte Schlafraumnutzung | Gebrauchsbeeinträchtigung | Parteivortrag; Wahrnehmung Novak am 18.02. | gelb | konkrete Nutzungsangaben und Zeugen prüfen |
| Fenstererneuerung im September 2025 | mögliche technische Anknüpfungstatsache | Auftrag und Abnahme | grün | Montageunterlagen und Fugenschema anfordern |
| Fehlerhafte Fensteranschlussfuge | mögliche Ursache | Sichtvermerk Novak; Foto 6 | rot | technische Prüfung erforderlich |
| Bauzeitbedingte Wärmebrücke | mögliche Ursache | bislang keine Bauzeichnung | rot | Bauakte und Sachverständigenprüfung |
| Abstand des Schranks 3 bis 5 cm am 18.02.2026 | mögliche nutzungsbezogene Anknüpfungstatsache | Skizze, Foto 7, Novak | grün für Ortstermin | früheren Zustand nicht als bewiesen behandeln |
| Heiz- und Lüftungsverhalten Januar bis Mai | mögliche Mitursache | Parteivortrag; Logger teilweise | rot | konkrete Angaben, Rohdaten und Messgrenzen sichern |
| Loggerwerte 19.02. bis 04.03.2026 | nachträgliche Raumklimaindizien | Auswertung mit 61-Stunden-Lücke | gelb | Rohdatei, Kalibrierung und Geräteblatt beschaffen |
| Absage des Termins am 12.01.2026 | Zugang und Reaktionsablauf | E-Mail 11.01., Novak | grün | Folgetelefonate und Terminsuche ergänzen |
| Minderungsquote 20 Prozent | Rechtsfolge, kein Tatsachenbeweis durch SAP | Klageschrift | rot | Dauer, Fläche und konkrete Beeinträchtigung getrennt bewerten |

## Anlagenstatus

| Vorgesehene Anlage | Dokument | Status |
|---|---|---|
| B 1 | Mietvertrag | verwendbar |
| B 2 | Mietkonto Januar bis Juni 2026 | verwendbar |
| B 3 | Terminbestätigung und Absage | verwendbar |
| B 4 | Messprotokoll vom 18.02.2026 | verwendbar nach Versionskontrolle |
| B 5 | Fotodokumentation technischer Dienst | Originale vorhanden |
| B 6 | Arbeitsauftrag und Abnahme Fenster | verwendbar; Montageanlage fehlt |
| B 7 | Loggerauswertung | nur mit Einschränkung; Rohdatei fehlt |
