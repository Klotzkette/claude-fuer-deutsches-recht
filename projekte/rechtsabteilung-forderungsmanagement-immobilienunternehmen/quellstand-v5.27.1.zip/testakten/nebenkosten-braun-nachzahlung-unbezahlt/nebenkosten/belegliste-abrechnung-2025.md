# Belegliste Betriebskosten 2025

## 1 Objekt und Abrechnung

| Feld | Wert |
|---|---|
| Objekt | Greifswalder Straße 201, 10405 Berlin |
| Abrechnungszeitraum | 01.01.2025 bis 31.12.2025 |
| Wohnung | 1. OG mitte, Lukas Braun |
| Vertragsnummer | WBI-MV-2022-00943 |

## 2 Belegregister

| Nr. | Kostenart | Kreditor oder Stelle | Bruttobetrag Objekt | Rechnung oder Bescheid | Zahlung | Vertragsbeleg | Leistungsnachweis |
|---:|---|---|---:|---|---|---|---|
| 1 | Grundsteuer | Finanzamt Prenzlauer Berg | 18400,00 EUR | vorhanden | vorhanden | entfällt | entfällt |
| 2 | Wasser und Abwasser | Berliner Wasserbetriebe | 28700,00 EUR | vorhanden | vorhanden | entfällt | Zählerliste vorhanden |
| 3 | Hausmeister | Hausservice Nordlicht GmbH | 21600,00 EUR | vorhanden | vorhanden | Vertrag vorhanden | Monatsblätter 10 von 12 |
| 4 | Gartenpflege | Grünwerk Berlin GmbH | 9400,00 EUR | vorhanden | vorhanden | Auftrag 2024 verlängert | vier Einsatzberichte |
| 5 | Gebäudereinigung | Klarblick Gebäudedienste KG | 12200,00 EUR | vorhanden | vorhanden | Vertrag vorhanden | Quartalskontrollen vorhanden |
| 6 | Versicherung | Berliner Kommunalversicherung AG | 15100,00 EUR | Beitragsrechnung vorhanden | vorhanden | Police vorhanden | entfällt |
| 7 | Heizkosten | WärmeMess Berlin GmbH | 43600,00 EUR | Gesamtabrechnung vorhanden | vorhanden | Wärmeliefervertrag vorhanden | Ablesedaten vorhanden |

## 3 Nachlauf

Für Hausmeister fehlen im DMS die Tätigkeitsblätter Februar und Oktober 2025. Laut Kreditorenakte wurden beide Monate vollständig bezahlt. Die Gartenpflege enthält einen gesonderten Einsatz nach Sturmschaden; dessen Zuordnung zur laufenden Pflege ist in der Belegmatrix zu prüfen.
