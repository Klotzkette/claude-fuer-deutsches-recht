# Jahresrechnung Wasser und Abwasser 2025

Berliner Wasserbetriebe

Rechnungsempfängerin: Wohnen Berlin Immobilien GmbH

Verbrauchsstelle: Greifswalder Straße 201, 10405 Berlin

Kundennummer: 44719028

Rechnungsnummer: BWB-2026-011847

Rechnungsdatum: 18.01.2026

Leistungszeitraum: 01.01.2025 bis 31.12.2025

## 1. Abrechnung

| Position | Menge oder Basis | Nettobetrag | Umsatzsteuer | Bruttobetrag |
|---|---|---:|---:|---:|
| Trinkwasser | 3240 m³ | 7520,00 EUR | 526,40 EUR | 8046,40 EUR |
| Schmutzwasser | 3198 m³ | 14780,00 EUR | 0,00 EUR | 14780,00 EUR |
| Niederschlagswasser | 1460 m² | 4248,60 EUR | 0,00 EUR | 4248,60 EUR |
| Grundpreise und Messstellen | Objekt | 1625,00 EUR | 0,00 EUR | 1625,00 EUR |
| **Gesamt** | | | | **28700,00 EUR** |

## 2. Abschläge

Im Abrechnungszeitraum wurden Abschläge in Höhe von insgesamt 27400,00 EUR berücksichtigt. Der verbleibende Rechnungsbetrag von 1300,00 EUR war zum 05.02.2026 fällig und wurde im Kreditoren-Sammellauf beglichen.

## 3. Anlagenhinweis

Die Zählerliste mit Anfangs- und Endständen ist Bestandteil der elektronischen Rechnung. Einzelne Wohnungszähler werden durch den Messdienst verwaltet; diese Rechnung enthält nur die Objektabrechnung.

Berliner Wasserbetriebe
