# Verteilungsblatt Wasser und Abwasser 2025

**Objekt:** Greifswalder Straße 201, 10405 Berlin

**Wohnung:** 1. OG Mitte, Lukas Braun

**Vertragsnummer:** WBI-MV-2022-00943

**Abrechnungszeitraum:** 01.01.2025 bis 31.12.2025

**Erstellt:** 24.03.2026

## 1. Zählerablesung Wohnung

| Messstelle | Zählernummer | Anfangsstand | Endstand | Abgerechnete Menge |
|---|---|---:|---:|---:|
| Kaltwasser Küche | KW-201-019-01 | 144,260 m³ | 169,610 m³ | 25,350 m³ |
| Kaltwasser Bad | KW-201-019-02 | 318,410 m³ | 348,060 m³ | 29,650 m³ |
| **Trinkwasser gesamt** |  |  |  | **55,000 m³** |

Für Schmutzwasser sind nach dem dokumentierten Abzug von 0,046 m³ für die gemeinschaftlich abgerechnete Leitungsprüfung 54,954 m³ angesetzt. Eine Schätzung oder Nutzerwechselabgrenzung war nicht erforderlich.

## 2. Kostenverteilung

| Bestandteil | Objektbasis | Wohnungsbasis | Anteil Wohnung |
|---|---|---|---:|
| Trinkwasser | 8046,40 EUR bei 3240,000 m³ | 55,000 m³ | 136,59 EUR |
| Schmutzwasser | 14780,00 EUR bei 3198,000 m³ | 54,954 m³ | 253,98 EUR |
| Niederschlagswasser | 4248,60 EUR bei 2736,40 qm | 52,10 qm | 80,89 EUR |
| Grundpreise und Messstellen | 1625,00 EUR bei 2736,40 qm | 52,10 qm | 30,94 EUR |
| **Anteil Wasser und Abwasser** |  |  | **502,40 EUR** |

## 3. Kontrollvermerke

Die Summe der vier Wohnungsanteile wurde auf zwei Nachkommastellen gerundet. Die Objektbasis stimmt mit der Jahresrechnung BWB-2026-011847 überein. Die Zählernummern wurden mit dem Geräteverzeichnis der WärmeMess Berlin GmbH abgeglichen; Abweichungen sind nicht vermerkt.

Sachlich geprüft am 24.03.2026 durch M. Ullrich.

Rechnerisch gegengeprüft am 25.03.2026 durch A. Klose.
