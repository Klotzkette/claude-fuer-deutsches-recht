# Grünwerk Berlin GmbH

Wiesenweg 14, 13156 Berlin

Amtsgericht Charlottenburg HRB 221904 B

USt-IdNr. DE348771204

Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

## 1 Rechnung

| Feld | Inhalt |
|---|---|
| Rechnung | GW-2025-1184 |
| Rechnungsdatum | 18.12.2025 |
| Objekt | Greifswalder Straße 201, 10405 Berlin |
| Leistungszeitraum | März bis November 2025 |
| Auftragsnummer | WBI-GR-2024-201 |
| Kreditorennummer | 4400317 |

## 2 Leistungsübersicht

| Position | Umfang | Betrag |
|---|---|---:|
| Rasen- und Randpflege | neun Einsätze | 3600,00 EUR |
| Hecken- und Strauchschnitt | drei Einsätze | 2100,00 EUR |
| Pflege der Hofbeete | sieben Einsätze | 1750,00 EUR |
| Laubaufnahme und Abfuhr | vier Einsätze | 1200,00 EUR |
| Sicherung abgebrochener Äste nach Sturm vom 27.06.2025 | ein Einsatz | 750,00 EUR |
| Rechnungsbetrag | | 9400,00 EUR |

Die Preise verstehen sich als Bruttobeträge einschließlich Umsatzsteuer. Grundlage ist das Leistungsverzeichnis vom 12.12.2024. Die Einsatzorte umfassen Innenhof, Vorgarten, Müllplatzumfassung und die straßenseitige Pflanzfläche; Pflegeflächen benachbarter Objekte sind nicht enthalten.

## 3 Anlagenvermerk

Der Rechnung waren vier Sammel-Einsatzberichte beigefügt. Für die regulären Rasenpflegeeinsätze liegen keine einzelnen Stundenzettel vor. Der Sturmeinsatz wurde auf demselben Auftragskonto wie die laufende Gartenpflege gebucht.

Der Einsatz nach dem Sturm vom 27.06.2025 betraf das Absperren und Zerkleinern zweier abgebrochener Äste im Innenhof. Eine Baumfällung, Reparatur am Spielgerät oder Beseitigung eines Gebäudeschadens wurde nicht berechnet. Ob dieser Sonderaufwand vom laufenden Gartenpflegeauftrag umfasst ist, ergibt sich aus der Vertragsanlage und ist bei der Rechnungsprüfung gesondert zu kennzeichnen.

Zahlbar bis 15.01.2026 auf das im Kreditorenstamm hinterlegte Konto unter Angabe der Rechnungsnummer. Bitte teilen Sie Beanstandungen mit Positionsbezug mit.

Grünwerk Berlin GmbH

Rechnungswesen
