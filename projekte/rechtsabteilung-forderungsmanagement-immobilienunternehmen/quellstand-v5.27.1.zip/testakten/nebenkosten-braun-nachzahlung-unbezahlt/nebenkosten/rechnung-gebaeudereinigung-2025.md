# Klarblick Gebäudedienste KG

Beusselstraße 77, 10553 Berlin

Amtsgericht Charlottenburg HRA 59218 B

USt-IdNr. DE319440882

Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

## 1 Jahresrechnung

| Feld | Inhalt |
|---|---|
| Rechnung | KB-25-99107 |
| Rechnungsdatum | 30.12.2025 |
| Objekt | Greifswalder Straße 201, 10405 Berlin |
| Vertragsreferenz | WBI-RG-2019-201 |
| Leistungszeitraum | 01.01.2025 bis 31.12.2025 |
| Kreditorennummer | 4400228 |

## 2 Abrechnung

| Leistung | Turnus | Betrag |
|---|---|---:|
| Treppenhausreinigung | wöchentlich | 8400,00 EUR |
| Keller- und Nebenflächen | monatlich | 1800,00 EUR |
| Glasflächen Hauseingang | vierteljährlich | 1200,00 EUR |
| Verbrauchsmittel und Mattenservice | pauschal | 800,00 EUR |
| Rechnungsbetrag | | 12200,00 EUR |

Die Jahresrechnung fasst die monatlichen Abschläge des Vertrags WBI-RG-2019-201 zusammen. Sonderreinigungen nach Bauarbeiten, Wohnungsreinigungen und Schädlingsbekämpfung sind nicht enthalten. Die ausgewiesenen Beträge verstehen sich einschließlich Umsatzsteuer.

## 3 Qualitätskontrollen

Die Quartalskontrollen vom 28.03., 27.06., 26.09. und 19.12.2025 sind im Objektportal als erledigt markiert. Am 11.04.2025 wurde eine Reklamation zur Kellerreinigung erfasst und nach kostenfreier Nacharbeit geschlossen.

Die Nacharbeit am 16.04.2025 wurde nicht zusätzlich berechnet. Das Kontrollblatt enthält Fotos vom Kellerflur vor und nach der Nacharbeit sowie die Unterschrift der Objektbetreuerin. Eine pauschale Kürzung der Jahresrechnung wurde von der Auftraggeberin nicht vorgenommen.

Zahlungsziel 14 Tage netto unter Angabe der Rechnungsnummer. Bankverbindung und Steuerdaten entsprechen dem freigegebenen Kreditorenstamm.

Klarblick Gebäudedienste KG

Debitorenbuchhaltung
