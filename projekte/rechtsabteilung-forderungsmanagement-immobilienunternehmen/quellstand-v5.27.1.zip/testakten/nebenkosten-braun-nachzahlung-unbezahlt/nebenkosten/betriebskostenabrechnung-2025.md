# Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

Herrn

Lukas Braun

Greifswalder Straße 201

10405 Berlin

Berlin, 28.06.2026

**Vertragsnummer:** WBI-MV-2022-00943

**Mietkonto:** 930943

**Objekt:** Greifswalder Straße 201, 10405 Berlin, 1. OG Mitte

**Betriebskostenabrechnung 2025**

Sehr geehrter Herr Braun,

wir rechnen nachfolgend die Betriebs- und Heizkostenvorauszahlungen für den Zeitraum vom 01.01.2025 bis 31.12.2025 ab. Sie waren während des gesamten Abrechnungszeitraums Mieter der Wohnung. Als Wohnfläche sind 52,10 qm angesetzt; die für flächenabhängige Kosten maßgebliche Gesamtfläche des Objekts beträgt 2736,40 qm.

## 1. Abrechnungsergebnis

| Abrechnungsbereich | Ihr Kostenanteil | Ihre Vorauszahlungen | Ergebnis |
|---|---:|---:|---:|
| Kalte Betriebskosten | 1962,74 EUR | 2040,00 EUR | 77,26 EUR Guthaben |
| Heizkosten | 1961,54 EUR | 1200,00 EUR | 761,54 EUR Nachzahlung |
| **Gesamtergebnis** | **3924,28 EUR** | **3240,00 EUR** | **684,28 EUR Nachzahlung** |

Bitte überweisen Sie den Nachzahlungsbetrag von **684,28 EUR bis zum 30.07.2026** auf das bekannte Mietkonto. Geben Sie als Verwendungszweck `WBI-MV-2022-00943 BK 2025` an. Die laufende Miete bleibt hiervon getrennt und ist weiterhin zum vertraglichen Termin zu zahlen.

## 2. Kalte Betriebskosten im Einzelnen

| Kostenart | Gesamtkosten Objekt | Verteilerschlüssel | Berechnung Ihres Anteils | Ihr Anteil |
|---|---:|---|---|---:|
| Grundsteuer | 18400,00 EUR | Wohnfläche | 18400,00 × 52,10 / 2736,40 | 350,33 EUR |
| Wasser und Abwasser | 28700,00 EUR | Verbrauch und Fläche | Wohnungszähler sowie Flächenanteile für Grund- und Niederschlagskosten | 502,40 EUR |
| Hausmeister | 21600,00 EUR | Wohnfläche | 21600,00 × 52,10 / 2736,40 | 411,26 EUR |
| Gartenpflege | 9400,00 EUR | Wohnfläche | 9400,00 × 52,10 / 2736,40 | 178,97 EUR |
| Gebäudereinigung | 12200,00 EUR | Wohnfläche | 12200,00 × 52,10 / 2736,40 | 232,28 EUR |
| Gebäude- und Haftpflichtversicherung | 15100,00 EUR | Wohnfläche | 15100,00 × 52,10 / 2736,40 | 287,50 EUR |
| **Summe kalte Betriebskosten** |  |  |  | **1962,74 EUR** |

Der Anteil für Wasser und Abwasser setzt sich aus dem wohnungsbezogenen Kaltwasserverbrauch, dem korrespondierenden Schmutzwasser sowie den flächenabhängigen Anteilen für Niederschlagswasser, Grundpreise und Messstellen zusammen. Die vollständige Berechnung ist im beigefügten Verteilungsblatt ausgewiesen.

## 3. Heizkosten

Die umlagefähigen Objektkosten betragen 43600,00 EUR. Davon werden 30 Prozent nach Fläche und 70 Prozent nach den in der Einzelabrechnung ausgewiesenen Verbrauchseinheiten verteilt. Auf Ihre Wohnung entfallen 249,04 EUR Grundkosten und 1712,50 EUR Verbrauchskosten, zusammen **1961,54 EUR**. Der Gerätewechsel am Schlafzimmerheizkörper am 18.08.2025 wurde durch einen dokumentierten Alt- und Neuwert berücksichtigt; eine Schätzung wegen fehlender Ablesung erfolgte nicht.

Die elektrische Warmwasserbereitung Ihrer Wohnung wird über Ihren eigenen Stromvertrag abgerechnet. Hier werden keine zentralen Warmwasserkosten angesetzt.

## 4. Berücksichtigte Vorauszahlungen

Im Jahr 2025 wurden zwölf monatliche Betriebskostenvorauszahlungen zu je 170,00 EUR und zwölf Heizkostenvorauszahlungen zu je 100,00 EUR gebucht. Damit sind insgesamt **3240,00 EUR** vollständig berücksichtigt. Nicht enthalten sind die Nettokaltmiete, die Kaution und Zahlungen außerhalb des Abrechnungszeitraums.

## 5. Belegeinsicht und Rückfragen

Sie können die der Abrechnung zugrunde liegenden Rechnungen, Verträge, Leistungsnachweise, Zahlungsbelege, Flächenaufstellungen und Verteilungsunterlagen nach Terminvereinbarung in unserem Verwaltungsbüro Prenzlauer Berg einsehen. Bitte benennen Sie bei Ihrer Anfrage möglichst die Kostenarten, zu denen Sie Unterlagen sehen möchten. Auf Wunsch stellen wir vorhandene digitale Kopien bereit, soweit Rechte Dritter und Datenschutz dem nicht entgegenstehen.

Einwendungen gegen die Abrechnung teilen Sie uns bitte nachvollziehbar mit. Die gesetzlichen Fristen bleiben maßgeblich. Rückfragen richten Sie unter Angabe der Vertragsnummer an die Betriebskostenabteilung, Telefon 030 2055 4864 oder betriebskosten@wohnen-berlin-immobilien.de.

Mit freundlichen Grüßen

Wohnen Berlin Immobilien GmbH

Maja Ullrich

Betriebskostenabrechnung

**Anlagen:** Kostenartenübersicht, Verteilungsblatt Wasser und Abwasser, Heizkosten-Einzelabrechnung, Übersicht der berücksichtigten Vorauszahlungen
