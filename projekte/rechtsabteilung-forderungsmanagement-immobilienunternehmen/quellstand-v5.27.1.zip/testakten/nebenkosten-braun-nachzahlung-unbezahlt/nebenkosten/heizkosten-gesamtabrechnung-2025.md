# WärmeMess Berlin GmbH

Storkower Straße 118

10407 Berlin

**Heizkostenabrechnung 2025**

**Auftraggeberin:** Wohnen Berlin Immobilien GmbH

**Objekt:** Greifswalder Straße 201, 10405 Berlin

**Nutzer:** Lukas Braun, 1. OG Mitte

**Vertragsnummer:** WBI-MV-2022-00943

**Abrechnungsnummer:** WM-25-10405-201-019

**Erstellt am:** 22.03.2026

**Abrechnungszeitraum:** 01.01.2025 bis 31.12.2025

## 1. Umlagefähige Objektkosten

| Position | Bruttobetrag |
|---|---:|
| Wärmelieferung einschließlich Grundpreis | 35240,00 EUR |
| Betriebsstrom der Heizungsanlage | 2180,00 EUR |
| Wartung und Emissionsmessung | 2960,00 EUR |
| Messdienst, Ablesung und Abrechnung | 3220,00 EUR |
| **Umlagefähige Gesamtkosten** | **43600,00 EUR** |

Die vorstehende Summe berücksichtigt bereits den nicht auf die Nutzer umgelegten Vermieteranteil an den Kohlendioxidkosten. Die zugrunde liegende Wärmelieferrechnung, die Emissionsdaten und die Berechnung der Kostenteilung gehören zum Objektkostensatz.

## 2. Verteilungsschlüssel

Die Kosten betreffen ausschließlich die Raumheizung. Warmwasser wird in den Wohnungen durch elektrische Durchlauferhitzer bereitet und über den jeweiligen privaten Stromvertrag bezahlt; eine zentrale Warmwasseranlage besteht nicht. Die Heizkosten werden zu 30 Prozent nach beheizbarer Nutzfläche und zu 70 Prozent nach Verbrauch verteilt. Die beheizbare Gesamtfläche des Objekts beträgt 2736,40 qm. Für die Wohnung Braun sind 52,10 qm angesetzt. Der Gesamtverbrauch des Objekts beträgt 159410,0 Verbrauchseinheiten; auf die Wohnung entfallen 8944,6 Verbrauchseinheiten.

| Kostenblock | Objektbetrag | Berechnungsgrundlage Wohnung | Anteil Wohnung |
|---|---:|---|---:|
| Grundkosten 30 Prozent | 13080,00 EUR | 52,10 qm / 2736,40 qm | 249,04 EUR |
| Verbrauchskosten 70 Prozent | 30520,00 EUR | 8944,6 / 159410,0 Einheiten | 1712,50 EUR |
| **Heizkosten Wohnung** |  |  | **1961,54 EUR** |

Jeder Kostenblock wird mit der vollständigen Quote gerechnet und anschließend auf Cent gerundet: 13080,00 × 52,10 / 2736,40 = 249,04 EUR; 30520,00 × 8944,6 / 159410,0 = 1712,50 EUR. Die Summe beträgt 1961,54 EUR. Zwischenfaktoren werden nicht vorzeitig gekürzt.

## 3. Ablesewerte der Wohnung

| Raum oder Gerät | Gerätenummer | Ablesung 2025 | Besonderheit |
|---|---|---:|---|
| Wohnzimmer Heizkörper 1 | HKV-201-019-01 | 2861,4 | Funkablesung 05.01.2026 |
| Wohnzimmer Heizkörper 2 | HKV-201-019-02 | 1944,7 | Funkablesung 05.01.2026 |
| Schlafzimmer Altgerät | HKV-201-019-03A | 1187,5 | Ausbauwert 18.08.2025 |
| Schlafzimmer Neugerät | HKV-201-019-03B | 1012,6 | Einbauwert null; Stichtagswert 05.01.2026 |
| Bad | HKV-201-019-04 | 824,1 | Funkablesung 05.01.2026 |
| Küche | HKV-201-019-05 | 1114,3 | Funkablesung 05.01.2026 |
| **Summe bewertete Einheiten** |  | **8944,6** | keine Schätzung |

Der Gerätewechsel im Schlafzimmer wurde zeitanteilig mit dem dokumentierten Ausbauwert des Altgeräts und dem Einbauwert des Neugeräts verarbeitet. Die Gerätenummern stimmen mit dem Montageprotokoll WM-MO-180825-771 überein. Für keinen Heizkörper wurde ein Vorjahres- oder Vergleichswert eingesetzt.

## 4. Verbrauchsinformation

Der witterungsbereinigte Verbrauch der Wohnung liegt über dem Objektmittel. Ein solcher Vergleich ist keine technische Ursachenfeststellung und ändert den vertraglichen Verteilerschlüssel nicht. Für Rückfragen zu Gerätenummern, Ablesewerten oder dem Gerätewechsel ist die Abrechnungsnummer WM-25-10405-201-019 anzugeben.

WärmeMess Berlin GmbH

Abrechnungsservice
