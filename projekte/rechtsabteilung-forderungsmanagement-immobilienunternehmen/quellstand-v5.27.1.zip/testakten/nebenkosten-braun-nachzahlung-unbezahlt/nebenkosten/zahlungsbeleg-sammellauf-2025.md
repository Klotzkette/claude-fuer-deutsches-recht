# Kreditoren-Sammellauf

## 1 Zahlungslauf

| Feld | Wert |
|---|---|
| Buchungskreis | WBI-DE-BER |
| Zahlungslauf | ZL-2026-01-20-03 |
| Ausführung | 20.01.2026, 05:42 Uhr |
| Hausbank | Berliner Handelsbank AG |

## 2 Einzelzahlungen

| Kreditor | Rechnung | Betrag | Bankstatus | SAP-Beleg |
|---|---|---:|---|---|
| Hausservice Nordlicht GmbH | HN-2025-12088 | 21600,00 EUR | ausgeführt | KZ-2026-004411 |
| Grünwerk Berlin GmbH | GW-2025-1184 | 9400,00 EUR | ausgeführt | KZ-2026-004412 |
| Klarblick Gebäudedienste KG | KB-25-99107 | 12200,00 EUR | ausgeführt | KZ-2026-004413 |
| Summe | | 43200,00 EUR | | |

## 3 Rückmeldestatus

Für alle drei Zahlungen liegt die Bankrückmeldung „ACSC - Settlement completed“ vor. Rücklastschriften oder nachträgliche Gutschriften sind bis zum Exportdatum 11.08.2026 nicht erfasst.

## 4 Freigabespur

Der Zahlungsvorschlag wurde am 19.01.2026 um 15:18 Uhr durch Kreditorenbuchhaltung M. Seidel erstellt. Sachliche Freigabe der drei Rechnungen: Objektbetreuung M. Scholz am 19.01.2026 um 16:02 Uhr. Zweite Zahlungsfreigabe: Teamleitung Finanzen A. Peters am 20.01.2026 um 05:31 Uhr. Das Vier-Augen-Protokoll ist unter der Laufnummer ZL-2026-01-20-03 im SAP-Zahlungsverkehr gespeichert.

Der Sammellauf belegt die tatsächliche Zahlung der drei bezeichneten Rechnungen. Er trifft keine Aussage zur mietrechtlichen Umlagefähigkeit einzelner Leistungen oder zur Richtigkeit des verwendeten Verteilerschlüssels; diese Prüfung erfolgt in der Betriebskostenakte.
