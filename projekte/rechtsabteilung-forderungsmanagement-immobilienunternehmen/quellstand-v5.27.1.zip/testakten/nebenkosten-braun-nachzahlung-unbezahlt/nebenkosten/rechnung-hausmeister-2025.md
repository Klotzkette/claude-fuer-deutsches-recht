# Hausservice Nordlicht GmbH

## 1 Rechnung

| Feld | Inhalt |
|---|---|
| Rechnung | HN-2025-12088 |
| Rechnungsdatum | 31.12.2025 |
| Leistungszeitraum | 01.01.2025 bis 31.12.2025 |
| Objekt | Greifswalder Straße 201, 10405 Berlin |
| Auftraggeberin | Wohnen Berlin Immobilien GmbH |

## 2 Leistungen

| Position | Menge | Einzelpreis | Gesamt |
|---|---:|---:|---:|
| Hausmeister-Grunddienst Januar bis Dezember | 12 Monate | 1350,00 EUR | 16200,00 EUR |
| Kontrollgänge technische Gemeinschaftsflächen | 12 Monate | 250,00 EUR | 3000,00 EUR |
| Bereitstellung Müllgroßbehälter und Sperrmüllkoordination | 12 Monate | 150,00 EUR | 1800,00 EUR |
| Kleinmaterial Gemeinschaftsflächen laut Pauschale | 12 Monate | 50,00 EUR | 600,00 EUR |
| Rechnungsbetrag | | | 21600,00 EUR |

## 3 Abgrenzung

Instandsetzungsarbeiten innerhalb von Wohnungen, Material für Reparaturen und Verwaltungstätigkeiten sind nach dem Leistungsverzeichnis nicht Bestandteil dieser Rechnung. Gesonderte Reparaturaufträge werden separat abgerechnet.

Zahlbar bis 20.01.2026 unter Angabe der Rechnungsnummer.

Hausservice Nordlicht GmbH

Kreditor 4400188
