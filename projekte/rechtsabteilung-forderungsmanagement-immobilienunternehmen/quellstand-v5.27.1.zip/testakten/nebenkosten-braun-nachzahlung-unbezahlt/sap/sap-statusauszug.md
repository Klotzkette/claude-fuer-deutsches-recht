# SAP RE-FX / FI-CA Statusauszug

**System:** SAP S/4HANA RE-FX, Produktivmandant WBI-PRD
**Export:** 22.07.2026, 09:06 Uhr
**Export-ID:** REFX-FICA-20260722-GS201-01M
**Sachbearbeitung:** Sandra Berger, Forderungsmanagement Betriebskosten

## Vertragskopf

| Feld | Wert |
|---|---|
| Buchungskreis | WBI-DE-BER |
| Vertragsnummer | WBI-MV-2022-00943 |
| SAP-Vertragsobjekt | MV-117903-BR |
| Debitor | D-664201 |
| Objekt | 10405-B-GS201-01M |
| Nutzungseinheit | Greifswalder Straße 201, 1. OG Mitte |
| Vermieterin | Wohnen Berlin Immobilien GmbH |
| Mieter | Lukas Braun |
| Vertragsbeginn | 01.02.2022 |
| Status | Aktiv |

## Betriebskostenkonto 2025

| Feld | Wert |
|---|---|
| Abrechnungszeitraum | 01.01.2025 bis 31.12.2025 |
| Zugang Abrechnung | 30.06.2026, DMS-Postausgang |
| Vorauszahlungen laut Vertrag | 3240,00 EUR jährlich |
| Kostenanteil laut Abrechnung | 3924,28 EUR |
| Nachzahlung | 684,28 EUR |
| Fälligkeit | 30 Tage nach Zugang |
| Belegeinsicht angeboten | Ja, digital oder vor Ort |

## Offener Posten

| OP-Nr. | Fälligkeit | Text | Soll | Ist | Offen | Status |
|---|---|---|---:|---:|---:|---|
| 930943-BK25 | 30.07.2026 | Nachzahlung Betriebskosten 2025 | 684,28 EUR | 0,00 EUR | 684,28 EUR | bestritten |

## Zahlungs- und Streitstatus

| Prüfpunkt | Ergebnis |
|---|---|
| Laufende Miete | Juli 2026 bezahlt |
| Frühere Rückstände | Keine offenen Mietrückstände |
| Widerspruch | Pauschal, keine konkrete Position benannt |
| Mahnsperre | Nein |
| Streitkennzeichen | Betriebskostenwiderspruch pauschal |
| Belegpaket | Im DMS vorhanden, Index BK-2025-GS201 |
| Wiedervorlage | 30.07.2026, Zahlung oder konkreten Widerspruch prüfen |

## Bearbeitungshinweis

Die Akte ist kein Mietrückstand, sondern ein isolierter Nachzahlungsfall. Für die Anspruchsprüfung sind formelle Ordnungsmäßigkeit, Zugang, Abrechnungsfrist, Umlageschlüssel, Vorauszahlungen und Belegeinsicht zu trennen. Ein pauschaler Widerspruch wird als Einwendung aufgenommen, ersetzt aber keine konkrete Prüfposition.
