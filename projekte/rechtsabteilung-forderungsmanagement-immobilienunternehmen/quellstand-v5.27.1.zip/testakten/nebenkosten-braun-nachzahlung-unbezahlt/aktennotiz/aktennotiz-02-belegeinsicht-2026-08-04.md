# Aktennotiz Belegeinsicht

## 1 Termin

| Feld | Inhalt |
|---|---|
| Datum | 04.08.2026, 14:07 bis 15:31 Uhr |
| Ort | Verwaltungsbüro Prenzlauer Berg |
| Anwesend | Lukas Braun, Sandra Berger, zeitweise Maja Ullrich aus der Betriebskostenabteilung |
| Akte | F-2026-00427 |

## 2 Vorgelegte Unterlagen

Vorgelegt wurden die Dienstleistungsverträge, Jahresrechnungen und Zahlungsnachweise zu Hausmeister, Gartenpflege und Gebäudereinigung. Außerdem lagen die Belegliste, die Flächenaufstellung des Objekts und die Abrechnung des Mieters bereit.

Herr Braun fotografierte die drei Rechnungen, den Hausmeistervertrag, vier Gartenpflege-Einsatzberichte und die Quartalskontrollen der Gebäudereinigung. Die fehlenden Hausmeister-Tätigkeitsblätter für Februar und Oktober 2025 konnten nicht vorgelegt werden. Frau Ullrich sagte zu, beim Dienstleister nachzufragen.

## 3 Erklärungen des Mieters

Herr Braun hielt die Hausmeisterkosten weiterhin für hoch und fragte, ob in der Pauschale Reparaturen enthalten seien. Zur Gartenpflege beanstandete er den Sturmeinsatz. Bei der Gebäudereinigung verwies er auf eine im April aus seiner Sicht schlecht ausgeführte Kellerreinigung. Einen eigenen Kürzungsbetrag nannte er nicht.

## 4 Abschluss

Herr Braun nahm keine vorbereitete Erklärung zur Zahlung oder Anerkennung entgegen. Er kündigte eine E-Mail nach Durchsicht seiner Fotos an. Die offenen Hausmeisterblätter wurden am 04.08.2026 um 16:02 Uhr beim Dienstleister angefordert.
