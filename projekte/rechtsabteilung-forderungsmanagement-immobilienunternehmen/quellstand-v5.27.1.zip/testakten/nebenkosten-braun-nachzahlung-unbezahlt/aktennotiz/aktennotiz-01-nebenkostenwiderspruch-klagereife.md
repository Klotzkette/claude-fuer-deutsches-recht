# Aktennotiz Nr. 1

Wohnen Berlin Immobilien GmbH
Abteilung Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Geschäftszeichen:    F-2026-00427
Mietverhältnis:      MV-117903-BR, Greifswalder Straße 201, 10405 Berlin, 1. OG mitte
Mieter:              Lukas Braun
Verfasserin:         Sandra Berger, Renofa, Tel. 030 2055 4810
Datum:               22.07.2026
Betreff:             Bewertung Mieterwiderspruch Betriebskosten 2025 und Klagereife der Forderung

## 1. Anlass

Die Betriebskostenabrechnung 2025 wurde dem Mieter laut Dokumentenmanagementsystem am 30.06.2026 zugestellt. Die Nachzahlung beträgt 684,28 EUR. Der Mieter beanstandete am 20.07.2026 konkret die Kostenarten Hausmeister und Gartenpflege und verlangte am 21.07.2026 ergänzend Belegeinsicht auch zur Gebäudereinigung. Die Zahlung verweigert er vorläufig vollständig.

## 2. Sachstand

### 2.1 Formelle Prüfung der Abrechnung

Die Abrechnung (vgl. nebenkosten/betriebskostenabrechnung-2025.md) enthält:

- Abrechnungszeitraum: 01.01.2025 bis 31.12.2025 (vollständiges Kalenderjahr)
- Gesamtkosten je Position mit Umlageschlüssel (Wohnfläche bzw. Verbrauch)
- Anteil des Mieters und Gegenüberstellung mit den Vorauszahlungen

Die Abrechnungsfrist nach § 556 Absatz 3 Satz 2 BGB (12 Monate nach Ende des Abrechnungszeitraums, also bis 31.12.2026) ist eingehalten.

### 2.2 Mietereinwendungen

Der Mieter hat innerhalb der Frist des § 556 Absatz 3 Satz 5 BGB die Kostenarten Hausmeister, Gartenpflege und Gebäudereinigung benannt. Dass er noch keinen Gegenbetrag beziffert hat, macht den rechtzeitig erhobenen Einwand nicht automatisch unbeachtlich. Nach BGH VIII ZR 6/24 reicht allein der Vorwurf, es seien keine Vergleichsangebote eingeholt worden, für einen Verstoß gegen das Wirtschaftlichkeitsgebot nicht aus; zu prüfen sind jedoch objektive Marktgerechtigkeit, mögliche Mehrkosten und deren Ursächlichkeit. Die angeforderten Verträge, Rechnungen, Leistungsnachweise und Umlageunterlagen fehlen derzeit in der Prozessakte.

### 2.3 Verhältnis Betriebskosten-Nachzahlung und Mietrückstand

Die laufende Miete für 2026 ist vollständig bezahlt (vgl. konto/mietkonto-fbl5n.md). Es handelt sich ausschließlich um eine offene Betriebskosten-Nachzahlung. Diese begründet keinen Mietrückstand im Sinne des § 543 Absatz 2 Satz 1 Nummer 3 BGB.

## 3. Rechtliche Bewertung

Die Abrechnung ist nach Aktenlage formell ordnungsgemäß. Ob und in welcher Höhe der Zahlungsanspruch nach § 535 Absatz 2 und § 556 BGB materiell durchsetzbar ist, bleibt für die beanstandeten Positionen offen. Vor Klagefreigabe müssen Umlagefähigkeit, Rechnung, Leistungsumfang, Verteilerschlüssel und Wirtschaftlichkeit geprüft werden.

Dem Mieter ist zeitnah eine zumutbare Belegeinsicht anzubieten. § 556 Abs. 4 Satz 2 BGB erlaubt die elektronische Bereitstellung. Die ältere Entscheidung BGH VIII ZR 66/20 trägt deshalb keinen allgemeinen Papierzwang mehr. Vollständigkeit, Lesbarkeit und Zuordnung zur Abrechnung müssen auch digital gewährleistet sein. Das Einsichtsrecht umfasst nach BGH VIII ZR 118/19 auch Zahlungsbelege. Solange und soweit die berechtigt verlangte Einsicht nicht ermöglicht ist, ist der Mieter nach BGH VIII ZR 189/17 zur Nachzahlung vorläufig nicht verpflichtet. Anspruchsbestand und derzeitige Durchsetzbarkeit sind deshalb zu trennen; die Einreichungsampel bleibt rot.

## 4. Nächste Schritte

1. Vollständige Rechnungs- und Zahlungsbelege nach § 556 Abs. 4 BGB lesbar bereitstellen; elektronischen Zugang oder einen geeigneten Einsichtstermin dokumentieren.
2. Hausmeister-, Gartenpflege- und Reinigungsverträge, Rechnungen, Zahlungsnachweise, Leistungsnachweise, Umlageschlüssel und Vergleichsdaten von der Hausverwaltung anfordern.
3. Nach tatsächlicher Einsicht und angemessener Reaktionszeit Einwendungsmatrix und Forderung neu berechnen; nur belegte und umlagefähige Positionen in den Klageentwurf übernehmen.

## 5. Eskalation / Vorlage

Zuständig wäre das Amtsgericht Pankow nach § 23 Nummer 2a GVG und § 29a ZPO. Eine Klagefreigabe erfolgt erst nach Belegeinsicht und materieller Positionsprüfung.

(gez.) Sandra Berger
Renofa, Forderungsmanagement
