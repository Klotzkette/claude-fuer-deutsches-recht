# Wohnraummietvertrag

**Vertragsnummer:** WBI-MV-2022-00943
**Objekt:** Greifswalder Straße 201, 10405 Berlin, 1. OG Mitte
**Ablage:** SAP RE-FX / DMS Vertragsakte

**Parteien**

**Vermieterin**
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin

**Mieter**
Herr Lukas Braun, geboren am 18.06.1993
Greifswalder Straße 201
10405 Berlin

## 1 Mietsache

### 1.1

Vermietet wird die Wohnung Greifswalder Straße 201, 10405 Berlin, 1. OG Mitte, bestehend aus zwei Zimmern, Küche, Bad, Flur und Kellerraum Nr. 201-M1.

### 1.2

Die Wohnfläche beträgt **52,10 qm**.

## 2 Mietzeit

Das Mietverhältnis beginnt am **01.02.2022** und läuft auf unbestimmte Zeit.

## 3 Miete

| Position | Betrag |
|---|---:|
| Nettokaltmiete | 640,00 EUR |
| Betriebskostenvorauszahlung | 170,00 EUR |
| Heizkostenvorauszahlung | 100,00 EUR |
| **Bruttowarmmiete** | **910,00 EUR** |

Die Miete ist monatlich im Voraus spätestens am dritten Werktag zu zahlen.

## 4 Betriebs- und Heizkosten

### 4.1

Der Mieter trägt die Betriebskosten gemäß Betriebskostenkatalog Anlage 2. Umgelegt werden nur Kostenarten, die vertraglich vereinbart und nach den gesetzlichen Vorschriften umlagefähig sind. Hierzu gehören insbesondere Grundsteuer, Wasser und Entwässerung, Heizung und Warmwasser, Müllabfuhr, Gebäudereinigung, Gartenpflege, Beleuchtung, Versicherungen und Hauswartkosten.

### 4.2

Soweit kein verbrauchsabhängiger Maßstab vorgeschrieben oder vereinbart ist, erfolgt die Verteilung nach dem Verhältnis der Wohnfläche zur maßgeblichen Gesamtfläche. Wasser und Heizkosten werden nach den erfassten Verbrauchswerten und den jeweils geltenden Grundkostenanteilen verteilt. Warmwasser wird durch den elektrischen Durchlauferhitzer der Wohnung bereitet; dessen Stromkosten trägt der Mieter über seinen eigenen Stromvertrag. Zentrale Warmwasserkosten werden nicht erhoben. Die Abrechnung weist Gesamtkosten, Verteilerschlüssel, Berechnung des Wohnungsanteils, Vorauszahlungen und Ergebnis nachvollziehbar aus.

### 4.3

Die Vorauszahlungen für 2025 betragen monatlich **270,00 EUR** und damit jährlich **3240,00 EUR**.

### 4.4

Über die Vorauszahlungen wird kalenderjährlich abgerechnet. Vorauszahlungen können nach einer Abrechnung durch Erklärung in Textform auf eine angemessene Höhe angepasst werden. Die gesetzlichen Abrechnungs- und Einwendungsfristen bleiben unberührt.

## 5 Belegeinsicht

### 5.1

Der Mieter kann nach Zugang der Betriebskostenabrechnung Einsicht in die der Abrechnung zugrunde liegenden Belege verlangen. Hierzu gehören die für die Prüfung erforderlichen Rechnungen, Verträge, Leistungsnachweise, Zahlungsbelege und Unterlagen zum Verteilerschlüssel, soweit sie für die konkrete Abrechnung Bedeutung haben.

### 5.2

Ort, Termin und eine etwaige elektronische Bereitstellung werden nach Zugang des hinreichend bestimmten Verlangens abgestimmt. Personenbezogene Daten Dritter dürfen dabei geschwärzt werden, soweit sie für die Abrechnungsprüfung nicht erforderlich sind. Gesetzliche Rechte und Einwendungen werden durch diese Verfahrensabrede nicht verkürzt.

## 6 Mietsicherheit

Die Kaution beträgt **1920,00 EUR** und entspricht drei Nettokaltmieten. Der Mieter kann eine Geldsicherheit in drei gleichen monatlichen Raten leisten; die erste Rate ist zu Mietbeginn, die weiteren Raten sind mit den beiden folgenden Mietzahlungen fällig. Die Vermieterin legt die Kaution getrennt von ihrem Vermögen an. Über geleistete Raten und die Anlage wird gesondert Nachweis erteilt.

## 7 Gebrauch, Erhaltung und Mängelanzeige

### 7.1

Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Eine Gebrauchsüberlassung an Dritte richtet sich nach den gesetzlichen Vorschriften. Gewerbliche Außenwerbung und Eingriffe in Fassade, Leitungen oder Gebäudetechnik bedürfen der vorherigen Zustimmung.

### 7.2

Die Vermieterin erhält die Mietsache im vertragsgemäßen Zustand. Mängel, Schäden und Gefahren sind unverzüglich mit einer möglichst genauen Beschreibung zu melden. Zur Prüfung angezeigter Mängel und zur Durchführung erforderlicher Arbeiten ist nach angemessener Terminabstimmung Zutritt zu gewähren.

### 7.3

Die Räume sind angemessen zu beheizen und zu lüften. Starre Zeit- oder Intervallvorgaben werden nicht vereinbart. Die gesetzlichen Rechte bei Mängeln bleiben unberührt.

## 8 Hausordnung und Gemeinschaftsflächen

### 8.1

Die Hausordnung regelt die Nutzung von Treppenhaus, Hof, Fahrradabstellflächen, Müllplätzen und sonstigen Gemeinschaftsanlagen. Gegenstände dürfen Flucht- und Rettungswege nicht verstellen.

### 8.2

Der zum Mietobjekt gehörende Kellerraum wird ohne Zusicherung einer besonderen Trockenheit für übliche Lagerzwecke überlassen. Wasserempfindliche oder gefährliche Stoffe dürfen dort nicht gelagert werden.

## 9 Übergabe, Schlüssel und Zähler

### 9.1

Der Zustand bei Mietbeginn, die Zahl der übergebenen Schlüssel und die Zählerstände ergeben sich aus dem Übergabeprotokoll vom 28.01.2022. Das Protokoll dokumentiert Wahrnehmungen bei Übergabe; weitergehende Ansprüche werden dadurch weder anerkannt noch ausgeschlossen.

### 9.2

Zusätzliche Schlüssel dürfen nur auf eigene Kosten und unter Beachtung der Schließanlage angefertigt werden. Bei Vertragsende sind alle Originale und zulässig angefertigten Schlüssel zurückzugeben.

## 10 Kommunikation und Vertragsänderungen

### 10.1

Der Mieter teilt Änderungen seiner Zustellanschrift sowie der für laufende Mitteilungen genutzten Kontaktdaten zeitnah mit. Gesetzlich vorgeschriebene Formen bleiben maßgeblich.

### 10.2

Nebenabreden bestehen nicht. Änderungen der Miethöhe, Vorauszahlungen oder sonstiger Vertragsbedingungen werden in einer eindeutig bezeichneten Erklärung oder einem Nachtrag dokumentiert.

## 11 Anlagen

1. Wohnflächenberechnung mit Gesamtflächenblatt des Objekts
2. Betriebskostenkatalog
3. Übergabeprotokoll vom 28.01.2022 mit Schlüssel- und Zählerliste
4. Hausordnung
5. Energieausweis zur Einsichtnahme

**Unterschriften**

Berlin, den 19.01.2022

| Vermieterin | Mieter |
|---|---|
| Wohnen Berlin Immobilien GmbH, Dr. Markus Lehmann | Lukas Braun |
