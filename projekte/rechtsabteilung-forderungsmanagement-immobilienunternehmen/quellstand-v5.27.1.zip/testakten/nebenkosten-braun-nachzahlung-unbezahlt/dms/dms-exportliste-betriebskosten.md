# DocuWeb Exportliste Betriebskosten Braun

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportzeitpunkt | 13.08.2026, 07:52 Uhr |
| Akte | F-2026-00427 |
| Vertragsnummer | WBI-MV-2022-00943 |
| Abrechnungsjahr | 2025 |
| Treffer | 24 |

## 2 Dokumentenbestand

| DMS-ID | Datum | Klasse | Indexname | Version | Hinweis |
|---|---|---|---|---:|---|
| DW-741001 | 12.01.2022 | Vertrag | Mietvertrag_Braun.pdf | 1 | vollständig |
| DW-889700 | 15.02.2025 | Rechnung | Grundsteuer_2025.pdf | 1 | Jahresbescheid |
| DW-891004 | 18.03.2025 | Rechnung | Versicherung_2025.pdf | 1 | Objektpolice |
| DW-896551 | 31.12.2025 | Rechnung | Hausmeister_2025.pdf | 1 | 21.600,00 EUR |
| DW-896552 | 31.12.2025 | Rechnung | Gartenpflege_2025.pdf | 1 | 9.400,00 EUR |
| DW-896553 | 31.12.2025 | Rechnung | Reinigung_2025.pdf | 1 | 12.200,00 EUR |
| DW-896554 | 31.12.2025 | Zahlungsbeleg | Sammellauf_2025_12.pdf | 1 | drei Rechnungen |
| DW-897104 | 18.01.2026 | Rechnung | Wasser_Abwasser_2025.pdf | 1 | Objektgesamtbetrag 28.700,00 EUR |
| DW-900300 | 22.03.2026 | Abrechnung | Heizkosten_Einzel_Braun.pdf | 2 | 1.961,54 EUR; Gerätewechsel verarbeitet |
| DW-900301 | 20.02.2026 | Abrechnung | Heizkosten_Gesamtobjekt.pdf | 2 | Korrektur nach Zählerwechsel |
| DW-900410 | 22.03.2026 | Rechnung | Heizkosten_Gesamtabrechnung_2025.pdf | 1 | Kostenblöcke und Schlüssel ausgewiesen |
| DW-900455 | 24.03.2026 | Abrechnung | Wasser_Verteilungsblatt_Braun.xlsx | 1 | Zähler- und Flächenanteile 502,40 EUR |
| DW-903881 | 28.06.2026 | Abrechnung | BKA_2025_Braun.pdf | 3 | versandte Fassung |
| DW-903882 | 28.06.2026 | Abrechnung | BKA_2025_Braun_alt.pdf | 2 | nicht versandt |
| DW-904112 | 30.06.2026 | Zustellung | Versandprotokoll_BKA.pdf | 1 | Portallog plus Brief |
| DW-905778 | 15.07.2026 | Ausgang | Zahlungsaufforderung_Braun.pdf | 1 | versandt |
| DW-906210 | 20.07.2026 | Eingang | Widerspruch_Braun.pdf | 1 | zwei Kostenarten |
| DW-906255 | 21.07.2026 | Eingang | Nachtrag_Belegeinsicht.pdf | 1 | Reinigung ergänzt |
| DW-906770 | 24.07.2026 | Ausgang | Einladung_Belegeinsicht.pdf | 1 | Termin 04.08.2026 |
| DW-907404 | 04.08.2026 | Notiz | Protokoll_Belegeinsicht.docx | 2 | Mieter anwesend |
| DW-907512 | 06.08.2026 | Eingang | Mail_nach_Einsicht.pdf | 1 | Widerspruch aufrechterhalten |
| DW-907913 | 11.08.2026 | Tabelle | Belegmatrix_Braun.xlsx | 4 | drei Positionen gelb |
| DW-908004 | 12.08.2026 | Entwurf | Klage_Braun.docx | 3 | noch nicht freigegeben |
| DW-908005 | 12.08.2026 | Sonstiges | BKA-neu-neu.pdf | 1 | Kopie der versandten Fassung |

## 3 Versionshinweis

Die versandte Abrechnung ist Version 3. Version 2 enthält noch eine Vorauszahlungssumme von 3.180,00 EUR und darf nicht verwendet werden. Die Datei BKA-neu-neu.pdf ist nach Prüfsumme eine Kopie der Version 3.

Die beiden Gesamtrechnungen belegen Kosten auf Objektebene. Sie ersetzen
weder die Prüfung des vereinbarten Umlageschlüssels noch die
wohnungsbezogene Heizkostenverteilung oder den Nachweis der tatsächlichen
Zahlung.
