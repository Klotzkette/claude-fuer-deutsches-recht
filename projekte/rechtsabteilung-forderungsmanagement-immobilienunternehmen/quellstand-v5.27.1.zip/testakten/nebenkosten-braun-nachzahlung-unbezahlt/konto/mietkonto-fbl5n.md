# Mietkonto FBL5N

**Debitor:** D-664201
**Vertrag:** WBI-MV-2022-00943
**Zeitraum:** 01.01.2026 bis 22.07.2026
**Export:** FI-CA Einzelpostenliste, 22.07.2026, 09:10 Uhr

## Buchungsjournal

| Buchungsdatum | Beleg | Periode | Soll | Ist | Buchungstext | Saldo |
|---|---|---|---:|---:|---|---:|
| 05.01.2026 | 73001031 | 01 2026 | 910,00 | 910,00 | Miete Januar bezahlt | 0,00 |
| 04.02.2026 | 73002144 | 02 2026 | 910,00 | 910,00 | Miete Februar bezahlt | 0,00 |
| 04.03.2026 | 73003218 | 03 2026 | 910,00 | 910,00 | Miete März bezahlt | 0,00 |
| 02.04.2026 | 73004305 | 04 2026 | 910,00 | 910,00 | Miete April bezahlt | 0,00 |
| 05.05.2026 | 73005477 | 05 2026 | 910,00 | 910,00 | Miete Mai bezahlt | 0,00 |
| 03.06.2026 | 73006560 | 06 2026 | 910,00 | 910,00 | Miete Juni bezahlt | 0,00 |
| 30.06.2026 | 79002525 | BK 2025 | 684,28 | 0,00 | Nachzahlung Betriebskosten 2025 | 684,28 |
| 03.07.2026 | 73007612 | 07 2026 | 910,00 | 910,00 | Miete Juli bezahlt | 684,28 |

## OP-Status

| Prüffeld | Ergebnis |
|---|---|
| Offene Hauptforderung | 684,28 EUR |
| Forderungsart | Betriebskosten-Nachzahlung 2025 |
| Laufende Mieten | Ausgeglichen |
| Teilzahlungen | Keine |
| Einwendungen | Pauschaler Widerspruch vom 18.07.2026 |
| Verrechnung | Keine offene Gegenforderung im Konto |

## Plausibilität

Nur die Betriebskosten-Nachzahlung ist offen. Die laufenden Mietzahlungen sind stabil, deshalb ist die Akte als reine Nachzahlungsklage mit besonderem Fokus auf Abrechnung, Belegeinsicht und Zugang zu führen. Eine Kündigungsprüfung ist hier nicht angezeigt.
