# Nachtrag des Mieters zum Betriebskostenwiderspruch

Von: lukas.braun@example.invalid

An: forderungsmanagement@wohnen-berlin-immobilien.de

Datum: 21.07.2026, 19:54 Uhr

Betreff: Betriebskosten 2025 - Belege

Hallo,

ich bleibe bei meinem Widerspruch. Ich verstehe vor allem Hausmeister, Gartenpflege und Reinigung nicht. Bei uns war nicht zu sehen, dass das alles so oft gemacht wurde.

Ich will Belege sehen, aber bitte nicht nur eine Tabelle. Wenn es Termine gibt, schicken Sie mir diese bitte auch. Die laufende Miete zahle ich weiter, die Nachzahlung erst einmal nicht.

Viele Grüße

Stefan Braun

---

Interner DMS-Vermerk:

Belegeinsicht noch nicht terminiert. Die Abrechnung selbst liegt doppelt vor: einmal als PDF aus SAP, einmal als Scan aus dem Mieterportal. Inhalt gleich, Scan schief eingezogen.
