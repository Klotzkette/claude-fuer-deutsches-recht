# Arbeitsentwurf Betriebskosten-Nachzahlung - noch nicht einreichen

An das
**Amtsgericht Pankow**
Kissingenstraße 5-6
13189 Berlin

Berlin, 12.08.2026

## Klage

der **Wohnen Berlin Immobilien GmbH**, Friedrichstraße 99, 10117 Berlin, vertreten durch den Geschäftsführer Dr. Markus Lehmann

- Klägerin -

gegen

**Herrn Lukas Braun**, Greifswalder Straße 201, 10405 Berlin

- Beklagter -

wegen Betriebskosten-Nachzahlung

**Streitwert: 684,28 EUR**

## Antrag

Der Beklagte wird verurteilt, an die Klägerin **684,28 EUR** nebst Zinsen in Höhe von fünf Prozentpunkten über dem Basiszinssatz seit dem 30.07.2026 zu zahlen.

## Sachverhalt

Die Parteien sind durch Wohnraummietvertrag vom 19.01.2022 verbunden. Nach § 4 des Mietvertrags trägt der Beklagte die umlagefähigen Betriebs- und Heizkosten. Für das Abrechnungsjahr 2025 zahlte der Beklagte Vorauszahlungen in Höhe von insgesamt 3240,00 EUR.

Die Klägerin rechnete mit Betriebskostenabrechnung vom 28.06.2026 über das Jahr 2025 ab. Die Abrechnung ging dem Beklagten am 30.06.2026 zu und weist eine Nachzahlung von **684,28 EUR** aus.

Der Beklagte beanstandete mit E-Mail vom 20.07.2026 die Hausmeister- und Gartenpflegekosten. Mit Nachtrag vom 21.07.2026 verlangte er Belegeinsicht auch zur Gebäudereinigung. Eine Zahlung leistete er nicht. Vor Einreichung sind Belegeinsicht, materielle Prüfung und Neuberechnung abzuschließen.

## Streitpunkte und Beweis

| Einwand | Antwortlinie | Beweis |
|---|---|---|
| Hausmeister zu teuer | Umlagefähigkeit, Leistungsanteile, Vertrag, Rechnung und Marktgerechtigkeit prüfen | Hausmeistervertrag, Jahresrechnung, Leistungsnachweise |
| Gartenpflege zu teuer | Pflegevertrag, Rechnung, Objektverteilung und Marktgerechtigkeit prüfen | Gartenpflegevertrag, Rechnung, Vergleichsdaten |
| Belegeinsicht verlangt | Rechnungs- und Zahlungsbelege vollständig lesbar bereitstellen, auch elektronisch; bis zur Gewährung temporäres Leistungsverweigerungsrecht prüfen | Zugangsnachweis oder Einsichtsprotokoll; § 556 Abs. 4 BGB, BGH VIII ZR 189/17 und VIII ZR 118/19 |
| vollständige Nichtzahlung | Anspruchsbestand, derzeitige Durchsetzbarkeit und Reichweite des Einsichtsverlangens trennen; keinen Teilbetrag pauschal als unstreitig behandeln | Mietvertrag, Abrechnung, Mietkonto, Einsichtsverlangen |

## Anlagen

| Anlage | Inhalt |
|---|---|
| K1 | Mietvertrag vom 19.01.2022 |
| K2 | Betriebskostenabrechnung 2025 |
| K3 | Zustellnachweis Abrechnung 30.06.2026 |
| K4 | Zahlungsaufforderung vom 15.07.2026 |
| K5 | Widerspruch des Beklagten vom 20.07.2026 |
| K6 | Nachtrag mit Belegeinsichtsverlangen vom 21.07.2026 |
| K7 | Belegliste sowie Rechnungs- und Zahlungsbelege Hausmeister/Gartenpflege/Gebäudereinigung |

## Einreichungssperre

Dieser Arbeitsentwurf darf erst freigegeben werden, wenn die berechtigt verlangte Einsicht in Rechnungs- und Zahlungsbelege tatsächlich ermöglicht, das Einsichtsprotokoll ausgewertet, eine angemessene Reaktionszeit eingeräumt und die beanstandeten Positionen anhand von Vertrag, Rechnung, Zahlung, Leistung, Umlageschlüssel und Wirtschaftlichkeit bestätigt oder aus dem Antrag herausgerechnet worden sind. Bis dahin besteht nach BGH VIII ZR 189/17 und VIII ZR 118/19 ein temporäres Leistungsverweigerungsrisiko; BGH VIII ZR 6/24 trägt keine pauschale Zurückweisung des Einwands.

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH
