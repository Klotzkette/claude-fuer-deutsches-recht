# Zahlungsaufforderung Betriebskostenabrechnung 2025

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99
10117 Berlin
Abteilung Forderungsmanagement Betriebskosten
Bearbeitung: Sandra Berger, Rechtsfachwirtin

Herrn
Lukas Braun
Greifswalder Straße 201
10405 Berlin

Berlin, 15.07.2026

**Mietverhältnis Greifswalder Straße 201, 10405 Berlin, 1. OG Mitte**
**Vertragsnummer WBI-MV-2022-00943**
**Betriebskostenabrechnung 2025 / Nachzahlung 684,28 EUR**

Sehr geehrter Herr Braun,

Ihnen wurde die Betriebskostenabrechnung 2025 am 30.06.2026 übersandt. Die Abrechnung weist folgende Nachzahlung aus:

| Position | Betrag |
|---|---:|
| Kostenanteil laut Abrechnung | 3924,28 EUR |
| Vorauszahlungen 2025 | 3240,00 EUR |
| **Nachzahlung** | **684,28 EUR** |

Die Nachzahlung ist offen. Bitte zahlen Sie den Betrag bis spätestens **29.07.2026** auf das bekannte Mietkonto mit dem Verwendungszweck **WBI-MV-2022-00943 BK 2025 Braun**.

Wenn Sie Belege einsehen möchten, nennen Sie bitte zwei Terminvorschläge. Wir stellen die Belege in der Hausverwaltung Friedrichstraße 99 oder digital über das Mieterportal bereit.

Ein pauschaler Widerspruch entbindet nicht davon, unstreitige Beträge zu prüfen und zu zahlen. Bitte teilen Sie daher konkret mit, welche Position Sie aus welchem Grund beanstanden.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH
