# Einladung zur Belegeinsicht

Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

Herrn

Lukas Braun

Greifswalder Straße 201

10405 Berlin

Berlin, 24.07.2026

## 1 Betriebskostenabrechnung 2025

Sehr geehrter Herr Braun,

wir bestätigen den Eingang Ihrer Schreiben vom 20.07.2026 und 21.07.2026. Sie können die der Betriebskostenabrechnung 2025 zugrunde liegenden Unterlagen am 04.08.2026 zwischen 14 und 16 Uhr in unserem Verwaltungsbüro Prenzlauer Berg, Greifswalder Straße 197, 10405 Berlin, einsehen.

Bereitgestellt werden insbesondere die Verträge, Rechnungen, Zahlungsbelege und vorhandenen Leistungsnachweise zu Hausmeister, Gartenpflege und Gebäudereinigung sowie die Abrechnungs- und Umlageunterlagen. Bitte melden Sie sich am Empfang unter dem Aktenzeichen F-2026-00427 an.

Sollte der Termin nicht passen, teilen Sie uns bis zum 29.07.2026 zwei Ausweichtermine mit. Fotografien der vorgelegten Unterlagen können Sie für Ihren persönlichen Gebrauch anfertigen, soweit keine Daten anderer Mieter sichtbar sind.

Mit freundlichen Grüßen

Wohnen Berlin Immobilien GmbH

Sandra Berger

Rechtsfachwirtin, Forderungsmanagement
