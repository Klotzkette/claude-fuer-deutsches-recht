# E-Mail-Ausdruck nach Belegeinsicht

## 1 Kopfzeilen

| Feld | Inhalt |
|---|---|
| Von | Lukas Braun, l.braun93@mailbox-beispiel.de |
| An | s.berger@wohnen-berlin-immo.de |
| Datum | 06.08.2026, 20:49 Uhr |
| Betreff | Belegeinsicht 04.08. / Abrechnung 2025 |

## 2 Nachricht

Sehr geehrte Frau Berger,

vielen Dank für den Termin. Ich halte meinen Widerspruch aufrecht. Bei den Hausmeisterkosten fehlen zwei Monatsnachweise. Außerdem verstehe ich nicht, warum der Sturmschaden als Gartenpflege abgerechnet wird. Die Kellerreinigung war im April nachweislich schlecht, auch wenn später nachgereinigt wurde.

Bitte senden Sie mir die beiden fehlenden Hausmeisterblätter und teilen Sie mir mit, welcher Anteil der Gartenrechnung auf den Sturmeinsatz entfällt. Bis das geklärt ist, zahle ich die Nachforderung nicht. Die laufende Miete überweise ich weiter wie bisher.

Mit freundlichen Grüßen

Lukas Braun

## 3 Anlagen

Angehängt waren sieben Mobiltelefonfotos aus der Belegeinsicht. Zwei Fotos zeigen dieselbe Rechnungsseite; auf einem Foto ist am Rand ein fremder Mietername aus einer darunterliegenden Ablage angeschnitten und wurde im DMS geschwärzt.
