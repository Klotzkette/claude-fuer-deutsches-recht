# E-Mail-Ausdruck

Von: objektservice@nordlicht-service.example

An: betriebskosten@wohnen-berlin.example

Datum: 07.08.2026, 11:38 Uhr

Betreff: HN-2025-12088 / Greifswalder Straße 201 / fehlende Monatsblätter

Sehr geehrte Frau Ullrich,

zu Ihrer Anfrage vom 04.08.2026 haben wir das Papierarchiv und den Einsatzkalender geprüft. Das unterschriebene Tätigkeitsblatt für Februar 2025 liegt derzeit nicht vor. Herr Evers war vom 10. bis 21. Februar krank; die Vertretung ist im Dienstplan mit Frau Albrecht eingetragen. Der Dienstplan belegt die Einteilung, nicht die Ausführung jedes einzelnen Kontrollgangs. Eine nachträgliche Bescheinigung als Original-Leistungsnachweis können wir deshalb nicht ausstellen.

Das Oktoberblatt befindet sich nach Auskunft der Objektleitung in einem noch nicht digitalisierten Sammelordner. Wir haben die Suche bis zum 12.08.2026 vorgemerkt und melden uns auch dann, wenn das Blatt nicht gefunden wird. Bitte behandeln Sie diese E-Mail noch nicht als Nachlieferung dieses Belegs.

Die Position Kleinmaterial bezeichnet Müllsäcke, Einweghandschuhe, Reinigungsbürsten und Leuchtmittel für Gemeinschaftsflächen. Ersatzteile für Türschließer und Arbeiten an defekten Schlössern wurden gesondert berechnet. Eine Einzelaufschlüsselung des Pauschalbetrags von 600,00 EUR wurde der Jahresrechnung nicht beigefügt. Wir stellen die vorhandenen Materialentnahmen zusammen; eine vollständige Zuordnung zu diesem Objekt ist noch zu prüfen.

Mit freundlichen Grüßen

Frank Neumann

Objektleitung / Hausservice Nordlicht GmbH
