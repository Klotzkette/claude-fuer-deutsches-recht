# Widerspruch des Mieters vom 20.07.2026

**Von:** Lukas Braun <lukas.braun@example.invalid>
**An:** Betriebskosten Wohnen Berlin <betriebskosten@wohnen-berlin-immo.de>
**Betreff:** Betriebskostenabrechnung 2025
**Eingang:** 20.07.2026, 19:11 Uhr

Sehr geehrte Damen und Herren,

ich widerspreche der Betriebskostenabrechnung 2025. Hausmeister und Gartenpflege sind viel zu teuer. Ich zahle deshalb gar nichts.

Belege brauche ich erst einmal nicht. Sie sollen mir eine bessere Abrechnung schicken. Ich sehe nicht ein, dass ich diese Kosten tragen soll.

Mit freundlichen Grüßen
Lukas Braun

## Interner Eingangsstempel

Eingegangen am 20.07.2026 um 19:11 Uhr über das Betriebskostenpostfach. Im DMS unter der Vertragsnummer WBI-MV-2022-00943 abgelegt. Die Nachricht benennt Hausmeister und Gartenpflege, enthält aber weder einen bezifferten Kürzungsbetrag noch ein Belegeinsichtsverlangen. Fachliche Weiterleitung an Maja Ullrich am 21.07.2026 um 08:07 Uhr.
