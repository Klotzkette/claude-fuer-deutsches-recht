# Testakte 6 — Nebenkosten Nachzahlung Braun Prenzlauer Berg


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 85 KB) | PDF | [testakte-nebenkosten-braun-nachzahlung-unbezahlt-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-nebenkosten-braun-nachzahlung-unbezahlt-gesamt.pdf) | [`gesamt-pdf/nebenkosten-braun-nachzahlung-unbezahlt_gesamt.pdf`](gesamt-pdf/nebenkosten-braun-nachzahlung-unbezahlt_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-nebenkosten-braun-nachzahlung-unbezahlt.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-nebenkosten-braun-nachzahlung-unbezahlt.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-nebenkosten-braun-nachzahlung-unbezahlt-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-nebenkosten-braun-nachzahlung-unbezahlt-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Betriebskostenabrechnung, konkretisierter Widerspruch, Belegeinsicht, temporäres Leistungsverweigerungsrecht und spätere Zahlungsklage |
| Startskills | `04-belegmatrix-aufbauen`, `35-sap-belegluecken-klaeren`, `44-betriebskosten-rueckstand-streit`, danach `20-zahlungsklage-mietrueckstand-erstellen` |
| Kernentscheidung | Ist die Betriebskosten-Nachzahlung formell, materiell und rechnerisch klagereif, obwohl die laufende Miete bezahlt wird? |
| Besonderheit | Wasser- und Heizkosten-Gesamtbelege tragen nur die Objektebene. Umlageschlüssel, Wohnungsanteil, Vorauszahlungen, Zahlung und Belegeinsicht müssen getrennt bis zur Nachforderung durchgerechnet werden. |

Die laufende Miete wird vollständig gezahlt. Offen ist allein die Nachzahlung aus der Betriebskostenabrechnung 2025. Der Mieter bestreitet einzelne Positionen und verlangt mit Nachtrag vom 21.07.2026 Einsicht in Rechnungen und Zahlungsbelege. Vor Gewährung und Auswertung der berechtigten Einsicht wird kein angeblich unstreitiger Teilbetrag unterstellt.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Bearbeiterin | Rechtsfachwirtin Sandra Berger |
| Mieter | Lukas Braun, geb. 18.06.1993 |
| Mietobjekt | Greifswalder Straße 201, 10405 Berlin, 1. OG mitte |
| Wohnfläche | 52,10 qm |
| Vertragsbeginn | 01.02.2022 |
| Bruttowarmmiete | 910,00 EUR |
| Nachzahlung Betriebskosten 2025 | 684,28 EUR |
| Aktenzeichen intern | F-2026-00427 |

## Sachverhalt

Die Betriebskostenabrechnung 2025 weist eine Nachzahlung von 684,28 EUR aus. Die laufenden Mieten für 2026 sind bezahlt. Der Mieter beanstandet am 20.07.2026 Hausmeister und Gartenpflege und verlangt am Folgetag ergänzend Belegeinsicht auch zur Gebäudereinigung. Die Nachzahlung zahlt er vorläufig nicht.

## Trainingsziel

Diese Akte testet, dass Betriebskostenforderungen nicht mit Mietrückstandskündigung verwechselt werden. Schwerpunkt sind Abrechnungsfrist, Einwendungsfrist, formelle Wirksamkeit, Rechnungs- und Zahlungsbelege, temporäres Leistungsverweigerungsrecht und die erst danach zu bewertende Zahlungsklage.

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Mietvertrag | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Mietkonto | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Betriebskostenabrechnung | [nebenkosten/betriebskostenabrechnung-2025.md](nebenkosten/betriebskostenabrechnung-2025.md) |
| Zahlungsaufforderung | [korrespondenz/zahlungsaufforderung-nebenkosten.md](korrespondenz/zahlungsaufforderung-nebenkosten.md) |
| Widerspruch Mieter | [korrespondenz/mieter-widerspruch.md](korrespondenz/mieter-widerspruch.md) |
| Nachtrag Belegeinsicht | [korrespondenz/mieter-widerspruch-nachtrag-belegeinsicht.md](korrespondenz/mieter-widerspruch-nachtrag-belegeinsicht.md) |
| Aktennotiz zu Widerspruch und Klagereife | [aktennotiz/aktennotiz-01-nebenkostenwiderspruch-klagereife.md](aktennotiz/aktennotiz-01-nebenkostenwiderspruch-klagereife.md) |
| Klageentwurf | [korrespondenz/klage-entwurf.md](korrespondenz/klage-entwurf.md) |
| DocuWeb-Exportliste mit Abrechnungsversionen | [dms/dms-exportliste-betriebskosten.md](dms/dms-exportliste-betriebskosten.md) |
| Belegliste zur Abrechnung 2025 | [nebenkosten/belegliste-abrechnung-2025.md](nebenkosten/belegliste-abrechnung-2025.md) |
| Hausmeisterrechnung 2025 | [nebenkosten/rechnung-hausmeister-2025.md](nebenkosten/rechnung-hausmeister-2025.md) |
| Gartenpflegerechnung 2025 | [nebenkosten/rechnung-gartenpflege-2025.md](nebenkosten/rechnung-gartenpflege-2025.md) |
| Gebäudereinigungsrechnung 2025 | [nebenkosten/rechnung-gebaeudereinigung-2025.md](nebenkosten/rechnung-gebaeudereinigung-2025.md) |
| Zahlungsbeleg des Kreditoren-Sammellaufs | [nebenkosten/zahlungsbeleg-sammellauf-2025.md](nebenkosten/zahlungsbeleg-sammellauf-2025.md) |
| Einladung zur Belegeinsicht | [korrespondenz/einladung-belegeinsicht-2026-07-24.md](korrespondenz/einladung-belegeinsicht-2026-07-24.md) |
| Aktennotiz zum durchgeführten Einsichtstermin | [aktennotiz/aktennotiz-02-belegeinsicht-2026-08-04.md](aktennotiz/aktennotiz-02-belegeinsicht-2026-08-04.md) |
| E-Mail des Mieters nach Belegeinsicht | [korrespondenz/email-mieter-nach-belegeinsicht.md](korrespondenz/email-mieter-nach-belegeinsicht.md) |
| Jahresrechnung Wasser und Abwasser | [nebenkosten/rechnung-wasser-abwasser-2025.md](nebenkosten/rechnung-wasser-abwasser-2025.md) |
| Wohnungsbezogenes Verteilungsblatt Wasser und Abwasser | [nebenkosten/berechnungsbogen-wasser-wohnung-braun-2025.md](nebenkosten/berechnungsbogen-wasser-wohnung-braun-2025.md) |
| Heizkosten-Gesamtabrechnung mit Gerätewechsel | [nebenkosten/heizkosten-gesamtabrechnung-2025.md](nebenkosten/heizkosten-gesamtabrechnung-2025.md) |
| Antwort des Hausservice zu fehlenden Monatsblättern und Material | [korrespondenz/email-hausservice-leistungsnachweise-2026-08-07.md](korrespondenz/email-hausservice-leistungsnachweise-2026-08-07.md) |

## Aufgabe für die Skills

Die nachgerechneten Heizkosten betragen 1.961,54 EUR; zusammen mit 1.962,74 EUR kalten Kosten und 3.240,00 EUR Vorauszahlungen ergibt sich rechnerisch eine Nachforderung von 684,28 EUR. Das ist noch keine Einreichungsfreigabe. Die [Dienstleisterantwort vom 07.08.2026](korrespondenz/email-hausservice-leistungsnachweise-2026-08-07.md) lässt Leistungs- und Materialnachweise offen. Erwartet sind eine genaue Nachforderung dieser Belege und eine davon getrennte Bewertung der aktuellen Durchsetzbarkeit. Elektronische Bereitstellung ist nach § 556 Abs. 4 BGB zulässig; unvollständige Belege werden durch einen Portalzugang nicht vollständig.

1. Laufende Miete und Betriebskosten-Nachzahlung getrennt auswerten.
2. Abrechnung auf formelle Mindestangaben, Fristen und Nachforderungshöhe prüfen.
3. Pauschale Einwendungen in klärbare Belegfragen und unerhebliche Einwände trennen.
4. Klagereife erst nach tatsächlicher Einsichtsmöglichkeit, Auswertung und angemessener Reaktionszeit neu bewerten; dann gegebenenfalls Zahlungsklage mit Anlagenmatrix vorbereiten.
