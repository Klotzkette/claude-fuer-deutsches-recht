# Testakten

[Repo-Start](../README.md) · [Zentrale Downloads](../README.md#sofort-downloads-latest-release) · [Plugin-Menü](../forderungsmanagement-immobilien/README.md) · [Alle Skills](../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick)

Neun vollständig synthetische Berliner Fach-Testakten für das Plugin [forderungsmanagement-immobilien](../forderungsmanagement-immobilien/README.md), plus ein Stamm-Hilfsordner [`mietspiegel-berlin/`](./mietspiegel-berlin/) mit einer Kurzfassung des Berliner Mietspiegels 2026 als Begründungsanker für § 558 BGB.

Alle Akten verwenden konsistente Konzern-Stammdaten:

- Vermieterin: **Wohnen Berlin Immobilien GmbH**, Friedrichstraße 99, 10117 Berlin
- Geschäftsführer: Dr. Markus Lehmann
- Eingetragen: Amtsgericht Charlottenburg HRB 198765 B
- Bearbeiterin (Forderungsmanagement): Rechtsfachwirtin **Sandra Berger**, Tel. 030 2055 4810

Alle Personennamen, Geburtsdaten und Vertragsdaten sind frei erfunden. Jede Ähnlichkeit mit echten Personen ist Zufall.

Die Akten sind nicht klinisch glatt. Einzelne Fälle enthalten bewusst DMS-Beifänge, Dublettenhinweise, unscharfe Scanvermerke, Rückrufnotizen, unklare Verwendungszwecke, angekündigte aber fehlende Anlagen oder E-Mail-Nachträge. Hinzu kommen falltypische Buchungsklärungen und Rücklastschriften, Einwurfprotokolle, Jobcenter-Nachläufe, technische Ortstermine, Objektbegehungen, Originalrechnungen, neue Ratenwünsche, Gerichtsvollzieher-Rückläufe und widersprüchliche Archivhinweise. Diese Unschärfen sollen den Alltag einer großen Forderungsabteilung abbilden, ohne den Kernfall rechnerisch oder rechtlich zu verfälschen.

## Schnellwahl nach Trainingsziel

Die Skillnummern führen über den [klickbaren Skill-Index](../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) direkt zur jeweiligen `SKILL.md`. Für den ersten Versuch genügt der dort beschriebene Autostart; eine manuelle Skillauswahl ist nicht erforderlich.

| Trainingsziel | Empfohlene Akte | Einstieg im Plugin |
|---|---|---|
| Zahlungsklage aus Mietkonto und SAP vorbereiten | [Mietrückstand Meier](./mietrueckstand-meier-wilhelmstrasse/) | `01` bis `06`, danach `20` bis `23` |
| Kündigung, Räumung und Schonfristzahlung sauber trennen | [Räumung Kowalski](./raeumungsklage-kowalski-friedrichshain/) | `13` bis `16`, `24`, `27`, `37` |
| Mieterhöhung mit Mietspiegel und Zustimmungsklage trainieren | [Mieterhöhung Becker](./mieterhoehung-becker-tempelhof/) plus [Mietspiegel](./mietspiegel-berlin/) | `28` bis `31` |
| Kulanz bei versehentlicher Nichtzahlung steuern | [Bankwechsel Lange](./mietrueckstand-lange-zwei-raten-versehen/) | `01` bis `06`, `10`, `12` |
| Harten Zahlungsstopp mit Kündigung und Räumung bearbeiten | [Zahlungsstopp Demir](./mietrueckstand-demir-fuenf-raten-absichtlich/) | `13`, `15`, `20`, `24`, `39` |
| Betriebskosten-Nachzahlung von Mietrückstand trennen | [Nebenkosten Braun](./nebenkosten-braun-nachzahlung-unbezahlt/) | `04`, `35`, `44`, `20` |
| Gebrochenen Ratenplan und Kulanzende entscheiden | [Ratenplan Riedel](./ratenplan-riedel-gebrochen/) | `10`, `11`, `12`, `20` |
| Nach Titel Kosten, Teilzahlung und Vollstreckung führen | [Vollstreckung Krüger](./vollstreckung-krueger-titel-teilzahlung/) | `46` bis `50` |
| Zugestellte Mieterklage wegen Schimmel verteidigen | [Mieterklage Schulz](./mieterklage-schimmel-schulz-verteidigung/) | `33`, `42`, `39`, `45`, danach `23` |

## Übersicht

| Akten-Ordner | Fallbild | Endprodukt |
|---|---|---|
| [`mietspiegel-berlin/`](./mietspiegel-berlin/) | Hilfsmaterial — Berliner Mietspiegel 2026 Kurzfassung | Begründungsanker für § 558 BGB |
| [`mietrueckstand-meier-wilhelmstrasse/`](./mietrueckstand-meier-wilhelmstrasse/) | Standardfall Zahlungsklage Mietrückstand Kreuzberg | Zahlungsklage Amtsgericht Kreuzberg |
| [`raeumungsklage-kowalski-friedrichshain/`](./raeumungsklage-kowalski-friedrichshain/) | Räumungsklage Friedrichshain mit Jobcenter-Schonfristzahlung | Schriftsatz Teilerledigung + Räumung |
| [`mieterhoehung-becker-tempelhof/`](./mieterhoehung-becker-tempelhof/) | Mieterhöhung Tempelhof, Begründung Berliner Mietspiegel 2026 | Mieterhöhungsverlangen und Zustimmungsklage |
| [`mietrueckstand-lange-zwei-raten-versehen/`](./mietrueckstand-lange-zwei-raten-versehen/) | Zwei offene Mieten nach Bankwechsel, glaubhafte versehentliche Nichtzahlung | Kulanz-Ratenplan mit enger Kontrolle |
| [`mietrueckstand-demir-fuenf-raten-absichtlich/`](./mietrueckstand-demir-fuenf-raten-absichtlich/) | Fünf offene Mieten, bewusster Zahlungsstopp ohne konkrete Minderungsgrundlage | Kündigung, Zahlung und Räumung |
| [`nebenkosten-braun-nachzahlung-unbezahlt/`](./nebenkosten-braun-nachzahlung-unbezahlt/) | Laufende Miete bezahlt, Betriebskosten-Nachzahlung offen und pauschal bestritten | Zahlungsklage Betriebskosten |
| [`ratenplan-riedel-gebrochen/`](./ratenplan-riedel-gebrochen/) | Laufende Miete wieder stabil, aber zwei Raten aus Kulanzplan offen | Kulanzende und Zahlungsklage Restforderung |
| [`vollstreckung-krueger-titel-teilzahlung/`](./vollstreckung-krueger-titel-teilzahlung/) | Rechtskräftiges Versäumnisurteil und KFB, Teilzahlung ohne Tilgungsbestimmung, danach Funkstille | Tilgungsjournal, Vollstreckungsauftrag und Monitoring |
| [`mieterklage-schimmel-schulz-verteidigung/`](./mieterklage-schimmel-schulz-verteidigung/) | Tatsächlicher Schimmel, Fenstererneuerung, Zutrittsverlauf, lückenhafte Raumklimadaten und zugestellte Mieterklage | Fristensicherung, Beweisplan, Klageerwiderung und gerichtsfertiges Anlagenpaket |

## Download-Pakete

Jede Akte steht im aktuellen Release in drei unmittelbar herunterladbaren Formen bereit. Das Gesamt-PDF liegt zusätzlich im jeweiligen Repo-Ordner, damit es auch ohne Release-Download direkt geöffnet werden kann.

| Arbeitsziel | Passender Download | Inhalt |
|---|---|---|
| Akte schnell lesen, drucken oder vorführen | Gesamt-PDF | alle Aktenstücke in einer durchgehenden PDF-Datei |
| Ungeordneten Praxisimport aus DMS, SAP und E-Mail trainieren | Arbeits-ZIP | flache Auswahl aus DOCX, XLSX und PDF; keine Unterordner, Markdown-Dateien oder Gesamt-PDF-Dublette |
| Getrennte Gerichtsanlagen oder einen reinen PDF-Upload trainieren | Einzel-PDF-ZIP | jedes fachliche Aktenstück als sprechend benannte Einzel-PDF; kein Gesamt-PDF |

| Sammelpaket | Direkt-Download | Verwendung |
|---|---|---|
| Alle Arbeitsdateien | [alle-testakten.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-testakten.zip) | flaches Sammel-ZIP; der Akten-Slug steht in jedem Dateinamen |
| Alle Unterlagen als Einzel-PDFs | [alle-testakten-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/alle-testakten-einzel-pdfs.zip) | Upload-Training mit getrennten, sauber benannten PDFs |
| Maschinenlesbarer Download-Index | [testakten-release-index.json](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakten-release-index.json) | Slugs, Dateinamen und Anzahl der enthaltenen Unterlagen |
| Vollständiger Release-Katalog | [release-katalog.md](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/release-katalog.md) | alle Plugin-, Prompt-, Dokumentations- und Testakten-Assets |

### Direktdownloads je Testakte

| Akte | Gesamt-PDF | Arbeits-ZIP | Einzel-PDF-ZIP |
|---|---|---|---|
| [Mietspiegel Berlin](./mietspiegel-berlin/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietspiegel-berlin-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietspiegel-berlin.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietspiegel-berlin-einzel-pdfs.zip) |
| [Mietrückstand Meier](./mietrueckstand-meier-wilhelmstrasse/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-meier-wilhelmstrasse-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-meier-wilhelmstrasse.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-meier-wilhelmstrasse-einzel-pdfs.zip) |
| [Räumung Kowalski](./raeumungsklage-kowalski-friedrichshain/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-raeumungsklage-kowalski-friedrichshain-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-raeumungsklage-kowalski-friedrichshain.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-raeumungsklage-kowalski-friedrichshain-einzel-pdfs.zip) |
| [Mieterhöhung Becker](./mieterhoehung-becker-tempelhof/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterhoehung-becker-tempelhof-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterhoehung-becker-tempelhof.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterhoehung-becker-tempelhof-einzel-pdfs.zip) |
| [Bankwechsel Lange](./mietrueckstand-lange-zwei-raten-versehen/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-lange-zwei-raten-versehen-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-lange-zwei-raten-versehen.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-lange-zwei-raten-versehen-einzel-pdfs.zip) |
| [Zahlungsstopp Demir](./mietrueckstand-demir-fuenf-raten-absichtlich/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-demir-fuenf-raten-absichtlich-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-demir-fuenf-raten-absichtlich.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-demir-fuenf-raten-absichtlich-einzel-pdfs.zip) |
| [Nebenkosten Braun](./nebenkosten-braun-nachzahlung-unbezahlt/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-nebenkosten-braun-nachzahlung-unbezahlt-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-nebenkosten-braun-nachzahlung-unbezahlt.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-nebenkosten-braun-nachzahlung-unbezahlt-einzel-pdfs.zip) |
| [Ratenplan Riedel](./ratenplan-riedel-gebrochen/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-ratenplan-riedel-gebrochen-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-ratenplan-riedel-gebrochen.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-ratenplan-riedel-gebrochen-einzel-pdfs.zip) |
| [Vollstreckung Krüger](./vollstreckung-krueger-titel-teilzahlung/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-vollstreckung-krueger-titel-teilzahlung-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-vollstreckung-krueger-titel-teilzahlung.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-vollstreckung-krueger-titel-teilzahlung-einzel-pdfs.zip) |
| [Mieterklage Schulz](./mieterklage-schimmel-schulz-verteidigung/) | [PDF](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterklage-schimmel-schulz-verteidigung-gesamt.pdf) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterklage-schimmel-schulz-verteidigung.zip) | [ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mieterklage-schimmel-schulz-verteidigung-einzel-pdfs.zip) |

Alle Links zeigen auf `releases/latest/download` und damit auf denselben veröffentlichten Stand. Der [Testakten-Asset-Index](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakten-release-index.json) ordnet Slug, Gesamt-PDF, Arbeits-ZIP, Einzel-PDF-ZIP und Dateizahlen maschinenlesbar zu.

## Verbindliche Regel: Arbeits-ZIP ohne Markdown

Diese Regel gilt dauerhaft für jede bestehende und jede künftige Testakte und für jedes Werkzeug, das hier Testakten erzeugt (Claude, Codex, Perplexity und alle weiteren):

- Die Markdown-Dateien unter `testakten/<akte>/` sind die redaktionelle Quelle. Auf ihnen laufen Validatoren, Gesamt-PDF- und Einzel-PDF-Erzeugung; sie bleiben diff-bar und auditierbar.
- Das Arbeits-ZIP (der lebensnahe Daten-Mix zum Vorführen von Lesen, Umbenennen und Konvertieren durch eine KI) enthält **keine einzige Markdown-Datei** und ausschließlich DOCX, XLSX oder PDF. Die Zuordnung steuert `scripts/testakte_realformate.py`: SAP-/FBL5N-/DMS-Listen werden XLSX, eigene Schreiben, Verträge, Schriftsätze und Vermerke DOCX, E-Mail-Ausdrucke, Urteile, Beschlüsse, Bescheide, Abrechnungen und Belege PDF.
- Arbeits-ZIP und Einzel-PDF-ZIP enthalten keine Unterordner. Der redaktionelle Bereich steht als Präfix im Dateinamen, etwa `korrespondenz__mahnung.docx`; im Sammelpaket steht zusätzlich der Akten-Slug davor. Das Arbeits-ZIP enthält das separat angebotene Gesamt-PDF nicht noch einmal.
- Neue Aktenstücke müssen einen Dateinamen tragen, der genau eine Regel in `scripts/testakte_realformate.py` trifft; sonst ist die Regelliste dort zu ergänzen.
- Inhaltsgleichheit ist Pflicht: Arbeits-ZIP, direktes Gesamt-PDF-Asset und Einzel-PDF-ZIP entstehen aus derselben Markdown-Quelle. Handgepflegte Parallelversionen sind verboten.
- `scripts/validate-testakten-release-zips.py` erzwingt die Regel vor jedem Release: Markdown im Arbeits-ZIP bricht den Build.

Im CI-Release entstehen für jeden Aktenordner `testakte-<slug>-gesamt.pdf`, `testakte-<slug>.zip` und `testakte-<slug>-einzel-pdfs.zip`. Der Validator liest jedes PDF vollständig, vergleicht das direkte Gesamt-PDF bytegenau mit der getrackten Quelle und prüft alle ZIP-Inhalte gegen dieselbe Aktenquelle. Der Mietspiegel-Ordner bleibt Querschnitt-Hilfsmaterial für Mieterhöhungsfälle.

## Qualitätssicherung

Die aktuelle Überarbeitung umfasst 174 Aktenstücke. Für die gezielte Abnahme eignen sich drei kurze Aufträge: bei Lange `Zahlungen abgleichen, keine Gutschrift doppelt zählen`, bei Braun `Heizkosten nachrechnen und fehlende Belege anfordern`, bei Riedel `Den neuen Ratenvorschlag wortgetreu auswerten`. Die jeweiligen READMEs beschreiben den erwarteten Ergebnisstand; die Aktenstücke selbst enthalten keine Lösungshinweise.

Vor jedem Release prüfen die Validatoren nicht nur Struktur und Gesamt-PDFs, sondern auch Navigation und fachliche Rechenlogik. `scripts/validate-readme-navigation.py` verlangt alle drei Downloadlinks und jedes redaktionelle Aktenstück im Register `## Akte`. `scripts/validate-testakten-financial-consistency.py` stimmt in allen neun finanziellen Fachakten Vertrag, Miete, Konto, Forderung, Teilzahlung, Ratenplan, Betriebskosten, Titel oder Klagebetrag fallbezogen gegeneinander ab. `scripts/validate-testakten-stammdaten.py` prüft zusätzlich jede Akte auf in sich stimmige Stammdaten: Vertragsnummer, Vertragsbeginn und Geburtsdatum je Person müssen in README, SAP-Auszug, Mietvertrag, Mietkonto und Korrespondenz übereinstimmen; gewollte Übungskonflikte müssen im README der Akte benannt und im Validator freigeschaltet sein. `scripts/validate-testakten-document-quality.py` sperrt leere DMS-Beifänge, interne Lehrtexte in Aktenstücken, zu kurze Mietvertragsgerippe und nicht dokumenttypisch begründete Tabellenwände.

Die Regressionen unter [tests/test_testakten_regressions.py](../tests/test_testakten_regressions.py) prüfen insbesondere gleiche, aber rechnerisch falsche Heizkosten-Endwerte, verdeckte Dokumentausfälle, die Trennung interner Notizen von Eingangspost und den Abbruch bei fehlgeschlagenem PDF-Bau.

## Struktur einer Akte (typisch)

```
<akte>/
├── README.md            Sachverhalt in Stichworten + Skill-Bezug
├── sap/                 SAP-Statusauszug (RE-FX, FBL5N)
├── vertrag/             Mietvertrag inkl. Nachträgen
├── konto/               Mietkonto FBL5N
├── dms/                 Exportlisten, Dubletten- und Versionsspuren
├── hausverwaltung/      Telefon-, Orts- und Übergabevermerke
├── zahlung/             Bankavise und Zahlungseingänge
└── korrespondenz/       Mahnungen, Kündigung, Klage, Schriftsätze
```
