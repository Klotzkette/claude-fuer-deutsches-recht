# Aktennotiz 02 - Bankwechsel und Rückruf

Wohnen Berlin Immobilien GmbH

Forderungsmanagement

Bearbeiterin: Sandra Berger

Datum: 10.06.2026

## Telefonischer Kontakt

Frau Lange ruft um 11:20 Uhr zurück. Sie wirkt kooperativ und erklärt, dass ihr altes Konto zum Monatswechsel geschlossen worden sei. Die Daueraufträge seien nach ihrer Darstellung neu eingerichtet, aber die beiden streitigen Monate seien nicht automatisch nachgezogen worden.

Frau Lange kündigt an, am Nachmittag eine Umsatzliste zu senden. Sie bittet darum, keine Kündigung auszusprechen, solange die Bank die Rückbuchungen prüfe.

## Unschärfen

Die telefonisch genannte neue IBAN wird aus Datenschutzgründen nicht in der Aktennotiz gespeichert. Im DMS liegt eine unscharfe Handyaufnahme eines Kontoauszugs; Betrag und Buchungstag sind erkennbar, Empfänger und Verwendungszweck nicht vollständig.

## Arbeitsstand

Kulanz bleibt vertretbar, wenn die angekündigte Nachzahlung fristgerecht eingeht und die laufende Miete stabil bleibt. Wiedervorlage kurz halten.
