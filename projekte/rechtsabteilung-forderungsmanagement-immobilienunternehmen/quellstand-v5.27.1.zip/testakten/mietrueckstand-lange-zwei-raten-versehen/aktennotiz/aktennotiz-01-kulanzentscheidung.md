# Aktennotiz Nr. 1

Wohnen Berlin Immobilien GmbH
Abteilung Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Geschäftszeichen:    F-2026-00411
Mietverhältnis:      MV-104872-LA, Hauptstraße 72, 10827 Berlin, 2. OG rechts
Mieterin:            Jana Lange
Verfasserin:         Sandra Berger, Renofa, Tel. 030 2055 4810
Datum:               15.07.2026
Betreff:             Kulanzentscheidung bei versehentlich offenen Mieten Mai und Juni 2026

## 1. Anlass

Die Zahlungserinnerung vom 10.07.2026 (vgl. korrespondenz/zahlungserinnerung.md) hat die Mieterin zur Reaktion veranlasst. Sie hat mit Schreiben vom 12.07.2026 (vgl. korrespondenz/mieter-antwort-bankwechsel.md) den Fehler dargelegt und einen Ausgleich in zwei Teilzahlungen angeboten. Die Abteilung muss vor Fristablauf entscheiden, ob Kulanz gewährt oder unverzüglich Kündigung vorbereitet wird.

## 2. Sachstand

### 2.1 Rückstand

Offen sind die Mieten für Mai 2026 und Juni 2026 in Höhe von jeweils 1.000,00 EUR, gesamt 2.000,00 EUR. Der Rückstand entspricht zwei Bruttowarmmieten, liegt damit formal an der Kündigungsschwelle (§ 543 Absatz 2 Satz 1 Nummer 3 BGB).

### 2.2 Vorgeschichte und Zahlungsverhalten

Das SAP-System (vgl. sap/sap-statusauszug.md) weist keine früheren Leistungsstörungen aus. Die Miete Juli 2026 wurde vollständig und pünktlich gezahlt, was die Glaubwürdigkeit der Erklärung stützt.

### 2.3 Erklärung der Mieterin

Die Mieterin erklärt, ihren Dauerauftrag nach einem Kontowechsel nicht neu eingerichtet zu haben. Dieses Versäumnis ist grundsätzlich dem Mieterschuldenbereich zuzurechnen, erscheint aber bei nachgewiesenem Kontowechsel und sofortiger proaktiver Kommunikation als entschuldbar.

## 3. Rechtliche Bewertung

Eine sofortige fristlose Kündigung nach § 543 Absatz 2 Satz 1 Nummer 3 BGB ist rechtlich vertretbar; die Tatbestandsvoraussetzungen (Rückstand zwei Monatsmieten) sind erfüllt. Wegen der unauffälligen Vorgeschichte, der glaubhaften Erklärung und der Wiederaufnahme der laufenden Zahlungen erscheint Kulanz im wirtschaftlichen Interesse der Vermieterin. Eine Kulanzlösung ist jedoch nur bei strenger Kontrolle und kurzer Frist zu gewähren.

## 4. Nächste Schritte

1. Kulanzangebot (vgl. korrespondenz/ratenplan-kulanzvorschlag.md): Zahlung 1.000,00 EUR bis 20.07.2026, Zahlung 1.000,00 EUR bis 05.08.2026, laufende Augustmiete ebenfalls bis 05.08.2026.
2. Ausdrücklich keine Anerkennung eines dauerhaften Stundungsanspruchs.
3. Wiedervorlage 21.07.2026 (nach erster Teilzahlung) und 06.08.2026 (nach zweiter Teilzahlung).
4. Bei Ausfall einer Rate: Mietkonto tagesaktuell abgleichen, Wirkung der Kulanzvereinbarung prüfen und Kündigungs- sowie Klageoption zur Freigabe vorlegen. Eine Kündigung wird nicht allein durch einen automatischen SAP-Status ausgelöst.

## 5. Eskalation / Vorlage

Die kontrollierte Kulanz liegt nach der internen Kompetenzmatrix in der Bearbeitungskompetenz, wird aber im Vier-Augen-Prinzip freigegeben. Sollte der Rückstand nach dem 06.08.2026 nicht vollständig ausgeglichen sein, sind Zahlungseingänge, Vereinbarung und aktueller Kündigungstatbestand neu zu prüfen und der Abteilungsleitung mit einer konkreten Handlungsoption vorzulegen.

(gez.) Sandra Berger
Renofa, Forderungsmanagement
