# Wohnraummietvertrag

**Vertragsnummer:** WBI-MV-2021-01877
**Objekt:** Hauptstraße 72, 10827 Berlin, 2. OG rechts
**Ablage:** SAP RE-FX / DMS Vertragsakte

**Parteien**

**Vermieterin**
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin
vertreten durch den Geschäftsführer Dr. Markus Lehmann

**Mieterin**
Frau Jana Lange, geboren am 22.02.1991
Hauptstraße 72
10827 Berlin

## 1 Mietsache

### 1.1

Vermietet wird die Wohnung Hauptstraße 72, 10827 Berlin, 2. OG rechts, bestehend aus zwei Zimmern, Küche, Bad, Flur, Balkon und Kellerraum Nr. 72-R2.

### 1.2

Die Wohnfläche beträgt **58,20 qm**. Die Wohnung ist frei finanziert und wird ausschließlich zu Wohnzwecken vermietet.

## 2 Mietzeit

Das Mietverhältnis beginnt am **01.05.2021** und läuft auf unbestimmte Zeit. Kündigungen bedürfen der Schriftform.

## 3 Miete und Fälligkeit

| Position | Betrag |
|---|---:|
| Nettokaltmiete | 690,00 EUR |
| Betriebskostenvorauszahlung | 180,00 EUR |
| Heizkostenvorauszahlung | 130,00 EUR |
| **Bruttowarmmiete** | **1000,00 EUR** |

### 3.1

Die Miete ist monatlich im Voraus spätestens am dritten Werktag des Monats zu zahlen.

### 3.2

Bankverbindung der Vermieterin:

| Empfängerin | IBAN | BIC | Institut |
|---|---|---|---|
| Wohnen Berlin Immobilien GmbH | DE47 1009 0000 0123 4567 89 | BEVODEBB | Berliner Volksbank |

### 3.3

Verwendungszweck: **WBI-MV-2021-01877 Lange Hauptstraße 72**.

## 4 Betriebskosten

Die Mieterin trägt die umlagefähigen Betriebskosten gemäß § 2 BetrKV sowie Heiz- und Warmwasserkosten nach der Heizkostenverordnung. Die Vorauszahlungen können nach ordnungsgemäßer Abrechnung angepasst werden.

## 5 Mietsicherheit

Die Mietsicherheit beträgt **2070,00 EUR** und entspricht drei Nettokaltmieten. Eine Geldsicherheit kann in drei gleichen monatlichen Raten erbracht werden; die erste Rate ist zu Mietbeginn, die weiteren Raten sind mit den beiden folgenden Mietzahlungen fällig. Die Vermieterin legt die Sicherheit getrennt von ihrem Vermögen an. Über geleistete Raten und die Anlage wird gesondert Nachweis erteilt.

## 6 Zahlungsverkehr

### 6.1

Die Mieterin kann den Zahlweg frei wählen. Bei Überweisungen soll die Vertragsnummer **WBI-MV-2021-01877** angegeben werden, damit der Zahlungseingang ohne Verzögerung dem Mietkonto zugeordnet werden kann.

### 6.2

Änderungen des eigenen Kontos entbinden nicht von der rechtzeitigen Zahlung. Die Vermieterin ist über einen Wechsel nur zu informieren, wenn ein erteiltes SEPA-Lastschriftmandat betroffen ist oder eine Erstattung auf ein anderes Konto erfolgen soll.

### 6.3

Stundungen, Ratenzahlungen oder Kulanzabreden gelten nur für die darin ausdrücklich bezeichneten Forderungen und Zeiträume. Die laufende Miete bleibt unberührt, sofern die Parteien nicht ausdrücklich etwas anderes vereinbaren.

## 7 Nutzung und Obhut

### 7.1

Die Wohnung ist ausschließlich zu Wohnzwecken bestimmt. Die Gebrauchsüberlassung an Dritte sowie eine teilweise Untervermietung richten sich nach den gesetzlichen Vorschriften.

### 7.2

Die Mieterin behandelt Wohnung, Balkon und Gemeinschaftseinrichtungen pfleglich. Schäden und Gefahren, insbesondere Leitungswasser, Heizungsausfall oder Störungen an Fenstern und Außentüren, sind unverzüglich anzuzeigen.

### 7.3

Bauliche Veränderungen sowie Eingriffe in Fassade, Leitungen, Abdichtung oder Gebäudetechnik bedürfen der vorherigen Zustimmung. Übliche bewegliche Einrichtungsgegenstände auf dem Balkon sind hiervon nicht erfasst.

## 8 Zutritt und Erhaltungsmaßnahmen

### 8.1

Besteht ein konkreter sachlicher Grund, insbesondere eine Mängelprüfung, Ablesung, Wartung oder angekündigte Erhaltungsmaßnahme, ermöglicht die Mieterin nach angemessener Terminabstimmung Zutritt. Notfälle bleiben unberührt.

### 8.2

Die Vermieterin kündigt planbare Maßnahmen rechtzeitig an und berücksichtigt bei der Terminierung die beruflichen und persönlichen Belange der Mieterin.

## 9 Hausordnung

Die beigefügte Hausordnung regelt insbesondere Ruhezeiten, Treppenhausnutzung, Mülltrennung und Gemeinschaftsflächen. Sie begründet keine Beschränkungen, die zwingenden gesetzlichen Vorschriften widersprechen.

## 10 Übergabe und Rückgabe

### 10.1

Anfangszustand, Zählerstände und überlassene Schlüssel sind im Übergabeprotokoll vom 29.04.2021 festgehalten. Die Mieterin erhielt zwei Haus- und Wohnungsschlüssel, einen Briefkastenschlüssel und einen Kellerschlüssel.

### 10.2

Bei Beendigung ist die Wohnung geräumt, besenrein und mit sämtlichen Schlüsseln zurückzugeben. Über Zustand, Zählerstände und Schlüssel wird ein gesondertes Protokoll erstellt.

## 11 Mitteilungen und Änderungen

### 11.1

Änderungen von Zustellanschrift, E-Mail-Adresse und Telefonnummer sollen zeitnah mitgeteilt werden. Gesetzlich vorgeschriebene Formen, insbesondere für Kündigungen, bleiben maßgeblich.

### 11.2

Nebenabreden bestehen bei Unterzeichnung nicht. Spätere Änderungen werden eindeutig bezeichnet und zur Vertragsakte genommen.

## 12 Anlagen

1. Wohnflächenberechnung
2. Übergabeprotokoll vom 29.04.2021
3. Hausordnung
4. Betriebskostenkatalog
5. Energieausweis zur Einsichtnahme

**Unterschriften**

Berlin, den 26.04.2021

| Vermieterin | Mieterin |
|---|---|
| Wohnen Berlin Immobilien GmbH, Dr. Markus Lehmann | Jana Lange |
