# DocuWeb Exportliste F-2026-00411

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportzeitpunkt | 21.07.2026, 08:16 Uhr |
| Vertragsnummer | WBI-MV-2021-01877 |
| Mieterin | Jana Lange |
| Dokumente | 15 |

## 2 Bestand

| DMS-ID | Datum | Dokumentklasse | Indexname | Status |
|---|---|---|---|---|
| DW-731900 | 20.04.2021 | Vertrag | Mietvertrag_Lange.pdf | final |
| DW-731901 | 20.04.2021 | Zahlungsweg | SEPA_Mandat_alt.pdf | durchgestrichen, nie aktiviert |
| DW-898441 | 08.06.2026 | Bankbeleg | Rückgabeinformation_Mai_Juni_2026.pdf | Bankwechsel und Rückgaben dokumentiert |
| DW-898512 | 11.06.2026 | Notiz | Telefonnotiz_Dauerauftrag_Kulanz.docx | Eigenerklärung der Mieterin |
| DW-901211 | 07.07.2026 | Ausgang | Zahlungserinnerung_Lange.pdf | versandt |
| DW-901992 | 09.07.2026 | Eingang | Mail_Bankwechsel_Lange.pdf | gelesen |
| DW-901993 | 09.07.2026 | Anlage | Kontoeröffnung_neu.pdf | Kontonummer geschwärzt |
| DW-902221 | 10.07.2026 | Notiz | Rückruf_Lange.docx | Rückruf 09:18 Uhr |
| DW-902700 | 13.07.2026 | Entscheidung | Kulanzvorschlag.docx | intern freigegeben |
| DW-902701 | 14.07.2026 | Ausgang | Ratenplan_Lange.pdf | per E-Mail versandt |
| DW-902994 | 15.07.2026 | Eingang | Ratenplan_unterschrieben_scan.pdf | Seite 2 leicht schief |
| DW-903418 | 20.07.2026 | Zahlung | Avis_1000_EUR.pdf | erste Rate |
| DW-903421 | 21.07.2026 | Bankbeleg | Kontoauszug_neues_Konto_Juli_2026.pdf | fallfremde Umsätze geschwärzt |
| DW-903419 | 20.07.2026 | Tabelle | Ratenmonitoring_Lange.xlsx | Wiedervorlage 06.08.2026 |
| DW-903420 | 20.07.2026 | Sonstiges | IMG_4421.pdf | Screenshot ohne sichtbaren Betrag |

## 3 Auffälligkeit

Das alte SEPA-Mandat ist im DMS vorhanden, war laut SAP aber nie aktiv. Der Screenshot IMG_4421 zeigt nur die Startseite einer Banking-App und belegt keine Zahlung. Das unterzeichnete Ratenplandokument enthält beide Seiten; die zweite Seite ist vollständig lesbar.

Die Bankinformation belegt die Rückgabevorgänge, nicht den später behaupteten
Ausgleich. Die Telefonnotiz stützt die Erklärung zum Bankwechsel, bleibt aber
eine interne Gesprächsdokumentation und ersetzt weder Vereinbarung noch
Zahlungseingang.
