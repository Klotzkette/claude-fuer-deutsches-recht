# Interner Entscheidungsvorschlag Kulanz-Ratenplan

**Akte:** WBI-MV-2021-01877 Lange / Hauptstraße 72
**Bearbeitung:** Sandra Berger, Rechtsfachwirtin
**Stand:** 13.07.2026

## 1. Ausgangslage

Frau Lange schuldet die Mieten Mai und Juni 2026 in Höhe von insgesamt **2000,00 EUR**. Die laufende Miete Juli 2026 ist gezahlt. Die Mieterin hat innerhalb von zwei Tagen reagiert und den Bankwechsel als Ursache angegeben.

## 2. Ampel

**Gelb.** Zwei Monatsmieten sind offen; eine Kündigungsprüfung ist grundsätzlich möglich. Wegen unauffälliger Historie, schneller Rückmeldung und gezahlter laufender Miete ist ein eng kontrollierter Kulanz-Ratenplan vertretbar.

## 3. Zahlungsvorschlag

| Termin | Zahlung | Zweck | Kontrolle |
|---|---:|---|---|
| 20.07.2026 | 1000,00 EUR | Rückstand Mai 2026 | Kontoauszug 21.07.2026 |
| 05.08.2026 | 1000,00 EUR | Rückstand Juni 2026 | Kontoauszug 06.08.2026 |
| 05.08.2026 | 1000,00 EUR | laufende Augustmiete | Kontoauszug 06.08.2026 |

## 4. Bedingungen

1. Keine Anerkennung eines dauerhaften Stundungsanspruchs.
2. Ratenplan gilt nur bei pünktlicher Zahlung.
3. Bei Ausfall einer Rate sofort neue Prüfung von Kündigung und Zahlungsklage.
4. Keine weiteren Rückstände bis 31.10.2026.
5. Schriftliche Bestätigung an Mieterin mit Tilgungsreihenfolge.

## 5. Freigabevorschlag

Kulanz freigeben. Wiedervorlage in SAP und Fristenliste setzen. Keine Kündigung vor dem 21.07.2026, wenn die erste Rate rechtzeitig eingeht.
