# Zahlungserinnerung

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99
10117 Berlin
Abteilung Forderungsmanagement
Bearbeitung: Sandra Berger, Rechtsfachwirtin

Frau
Jana Lange
Hauptstraße 72
10827 Berlin

Berlin, 10.07.2026

**Mietverhältnis Hauptstraße 72, 10827 Berlin, 2. OG rechts**
**Vertragsnummer WBI-MV-2021-01877**
**Zahlungserinnerung wegen offener Mieten Mai und Juni 2026**

Sehr geehrte Frau Lange,

nach unserem Mietkonto sind die Mieten für Mai 2026 und Juni 2026 offen. Die laufende Juli-Miete wurde am 03.07.2026 gezahlt.

| Monat | Soll | Zahlung | Offen |
|---|---:|---:|---:|
| Mai 2026 | 1000,00 EUR | 0,00 EUR | 1000,00 EUR |
| Juni 2026 | 1000,00 EUR | 0,00 EUR | 1000,00 EUR |
| Juli 2026 | 1000,00 EUR | 1000,00 EUR | 0,00 EUR |
| **Summe offen** | | | **2000,00 EUR** |

Bitte gleichen Sie den Rückstand bis zum **22.07.2026** aus oder teilen Sie uns bis zu diesem Datum mit, falls aus Ihrer Sicht eine Buchung fehlt.

Sollte die Nichtzahlung auf einem Bankwechsel, Dauerauftragsfehler oder einer einmaligen Zahlungsschwierigkeit beruhen, melden Sie sich bitte kurzfristig. Bei bislang unauffälliger Zahlungshistorie prüfen wir eine eng befristete Kulanzregelung.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH

**Versandvermerk:** Briefpost und zusätzlich E-Mail an jana.lange@example.invalid am 10.07.2026.
