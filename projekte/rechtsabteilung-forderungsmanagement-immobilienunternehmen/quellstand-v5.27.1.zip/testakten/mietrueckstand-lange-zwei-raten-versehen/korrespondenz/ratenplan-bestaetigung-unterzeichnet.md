# Bestätigung des Kulanz-Ratenplans

Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

## 1 Bezug

Mietverhältnis Hauptstraße 72, 10827 Berlin, 2. OG rechts

Vertragsnummer WBI-MV-2021-01877

Berlin, 15.07.2026

Sehr geehrte Frau Berger,

ich bestätige den mir am 14.07.2026 übersandten Kulanz-Ratenplan. Den Rückstand für Mai 2026 in Höhe von 1.000,00 EUR zahle ich bis zum 20.07.2026. Den Rückstand für Juni 2026 in Höhe von 1.000,00 EUR zahle ich bis zum 05.08.2026. Die laufende Augustmiete von 1.000,00 EUR wird zusätzlich zum 05.08.2026 gezahlt.

Mir ist bekannt, dass die Vereinbarung nur gilt, wenn die genannten Zahlungen vollständig und rechtzeitig eingehen. Ich bitte darum, bis zur Kontrolle am 06.08.2026 von einer Kündigung abzusehen.

Mit freundlichen Grüßen

Jana Lange

## 2 Scanvermerk

Eingang per E-Mail am 15.07.2026 um 22:04 Uhr. Die Unterschrift befindet sich auf Seite 2 des Scans. Die handschriftliche Ergänzung „August wieder per Dauerauftrag“ steht neben dem letzten Absatz; ein eigener Betrag wurde dort nicht eingetragen.
