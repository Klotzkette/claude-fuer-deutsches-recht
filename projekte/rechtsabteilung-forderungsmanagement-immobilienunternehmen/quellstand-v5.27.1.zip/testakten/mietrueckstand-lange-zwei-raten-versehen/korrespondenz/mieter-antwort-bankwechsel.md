# Antwort der Mieterin vom 12.07.2026

**Von:** Jana Lange <jana.lange@example.invalid>
**An:** Sandra Berger <s.berger@wohnen-berlin-immo.de>
**Betreff:** Zahlungserinnerung Hauptstraße 72 / Bankwechsel
**Eingang:** 12.07.2026, 08:46 Uhr

Sehr geehrte Frau Berger,

die offenen Mieten sind mein Fehler. Ich habe im Mai die Bank gewechselt und den Dauerauftrag für die Miete nicht neu eingerichtet. Ich habe das erst durch Ihr Schreiben bemerkt.

Ich kann am **20.07.2026 sofort 1000,00 EUR** zahlen und den Rest am **05.08.2026**. Die laufende Augustmiete zahle ich ebenfalls am 05.08.2026 mit.

Bitte sehen Sie von einer Kündigung ab. Es gab bisher keine Probleme, und ich möchte das sofort bereinigen.

Mit freundlichen Grüßen
Jana Lange
