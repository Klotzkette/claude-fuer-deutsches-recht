# Ratenmonitoring Kulanz Lange

## 1 Plan und Ist

| Position | Fällig | Planbetrag | Eingang | Istbetrag | Status |
|---|---|---:|---|---:|---|
| Rückstand Mai 2026 | 20.07.2026 | 1000,00 EUR | 20.07.2026 | 1000,00 EUR | erfüllt |
| Rückstand Juni 2026 | 05.08.2026 | 1000,00 EUR | offen | 0,00 EUR | vorgemerkt |
| Laufende Miete August 2026 | 05.08.2026 | 1000,00 EUR | offen | 0,00 EUR | Dauerauftrag angekündigt |

## 2 Wiedervorlagen

| Datum | Kontrolle | Verantwortlich | Ergebnis |
|---|---|---|---|
| 21.07.2026 | erste Rate verbuchen | S. Berger | erledigt |
| 04.08.2026 | Vorfrist zweite Rate | Team Forderung 2 | offen |
| 06.08.2026 | Konto auf zweite Rate und Augustmiete prüfen | S. Berger | offen |
| 07.08.2026 | bei Fehlbetrag Eskalationsvorlage erstellen | S. Berger | offen |

## 3 Systemnotiz

SAP-Kennzeichen STU-KULANZ endet automatisch am 06.08.2026. Eine Verlängerung darf nicht allein wegen des angelegten Dauerauftrags erfolgen; maßgeblich ist der tatsächliche Zahlungseingang.
