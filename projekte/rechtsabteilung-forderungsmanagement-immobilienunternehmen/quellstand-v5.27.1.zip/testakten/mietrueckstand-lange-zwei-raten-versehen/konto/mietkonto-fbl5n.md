# Mietkonto FBL5N

**Debitor:** D-778421
**Vertrag:** WBI-MV-2021-01877
**Zeitraum:** 01.04.2026 bis 15.07.2026
**Export:** FI-CA Einzelpostenliste, 15.07.2026, 11:21 Uhr

## Buchungsjournal

| Buchungsdatum | Beleg | Periode | Soll | Ist | Buchungstext | Saldo |
|---|---|---|---:|---:|---|---:|
| 02.04.2026 | 62004110 | 04 2026 | 1000,00 | 1000,00 | Miete April bezahlt | 0,00 |
| 05.05.2026 | 62005217 | 05 2026 | 1000,00 | 0,00 | Miete Mai offen | 1000,00 |
| 04.06.2026 | 62006308 | 06 2026 | 1000,00 | 0,00 | Miete Juni offen | 2000,00 |
| 03.07.2026 | 62007409 | 07 2026 | 1000,00 | 1000,00 | Miete Juli bezahlt | 2000,00 |

## OP-Status

| Prüffeld | Ergebnis |
|---|---|
| Offene Hauptforderung | 2000,00 EUR |
| Offene Nebenforderungen | 0,00 EUR |
| Teilzahlungen | Keine |
| Zahlung Juli | Vollständig und pünktlich |
| Stornos/Gutschriften | Keine |
| Mahnhistorie | Erste Zahlungsstörung seit Vertragsbeginn |

## Plausibilität

Der Rückstand entspricht exakt zwei Bruttowarmmieten. Der Zahlungseingang Juli spricht gegen fortgesetzte Leistungsverweigerung und passt zur behaupteten Bankwechsel-Panne. Bei Bruch einer Raten- oder Kulanzvereinbarung ist die Kündigungsprüfung erneut vorzunehmen.
