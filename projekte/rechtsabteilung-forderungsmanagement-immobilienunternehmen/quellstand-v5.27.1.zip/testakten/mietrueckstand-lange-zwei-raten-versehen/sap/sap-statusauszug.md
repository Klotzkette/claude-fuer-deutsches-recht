# SAP RE-FX / FI-CA Statusauszug

**System:** SAP S/4HANA RE-FX, Produktivmandant WBI-PRD
**Export:** 15.07.2026, 11:18 Uhr
**Export-ID:** REFX-FICA-20260715-HS72-02R
**Sachbearbeitung:** Sandra Berger, Forderungsmanagement

## Vertragskopf

| Feld | Wert |
|---|---|
| Buchungskreis | WBI-DE-BER |
| Vertragsnummer | WBI-MV-2021-01877 |
| SAP-Vertragsobjekt | MV-104872-LA |
| Debitor | D-778421 |
| Objekt | 10827-B-HS72-02R |
| Nutzungseinheit | Hauptstraße 72, 2. OG rechts |
| Vermieterin | Wohnen Berlin Immobilien GmbH |
| Mieterin | Jana Lange |
| Vertragsbeginn | 01.05.2021 |
| Status | Aktiv |

## Mietkonditionen laut Konditionsblatt

| Kondition | Betrag monatlich | Gültig ab | Quelle |
|---|---:|---|---|
| Nettokaltmiete | 690,00 EUR | 01.05.2021 | RE-FX Konditionssatz 100 |
| Betriebskostenvorauszahlung | 180,00 EUR | 01.05.2021 | RE-FX Konditionssatz 210 |
| Heizkostenvorauszahlung | 130,00 EUR | 01.05.2021 | RE-FX Konditionssatz 220 |
| **Bruttowarmmiete** | **1000,00 EUR** | 01.05.2021 | Systemsumme |

## Offene Posten

| OP-Nr. | Fälligkeit | Text | Soll | Ist | Offen | Mahnstufe |
|---|---|---|---:|---:|---:|---|
| 910872-05 | 05.05.2026 | Miete Mai 2026 | 1000,00 EUR | 0,00 EUR | 1000,00 EUR | 1 |
| 910872-06 | 04.06.2026 | Miete Juni 2026 | 1000,00 EUR | 0,00 EUR | 1000,00 EUR | 1 |
| **Summe** | | | **2000,00 EUR** | **0,00 EUR** | **2000,00 EUR** | |

## Zahlungs- und Klärungsstatus

| Prüfpunkt | Ergebnis |
|---|---|
| Letzte Zahlung | 03.07.2026, 1000,00 EUR, laufende Miete Juli |
| Frühere Leistungsstörungen | Keine seit Vertragsbeginn |
| Lastschriftmandat | Nicht erteilt, Zahlung per Dauerauftrag |
| Mahnsperre | Nein |
| Streitkennzeichen | Nein |
| Mängelanzeige | Keine |
| Kulanzindikator | Gelb: Rückstand plausibel versehentlich, laufende Miete wieder stabil |
| Wiedervorlage | 29.07.2026, Zahlungseingang Rate 1 prüfen |

## Bearbeitungshinweis

Die Akte ist nicht auf sofortige Eskalation angelegt, sondern auf saubere Rückstandsaufklärung und belastbare Kulanzentscheidung. Der Rückstand erreicht zwei Bruttowarmmieten; wegen der bisherigen störungsfreien Zahlungshistorie ist ein befristeter Ratenplan fachlich vertretbar, wenn die Mieterin die Ursache belegt und laufende Mieten pünktlich zahlt.
