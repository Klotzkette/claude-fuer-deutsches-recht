# Telefonnotiz

Wohnen Berlin Immobilien GmbH

Forderungsmanagement

## 1. Gesprächsdaten

| Feld | Inhalt |
|---|---|
| Datum | 11.06.2026 |
| Zeit | 09:14 bis 09:27 Uhr |
| Gesprächspartnerin | Jana Lange |
| Bearbeitung | Sandra Berger |
| Akte | F-2026-00411 |

## 2. Gespräch

Frau Lange bestätigt, dass die Bank im Mai und Juni keine Mietzahlung ausgeführt habe. Sie habe zunächst angenommen, der Dauerauftrag sei beim Kontowechsel übernommen worden. Die Bankinformation wolle sie noch am selben Tag per E-Mail übersenden.

Frau Lange erklärt, die Juli-Miete werde über den neu eingerichteten Dauerauftrag gezahlt. Den Rückstand könne sie nicht sofort vollständig ausgleichen. Sie bietet vier monatliche Zusatzraten zu je 500,00 EUR an, beginnend am 20.07.2026.

Auf Nachfrage erklärt sie, derzeit keine weiteren Miet-, Energie- oder Ratenrückstände zu haben. Belege hierzu wurden nicht verlangt. Eine verbindliche Zusage der Vermieterin wurde im Gespräch nicht erteilt.

## 3. Vereinbarter Nachlauf

Frau Lange sendet die Bankinformation und einen unterschriebenen Ratenvorschlag. Die Abteilung prüft Zahlungshistorie, laufende Juli-Miete und interne Kulanzfreigabe.

Wiedervorlage: 15.06.2026.

Sandra Berger
