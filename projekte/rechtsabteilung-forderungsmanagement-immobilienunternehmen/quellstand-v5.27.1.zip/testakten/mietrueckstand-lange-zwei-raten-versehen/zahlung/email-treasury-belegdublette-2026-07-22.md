# E-Mail-Ausdruck

Von: zahlungsverkehr@wohnen-berlin.example

An: forderungsmanagement@wohnen-berlin.example

Datum: 22.07.2026, 09:16 Uhr

Betreff: WBI-MV-2021-01877 / zweiter Import des Zahlungsbelegs

Sehr geehrte Frau Berger,

die heute aus dem Bankportal nachgelieferte Buchungsanzeige über 1.000,00 EUR betrifft den bereits am 20.07.2026 gebuchten Eingang von Jana Lange. Die Referenz lautet erneut EREF NL-200726-410088, die Wertstellung ist unverändert der 20.07.2026. Im SAP steht dazu genau ein Beleg BA-2026-03188. Eine weitere Zahlung über diesen Betrag ist bis zum heutigen Bankabruf um 08:45 Uhr nicht eingegangen.

Der erneute Export wurde angefordert, weil auf dem ersten Ausdruck der Verwendungszweck rechts abgeschnitten war. Im vollständigen Datensatz steht RATE 1 MAI 2026 MV 2021 01877. Bitte hängen Sie die neue Anzeige an denselben Zahlungsvorgang; es handelt sich nicht um die zweite Kulanzrate für Juni.

Die Juli-Miete ist weiterhin als eigener Eingang vom 03.07.2026 erfasst. Der Sollposten für Juni bleibt nach unserer Buchungsliste mit 1.000,00 EUR offen. Zu den für August angekündigten Zahlungen enthält dieser Abruf noch keine Aussage. Ein eingerichteter Dauerauftrag erscheint bei uns erst nach tatsächlicher Gutschrift.

Mit freundlichen Grüßen

Miriam Seidel

Zahlungsverkehr / Wohnen Berlin Immobilien GmbH
