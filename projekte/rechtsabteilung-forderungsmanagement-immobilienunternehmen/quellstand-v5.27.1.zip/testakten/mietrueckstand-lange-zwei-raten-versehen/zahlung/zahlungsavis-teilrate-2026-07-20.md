# Zahlungsavis erste Kulanzrate

## 1 Buchungsdaten

| Feld | Wert |
|---|---|
| Buchungstag | 20.07.2026 |
| Wertstellung | 20.07.2026 |
| Betrag | 1000,00 EUR Haben |
| Auftraggeberin | Jana Lange |
| Verwendungszweck | RATE 1 MAI 2026 MV 2021 01877 |
| Bankreferenz | EREF NL-200726-410088 |
| SAP-Beleg | BA-2026-03188 |

## 2 Zuordnung

Die Zahlung wurde dem Rückstand Mai 2026 zugeordnet. Die laufende Juli-Miete war bereits am 03.07.2026 eingegangen. Nach dieser Buchung verbleiben 1.000,00 EUR Rückstand für Juni 2026.

## 3 Nachlauf

Die zweite Rückstandsrate und die laufende Augustmiete sind nach dem bestätigten Kulanzplan am 05.08.2026 zu kontrollieren. Dieses Avis enthält keine Vorausbestätigung für die zweite Rate.
