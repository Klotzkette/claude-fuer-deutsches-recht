# Testakte 4 — Zwei offene Mieten Lange Schöneberg


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 54 KB) | PDF | [testakte-mietrueckstand-lange-zwei-raten-versehen-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-lange-zwei-raten-versehen-gesamt.pdf) | [`gesamt-pdf/mietrueckstand-lange-zwei-raten-versehen_gesamt.pdf`](gesamt-pdf/mietrueckstand-lange-zwei-raten-versehen_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-mietrueckstand-lange-zwei-raten-versehen.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-lange-zwei-raten-versehen.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-mietrueckstand-lange-zwei-raten-versehen-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-lange-zwei-raten-versehen-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Zwei offene Mieten nach Bankwechsel, gelbe Ampel, Kulanz-Ratenplan und enge Wiedervorlage |
| Startskills | `01-sap-akte-importieren`, `03-kontoauszug-mietkonto-auslesen`, `06-fallziel-renofa-triage`, `10-zahlungsplan-stundungsvereinbarung` |
| Kernentscheidung | Reicht die glaubhafte Fehlererklärung für eine kontrollierte Kulanz oder ist sofortige Eskalation nötig? |
| Besonderheit | Bankinformation und Rückrufnotiz erklären den Bankwechsel, beweisen aber weder späteren Ausgleich noch einen neuen Ratenplan. Kulanz braucht Annahme, Zahlungseingang und Wiedervorlage. |

Zwei Monatsmieten sind wegen eines Bankwechsels versehentlich nicht gezahlt worden. Die Mieterin meldet sich nach Zahlungserinnerung, legt den Fehler offen und bittet um Kulanz durch kurzfristigen Ausgleich in zwei Teilzahlungen.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Bearbeiterin | Rechtsfachwirtin Sandra Berger |
| Mieterin | Jana Lange, geb. 22.02.1991 |
| Mietobjekt | Hauptstraße 72, 10827 Berlin, 2. OG rechts |
| Wohnfläche | 58,20 qm |
| Vertragsbeginn | 01.05.2021 |
| Nettokaltmiete | 690,00 EUR |
| BK-Vorauszahlung | 180,00 EUR |
| HK-Vorauszahlung | 130,00 EUR |
| Bruttowarmmiete | 1000,00 EUR |
| Fälligkeit | 3. Werktag des Monats § 556b BGB |
| Aktenzeichen intern | F-2026-00411 |

## Sachverhalt

Die Mieten Mai und Juni 2026 sind offen. April und Juli 2026 sind bezahlt. Der SAP-Status zeigt keine früheren Rückstände. Die Mieterin erklärt, ihr Dauerauftrag sei nach Kontowechsel nicht neu eingerichtet worden.

| Monat | Soll | Ist | Saldo |
|---|---:|---:|---:|
| 05 2026 | 1000,00 | 0,00 | 1000,00 |
| 06 2026 | 1000,00 | 0,00 | 1000,00 |
| 07 2026 | 1000,00 | 1000,00 | 0,00 |
| **Summe offen** | | | **2000,00** |

## Trainingsziel

Diese Akte testet die gelbe Ampel: Rückstand ist rechtlich erheblich, aber die Historie und die glaubhafte Erklärung sprechen für eine kontrollierte Kulanzlösung mit enger Frist, nicht sofort für harte Eskalation.

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Mietvertrag | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Mietkonto FBL5N | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Zahlungserinnerung | [korrespondenz/zahlungserinnerung.md](korrespondenz/zahlungserinnerung.md) |
| Antwort der Mieterin | [korrespondenz/mieter-antwort-bankwechsel.md](korrespondenz/mieter-antwort-bankwechsel.md) |
| Aktennotiz zur Kulanzentscheidung | [aktennotiz/aktennotiz-01-kulanzentscheidung.md](aktennotiz/aktennotiz-01-kulanzentscheidung.md) |
| Rückrufnotiz Bankwechsel | [aktennotiz/aktennotiz-02-bankwechsel-rueckruf.md](aktennotiz/aktennotiz-02-bankwechsel-rueckruf.md) |
| Kulanzvorschlag | [korrespondenz/ratenplan-kulanzvorschlag.md](korrespondenz/ratenplan-kulanzvorschlag.md) |
| DocuWeb-Exportliste zum Bankwechsel und Ratenplan | [dms/dms-exportliste-bankwechsel.md](dms/dms-exportliste-bankwechsel.md) |
| Bankbestätigung zum nicht aktivierten Dauerauftrag | [bank/bank-avis-kontowechsel-dauerauftrag.md](bank/bank-avis-kontowechsel-dauerauftrag.md) |
| Gekürzter Kontoauszug mit Julimiete und erster Rückstandsrate | [bank/kontoauszug-neues-konto-juli-2026.md](bank/kontoauszug-neues-konto-juli-2026.md) |
| Zahlungsavis der ersten Kulanzrate | [zahlung/zahlungsavis-teilrate-2026-07-20.md](zahlung/zahlungsavis-teilrate-2026-07-20.md) |
| Ratenmonitoring mit Wiedervorlagen | [konto/ratenmonitoring-kulanz.md](konto/ratenmonitoring-kulanz.md) |
| Unterzeichnete Bestätigung des Kulanzplans | [korrespondenz/ratenplan-bestaetigung-unterzeichnet.md](korrespondenz/ratenplan-bestaetigung-unterzeichnet.md) |
| Bankinformation zu den nicht ausgeführten Zahlungen Mai und Juni | [bank/ruecklastschrift-mai-juni-2026.md](bank/ruecklastschrift-mai-juni-2026.md) |
| Telefonnotiz zum neuen Dauerauftrag und Kulanzvorschlag | [hausverwaltung/telefonnotiz-dauerauftrag-kulanz.md](hausverwaltung/telefonnotiz-dauerauftrag-kulanz.md) |
| Treasury bestätigt einen erneut übersandten Zahlungsbeleg | [zahlung/email-treasury-belegdublette-2026-07-22.md](zahlung/email-treasury-belegdublette-2026-07-22.md) |

## Aufgabe für die Skills

Der Nachlauf vom 22.07.2026 enthält eine erneut übersandte Buchungsanzeige zur ersten Rate. Erwartet sind genau eine Anrechnung von 1.000,00 EUR, ein verbleibender Juni-Rückstand von 1.000,00 EUR und die Kontrolle der Augustzahlungen. Die Zahl der Belegdateien darf den Zahlungssaldo nicht verändern. [Treasury-Nachricht zur Belegdublette](zahlung/email-treasury-belegdublette-2026-07-22.md)

1. SAP- und Mietkonto-Daten strukturieren.
2. Rückstandshöhe und Kündigungsrisiko prüfen.
3. Kulanzoption mit Frist, Widerrufsvorbehalt und Kontrolltermin ausarbeiten.
4. Bei Nichtzahlung den nächsten Eskalationsschritt vorbereiten.
