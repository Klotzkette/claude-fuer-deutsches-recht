# Bankbestätigung Kontowechsel

## 1 Kundendaten

| Feld | Inhalt |
|---|---|
| Institut | Nordufer Direktbank AG |
| Kundin | Jana Lange |
| Schreiben vom | 06.07.2026 |
| Referenz | KW-2026-771804 |

## 2 Bestätigung

Wir bestätigen, dass das neue Girokonto von Frau Jana Lange am 28.04.2026 eröffnet wurde. Der durch unseren Kontowechselservice importierte Dauerauftrag mit dem Empfänger „Wohnen Berlin Immobilien GmbH“ wurde wegen eines unvollständigen Ausführungstermins nicht aktiviert.

Der Fehlerhinweis wurde der Kundin am 04.05.2026 im elektronischen Postfach bereitgestellt. Ein automatischer Nachversand per Brief erfolgte nicht. Am 06.07.2026 wurde ein neuer monatlicher Dauerauftrag über 1.000,00 EUR mit erster Ausführung zum 03.08.2026 eingerichtet.

Diese Bestätigung enthält keine Aussage darüber, ob Einzelüberweisungen für Mai oder Juni 2026 beauftragt wurden.

Nordufer Direktbank AG

Kundenservice Kontowechsel
