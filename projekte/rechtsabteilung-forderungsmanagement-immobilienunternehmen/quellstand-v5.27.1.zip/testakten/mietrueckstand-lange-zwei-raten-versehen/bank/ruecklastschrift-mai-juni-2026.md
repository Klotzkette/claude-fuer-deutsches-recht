# Umsatz- und Rückgabeinformation

Nordstadt Direktbank AG

Privatkundenservice

Dokument erstellt am 08.06.2026

## 1. Kontobezug

| Feld | Inhalt |
|---|---|
| Kontoinhaberin | Jana Lange |
| Altes Konto | DE** **** **** 7712 |
| Schließungsdatum | 30.04.2026 |
| Neues Konto | DE** **** **** 4089 |
| Referenz | NSD-2026-884103 |

## 2. Dauerauftrag

Der auf dem alten Konto gespeicherte Dauerauftrag an die Wohnen Berlin Immobilien GmbH wurde mit der Kontoschließung beendet. Eine automatische Übertragung auf das neue Konto erfolgte nicht.

| Vorgesehener Termin | Betrag | Ergebnis |
|---|---:|---|
| 02.05.2026 | 1000,00 EUR | nicht ausgeführt, Ursprungskonto geschlossen |
| 01.06.2026 | 1000,00 EUR | kein aktiver Dauerauftrag auf dem neuen Konto |

Es handelt sich nicht um Rückgaben einer bereits beim Empfänger gutgeschriebenen Lastschrift. Die Bank hat für beide Termine keine Zahlung an die Vermieterin ausgeführt.

## 3. Neuer Auftrag

Am 07.06.2026 wurde über das Onlinebanking ein neuer Dauerauftrag über 1000,00 EUR mit erstmaliger Ausführung zum 01.07.2026 eingerichtet. Überweisungen für Mai und Juni 2026 waren darin nicht enthalten.

Dieses Schreiben bestätigt technische Kontovorgänge. Es enthält keine Aussage zu den Verpflichtungen aus dem Mietverhältnis.

Nordstadt Direktbank AG

Privatkundenservice
