# Nordbank Berlin

## Kontoauszug Nr. 07/2026 — gekürzte Kundenkopie

**Kontoinhaberin:** Jana Lange

**Abrechnungszeitraum:** 01.07.2026 bis 21.07.2026

**IBAN:** DE** **** **** **** 6402 11

**Erstellt:** 21.07.2026, 06:18 Uhr

Die nachstehende Kopie wurde von der Kontoinhaberin für die Wohnen Berlin Immobilien GmbH erstellt. Nicht fallbezogene Umsätze und der Kontostand wurden von ihr geschwärzt. Die Bank hat die Schwärzungen nicht vorgenommen.

| Buchung | Wertstellung | Buchungstext | Betrag |
|---|---|---|---:|
| 03.07.2026 | 03.07.2026 | SEPA-Überweisung WBI, Miete Juli 2026, MV 2021-01877 | -1000,00 EUR |
| 06.07.2026 | 06.07.2026 | Einrichtung Dauerauftrag WBI, monatlich, erste Ausführung 03.08.2026 | 0,00 EUR |
| 20.07.2026 | 20.07.2026 | SEPA-Überweisung WBI, Rate 1 Mai 2026, MV 2021-01877 | -1000,00 EUR |

## Umsatzdetails zur Zahlung vom 20.07.2026

| Feld | Inhalt |
|---|---|
| Empfängerin | Wohnen Berlin Immobilien GmbH |
| Empfänger-IBAN | DE47 1009 0000 0123 4567 89 |
| End-to-End-Referenz | NL-200726-410088 |
| Status | ausgeführt |
| Ausführungszeit | 20.07.2026, 07:14 Uhr |
| Verwendungszweck | RATE 1 MAI 2026 MV 2021 01877 |

Der Kontoauszug belegt die laufende Julimiete, die erste Rückstandsrate und die Einrichtung eines Dauerauftrags ab August. Er enthält keine Ausführung der für den 05.08.2026 vereinbarten zweiten Rückstandsrate; diese Zahlung liegt außerhalb des Abrechnungszeitraums und ist gesondert zu kontrollieren.

Nordbank Berlin

Elektronischer Kontoauszug — ohne Unterschrift gültig
