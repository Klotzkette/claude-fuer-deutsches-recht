# Tilgungsjournal Krüger

## 1 Rechenstand 15.06.2026

| Forderungsbestandteil | Ausgangsbetrag | Zinslauf bis 15.06.2026 | Zahlung | Rest |
|---|---:|---:|---:|---:|
| Festgesetzte Kosten KFB | 381,00 EUR | 2,62 EUR | 381,00 EUR | 0,00 EUR Kostenhauptforderung |
| Zinsen aus KFB | 0,00 EUR | 2,62 EUR | 2,62 EUR | 0,00 EUR |
| Zinsen aus vier Mietforderungen | 0,00 EUR | 97,77 EUR | 97,77 EUR | 0,00 EUR bis Stichtag |
| Hauptforderung Versäumnisurteil | 3240,00 EUR | 0,00 EUR | 18,61 EUR | 3221,39 EUR |
| Summe | 3621,00 EUR | 100,39 EUR | 500,00 EUR | 3221,39 EUR zuzüglich weiterer Zinsen |

## 2 Zinsparameter

| Zeitraum | Basiszinssatz im System | Vertrags- oder Titelaufschlag | Rechenzins |
|---|---:|---:|---:|
| bis 15.06.2026 | 1,27 Prozent | 5 Prozentpunkte | 6,27 Prozent p. a. |

Die Zinsen aus der Hauptforderung wurden für jede Teilforderung von 810,00 EUR ab dem im Urteil genannten Beginn bis zum Zahlungstag getrennt gerechnet. Rundungsdifferenzen werden erst im abschließenden Forderungskonto ausgeglichen.

## 3 Fortschreibung

Ab 16.06.2026 läuft der titulierte Zins auf die verbliebene Hauptforderung von 3.221,39 EUR weiter. Vollstreckungskosten werden erst nach tatsächlicher Entstehung mit Beleg aufgenommen.
