# Mietkonto FBL5N

**Debitor:** D-518772
**Vertrag:** WBI-MV-2021-01455
**Zeitraum:** 01.11.2025 bis 20.08.2026
**Export:** FI-CA Einzelpostenliste, 20.08.2026, 09:18 Uhr

## Buchungsjournal

| Buchungsdatum | Beleg | Periode | Soll | Ist | Buchungstext | Saldo |
|---|---|---|---:|---:|---|---:|
| 05.11.2025 | 84011003 | 11 2025 | 810,00 | 0,00 | Miete November 2025 offen, Lastschrift widerrufen | 810,00 |
| 03.12.2025 | 84012003 | 12 2025 | 810,00 | 0,00 | Miete Dezember 2025 offen | 1620,00 |
| 06.01.2026 | 84001003 | 01 2026 | 810,00 | 0,00 | Miete Januar 2026 offen | 2430,00 |
| 04.02.2026 | 84002003 | 02 2026 | 810,00 | 0,00 | Miete Februar 2026 offen | 3240,00 |
| 01.03.2026 | 84003001 | 03 2026 | 0,00 | 0,00 | März 2026 als Nutzungsentschädigung in Objektakte gebucht | 3240,00 |
| 28.04.2026 | 86004020 | Titel | 0,00 | 0,00 | Versäumnisurteil 9 C 118/26 rechtskräftig, OP-Kennzeichen tituliert | 3240,00 |
| 10.06.2026 | 86006010 | Kosten | 381,00 | 0,00 | Festgesetzte Kosten laut KFB vom 03.06.2026 | 3621,00 |
| 15.06.2026 | 85006150 | Eingang | 0,00 | 500,00 | Überweisung Daniel Krüger, Verwendungszweck: Miete Krüger | 3121,00 |

## OP-Status

| Prüffeld | Ergebnis |
|---|---|
| Titulierte Hauptforderung | 3240,00 EUR (Mieten November 2025 bis Februar 2026) |
| Festgesetzte Kosten | 381,00 EUR laut KFB |
| Zahlungseingang nach Titel | 500,00 EUR am 15.06.2026 |
| Tilgungsbestimmung | Keine; Verwendungszweck nur: Miete Krüger |
| Zinsen | Laufend nach Titel, im System nicht ausgerechnet |
| Letzter Eingang | 15.06.2026, seither kein Eingang |

## Plausibilität

Der Saldo 3121,00 EUR ist ein reiner Buchsaldo ohne Zinsen und ohne fachliche Anrechnungsentscheidung. Die Teilzahlung vom 15.06.2026 ist mangels Tilgungsbestimmung nach § 367 Abs. 1 BGB zunächst auf Kosten, dann auf Zinsen und zuletzt auf die Hauptforderung anzurechnen; das Tilgungsjournal ist vor dem nächsten Vollstreckungsauftrag zu erstellen, damit die Forderungsaufstellung gegenüber Gerichtsvollzieher und Schuldner stimmt.
