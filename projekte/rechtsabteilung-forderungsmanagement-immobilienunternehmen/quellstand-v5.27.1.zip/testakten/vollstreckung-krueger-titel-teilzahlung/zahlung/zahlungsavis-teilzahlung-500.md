# Zahlungsavis Teilzahlung nach Titel

## 1 Buchungsdaten

| Feld | Wert |
|---|---|
| Buchungstag | 15.06.2026 |
| Wertstellung | 15.06.2026 |
| Betrag | 500,00 EUR Haben |
| Auftraggeber | Daniel Krüger |
| Auftraggeber-IBAN | DE89 1005 0000 0567 1234 88 |
| Empfängerkonto | Vollstreckungssammelkonto WBI |
| Verwendungszweck | ohne Angabe |
| Bankreferenz | EREF DK-150626-008144 |
| SAP-Beleg | BA-2026-029911 |

## 2 Import

Der Zahlungseingang wurde wegen fehlender Vertragsnummer zunächst dem allgemeinen Klärungskonto zugeordnet. Die manuelle Zuordnung zur Akte F-2026-00512 erfolgte am 16.06.2026 anhand von Name, Betrag und der im Zahlungsverkehr gespeicherten Absender-IBAN.

Eine Tilgungsbestimmung des Schuldners liegt weder im Verwendungszweck noch in gesonderter Nachricht vor.

## 3 Kontroll- und Sperrvermerk

Die Absender-IBAN entspricht dem bis Oktober 2025 für Mietzahlungen verwendeten Konto. Diese Übereinstimmung genügt für die Zuordnung des Zahlungseingangs zur Person, belegt aber weder den Fortbestand des Kontos noch pfändbares Guthaben. Eine Kontopfändung darf nicht allein auf dieses Avis gestützt werden.

Die Zahlung ist im Vollstreckungsjournal zunächst als ungeklärte Teilzahlung zu führen. Vor Mitteilung eines neuen Forderungsstands sind titulierte Kosten, bis zum Wertstellungstag aufgelaufene Zinsen und Hauptforderung nach § 367 Abs. 1 BGB in dieser Reihenfolge zu verrechnen. Der SAP-Buchsaldo ohne diese Fachverrechnung ist kein vollstreckungsfähiger Forderungsstand.
