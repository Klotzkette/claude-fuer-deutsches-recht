# SAP RE-FX / FI-CA Statusauszug

**System:** SAP S/4HANA RE-FX, Produktivmandant WBI-PRD
**Export:** 20.08.2026, 09:12 Uhr
**Export-ID:** REFX-FICA-20260820-SS87-2OR
**Sachbearbeitung:** Sandra Berger, Forderungsmanagement

## Vertragskopf

| Feld | Wert |
|---|---|
| Buchungskreis | WBI-DE-BER |
| Vertragsnummer | WBI-MV-2021-01455 |
| SAP-Vertragsobjekt | MV-104882-KR |
| Debitor | D-518772 |
| Objekt | 13353-B-SS87-2OR |
| Nutzungseinheit | Seestraße 87, 2. OG rechts |
| Vermieterin | Wohnen Berlin Immobilien GmbH |
| Mieter | Daniel Krüger |
| Vertragsbeginn | 01.06.2021 |
| Vertragsende | 31.03.2026 (fristlose Kündigung, Wohnung zurückgegeben) |
| Status | Beendet, Forderungsakte aktiv |

## Mietkonditionen laut Konditionsblatt (letzter Stand)

| Kondition | Betrag monatlich | Gültig ab | Quelle |
|---|---:|---|---|
| Nettokaltmiete | 590,00 EUR | 01.06.2021 | RE-FX Konditionssatz 100 |
| Betriebskostenvorauszahlung | 130,00 EUR | 01.06.2021 | RE-FX Konditionssatz 210 |
| Heizkostenvorauszahlung | 90,00 EUR | 01.06.2021 | RE-FX Konditionssatz 220 |
| **Bruttowarmmiete** | **810,00 EUR** | 01.06.2021 | Systemsumme |

## Titelstatus im System

| Feld | Wert |
|---|---|
| Titel 1 | Versäumnisurteil AG Wedding vom 07.04.2026, Az. 9 C 118/26 |
| Titulierte Hauptforderung | 3240,00 EUR nebst Zinsen |
| Rechtskraftvermerk | Einspruchsfrist abgelaufen, kein Einspruch |
| Titel 2 | Kostenfestsetzungsbeschluss AG Wedding vom 03.06.2026 |
| Festgesetzte Kosten | 381,00 EUR nebst Zinsen |
| Vollstreckbare Ausfertigungen | Beide Titel mit Klausel, Zustellung nachgewiesen |
| Zahlungseingang nach Titel | 500,00 EUR am 15.06.2026, ohne Tilgungsbestimmung |
| Neue Anschrift Schuldner | Müllerstraße 142, 13353 Berlin (eigene Mitteilung vom 02.04.2026) |

## Offene Posten

| OP-Nr. | Fälligkeit | Text | Soll | Ist | Offen | Status |
|---|---|---|---:|---:|---:|---|
| 26011003 | 05.11.2025 | Miete November 2025 | 810,00 EUR | 0,00 EUR | 810,00 EUR | tituliert |
| 26012003 | 03.12.2025 | Miete Dezember 2025 | 810,00 EUR | 0,00 EUR | 810,00 EUR | tituliert |
| 26001003 | 06.01.2026 | Miete Januar 2026 | 810,00 EUR | 0,00 EUR | 810,00 EUR | tituliert |
| 26002003 | 04.02.2026 | Miete Februar 2026 | 810,00 EUR | 0,00 EUR | 810,00 EUR | tituliert |
| KFB-0626 | 10.06.2026 | Festgesetzte Kosten laut KFB | 381,00 EUR | 0,00 EUR | 381,00 EUR | tituliert |
| ZE-0615 | 15.06.2026 | Zahlungseingang ohne Tilgungsbestimmung | 0,00 EUR | 500,00 EUR | -500,00 EUR | zu verrechnen |
| **Summe vor Verrechnung** | | | **3621,00 EUR** | **500,00 EUR** | **3121,00 EUR** | zzgl. Zinsen |

## Bearbeitungshinweis

Beide Titel liegen mit Vollstreckungsklausel und Zustellnachweis vor. Die Teilzahlung vom 15.06.2026 trägt keine Tilgungsbestimmung und ist im System noch nicht verrechnet; die Anrechnungsreihenfolge nach § 367 BGB ist vor jedem Forderungsupdate fachlich festzulegen. Seit der Teilzahlung ist kein weiterer Eingang gebucht. Akte auf rot, Vollstreckungsstrategie erstellen und Wiedervorlage setzen.
