# Protokoll des Gerichtsvollziehers

## 1 Auftrag

| Feld | Inhalt |
|---|---|
| DR-Nummer | DR II 1441/26 |
| Gläubigerin | Wohnen Berlin Immobilien GmbH |
| Schuldner | Daniel Krüger |
| Anschrift | Müllerstraße 142, 13353 Berlin |
| Termin | 14.07.2026, 17:10 Uhr |

## 2 Vollstreckungsversuch

Der Schuldner wurde in der Wohnung angetroffen. Eine sofortige Zahlung erfolgte nicht. Der Schuldner erklärte, er sei seit Juni nur unregelmäßig als Veranstaltungstechniker beschäftigt und könne derzeit höchstens 100,00 EUR monatlich zahlen. Belege wurden nicht vorgelegt.

Pfändbare bewegliche Sachen wurden bei der überschlägigen Besichtigung nicht festgestellt. Die vorhandenen Möbel und Haushaltsgeräte erschienen dem gewöhnlichen persönlichen Gebrauch zu dienen. Eine abschließende Bewertung weiterer Vermögenswerte war im Termin nicht möglich.

Der Schuldner gab an, sein Konto werde als Pfändungsschutzkonto geführt. Den Namen seiner Bank nannte er mündlich, wollte ihn aber nicht schriftlich bestätigen. Eine Zahlungskarte mit Termin zum 28.07.2026 wurde ausgehändigt.

## 3 Weiteres Verfahren

Für den Fall ausbleibender Zahlung wurde der Schuldner auf den bereits beantragten Termin zur Abgabe der Vermögensauskunft hingewiesen. Eine Ratenzahlungsvereinbarung wurde im Termin nicht geschlossen.
