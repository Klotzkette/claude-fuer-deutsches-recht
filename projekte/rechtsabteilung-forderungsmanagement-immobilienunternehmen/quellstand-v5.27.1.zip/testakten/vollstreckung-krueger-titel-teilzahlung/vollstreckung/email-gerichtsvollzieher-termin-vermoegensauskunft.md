# E-Mail-Ausdruck

Von: gv.stelle-wedding@justiz.example

An: vollstreckung@wohnen-berlin.example

Datum: 21.07.2026, 09:06 Uhr

Betreff: DR II 1441/26 / Krüger / Vermögensauskunft

Sehr geehrte Damen und Herren,

nach dem erfolglosen Zahlungsversuch vom 14.07.2026 ist Termin zur Abgabe der Vermögensauskunft auf den 18.08.2026 um 10:20 Uhr bestimmt worden. Die Ladung wird dem Schuldner an der Anschrift Müllerstraße 142, 13353 Berlin, zugestellt.

Bitte teilen Sie bis zum 05.08.2026 mit, falls

1. eine Zahlung eingegangen ist,
2. eine verbindliche Zahlungsvereinbarung geschlossen wurde,
3. der Auftrag eingeschränkt oder zurückgenommen werden soll oder
4. Ihnen eine neuere Anschrift bekannt geworden ist.

Die mündliche Angabe des Schuldners, als Veranstaltungstechniker tätig zu sein, enthält keine hinreichende Arbeitgeberbezeichnung. Ohne weitere Daten wird daraus kein Pfändungsauftrag an einen Drittschuldner abgeleitet.

Diese E-Mail bestätigt noch keine erfolgreiche Zustellung der Terminsladung und keinen Eintrag in das Schuldnerverzeichnis.

Mit freundlichen Grüßen

Geschäftsstelle der Gerichtsvollzieherverteilerstelle

Amtsgericht Wedding
