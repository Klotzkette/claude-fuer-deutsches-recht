# Telefonnotiz Arbeitgeberhinweis

Wohnen Berlin Immobilien GmbH

Vollstreckungsmanagement

## 1. Gesprächsdaten

| Feld | Inhalt |
|---|---|
| Datum | 22.07.2026 |
| Zeit | 13:18 bis 13:23 Uhr |
| Anrufer | männliche Person, Name nicht genannt |
| Aufgenommen von | Sandra Berger |
| Akte | F-2026-00512 |

## 2. Inhalt

Der Anrufer erklärte, Daniel Krüger arbeite gelegentlich für eine Firma mit dem Namen „StageFox“ oder ähnlich. Er könne weder Rechtsform noch Anschrift nennen. Auf Nachfrage erklärte er, Herr Krüger werde häufig nur tageweise für Veranstaltungen eingesetzt.

Der Anrufer wollte nicht mitteilen, woher er die Informationen hat. Eine Rückrufnummer wurde im Display nicht angezeigt. Das Gespräch wurde nach dem Hinweis beendet, dass ohne Identitäts- und Quellenklärung keine weiteren Schuldnerdaten besprochen werden.

## 3. Aktenstatus

Der Hinweis ist unbestätigt. Eine Internetnotiz im DMS nennt mehrere Unternehmen mit ähnlichen Namen, aber keinen belastbaren Bezug zum Schuldner. Es wurde kein Arbeitgeber als Drittschuldner erfasst und keine Kontaktaufnahme veranlasst.

Weiteres Vorgehen erfolgt nur aus einer zulässigen, dokumentierten Auskunftsquelle oder aus der Vermögensauskunft.

Sandra Berger
