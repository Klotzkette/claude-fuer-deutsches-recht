# Einfache Melderegisterauskunft

**Landesamt für Bürger- und Ordnungsangelegenheiten Berlin**
Referat Einwohnerwesen, Zentrale Auskunftsstelle
Friedrichstraße 219, 10969 Berlin

**Auskunftsnummer:** EMA-2026-771009
**Bereitgestellt:** 20.07.2026, 10:14 Uhr
**Übermittlungsweg:** Servicekonto der anfragenden Stelle

## 1 Anfrage

| Feld | Inhalt |
|---|---|
| Anfragende Stelle | Wohnen Berlin Immobilien GmbH |
| Zweck | Vollstreckung aus 9 C 118/26 |
| Gesuchte Person | Daniel Krüger, geboren am 19.09.1989 |
| Anfrage vom | 16.07.2026 |
| Letzte bekannte Anschrift | Seestraße 87, 13353 Berlin |
| Aktenzeichen der anfragenden Stelle | F-2026-00318 / 9 C 118/26 |

Die Person konnte anhand von Familienname, Vorname, Geburtsdatum und letzter bekannter Anschrift eindeutig zugeordnet werden. Die nachstehenden Angaben geben den im Melderegister zum Zeitpunkt der Auskunft gespeicherten Stand wieder.

## 2 Auskunft

| Feld | Ergebnis |
|---|---|
| Aktuelle alleinige Wohnung | Müllerstraße 142, 13353 Berlin |
| Einzugsdatum | 01.04.2026 |
| Frühere Anschrift | Seestraße 87, 13353 Berlin |
| Auskunftssperre | keine gespeichert |
| Sterbedatum | keines gespeichert |

Weitere Anschriften, Familienstand, Staatsangehörigkeit sowie Daten zu Mitbewohnern sind nicht Gegenstand dieser einfachen Melderegisterauskunft. Eine Gewähr dafür, dass die gemeldete Anschrift zugleich den tatsächlichen Aufenthaltsort bezeichnet, wird nicht übernommen.

## 3 Gebührenvermerk

Für die Auskunft wurde eine Gebühr von 10,00 EUR erhoben. Das Kassenzeichen lautet LABO-EMA-2026-771009; die Belastung des hinterlegten Gebührenkontos erfolgte mit Bereitstellung. Dieses Dokument wurde elektronisch erstellt und enthält keine Unterschrift.

**Bearbeitungsvermerk der Auskunftsstelle:** Anfrage und Auskunft wurden unter der Auskunftsnummer für die Dauer der gesetzlichen Nachweisfrist protokolliert. Rückfragen sind ausschließlich unter Angabe der Auskunftsnummer möglich.
