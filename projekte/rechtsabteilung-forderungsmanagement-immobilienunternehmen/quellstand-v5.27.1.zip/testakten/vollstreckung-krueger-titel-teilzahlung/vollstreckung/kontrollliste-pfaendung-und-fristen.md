# Vollstreckungskontrollliste Krüger

## 1 Titel und Voraussetzungen

| Prüffeld | Stand | Quelle | Wiedervorlage |
|---|---|---|---|
| Vollstreckbare Ausfertigung VU | vorhanden | Titeltresor T-2026-018 | vor jeder Entnahme |
| Zustellung VU | 14.04.2026 | Zustellungsurkunde | erledigt |
| Rechtskraft VU | seit 29.04.2026 | Geschäftsstellenvermerk | erledigt |
| Vollstreckbare Ausfertigung KFB | vorhanden | Titeltresor T-2026-018 | vor jeder Entnahme |
| Zustellung KFB | 10.06.2026 | Zustellungsurkunde | erledigt |
| Teilzahlung | 500,00 EUR am 15.06.2026 | Bankavis | verrechnet |
| Aktuelle Anschrift | Müllerstraße 142 | Melderegister | 20.01.2027 prüfen |

## 2 Maßnahmen

| Maßnahme | Status | Nächster Termin | Hinweis |
|---|---|---|---|
| Zahlungsaufforderung nach Titel | fruchtlos | abgeschlossen | Frist 06.07.2026 |
| Gerichtsvollzieherauftrag | erster Versuch erfolgt | 28.07.2026 | Zahlungskarte abwarten |
| Vermögensauskunft | beantragt | Terminmitteilung ausstehend | keine Doppelbeauftragung |
| Drittauskunft | nicht ausgelöst | nach gesetzlichen Voraussetzungen | Schuldnerangabe nicht ungeprüft übernehmen |
| Kontopfändung | nicht beauftragt | nach Kontonachweis und Freigabe | P-Konto-Hinweis dokumentiert |
| Kostenjournal | fortzuschreiben | nach jedem Rücklauf | nur belegte Kosten |

## 3 Datenschutz und Ablage

Meldeauskunft, Bankhinweise und spätere Drittauskünfte bleiben in der zugriffsbeschränkten Vollstreckungsakte. Veraltete Anschriften werden nicht aus dem Bestand gelöscht, sondern mit Gültigkeitszeitraum gekennzeichnet.
