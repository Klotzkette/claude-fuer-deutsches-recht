# Aktennotiz 01 — Vollstreckungsstrategie nach Titel

**Akte:** F-2026-00512 — Wohnen Berlin Immobilien GmbH ./. Krüger
**Verfasserin:** Rechtsfachwirtin Sandra Berger, Forderungsmanagement
**Datum:** 20.08.2026

## 1 Sachstand

Gegen den ehemaligen Mieter Daniel Krüger liegen zwei vollstreckbare Titel vor: das rechtskräftige Versäumnisurteil des Amtsgerichts Wedding vom 07.04.2026 (Az. 9 C 118/26) über 3240,00 EUR nebst gestaffelten Zinsen und der Kostenfestsetzungsbeschluss vom 03.06.2026 über 381,00 EUR nebst Zinsen. Beide Titel sind mit Vollstreckungsklausel versehen und dem Schuldner zugestellt. Am 15.06.2026 ging eine Teilzahlung von 500,00 EUR ohne Tilgungsbestimmung ein. Die Zahlungsaufforderung vom 22.06.2026 mit Frist bis zum 06.07.2026 blieb fruchtlos; der Schuldner hat sich nicht gemeldet.

## 2 Offene Rechenaufgabe Tilgungsjournal

Die Teilzahlung ist mangels Tilgungsbestimmung nach § 367 Abs. 1 BGB zunächst auf die Kosten, dann auf die Zinsen und zuletzt auf die Hauptforderung anzurechnen. Das Tilgungsjournal mit tagesgenauer Zinsberechnung ist noch nicht erstellt; es muss vor dem Vollstreckungsauftrag vorliegen, damit die Forderungsaufstellung gegenüber Gerichtsvollzieher und Schuldner exakt ist. Der Buchsaldo von 3121,00 EUR aus FBL5N ist nur eine Zwischengröße ohne Zinsen und ohne Anrechnungsentscheidung.

## 3 Bekannte Vollstreckungsansätze

Aus dem Mietvertrag ist die frühere Bankverbindung des Schuldners bei der Berliner Sparkasse bekannt (SEPA-Mandat bis Oktober 2025). Ob das Konto noch besteht und ob es als Pfändungsschutzkonto geführt wird, ist nicht bekannt. Die aktuelle Wohnanschrift Müllerstraße 142, 13353 Berlin, stammt aus der eigenen Mitteilung des Schuldners vom 02.04.2026. Ein Arbeitgeber ist nicht bekannt. Anhaltspunkte für ein Insolvenzverfahren liegen nicht vor; eine aktuelle Abfrage ist vor dem Vollstreckungsauftrag zu dokumentieren.

## 4 Strategie

Erster Schritt ist der Vollstreckungsauftrag an die zuständige Gerichtsvollzieherverteilerstelle mit dem amtlichen Formular, kombiniert mit dem Auftrag zur gütlichen Erledigung und zur Abnahme der Vermögensauskunft nach § 802c ZPO. Eine Kontopfändung auf die nur historisch bekannte Bankverbindung wird erst nach dem Ergebnis der Vermögensauskunft entschieden, weil ein ins Leere gehender Pfändungs- und Überweisungsbeschluss Kosten ohne Erkenntnisgewinn erzeugt. Drittauskünfte nach § 802l ZPO kommen erst in Betracht, wenn der Schuldner die Vermögensauskunft nicht abgibt oder die Auskunft keine Befriedigung erwarten lässt; die gesetzlichen Voraussetzungen sind vor dem Antrag zu dokumentieren.

## 5 Datenschutz und Aufbewahrung

Die Vollstreckungstitel unterliegen der dreißigjährigen Verjährung nach § 197 Abs. 1 Nr. 3 BGB und werden mit gesonderter Aufbewahrungsfrist im Titeltresor geführt. Der Datenschutz-Vermerk für die Vollstreckungsphase ist zu erstellen; eine Auskunftei-Meldung ist nicht Standard und nur nach Freigabe durch den Datenschutzbeauftragten zulässig.

## 6 Nächste Schritte und Wiedervorlage

Erstens Tilgungsjournal nach § 367 BGB erstellen und Forderungsaufstellung zum Stichtag berechnen. Zweitens Insolvenz- und Schuldnerverzeichnisabfrage dokumentieren. Drittens Vollstreckungsauftrag mit Vermögensauskunft vorbereiten und zur fachlichen Freigabe vorlegen. Viertens Wiedervorlage auf den 21.09.2026 setzen und das Vollstreckungsmonitoring mit Tilgungsjournal, Kostenkonto und Fristenkontrolle beginnen.
