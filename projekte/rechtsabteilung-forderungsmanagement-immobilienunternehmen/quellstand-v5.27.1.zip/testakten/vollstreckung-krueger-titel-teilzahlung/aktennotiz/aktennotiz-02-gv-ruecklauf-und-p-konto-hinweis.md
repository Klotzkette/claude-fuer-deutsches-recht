# Aktennotiz 02 - Rücklauf Gerichtsvollzieher und Kontohinweis

Wohnen Berlin Immobilien GmbH

Forderungsmanagement

Bearbeiterin: Sandra Berger

Datum: 18.09.2026

## Rücklauf

Der Gerichtsvollzieher teilt telefonisch mit, dass unter der bekannten Anschrift niemand geöffnet habe. Eine Benachrichtigung sei eingeworfen worden. Eine Terminankündigung zur Abgabe der Vermögensauskunft sei vorbereitet, aber noch nicht zugestellt.

## Kontohinweis

Aus früheren Mietzahlungen ist eine Bankverbindung bekannt. Es gibt zugleich einen telefonischen Hinweis der ehemaligen Hausverwaltung, dass das Konto möglicherweise als Pfändungsschutzkonto geführt wird. Kein Beleg in der Akte.

## Arbeitsstand

Keine freie Recherche nach Arbeitgeber oder Konten. Weitere Drittauskünfte nur über den gesetzlich zulässigen Vollstreckungsweg und erst nach Prüfung der Voraussetzungen. Teilzahlung bleibt im Tilgungsjournal offen zu verrechnen, solange keine andere Tilgungsbestimmung nachweisbar ist.
