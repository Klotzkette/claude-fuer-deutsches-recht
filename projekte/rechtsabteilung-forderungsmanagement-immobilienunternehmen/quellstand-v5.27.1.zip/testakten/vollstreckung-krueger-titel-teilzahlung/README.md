# Testakte 8 — Vollstreckung nach Titel Krüger Wedding


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 72 KB) | PDF | [testakte-vollstreckung-krueger-titel-teilzahlung-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-vollstreckung-krueger-titel-teilzahlung-gesamt.pdf) | [`gesamt-pdf/vollstreckung-krueger-titel-teilzahlung_gesamt.pdf`](gesamt-pdf/vollstreckung-krueger-titel-teilzahlung_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-vollstreckung-krueger-titel-teilzahlung.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-vollstreckung-krueger-titel-teilzahlung.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-vollstreckung-krueger-titel-teilzahlung-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-vollstreckung-krueger-titel-teilzahlung-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Kostenfestsetzung, Titelverwaltung, Teilzahlung, Tilgungsjournal, Vollstreckungsauftrag und Monitoring |
| Startskills | `46-kostenfestsetzung-antrag`, `47-kostenbeschluss-pruefen`, `48-titulierte-forderung-vollstrecken`, `49-kontoermittlung-und-drittauskunft`, `50-vollstreckungsakte-monitoring` |
| Kernentscheidung | Welche Forderung bleibt nach Teilzahlung, Zinsen und Kosten offen und welche Vollstreckungsmaßnahme ist zulässig und verhältnismäßig? |
| Besonderheit | GV-Termin und Titelstand steuern die nächste Maßnahme. Der anonyme Arbeitgeberhinweis kam nach dem DMS-Export und bleibt ungeprüfter Nachlauf, nicht sofort verwertbare Drittauskunft. |

Zahlungsklage gewonnen, Kostenfestsetzungsbeschluss erlassen, eine Teilzahlung ohne Tilgungsbestimmung eingegangen — danach Funkstille. Die Akte deckt die Nach-Titel-Phase ab: Kostenfestsetzung, Titelverwaltung, Tilgungsreihenfolge nach § 367 BGB, Vollstreckungsauftrag mit Vermögensauskunft und Monitoring.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Bearbeiterin | Rechtsfachwirtin Sandra Berger |
| Schuldner | Daniel Krüger, geb. 19.09.1989, ehemaliger Mieter |
| Mietobjekt (beendet) | Seestraße 87, 13353 Berlin, 2. OG rechts |
| Neue Anschrift | Müllerstraße 142, 13353 Berlin |
| Bruttowarmmiete (zuletzt) | 810,00 EUR |
| Titel 1 | Versäumnisurteil AG Wedding vom 07.04.2026, Az. 9 C 118/26, über 3240,00 EUR nebst Zinsen |
| Titel 2 | Kostenfestsetzungsbeschluss vom 03.06.2026 über 381,00 EUR nebst Zinsen |
| Zahlungseingang nach Titel | 500,00 EUR am 15.06.2026, ohne Tilgungsbestimmung |
| Aktenzeichen intern | F-2026-00512 |

## Sachverhalt

Der Mieter zahlte die Mieten November 2025 bis Februar 2026 nicht (4 x 810,00 EUR = 3240,00 EUR). Das Mietverhältnis wurde fristlos gekündigt, die Wohnung am 31.03.2026 zurückgegeben. Die Zahlungsklage endete mit rechtskräftigem Versäumnisurteil; die Gerichtskosten von 381,00 EUR wurden per Kostenfestsetzungsbeschluss festgesetzt, eine interne Bearbeitungspauschale wurde vom Gericht zurückgewiesen. Nach einer Teilzahlung von 500,00 EUR ohne Tilgungsbestimmung und fruchtloser Zahlungsaufforderung steht jetzt die Zwangsvollstreckung an.

## Trainingsziel

Diese Akte testet die Nach-Titel-Arbeit: Kostenfestsetzungsantrag und Kostenfestsetzungsbeschluss auswerten (einschließlich zurückgewiesener interner Kosten), Titel mit Klausel und Zustellung verwalten, die Teilzahlung nach § 367 BGB in ein Tilgungsjournal überführen, den Vollstreckungsauftrag mit Vermögensauskunft vorbereiten, Drittauskünfte nur unter den gesetzlichen Voraussetzungen einplanen und das Vollstreckungsmonitoring mit Wiedervorlagen und Datenschutz-Vermerk aufsetzen.

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Wohnraummietvertrag | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Beendigungs- und Kautionsvermerk | [vertrag/beendigungs-und-kautionsvermerk-2026-04-06.md](vertrag/beendigungs-und-kautionsvermerk-2026-04-06.md) |
| Mietkonto FBL5N | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Versäumnisurteil AG Wedding | [titel/versaeumnisurteil-ag-wedding.md](titel/versaeumnisurteil-ag-wedding.md) |
| Kostenfestsetzungsbeschluss | [titel/kostenfestsetzungsbeschluss.md](titel/kostenfestsetzungsbeschluss.md) |
| Kostenfestsetzungsantrag | [korrespondenz/kostenfestsetzungsantrag.md](korrespondenz/kostenfestsetzungsantrag.md) |
| Zahlungsaufforderung nach Titel | [korrespondenz/zahlungsaufforderung-nach-titel.md](korrespondenz/zahlungsaufforderung-nach-titel.md) |
| Aktennotiz Vollstreckungsstrategie | [aktennotiz/aktennotiz-01-vollstreckungsstrategie.md](aktennotiz/aktennotiz-01-vollstreckungsstrategie.md) |
| Aktennotiz GV-Rücklauf und P-Konto-Hinweis | [aktennotiz/aktennotiz-02-gv-ruecklauf-und-p-konto-hinweis.md](aktennotiz/aktennotiz-02-gv-ruecklauf-und-p-konto-hinweis.md) |
| DocuWeb-Exportliste mit Original- und Kopiestatus | [dms/dms-exportliste-vollstreckung.md](dms/dms-exportliste-vollstreckung.md) |
| Zustellungsurkunde des Versäumnisurteils | [titel/zustellungsurkunde-versaeumnisurteil.md](titel/zustellungsurkunde-versaeumnisurteil.md) |
| Rechtskraft- und Klauselvermerk | [titel/rechtskraftvermerk-versaeumnisurteil.md](titel/rechtskraftvermerk-versaeumnisurteil.md) |
| Zahlungsavis der Teilzahlung | [zahlung/zahlungsavis-teilzahlung-500.md](zahlung/zahlungsavis-teilzahlung-500.md) |
| Tilgungsjournal nach der Teilzahlung | [konto/tilgungsjournal-nach-teilzahlung.md](konto/tilgungsjournal-nach-teilzahlung.md) |
| Gerichtsvollzieherprotokoll | [vollstreckung/gerichtsvollzieher-protokoll-2026-07-14.md](vollstreckung/gerichtsvollzieher-protokoll-2026-07-14.md) |
| Melderegisterauskunft | [vollstreckung/meldeauskunft-2026-07-20.md](vollstreckung/meldeauskunft-2026-07-20.md) |
| Kontrollliste Pfändung und Fristen | [vollstreckung/kontrollliste-pfaendung-und-fristen.md](vollstreckung/kontrollliste-pfaendung-und-fristen.md) |
| E-Mail der Gerichtsvollzieherstelle zum Termin der Vermögensauskunft | [vollstreckung/email-gerichtsvollzieher-termin-vermoegensauskunft.md](vollstreckung/email-gerichtsvollzieher-termin-vermoegensauskunft.md) |
| Telefonnotiz mit unbestätigtem Arbeitgeberhinweis | [vollstreckung/arbeitgeberhinweis-telefonnotiz.md](vollstreckung/arbeitgeberhinweis-telefonnotiz.md) |

## Aufgabe für die Skills

1. Titelbestand mit Klausel, Zustellung und Rechtskraft in eine Titelübersicht bringen (`48-titulierte-forderung-vollstrecken`).
2. Kostenfestsetzungsantrag und Kostenfestsetzungsbeschluss abgleichen und den zurückgewiesenen internen Kostenanteil als Lernpunkt dokumentieren (`46-kostenfestsetzung-antrag`, `47-kostenbeschluss-pruefen`).
3. Die Teilzahlung vom 15.06.2026 nach § 367 BGB anrechnen und ein Tilgungsjournal mit tagesgenauer Zinslogik erstellen.
4. Vollstreckungsauftrag mit gütlicher Erledigung und Vermögensauskunft vorbereiten; Kontopfändung und Drittauskunft nur nach Voraussetzungsprüfung (`49-kontoermittlung-und-drittauskunft`).
5. Vollstreckungsmonitoring mit Wiedervorlagen, Kostenkonto, Verjährungskontrolle und Datenschutz-Vermerk aufsetzen (`50-vollstreckungsakte-monitoring`, `32-datenschutz-mieterdaten`).
