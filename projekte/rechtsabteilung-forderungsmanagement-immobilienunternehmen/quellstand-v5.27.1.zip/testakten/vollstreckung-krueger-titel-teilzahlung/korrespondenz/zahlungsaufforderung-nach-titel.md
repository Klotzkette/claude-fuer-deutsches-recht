# Zahlungsaufforderung nach Titel

**Wohnen Berlin Immobilien GmbH** — Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Herrn
Daniel Krüger
Müllerstraße 142
13353 Berlin

Berlin, den 22.06.2026

**In Sachen Wohnen Berlin Immobilien GmbH ./. Krüger — Versäumnisurteil des Amtsgerichts Wedding vom 07.04.2026, Az. 9 C 118/26, und Kostenfestsetzungsbeschluss vom 03.06.2026**

Sehr geehrter Herr Krüger,

gegen Sie liegen zwei vollstreckbare Titel vor: das Versäumnisurteil des Amtsgerichts Wedding vom 07.04.2026 über 3240,00 EUR nebst Zinsen sowie der Kostenfestsetzungsbeschluss vom 03.06.2026 über 381,00 EUR nebst Zinsen. Beide Titel sind Ihnen zugestellt worden.

Ihre Zahlung vom 15.06.2026 in Höhe von 500,00 EUR haben wir erhalten. Da Sie keine Tilgungsbestimmung getroffen haben, wird die Zahlung nach der gesetzlichen Reihenfolge zunächst auf die Kosten, dann auf die Zinsen und zuletzt auf die Hauptforderung angerechnet (§ 367 Abs. 1 BGB). Eine aktuelle Forderungsaufstellung mit dem verbleibenden Gesamtbetrag stellen wir Ihnen auf Anforderung gern zur Verfügung.

Wir fordern Sie auf, den offenen Restbetrag

**bis zum 06.07.2026**

auf das Ihnen bekannte Konto DE47 1009 0000 0123 4567 89 bei der Berliner Volksbank zu zahlen. Sollten Sie den Betrag nicht in einer Summe zahlen können, sprechen Sie uns bitte umgehend wegen einer Ratenzahlungsvereinbarung an.

Geht die Zahlung nicht fristgerecht ein, werden wir ohne weitere Ankündigung die Zwangsvollstreckung einleiten. Dadurch entstehen weitere Kosten (unter anderem Gerichtsvollzieher- und Gerichtskosten), die Sie zusätzlich tragen müssen.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin, Forderungsmanagement
Wohnen Berlin Immobilien GmbH

---

## Zustell- und Reaktionsvermerk der Akte

| Vermerk | Datum | Inhalt |
|---|---|---|
| Versand | 22.06.2026 | Einwurf-Einschreiben, Beleg in DMS |
| Fristablauf | 06.07.2026 | Kein Zahlungseingang |
| Reaktion des Schuldners | Keine | Auch kein Ratenzahlungsangebot |
