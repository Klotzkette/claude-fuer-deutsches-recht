# Kostenfestsetzungsantrag

**Wohnen Berlin Immobilien GmbH** — Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

An das
Amtsgericht Wedding
Brunnenplatz 1
13357 Berlin

Berlin, den 05.05.2026

**Geschäftsnummer: 9 C 118/26**
**Wohnen Berlin Immobilien GmbH ./. Krüger**

## Antrag

In dem oben bezeichneten Rechtsstreit beantragen wir, die von dem Beklagten an die Klägerin zu erstattenden Kosten auf Grundlage des Versäumnisurteils vom 07.04.2026 festzusetzen und ab Eingang dieses Antrags mit fünf Prozentpunkten über dem Basiszinssatz zu verzinsen (§ 104 Abs. 1 Satz 2 ZPO).

## Kostenaufstellung

| Nr. | Position | Beleg | Betrag |
|---|---|---|---:|
| 1 | Gerichtskosten (Vorschuss auf die Verfahrensgebühr) | Gerichtskostenrechnung vom 24.02.2026, gezahlt am 26.02.2026 | 381,00 EUR |
| 2 | Interne Bearbeitungspauschale Forderungsmanagement | Kostenstellenvermerk | 40,00 EUR |
| | **Summe** | | **421,00 EUR** |

Die Klägerin ist im Rechtsstreit durch eigene Mitarbeiterinnen des Konzernrechtsdienstes aufgetreten; Rechtsanwaltsgebühren sind nicht entstanden und werden nicht geltend gemacht.

Wir bitten um Übersendung des Kostenfestsetzungsbeschlusses mit vollstreckbarer Ausfertigung.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin, Forderungsmanagement
Wohnen Berlin Immobilien GmbH

---

## Interner Hinweis der Akte

Die Position Nr. 2 wurde vom Gericht im Kostenfestsetzungsbeschluss vom 03.06.2026 zurückgewiesen. Der Vorgang ist als Lernpunkt dokumentiert: Interner Personal- und Verwaltungsaufwand der Partei ist nicht erstattungsfähig und gehört nicht in den Kostenfestsetzungsantrag.
