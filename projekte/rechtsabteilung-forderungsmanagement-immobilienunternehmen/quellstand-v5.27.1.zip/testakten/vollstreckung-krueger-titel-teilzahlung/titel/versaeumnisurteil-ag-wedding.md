# Versäumnisurteil

**Amtsgericht Wedding**
Brunnenplatz 1, 13357 Berlin

**Geschäftsnummer:** 9 C 118/26
**Verkündet am:** 07.04.2026

## Rubrum

In dem Rechtsstreit

**der Wohnen Berlin Immobilien GmbH,** vertreten durch den Geschäftsführer Dr. Markus Lehmann, Friedrichstraße 99, 10117 Berlin,

— Klägerin —

**gegen**

**Herrn Daniel Krüger,** Müllerstraße 142, 13353 Berlin,

— Beklagter —

hat das Amtsgericht Wedding durch die Richterin am Amtsgericht Dr. Sommerfeld am 07.04.2026 aufgrund der mündlichen Verhandlung, zu der der Beklagte trotz ordnungsgemäßer Ladung nicht erschienen ist, für Recht erkannt:

## Tenor

1. Der Beklagte wird verurteilt, an die Klägerin 3240,00 EUR nebst Zinsen in Höhe von fünf Prozentpunkten über dem Basiszinssatz aus jeweils 810,00 EUR seit dem 06.11.2025, dem 04.12.2025, dem 07.01.2026 und dem 05.02.2026 zu zahlen.

2. Der Beklagte trägt die Kosten des Rechtsstreits.

3. Das Urteil ist vorläufig vollstreckbar.

Von der Darstellung des Tatbestands und der Entscheidungsgründe wird gemäß § 313b Abs. 1 ZPO abgesehen.

## Rechtsbehelfsbelehrung

Gegen dieses Versäumnisurteil kann binnen einer Notfrist von zwei Wochen ab Zustellung Einspruch beim Amtsgericht Wedding eingelegt werden.

Dr. Sommerfeld
Richterin am Amtsgericht

---

## Zustell- und Rechtskraftvermerke (Aktenexemplar)

| Vermerk | Datum | Beleg |
|---|---|---|
| Zustellung an den Beklagten | 14.04.2026 | Zustellungsurkunde Bl. 41 d. A. |
| Ablauf der Einspruchsfrist | 28.04.2026 | Fristenblatt Forderungsmanagement |
| Einspruch | Nicht eingelegt | Geschäftsstellenauskunft vom 30.04.2026 |
| Vollstreckbare Ausfertigung mit Klausel | Erteilt am 05.05.2026 | Original im Titeltresor, Fach T-2026-018 |
