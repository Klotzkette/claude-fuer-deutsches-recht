# Kostenfestsetzungsbeschluss

**Amtsgericht Wedding**
Brunnenplatz 1, 13357 Berlin

**Geschäftsnummer:** 9 C 118/26
**Beschluss vom:** 03.06.2026

## Rubrum

In dem Rechtsstreit

**Wohnen Berlin Immobilien GmbH ./. Krüger**

hat das Amtsgericht Wedding durch die Rechtspflegerin Behrend am 03.06.2026 beschlossen:

## Tenor

1. Die von dem Beklagten an die Klägerin nach dem Versäumnisurteil vom 07.04.2026 zu erstattenden Kosten werden auf **381,00 EUR** nebst Zinsen in Höhe von fünf Prozentpunkten über dem Basiszinssatz seit dem 06.05.2026 festgesetzt.

2. Der weitergehende Antrag wird zurückgewiesen.

## Gründe

Die Festsetzung beruht auf § 104 ZPO. Berücksichtigt wurden die von der Klägerin verauslagten Gerichtskosten in Höhe von 381,00 EUR gemäß Gerichtskostenrechnung vom 24.02.2026. Die geltend gemachte interne Bearbeitungspauschale von 40,00 EUR ist nicht erstattungsfähig, weil eigener Personal- und Verwaltungsaufwand der Partei nicht zu den Kosten des Rechtsstreits im Sinne des § 91 ZPO gehört. Die Verzinsung folgt aus § 104 Abs. 1 Satz 2 ZPO ab Eingang des Festsetzungsantrags am 06.05.2026.

## Rechtsbehelfsbelehrung

Gegen diesen Beschluss ist die sofortige Beschwerde statthaft, wenn der Wert des Beschwerdegegenstands 300,00 EUR übersteigt (§ 567 Abs. 2 ZPO). Sie ist binnen einer Notfrist von zwei Wochen ab Zustellung beim Amtsgericht Wedding einzulegen.

Behrend
Rechtspflegerin

---

## Zustellvermerke (Aktenexemplar)

| Vermerk | Datum | Beleg |
|---|---|---|
| Zustellung an den Beklagten | 10.06.2026 | Zustellungsurkunde Bl. 58 d. A. |
| Zustellung an die Klägerin | 10.06.2026 | Empfangsbekenntnis Forderungsmanagement |
| Vollstreckbare Ausfertigung mit Klausel | Erteilt am 12.06.2026 | Original im Titeltresor, Fach T-2026-018 |
