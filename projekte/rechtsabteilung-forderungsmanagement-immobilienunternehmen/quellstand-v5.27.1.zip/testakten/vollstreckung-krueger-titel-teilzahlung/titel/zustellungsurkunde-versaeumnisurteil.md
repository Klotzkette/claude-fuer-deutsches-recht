# Zustellungsurkunde Versäumnisurteil

## 1 Schriftstück

| Feld | Inhalt |
|---|---|
| Gericht | Amtsgericht Wedding |
| Geschäftsnummer | 9 C 118/26 |
| Empfänger | Daniel Krüger |
| Anschrift | Müllerstraße 142, 13353 Berlin |
| Schriftstück | Versäumnisurteil vom 07.04.2026 |

## 2 Zustellung

Das Schriftstück wurde am 14.04.2026 um 11:16 Uhr durch Einlegen in den zur Anschrift gehörenden Briefkasten zugestellt. Eine persönliche Übergabe war zuvor nicht möglich. Der Briefkasten war mit „D. Krüger“ beschriftet.

Zustellungsart: Ersatzzustellung durch Einlegen in den Briefkasten.

## 3 Scanvermerk

Eingang der elektronischen Zustellungsurkunde beim Amtsgericht am 14.04.2026. Der Scan in der Konzernakte enthält Vorder- und Rückseite. Auf der Rückseite ist ein Stempelabdruck blass, das Zustellungsdatum bleibt eindeutig lesbar.
