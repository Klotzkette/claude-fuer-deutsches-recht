# Rechtskraft- und Klauselvermerk

## 1 Verfahren

| Feld | Inhalt |
|---|---|
| Gericht | Amtsgericht Wedding |
| Aktenzeichen | 9 C 118/26 |
| Entscheidung | Versäumnisurteil vom 07.04.2026 |
| Zustellung an Beklagten | 14.04.2026 |

## 2 Vermerk der Geschäftsstelle

Gegen das Versäumnisurteil ist bis zum Ablauf des 28.04.2026 kein Einspruch eingegangen. Das Urteil ist seit dem 29.04.2026 rechtskräftig.

Die vorstehende Ausfertigung wurde der Klägerin am 05.05.2026 mit Vollstreckungsklausel erteilt.

Berlin, 05.05.2026

Geschäftsstelle des Amtsgerichts Wedding

## 3 Interner Originalnachweis

Original eingegangen am 06.05.2026 um 10:18 Uhr. Erfasst im Titeltresorjournal unter T-2026-018. Entnahme nur gegen Vier-Augen-Protokoll.
