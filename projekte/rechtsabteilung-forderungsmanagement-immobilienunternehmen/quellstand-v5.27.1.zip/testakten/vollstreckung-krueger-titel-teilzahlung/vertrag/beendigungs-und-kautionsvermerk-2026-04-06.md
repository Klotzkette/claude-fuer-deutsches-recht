# Beendigungs- und Kautionsvermerk

Wohnen Berlin Immobilien GmbH

Bestandsmanagement Wedding

**Vertragsnummer:** WBI-MV-2021-01455

**Ehemaliger Mieter:** Daniel Krüger, geboren am 19.09.1989

**Wohnung:** Seestraße 87, 13353 Berlin, 2. OG rechts

**Bearbeitungsstand:** 06.04.2026

## 1. Vertragsende und Rückgabe

Das Mietverhältnis wurde mit Schreiben vom 10.02.2026 wegen der offenen Mieten November 2025 bis Februar 2026 fristlos und hilfsweise ordentlich gekündigt. Herr Krüger räumte die Wohnung und übergab sie am 31.03.2026 an die Objektbetreuerin. Das gesonderte Rückgabeprotokoll verzeichnet drei zurückgegebene Schlüssel; ein Haus- und Wohnungsschlüssel sowie ein Briefkastenschlüssel fehlten.

Die Wohnung war geräumt. Im Wohnzimmer war das Türblatt an der Schlossseite ausgebrochen. Die zentrale Schließanlage musste nicht ersetzt werden; der betroffene Wohnungszylinder und der Briefkastenzylinder wurden am 01.04.2026 ausgetauscht. Zählerstände und erkennbare Schäden sind im Rückgabeprotokoll mit fünf Fotos dokumentiert.

## 2. Kautionsabrechnung

Die zu Vertragsbeginn geleistete Mietsicherheit beträgt 1770,00 EUR. Mit Abrechnung vom 06.04.2026 wurden folgende belegte Gegenforderungen erklärt:

| Position | Beleg | Betrag |
|---|---|---:|
| Austausch Wohnungs- und Briefkastenzylinder einschließlich Schlüssel | Rechnung SI-2026-4418 vom 01.04.2026 | 286,40 EUR |
| Ersatz Türblatt Wohnzimmer nach Zeitwertabzug | Rechnung TB-2026-771 vom 03.04.2026 | 492,60 EUR |
| Fällige Nachzahlung aus Betriebskostenabrechnung 2025 | Abrechnung vom 02.04.2026 | 991,00 EUR |
| **Summe** |  | **1770,00 EUR** |

Die Kaution ist damit rechnerisch aufgebraucht. Die Abrechnung wurde am 06.04.2026 an die neue, vom Mieter mitgeteilte Anschrift Müllerstraße 142, 13353 Berlin versandt. Ein Widerspruch ist bis zum Stand dieses Vermerks nicht eingegangen.

## 3. Abgrenzung zur laufenden Zahlungsklage

Die Kautionsabrechnung betrifft ausschließlich Schlüssel, Türblatt und die Betriebskostennachzahlung 2025. Die im Verfahren 9 C 118/26 beim Amtsgericht Wedding geltend gemachten Mietrückstände von 3240,00 EUR für November 2025 bis Februar 2026 sind darin nicht enthalten und wurden durch diese Kautionsverrechnung nicht getilgt. Zum Bearbeitungsstand liegt der Abteilung noch kein Urteil vor. Vor einer späteren Vollstreckung sind der dann vorliegende Titel und sämtliche zwischenzeitlichen Zahlungen gesondert abzugleichen; eine erneute Anrechnung derselben Kaution ist zu vermeiden.

Der Originalmietvertrag bleibt unverändert in der Vertragsakte. Dieser Vermerk ist als nachträgliches Aktenstück der Beendigungsphase abgelegt und nicht Bestandteil der bei Vertragsschluss unterzeichneten Urkunde.

Sandra Berger

Forderungsmanagement
