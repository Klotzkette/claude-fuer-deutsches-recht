# Wohnraummietvertrag

**Vertragsnummer:** WBI-MV-2021-01455
**Objekt:** Seestraße 87, 13353 Berlin, 2. OG rechts
**Ablage:** SAP RE-FX / DMS Vertragsakte

**Parteien**

**Vermieterin**
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin

**Mieter**
Herr Daniel Krüger, geboren am 19.09.1989
Seestraße 87
13353 Berlin

## 1 Mietsache

### 1.1

Vermietet wird die Wohnung Seestraße 87, 13353 Berlin, 2. OG rechts, bestehend aus zwei Zimmern, Küche, Bad, Flur und Kellerraum Nr. 87-2-R.

### 1.2

Die Wohnfläche beträgt **54,00 qm**.

## 2 Mietzeit

Das Mietverhältnis beginnt am **01.06.2021** und läuft auf unbestimmte Zeit.

## 3 Miete und Zahlung

### 3.1

Die monatliche Miete setzt sich wie folgt zusammen:

| Position | Betrag |
|---|---:|
| Nettokaltmiete | 590,00 EUR |
| Betriebskostenvorauszahlung | 130,00 EUR |
| Heizkostenvorauszahlung | 90,00 EUR |
| **Bruttowarmmiete** | **810,00 EUR** |

### 3.2

Die Miete ist monatlich im Voraus spätestens am dritten Werktag des Monats zu zahlen.

### 3.3

Bankverbindung:

| Empfängerin | IBAN | BIC | Institut |
|---|---|---|---|
| Wohnen Berlin Immobilien GmbH | DE47 1009 0000 0123 4567 89 | BEVODEBB | Berliner Volksbank |

### 3.4

Der Mieter hat ein SEPA-Lastschriftmandat erteilt; die Abbuchung erfolgte bis Oktober 2025 vom Konto DE89 1005 0000 0567 1234 88 bei der Landesbank Berlin (Berliner Sparkasse).

## 4 Betriebskosten

Der Mieter trägt die umlagefähigen Betriebskosten gemäß § 2 BetrKV sowie Heizkosten nach der Heizkostenverordnung. Über die Vorauszahlungen wird jährlich abgerechnet.

## 5 Mietsicherheit

Der Mieter leistet eine Mietsicherheit in Höhe von **1770,00 EUR** (drei Nettokaltmieten). Eine Geldsicherheit kann in drei gleichen monatlichen Raten erbracht werden; die erste Rate ist zu Mietbeginn, die weiteren Raten sind mit den beiden folgenden Mietzahlungen fällig. Die Vermieterin legt die Sicherheit getrennt von ihrem Vermögen an. Über geleistete Raten und die Anlage wird gesondert Nachweis erteilt.

## 6 Gebrauch und Obhut

### 6.1

Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Eine Gebrauchsüberlassung an Dritte richtet sich nach den gesetzlichen Vorschriften.

### 6.2

Der Mieter behandelt Wohnung und Gemeinschaftseinrichtungen pfleglich. Schäden, Mängel und Gefahren sind unverzüglich anzuzeigen. Eingriffe in Leitungen, Fassade oder Gebäudetechnik bedürfen der vorherigen Zustimmung.

### 6.3

Zur Prüfung angezeigter Mängel, zu Ablesungen sowie für angekündigte Erhaltungsmaßnahmen ist nach angemessener Terminabstimmung Zutritt zu gewähren. Notfälle bleiben unberührt.

## 7 Hausordnung und Schlüssel

### 7.1

Die Hausordnung regelt insbesondere Ruhezeiten, Treppenhausnutzung, Müllplätze und Gemeinschaftsflächen. Flucht- und Rettungswege sind freizuhalten.

### 7.2

Übergeben wurden zwei Haus- und Wohnungsschlüssel, zwei Briefkastenschlüssel und ein Kellerschlüssel. Nachfertigungen für die Schließanlage bedürfen der Abstimmung mit der Hausverwaltung und sind bei Vertragsende vollständig zurückzugeben.

## 8 Erklärungen zum Zahlungsverkehr

### 8.1

Das SEPA-Lastschriftmandat ist ein Zahlweg und ändert die Fälligkeit der Miete nicht. Der Mieter hat für ausreichende Kontodeckung zu sorgen und den Widerruf oder einen Kontowechsel rechtzeitig mitzuteilen.

### 8.2

Eine Rücklastschrift gilt nicht als Zahlung. Entstehende Fremdkosten können nur im gesetzlich erstattungsfähigen Umfang verlangt werden. Stundungen oder Ratenabreden bedürfen einer gesonderten, eindeutig bezeichneten Vereinbarung.

## 9 Übergabe und Rückgabe

### 9.1

Zustand, Zählerstände und Schlüssel bei Mietbeginn ergeben sich aus dem Übergabeprotokoll vom 28.05.2021. Festgehalten wurden unter anderem Laminat in den Wohnräumen, Fliesen in Küche und Bad sowie Gebrauchsspuren an zwei Innentüren.

### 9.2

Bei Vertragsende ist die Wohnung geräumt, besenrein und mit sämtlichen Schlüsseln zurückzugeben. Über den Rückgabetermin wird ein Protokoll gefertigt. Die Kautionsabrechnung erfolgt getrennt nach Prüfung offener Forderungen und belegter Gegenansprüche.

## 10 Anlagen

1. Übergabeprotokoll vom 28.05.2021
2. Wohnflächenberechnung
3. Hausordnung
4. Betriebskostenkatalog
5. SEPA-Lastschriftmandat
6. Energieausweis zur Einsichtnahme

## 11 Schlussbestimmungen

### 11.1

Änderungen und Ergänzungen dieses Vertrags werden in einer eindeutig bezeichneten Erklärung oder einem Nachtrag dokumentiert. Gesetzlich vorgeschriebene Formen bleiben maßgeblich.

### 11.2

Sollte eine Bestimmung dieses Vertrags unwirksam sein, bleibt der Vertrag im Übrigen wirksam. An die Stelle einer unwirksamen Bestimmung tritt nicht automatisch eine für den Mieter nachteiligere Regelung, sondern das Gesetz.

Berlin, den 12.05.2021

**Wohnen Berlin Immobilien GmbH** — Dr. Markus Lehmann, Geschäftsführer

**Daniel Krüger** — Mieter
