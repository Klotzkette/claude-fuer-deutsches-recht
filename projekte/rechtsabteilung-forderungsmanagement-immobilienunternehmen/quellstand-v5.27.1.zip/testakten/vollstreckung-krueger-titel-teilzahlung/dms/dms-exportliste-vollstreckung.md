# DocuWeb Exportliste Vollstreckung Krüger

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportzeitpunkt | 22.07.2026, 07:38 Uhr |
| Akte | F-2026-00512 |
| Gerichtsaktenzeichen | 9 C 118/26 |
| Titelfach | T-2026-018 |
| Treffer | 21 |

## 2 Dokumentenbestand

| DMS-ID | Datum | Klasse | Indexname | Version | Status |
|---|---|---|---|---:|---|
| DW-701104 | 12.05.2021 | Vertrag | Mietvertrag_Krueger.pdf | 1 | beendet |
| DW-880004 | 31.03.2026 | Objekt | Rückgabeprotokoll_Seestraße.pdf | 1 | zwei Schlüssel fehlen |
| DW-880772 | 06.04.2026 | Vertrag | Beendigungs_und_Kautionsvermerk.pdf | 1 | Kaution nicht auf titulierte Mieten verrechnet |
| DW-884712 | 07.04.2026 | Titel | VU_9C118-26.pdf | 1 | Ausfertigung |
| DW-885551 | 14.04.2026 | Zustellung | ZU_VU_Krueger.pdf | 1 | zugestellt |
| DW-887002 | 30.04.2026 | Gericht | Auskunft_kein_Einspruch.pdf | 1 | E-Mail-Ausdruck |
| DW-887410 | 05.05.2026 | Titel | Klausel_VU.pdf | 1 | Original Titeltresor |
| DW-887900 | 06.05.2026 | Kosten | KFA_Krueger.pdf | 2 | 421,00 EUR beantragt |
| DW-890774 | 03.06.2026 | Titel | KFB_9C118-26.pdf | 1 | 381,00 EUR festgesetzt |
| DW-891004 | 10.06.2026 | Zustellung | ZU_KFB_Krueger.pdf | 1 | zugestellt |
| DW-891771 | 12.06.2026 | Titel | Klausel_KFB.pdf | 1 | Original Titeltresor |
| DW-892118 | 15.06.2026 | Zahlung | Avis_500_Krueger.pdf | 1 | ohne Verwendungszweck |
| DW-892119 | 16.06.2026 | Tabelle | Tilgungsjournal_Krueger.xlsx | 3 | Zinslauf 15.06.2026 |
| DW-893010 | 22.06.2026 | Ausgang | Zahlungsaufforderung_Titel.pdf | 1 | Frist 06.07.2026 |
| DW-895441 | 08.07.2026 | Vollstreckung | GV_Auftrag.pdf | 2 | gütliche Erledigung und VA |
| DW-896003 | 14.07.2026 | Vollstreckung | GV_Protokoll.pdf | 1 | keine Zahlung |
| DW-896771 | 20.07.2026 | Auskunft | Melderegister_Krueger.pdf | 1 | Anschrift bestätigt |
| DW-896990 | 21.07.2026 | Vollstreckung | GV_Termin_Vermoegensauskunft.pdf | 1 | Termin 18.08.2026; Zwischenmitteilung |
| DW-897001 | 21.07.2026 | Notiz | P-Konto_Hinweis.docx | 1 | Quelle nur Schuldnerangabe |
| DW-897220 | 22.07.2026 | Tabelle | Vollstreckungsmonitor.xlsx | 4 | nächste Frist 28.07.2026 |
| DW-897221 | 22.07.2026 | Sonstiges | Titel_Kopie_alt.pdf | 1 | Kopie ohne Klauselseite |

## 3 Originalstand

Die vollstreckbaren Ausfertigungen von Versäumnisurteil und Kostenfestsetzungsbeschluss liegen laut Tresorjournal im Fach T-2026-018. Die Datei DW-897221 ist keine vollständige Vollstreckungsausfertigung und darf nicht als Originalstatus behandelt werden.

## Aktennachlauf am Exporttag

Der anonyme telefonische Arbeitgeberhinweis vom 22.07.2026 um 13:18 Uhr ging
erst nach dem Export um 07:38 Uhr ein. Er ist in der Arbeitsakte als
ungeprüfter Nachlauf erfasst, aber kein belastbarer Drittauskunftsnachweis und
keine Grundlage für eine sofortige Pfändung.
