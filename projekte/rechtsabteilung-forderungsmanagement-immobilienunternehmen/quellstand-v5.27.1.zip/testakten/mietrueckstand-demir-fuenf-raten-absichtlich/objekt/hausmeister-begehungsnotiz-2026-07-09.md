# Begehungsnotiz Donaustraße 38

## 1 Anlass

| Feld | Inhalt |
|---|---|
| Datum | 09.07.2026, 08:35 Uhr |
| Objektbetreuer | Sven Hartwig |
| Anlass | Prüfung allgemeiner Hauszustand nach E-Mail des Mieters |
| Wohnung | 4. OG links, kein vereinbarter Zutritt |

## 2 Feststellungen im Gemeinschaftsbereich

Der Hausflur war trocken und frei begehbar. Im Bereich zwischen 3. und 4. Obergeschoss waren ältere Farbabplatzungen an der Wand vorhanden. Ein akuter Wasseraustritt war nicht sichtbar. Die Treppenhausfenster ließen sich öffnen; zwei Leuchtmittel funktionierten nicht.

Die Wohnung wurde nicht betreten. Durch die geschlossene Wohnungstür waren keine ungewöhnlichen Gerüche wahrnehmbar. Vom Hof aus waren an den Fenstern der Wohnung keine gebrochenen Scheiben zu erkennen. Ob die Fenster dicht schließen, konnte nicht geprüft werden.

## 3 Kontaktversuch

Es wurde um 08:41 Uhr geklingelt. Niemand öffnete. Eine Karte mit der Bitte um Terminvereinbarung wurde in den Briefkasten „C. Demir“ eingeworfen. Eine fotografische Dokumentation des Wohnungsinneren liegt nicht vor.

## 4 Nebenbefund

Die Klingelbeschriftung lautet „C. Demir / E. Kaya“. Eine Person E. Kaya ist im Mietvertrag nicht aufgeführt. Der Nebenbefund wurde an die Hausverwaltung gegeben, ohne eine Wohnnutzung durch diese Person zu unterstellen.
