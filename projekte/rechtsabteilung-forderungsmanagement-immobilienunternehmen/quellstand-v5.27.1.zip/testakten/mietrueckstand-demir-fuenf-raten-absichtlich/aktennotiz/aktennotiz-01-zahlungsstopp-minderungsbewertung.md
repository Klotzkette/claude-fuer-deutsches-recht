# Aktennotiz Nr. 1

Wohnen Berlin Immobilien GmbH
Abteilung Forderungsmanagement
Friedrichstraße 99, 10117 Berlin

Geschäftszeichen:    F-2026-00419
Mietverhältnis:      MV-092144-DE, Donaustraße 38, 12043 Berlin, 4. OG links
Mieter:              Cem Demir
Verfasserin:         Sandra Berger, Renofa, Tel. 030 2055 4810
Datum:               18.07.2026
Betreff:             Bewertung Zahlungsstopp und Minderungsbehauptung; Kündigungsgrundlage

## 1. Anlass

Der Mieter hat mit Schreiben vom 20.05.2026 schriftlich erklärt, ab sofort keine Miete mehr zu zahlen, solange die Vermieterin Modernisierungswünsche nicht erfülle. Seit März 2026 sind fünf Bruttowarmmieten offen. Eine Mahnung vom 12.05.2026 blieb ohne Reaktion. Die Akte ist auf Kündigungstauglichkeit und Klagereife zu prüfen.

## 2. Sachstand

### 2.1 Rückstandshöhe

| Monat | Soll | Zahlung | Saldo |
|---|---:|---:|---:|
| 03 2026 | 1.180,00 | 0,00 | 1.180,00 |
| 04 2026 | 1.180,00 | 0,00 | 2.360,00 |
| 05 2026 | 1.180,00 | 0,00 | 3.540,00 |
| 06 2026 | 1.180,00 | 0,00 | 4.720,00 |
| 07 2026 | 1.180,00 | 0,00 | 5.900,00 |

### 2.2 Mieterklärung

Das Schreiben des Mieters vom 20.05.2026 enthält keine hinreichend konkrete Mängelanzeige. Es benennt weder eine wahrnehmbare Mangelerscheinung noch Zeitraum, Häufigkeit oder konkrete Gebrauchsbeeinträchtigung. Der Mieter verweist pauschal auf allgemeine Unzufriedenheit mit dem Zustand der Wohnung und der Verwaltungsreaktionszeit. Die angekündigten Fotos fehlen. Eine Minderungsquote oder technische Ursache musste er für eine substantiierte Mangelbehauptung allerdings nicht angeben.

### 2.3 Rechtliche Einordnung Minderung

Eine Mietminderung nach § 536 BGB setzt einen Mangel voraus, der die Tauglichkeit zum vertragsgemäßen Gebrauch aufhebt oder mehr als unerheblich mindert. Nach BGH, Urteil vom 29.02.2012 - VIII ZR 155/11 genügt grundsätzlich die Darlegung konkreter Mangelsymptome und ihrer Auswirkungen auf den Mietgebrauch; technische Ursache, exakter Beeinträchtigungsgrad und Minderungsquote sind keine allgemeinen Vortragspflichten. Hier fehlt bereits diese konkrete Beschreibung. Veraltete Fenster oder die bloße Hausfluroptik belegen für sich keine Gebrauchsbeeinträchtigung der Wohnung. Das Ergebnis ist deshalb eine Beleg- und Tatsachenlücke, nicht die Behauptung, eine Minderungsquote sei zwingend vorzutragen.

### 2.4 Kündigungsreife

Mit Ablauf der April-Fälligkeit erreichte der Rückstand zwei volle Monatsmieten. Damit war jedenfalls § 543 Absatz 2 Satz 1 Nummer 3 Buchstabe a BGB erfüllt. Seit der dritten offenen Monatsmiete erstreckt sich der Rückstand über mehr als zwei Termine und erreicht weiterhin zwei Monatsmieten, sodass auch Buchstabe b erfüllt ist. Die hilfsweise ordentliche Kündigung nach § 573 Absatz 2 Nummer 1 BGB ist anhand Verschulden und Erheblichkeit gesondert zu begründen.

## 3. Rechtliche Bewertung

Der Zahlungsstopp ist rechtswidrig. Ein Zurückbehaltungsrecht nach § 273 BGB setzt eine konkrete Gegenforderung voraus; ein pauschaler Verweis auf Unzufriedenheit reicht nicht. Die fristlose Kündigung ist nach § 543 Absatz 2 Nummer 3 BGB zulässig. Die hilfsweise ordentliche Kündigung nach § 573 Absatz 2 Nummer 1 BGB sichert den Räumungsanspruch auch bei Schonfristzahlung ab.

Schonfristzahlungsrisiko besteht: Zahlt das Jobcenter oder ein sonstiger Dritter innerhalb von zwei Monaten nach Rechtshängigkeit der Räumungsklage, wird die fristlose Kündigung nach § 569 Absatz 3 Nummer 2 BGB unwirksam. Die ordentliche Kündigung ist davon nicht erfasst.

## 4. Nächste Schritte

1. Kündigungsschreiben (fristlos, hilfsweise ordentlich) unverzüglich absenden, Zugang per Bote und Einwurf-Einschreiben sichern.
2. Räumungs- und Zahlungsklage vorbereiten; Streitwert Zahlungsantrag 5.900,00 EUR, Räumungsstreitwert 12 Nettokaltmieten nach § 41 Absatz 2 GKG.
3. Wiedervorlage nach Klagezustellung für Schonfrist-Monitoring.

## 5. Eskalation / Vorlage

Zuständig ist wegen der streitwertunabhängigen Sonderzuweisung für Wohnraum das Amtsgericht Neukölln nach § 23 Nummer 2a GVG und § 29a ZPO. Die interne Freigabegrenze und sonstige Eskalationsgründe bleiben getrennt zu prüfen.

(gez.) Sandra Berger
Renofa, Forderungsmanagement
