# E-Mail-Ausdruck Kroll Fenstertechnik GmbH

## 1 Kopfzeilen

| Feld | Inhalt |
|---|---|
| Von | dispo@kroll-fenstertechnik-beispiel.de |
| An | technik-neukoelln@wohnen-berlin-immobilien.de |
| Datum | 15.07.2026, 15:06 Uhr |
| Betreff | TS-2026-18841 / kein Zutritt Donaustraße 38 |

## 2 Nachricht

Guten Tag,

unser Monteur war heute von 13:42 bis 13:57 Uhr am Objekt. Auf Klingeln bei „C. Demir / E. Kaya“ wurde nicht geöffnet. Die im Auftrag angegebene Mobilnummer war nicht erreichbar. Eine Rückrufkarte wurde eingeworfen.

Es konnten weder Fenster noch Bad besichtigt werden. Eine technische Aussage zu Dichtigkeit, Feuchte oder Ursache ist daher nicht möglich. Bitte stimmen Sie vor einer erneuten Disposition ein Zeitfenster mit dem Bewohner ab.

Mit freundlichen Grüßen

Kroll Fenstertechnik GmbH

Disposition

## 3 Anlage

Die E-Mail nennt einen Monteurbericht als Anhang. Im DMS liegt nur der E-Mail-Ausdruck vor; der angekündigte Anhang wurde nicht übernommen.
