# E-Mail-Ausdruck: Fenster, Bad und Fotos

## 1 Kopfzeilen

| Feld | Inhalt |
|---|---|
| Von | Emre Demir, emre.demir@example.net |
| An | forderungsmanagement@wohnen-berlin-immobilien.de |
| Datum | 10.07.2026, 23:18 Uhr |
| Betreff | nochmal wegen Fenster und Bad |
| Nachrichten-ID | ED-100726-2318@example.net |

## 2 Nachricht

Guten Abend,

im Schlafzimmer zieht es am Fenster, besonders wenn es regnet. Im Bad riecht es morgens manchmal feucht. Ich weiß nicht, ob das Schimmel ist, weil man fast nichts sieht. Der Hausflur ist seit Jahren nicht gestrichen. Cem hat das schon öfter dem Hausmeister gesagt.

Die Fotos sind auf einem alten Handy und lassen sich gerade nicht übertragen. Ich kann nächste Woche neue machen. Der Termin am Mittwoch passt vielleicht nicht, weil tagsüber niemand da ist. Bitte rufen Sie vorher an.

Wir bleiben dabei, dass erst etwas gemacht werden muss, bevor wieder die volle Miete gezahlt wird.

Emre

## 3 Anlagen- und Identitätsstatus

Die E-Mail enthält keinen Anhang. Im Mietvertrag ist Cem Demir als alleiniger Mieter eingetragen. Eine Vollmacht von Emre Demir liegt nicht vor. Die Nachricht wurde gleichwohl wegen ihres Sachbezugs zur Objekt- und Forderungsakte genommen.
