# E-Mail des Mieters mit angekündigten Fotos

Von: emre.demir@example.net

An: forderungsmanagement@wohnen-berlin-immobilien.de

Datum: 03.07.2026, 18:06 Uhr

Betreff: Ihre Kündigung

Sehr geehrte Damen und Herren,

ich zahle nicht, weil hier seit Monaten alles schief läuft. Es ist laut, im Bad riecht es manchmal feucht und die Hausverwaltung reagiert nicht. Fotos schicke ich noch, sobald ich sie sortiert habe.

Dass Sie jetzt kündigen, finde ich nicht in Ordnung. Ich habe mehrfach mündlich Bescheid gesagt. Die Nachbarn wissen auch davon.

Mit freundlichen Grüßen

Emre Demir

---

Hinweis Posteingang:

Keine Fotos angehängt. Keine konkrete Datumsangabe zu Mängelanzeigen. Eingang wurde automatisch zusätzlich dem Objektordner "Donaustraße 18 - Allgemein" zugeordnet.
