# Klageentwurf Zahlung und Räumung

An das
**Amtsgericht Neukölln**
Karl-Marx-Straße 77
12043 Berlin

Berlin, 05.08.2026

## Klage

der **Wohnen Berlin Immobilien GmbH**, Friedrichstraße 99, 10117 Berlin, vertreten durch den Geschäftsführer Dr. Markus Lehmann

- Klägerin -

gegen

**Herrn Cem Demir**, Donaustraße 38, 12043 Berlin

- Beklagter -

wegen Zahlung und Räumung

**Streitwert vorläufig: 15.620,00 EUR**
Zahlungsforderung 5900,00 EUR; Räumung 12 x Nettokaltmiete 810,00 EUR = 9720,00 EUR.

## Anträge

Die Klägerin beantragt,

1. den Beklagten zu verurteilen, an die Klägerin **5900,00 EUR** nebst Zinsen in Höhe von fünf Prozentpunkten über dem Basiszinssatz aus jeweils 1180,00 EUR seit dem 05.03.2026, 08.04.2026, 07.05.2026, 04.06.2026 und 04.07.2026 zu zahlen,

2. den Beklagten zu verurteilen, die im Hause Donaustraße 38, 12043 Berlin, 4. OG links gelegene Wohnung, bestehend aus drei Zimmern, Küche, Bad, Flur, Balkon und Kellerraum Nr. 38-L4, zu räumen und an die Klägerin herauszugeben,

3. dem Beklagten die Kosten des Rechtsstreits aufzuerlegen,

4. das Urteil für vorläufig vollstreckbar zu erklären.

## Sachverhalt

Die Parteien sind durch Wohnraummietvertrag vom 24.09.2020 verbunden. Die monatliche Bruttowarmmiete beträgt 1180,00 EUR. Die Miete ist gemäß § 3 des Mietvertrags monatlich im Voraus spätestens am dritten Werktag zu zahlen.

Der Beklagte zahlt seit März 2026 keine Miete mehr. Die Klägerin hat ihn mit Schreiben vom 12.05.2026 unter Fristsetzung zur Zahlung aufgefordert und um konkrete Mitteilung etwaiger Mängel gebeten. Der Beklagte erklärte per E-Mail vom 20.05.2026 lediglich pauschal, er werde wegen des Zustands des Hauses überhaupt keine Miete mehr zahlen. Konkrete Mangelerscheinungen, Zeitraum und Gebrauchsbeeinträchtigung beschrieb er nicht; angekündigte Fotos legte er nicht vor.

Mit Schreiben vom 19.07.2026, zugestellt am 22.07.2026, kündigte die Klägerin das Mietverhältnis fristlos und hilfsweise ordentlich.

## Rechtliche Würdigung

Der Zahlungsanspruch folgt aus § 535 Abs. 2 BGB. Der Beklagte befindet sich aufgrund kalendermäßiger Fälligkeit gemäß § 286 Abs. 2 Nr. 1 BGB in Verzug.

Die fristlose Kündigung ist nach §§ 543 Abs. 2 Satz 1 Nr. 3, 569 Abs. 3 Nr. 1 BGB wirksam. Der Rückstand übersteigt zwei Monatsmieten deutlich.

Ein Minderungsrecht ist nach Aktenlage nicht schlüssig dargelegt. Der Beklagte hat weder konkrete Mangelerscheinungen noch Zeitraum oder Auswirkungen auf den vertragsgemäßen Gebrauch benannt. Eine technische Ursache, den exakten Grad der Beeinträchtigung oder eine bestimmte Minderungsquote müsste er dagegen nach BGH, Urteil vom 29.02.2012 - VIII ZR 155/11 nicht vortragen. Der Räumungsanspruch folgt aus § 546 Abs. 1 BGB.

## Anlagen

| Anlage | Inhalt |
|---|---|
| K1 | Mietvertrag vom 24.09.2020 |
| K2 | Mietkonto FBL5N Stand 05.08.2026 |
| K3 | Letzte Zahlungsaufforderung vom 12.05.2026 mit Zustellnachweis |
| K4 | E-Mail des Beklagten vom 20.05.2026 |
| K5 | Kündigung vom 19.07.2026 mit Zustellungsurkunde |

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH
