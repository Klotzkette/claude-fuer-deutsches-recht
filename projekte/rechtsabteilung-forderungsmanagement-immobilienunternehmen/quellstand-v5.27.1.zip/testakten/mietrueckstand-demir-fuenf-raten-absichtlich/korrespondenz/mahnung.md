# Letzte Zahlungsaufforderung vor Kündigung

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99
10117 Berlin
Abteilung Forderungsmanagement
Bearbeitung: Sandra Berger, Rechtsfachwirtin
Telefon 030 2055 4810

Herrn
Cem Demir
Donaustraße 38
12043 Berlin

Berlin, 12.05.2026

**Mietverhältnis Donaustraße 38, 12043 Berlin, 4. OG links**
**Vertragsnummer WBI-MV-2020-03114**
**Letzte Zahlungsaufforderung wegen Mietrückstand März bis Mai 2026**

Sehr geehrter Herr Demir,

nach dem Mietkonto sind die Mieten für März, April und Mai 2026 nicht eingegangen. Der Rückstand beträgt derzeit:

| Monat | Soll | Zahlung | Offen |
|---|---:|---:|---:|
| März 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| April 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| Mai 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| **Summe** | **3540,00 EUR** | **0,00 EUR** | **3540,00 EUR** |

Die Miete ist nach § 3 des Mietvertrags spätestens am dritten Werktag des Monats fällig. Sie befinden sich daher mit den vorgenannten Beträgen in Verzug.

Bitte zahlen Sie den offenen Betrag bis spätestens **24.05.2026** auf folgendes Konto:

| Empfängerin | IBAN | BIC | Verwendungszweck |
|---|---|---|---|
| Wohnen Berlin Immobilien GmbH | DE47 1009 0000 0123 4567 89 | BEVODEBB | WBI-MV-2020-03114 Rückstand 03-05/2026 |

Sollten Sie der Auffassung sein, dass ein Mangel der Wohnung vorliegt, teilen Sie uns bitte bis zum selben Datum konkret mit:

1. welchen Mangel Sie rügen,
2. seit wann der Mangel besteht,
3. wann und wem Sie den Mangel angezeigt haben,
4. welche Minderungsquote Sie ansetzen,
5. welche Belege oder Fotos vorliegen.

Ein pauschaler Zahlungsstopp ohne konkrete Mängelanzeige und ohne nachvollziehbare Minderungsberechnung wird von uns nicht akzeptiert.

Bleibt die Zahlung aus, prüfen wir ohne weitere Ankündigung die fristlose und hilfsweise ordentliche Kündigung sowie Zahlungs- und Räumungsklage.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH

**Zustellvermerk:** Einwurf-Einschreiben RR 8800 3144 116 DE, Einwurf laut Sendungsstatus am 14.05.2026 um 10:38 Uhr.
