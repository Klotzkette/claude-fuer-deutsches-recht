# Fristlose und hilfsweise ordentliche Kündigung

**Wohnen Berlin Immobilien GmbH**
Friedrichstraße 99
10117 Berlin
Abteilung Forderungsmanagement
Bearbeitung: Sandra Berger, Rechtsfachwirtin

Herrn
Cem Demir
Donaustraße 38
12043 Berlin

Berlin, 19.07.2026

**Mietverhältnis Donaustraße 38, 12043 Berlin, 4. OG links**
**Vertragsnummer WBI-MV-2020-03114**
**Außerordentliche fristlose Kündigung wegen Mietzahlungsverzugs, hilfsweise ordentliche Kündigung**

Sehr geehrter Herr Demir,

namens der Wohnen Berlin Immobilien GmbH kündigen wir das mit Ihnen bestehende Wohnraummietverhältnis über die oben bezeichnete Wohnung

**fristlos aus wichtigem Grund gemäß §§ 543 Abs. 2 Satz 1 Nr. 3, 569 Abs. 3 Nr. 1 BGB**

und vorsorglich

**hilfsweise ordentlich gemäß § 573 Abs. 2 Nr. 1 BGB zum 31.01.2027, hilfsweise zum nächstmöglichen Termin.**

## Rückstand

Zum Zeitpunkt dieser Kündigung bestehen folgende Mietrückstände:

| Monat | Bruttowarmmiete | Zahlung | Offen |
|---|---:|---:|---:|
| März 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| April 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| Mai 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| Juni 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| Juli 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR |
| **Summe** | **5900,00 EUR** | **0,00 EUR** | **5900,00 EUR** |

Der Rückstand übersteigt zwei Monatsmieten deutlich. Die Voraussetzungen einer fristlosen Kündigung wegen Zahlungsverzugs liegen damit vor.

Ihr Schreiben vom 20.05.2026 enthält keine konkrete Beschreibung einer Mangelerscheinung, ihres Zeitraums oder ihrer Auswirkungen auf den Mietgebrauch; die angekündigten Belege fehlen. Eine Minderungsquote müssen Sie nicht vorgeben. Ein pauschaler Zahlungsstopp ohne konkret beschriebene Gebrauchsbeeinträchtigung rechtfertigt die vollständige Nichtzahlung jedoch nicht.

## Räumungsaufforderung

Wir fordern Sie auf, die Wohnung bis spätestens **02.08.2026** vollständig geräumt mit sämtlichen Schlüsseln an die Hausverwaltung zurückzugeben.

## Hinweise

Sie können eine Beratungsstelle oder öffentliche Stelle einschalten. Eine spätere Zahlung kann die fristlose Kündigung unter den Voraussetzungen des § 569 Abs. 3 Nr. 2 BGB unwirksam machen; die hilfsweise ordentliche Kündigung wird dadurch nicht automatisch beseitigt.

Sie können der ordentlichen Kündigung nach §§ 574, 574b BGB widersprechen, wenn deren Beendigung für Sie, Ihre Familie oder einen Angehörigen Ihres Haushalts eine nicht zu rechtfertigende Härte bedeuten würde. Der Widerspruch ist in Textform zu erklären und muss uns grundsätzlich spätestens zwei Monate vor dem Beendigungstermin, hier bis zum 30.11.2026, zugehen.

Mit freundlichen Grüßen

Sandra Berger
Rechtsfachwirtin
Forderungsmanagement
Wohnen Berlin Immobilien GmbH

**Zustellvermerk:** Übergabe an Gerichtsvollzieherbüro Neukölln am 19.07.2026, Zustellung laut Zustellungsurkunde am 22.07.2026.
