# E-Mail des Mieters vom 20.05.2026

**Von:** Cem Demir <cem.demir.private@example.invalid>
**An:** Forderungsmanagement Wohnen Berlin <forderungen@wohnen-berlin-immo.de>
**Betreff:** Re: Mietrückstand Donaustraße 38
**Eingang:** 20.05.2026, 22:17 Uhr

Sehr geehrte Damen und Herren,

ich zahle die Miete ab sofort nicht mehr. Die Wohnung ist alt, die Fenster sind nicht modern, der Hausflur ist hässlich und die Verwaltung antwortet langsam. Solange hier nichts passiert, bekommen Sie gar nichts.

Eine genaue Berechnung mache ich nicht. Sie wissen selbst, was in dem Haus alles schlecht ist. Fotos habe ich gerade nicht, aber das sieht man doch.

Ich werde auch die kommenden Monate einbehalten, bis die Wohnung vollständig modernisiert ist.

Mit freundlichen Grüßen
Cem Demir

## Interner Eingangsstempel

| Prüffeld | Einordnung |
|---|---|
| Konkrete Mängelanzeige | nein |
| Zeitraum benannt | nein |
| Minderungsquote | nein |
| Belege/Fotos | nein |
| Risiko | pauschaler Zahlungsstopp, Kündigungs- und Klageprüfung fortsetzen |
