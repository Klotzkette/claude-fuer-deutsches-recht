# E-Mail-Ausdruck

Von: cem.demir@example.org

An: service@wohnen-berlin.example

Datum: 27.07.2026, 12:48 Uhr

Betreff: Termin heute / Fenster immer noch nicht ausgetauscht

Sehr geehrte Damen und Herren,

der Monteur war heute da und hat nur etwas eingestellt und geölt. Das reicht aus meiner Sicht nicht. Die Fenster sind alt und im Winter zieht es. Ich habe schon mehrfach gesagt, dass sie komplett erneuert werden müssen.

Die Fotos auf meinem Telefon konnte der Monteur sehen. Ich finde die Originaldateien gerade nicht, weil ich im Frühjahr das Telefon gewechselt habe. Vielleicht sind sie noch in meiner Cloud. Sobald ich sie finde, schicke ich sie.

Ich werde die zurückgehaltene Miete nicht vollständig zahlen, solange nicht schriftlich zugesagt ist, dass alle Fenster erneuert werden. Über eine Teilzahlung können wir sprechen, wenn die Dichtung eingesetzt und ein verbindlicher Plan vorgelegt wird.

Bitte schicken Sie mir außerdem das heutige Protokoll. Ich widerspreche der Darstellung, es gebe gar kein Problem.

Mit freundlichen Grüßen

Cem Demir
