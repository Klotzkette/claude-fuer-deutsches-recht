# Mietkonto FBL5N

**Debitor:** D-551902
**Vertrag:** WBI-MV-2020-03114
**Zeitraum:** 01.02.2026 bis 18.07.2026
**Export:** FI-CA Einzelpostenliste, 18.07.2026, 08:45 Uhr

## Buchungsjournal

| Buchungsdatum | Beleg | Periode | Soll | Ist | Buchungstext | Saldo |
|---|---|---|---:|---:|---|---:|
| 04.02.2026 | 51002038 | 02 2026 | 1180,00 | 1180,00 | Miete Februar bezahlt | 0,00 |
| 04.03.2026 | 51003114 | 03 2026 | 1180,00 | 0,00 | Miete März offen | 1180,00 |
| 07.04.2026 | 51004382 | 04 2026 | 1180,00 | 0,00 | Miete April offen | 2360,00 |
| 06.05.2026 | 51005412 | 05 2026 | 1180,00 | 0,00 | Miete Mai offen | 3540,00 |
| 03.06.2026 | 51006501 | 06 2026 | 1180,00 | 0,00 | Miete Juni offen | 4720,00 |
| 03.07.2026 | 51007622 | 07 2026 | 1180,00 | 0,00 | Miete Juli offen | 5900,00 |

## OP-Status

| Prüffeld | Ergebnis |
|---|---|
| Offene Hauptforderung | 5900,00 EUR |
| Offene Nebenforderungen | 0,00 EUR |
| Teilzahlungen | Keine |
| Tilgungsbestimmungen | Keine |
| Stornos/Gutschriften | Keine |
| Verrechnungssperren | Keine |

## Plausibilität

Der Rückstand entspricht fünf vollen Bruttowarmmieten. Es gibt keine technische Ursache wie geänderte Bankverbindung, Rückläufer oder Dublette. Für die fristlose Kündigung ist der Rückstand rechnerisch eindeutig; für die hilfsweise ordentliche Kündigung sind Dauer, Höhe und Vorsatzindizien in der Klage gesondert aufzubereiten.
