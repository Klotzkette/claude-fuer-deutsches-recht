# SAP RE-FX / FI-CA Statusauszug

**System:** SAP S/4HANA RE-FX, Produktivmandant WBI-PRD
**Export:** 18.07.2026, 08:41 Uhr
**Export-ID:** REFX-FICA-20260718-DO38-04L
**Sachbearbeitung:** Sandra Berger, Forderungsmanagement

## Vertragskopf

| Feld | Wert |
|---|---|
| Buchungskreis | WBI-DE-BER |
| Vertragsnummer | WBI-MV-2020-03114 |
| SAP-Vertragsobjekt | MV-092144-DE |
| Debitor | D-551902 |
| Objekt | 12043-B-DO38-04L |
| Nutzungseinheit | Donaustraße 38, 4. OG links |
| Vermieterin | Wohnen Berlin Immobilien GmbH |
| Mieter | Cem Demir |
| Vertragsbeginn | 01.10.2020 |
| Status | Aktiv |

## Mietkonditionen laut Konditionsblatt

| Kondition | Betrag monatlich | Gültig ab | Quelle |
|---|---:|---|---|
| Nettokaltmiete | 810,00 EUR | 01.10.2020 | RE-FX Konditionssatz 100 |
| Betriebskostenvorauszahlung | 210,00 EUR | 01.10.2020 | RE-FX Konditionssatz 210 |
| Heizkostenvorauszahlung | 160,00 EUR | 01.10.2020 | RE-FX Konditionssatz 220 |
| **Bruttowarmmiete** | **1180,00 EUR** | 01.10.2020 | Systemsumme |

## Offene Posten

| OP-Nr. | Fälligkeit | Text | Soll | Ist | Offen | Mahnstufe |
|---|---|---|---:|---:|---:|---|
| 900331-03 | 04.03.2026 | Miete März 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR | 2 |
| 900331-04 | 07.04.2026 | Miete April 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR | 2 |
| 900331-05 | 06.05.2026 | Miete Mai 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR | 2 |
| 900331-06 | 03.06.2026 | Miete Juni 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR | 1 |
| 900331-07 | 03.07.2026 | Miete Juli 2026 | 1180,00 EUR | 0,00 EUR | 1180,00 EUR | 1 |
| **Summe** | | | **5900,00 EUR** | **0,00 EUR** | **5900,00 EUR** | |

## Zahlungs- und Klärungsstatus

| Prüfpunkt | Ergebnis |
|---|---|
| Letzte vollständige Zahlung | 04.02.2026, 1180,00 EUR |
| Lastschriftrückläufer | Keine Rückläufer seit 01.01.2026 |
| Gutschriften/Stornos | Keine offenen Gutschriften oder Stornos |
| Mahnsperre | Nein |
| Mietminderungskennzeichen | Nicht gesetzt |
| Streitkennzeichen | Mieter verweigert Zahlung |
| Wiedervorlage | 19.07.2026, Kündigungsprüfung |

## Bearbeitungshinweis

Der Rückstand beträgt fünf volle Bruttowarmmieten. Im System ist keine konkrete Beschreibung von Mangelerscheinung, Zeitraum und Gebrauchsbeeinträchtigung, keine Buchungsklärung und keine Zahlungsvereinbarung hinterlegt. Eine bestimmte Minderungsquote ist keine notwendige Angabe. Die Akte ist für Kündigungs- und Klageprüfung rot zu markieren; vor Versand sind Vertrag, Kontoauszug und Zustellanschrift nochmals gegen DMS zu prüfen.
