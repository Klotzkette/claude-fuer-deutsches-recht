# Auftragsstatus technische Prüfung

## 1 Vorgang

| Feld | Inhalt |
|---|---|
| Auftrag | TS-2026-18841 |
| Objekt | Donaustraße 38, 4. OG links |
| Gewerk | Fenster und Feuchteprüfung |
| Eröffnet | 11.07.2026 |
| Auftragnehmer | Kroll Fenstertechnik GmbH |
| Status | Zugang nicht erfolgt |

## 2 Verlauf

| Datum | Eintrag |
|---|---|
| 11.07.2026 | Auftrag nach E-Mail-Eingang manuell angelegt. Keine Raumnennung im Ticket. |
| 12.07.2026 | Termin 15.07.2026 zwischen 13 und 15 Uhr per E-Mail angekündigt. |
| 15.07.2026 | Monteur um 13:42 Uhr vor Ort; Klingel und Mobilnummer ohne Antwort. |
| 15.07.2026 | Rückrufkarte eingeworfen. Keine Messung und keine Begutachtung. |
| 31.07.2026 | Zweittermin angefragt; Antwort des Mieters ausstehend. |

## 3 Altsystemsuche

Unter Vertragsnummer WBI-MV-2020-03114 wurden für 2024 bis Juni 2026 keine abgeschlossenen wohnungsbezogenen Fenster- oder Feuchteaufträge gefunden. Im Objekt bestehen mehrere Gemeinschaftsaufträge zum Treppenhausanstrich; sie betreffen nicht ohne Weiteres die Wohnung.
