# Testakte 5 — Fünf offene Mieten Demir Neukölln


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 68 KB) | PDF | [testakte-mietrueckstand-demir-fuenf-raten-absichtlich-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-demir-fuenf-raten-absichtlich-gesamt.pdf) | [`gesamt-pdf/mietrueckstand-demir-fuenf-raten-absichtlich_gesamt.pdf`](gesamt-pdf/mietrueckstand-demir-fuenf-raten-absichtlich_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-mietrueckstand-demir-fuenf-raten-absichtlich.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-demir-fuenf-raten-absichtlich.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-mietrueckstand-demir-fuenf-raten-absichtlich-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietrueckstand-demir-fuenf-raten-absichtlich-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Trainingspfad | Bewusster Zahlungsstopp, rote Ampel, Kündigung, Zahlungsklage und Räumung |
| Startskills | `13-fristlose-kuendigung-zahlungsverzug`, `15-kuendigung-zustellung-nachweis`, `20-zahlungsklage-mietrueckstand-erstellen`, `24-raeumungsklage-erstellen` |
| Kernentscheidung | Liegt eine konkrete Minderungsgrundlage vor oder bleibt es bei unbelegtem Zahlungsdruck des Mieters? |
| Besonderheit | Das technische Protokoll bestätigt Einstellarbeiten, der Mieter verlangt dagegen vollständigen Fensteraustausch. Technische Feststellung, Parteivortrag und fehlende Originalfotos bleiben drei getrennte Quellenlagen. |

Fünf Monatsmieten sind offen. Der Mieter zahlt bewusst nicht und erklärt schriftlich, er werde erst zahlen, wenn die Vermieterin umfassende Modernisierungswünsche erfüllt. Es fehlen konkrete Angaben zu Erscheinungsform, Zeitraum und Gebrauchsbeeinträchtigung sowie angekündigte Belege. Eine bestimmte Minderungsquote oder die technische Mangelursache muss der Mieter dagegen nicht vorgeben.

## Stammdaten

| Feld | Wert |
|---|---|
| Vermieterin | Wohnen Berlin Immobilien GmbH, Friedrichstraße 99, 10117 Berlin |
| Bearbeiterin | Rechtsfachwirtin Sandra Berger |
| Mieter | Cem Demir, geb. 05.11.1988 |
| Mietobjekt | Donaustraße 38, 12043 Berlin, 4. OG links |
| Wohnfläche | 71,40 qm |
| Vertragsbeginn | 01.10.2020 |
| Nettokaltmiete | 810,00 EUR |
| BK-Vorauszahlung | 210,00 EUR |
| HK-Vorauszahlung | 160,00 EUR |
| Bruttowarmmiete | 1180,00 EUR |
| Aktenzeichen intern | F-2026-00419 |

## Sachverhalt

Seit März 2026 wird keine Miete gezahlt. Der Rückstand beträgt fünf Bruttowarmmieten.

| Monat | Soll | Ist | Saldo |
|---|---:|---:|---:|
| 03 2026 | 1180,00 | 0,00 | 1180,00 |
| 04 2026 | 1180,00 | 0,00 | 1180,00 |
| 05 2026 | 1180,00 | 0,00 | 1180,00 |
| 06 2026 | 1180,00 | 0,00 | 1180,00 |
| 07 2026 | 1180,00 | 0,00 | 1180,00 |
| **Summe offen** | | | **5900,00** |

## Trainingsziel

Diese Akte testet rote Ampel, Kündigung, Zahlungsklage und Räumungspfad. Sie zwingt zur Trennung zwischen behaupteter Unzufriedenheit, echter Mietminderung, Beweislast, Zugang der Kündigung und Schonfristzahlungsrisiko.

## Akte

| Dokument | Pfad |
|---|---|
| SAP-Statusauszug | [sap/sap-statusauszug.md](sap/sap-statusauszug.md) |
| Mietvertrag | [vertrag/mietvertrag.md](vertrag/mietvertrag.md) |
| Mietkonto FBL5N | [konto/mietkonto-fbl5n.md](konto/mietkonto-fbl5n.md) |
| Mahnung | [korrespondenz/mahnung.md](korrespondenz/mahnung.md) |
| Mietererklärung Zahlungsstopp | [korrespondenz/mieter-zahlungsstopp.md](korrespondenz/mieter-zahlungsstopp.md) |
| Aktennotiz zur Minderungsbewertung | [aktennotiz/aktennotiz-01-zahlungsstopp-minderungsbewertung.md](aktennotiz/aktennotiz-01-zahlungsstopp-minderungsbewertung.md) |
| E-Mail mit angekündigten Mängelfotos | [korrespondenz/mieter-antwort-maengel-fotos-angekuendigt.md](korrespondenz/mieter-antwort-maengel-fotos-angekuendigt.md) |
| Kündigung | [korrespondenz/kündigung.md](korrespondenz/kuendigung.md) |
| Klageentwurf | [korrespondenz/klage-entwurf.md](korrespondenz/klage-entwurf.md) |
| DocuWeb-Exportliste mit Objekt- und Absenderkonflikt | [dms/dms-exportliste-maengel-forderung.md](dms/dms-exportliste-maengel-forderung.md) |
| Begehungsnotiz ohne Wohnungszutritt | [objekt/hausmeister-begehungsnotiz-2026-07-09.md](objekt/hausmeister-begehungsnotiz-2026-07-09.md) |
| Technischer Auftragsstatus Fenster und Feuchte | [hausverwaltung/auftragsstatus-fensterpruefung.md](hausverwaltung/auftragsstatus-fensterpruefung.md) |
| Konkretisierende E-Mail ohne angekündigte Fotos | [korrespondenz/email-mieter-fotos-fehlen-weiterhin.md](korrespondenz/email-mieter-fotos-fehlen-weiterhin.md) |
| Zustellungsurkunde der Kündigung | [zustellung/zustellungsurkunde-kuendigung-2026-07-22.md](zustellung/zustellungsurkunde-kuendigung-2026-07-22.md) |
| E-Mail des Handwerkers zum gescheiterten Zutritt | [korrespondenz/email-handwerkertermin-ohne-zutritt.md](korrespondenz/email-handwerkertermin-ohne-zutritt.md) |
| Protokoll des nachgeholten Fenster- und Feuchtetermins | [technik/terminprotokoll-fensterpruefung-2026-07-27.md](technik/terminprotokoll-fensterpruefung-2026-07-27.md) |
| Handwerkerrechnung mit technischem Befund und Abgrenzung | [technik/rechnung-fenstereinstellung-2026-07-28.md](technik/rechnung-fenstereinstellung-2026-07-28.md) |
| E-Mail des Mieters nach dem Ortstermin | [korrespondenz/email-mieter-nach-ortstermin.md](korrespondenz/email-mieter-nach-ortstermin.md) |

## Aufgabe für die Skills

1. Mietkonto und SAP-Saldo auf fünf offene Bruttowarmmieten abstimmen.
2. Mietererklärung als behaupteten Zahlungsstopp auswerten und von konkreter Mängelanzeige trennen.
3. Kündigung, Zahlungsklage und Räumungspfad mit Beleg- und Zustellmatrix vorbereiten.
4. Schonfristzahlungsrisiko, Vergleichsoption und RA-Eskalation klar markieren.
