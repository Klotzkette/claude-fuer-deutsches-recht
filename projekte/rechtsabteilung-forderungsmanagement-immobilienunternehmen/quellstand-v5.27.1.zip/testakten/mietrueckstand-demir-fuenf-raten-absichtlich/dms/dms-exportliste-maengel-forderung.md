# DocuWeb Exportliste F-2026-00419

## 1 Exportkopf

| Feld | Wert |
|---|---|
| Exportzeitpunkt | 06.08.2026, 16:22 Uhr |
| Vertragsnummer | WBI-MV-2020-03114 |
| Objekt | Donaustraße 38, 4. OG links |
| Suchbegriffe | Demir, Mietrückstand, Fenster, Feuchte |
| Treffer | 20 |

## 2 Trefferliste

| DMS-ID | Datum | Bereich | Indexname | Objektindex | Hinweis |
|---|---|---|---|---|---|
| DW-681004 | 14.09.2020 | Vertrag | Mietvertrag_Demir.pdf | Donaustraße 38 | vollständig |
| DW-885220 | 12.05.2026 | Ausgang | Mahnung_Demir.pdf | Donaustraße 38 | versandt |
| DW-886003 | 20.05.2026 | Eingang | Mail_Zahlungsstopp.pdf | Donaustraße 38 | Cem Demir |
| DW-886004 | 20.05.2026 | Sonstiges | Bildschirmfoto_ohne_Anhang.pdf | Donaustraße 38 | leere Vorschau |
| DW-890112 | 03.07.2026 | Eingang | Mail_Maengel_Fotos.pdf | Donaustraße 18 | falsch indiziert |
| DW-890113 | 03.07.2026 | Mailanhang | keine Datei | Donaustraße 18 | Anhangszähler 0 |
| DW-890991 | 09.07.2026 | Objekt | Begehungsnotiz_Hausmeister.docx | Donaustraße 38 | Wohnung nicht betreten |
| DW-891102 | 10.07.2026 | Eingang | Mail_Demir_Konkretisierung.pdf | Donaustraße 38 | Absender Emre Demir |
| DW-891550 | 12.07.2026 | Handwerker | Terminbestätigung_Fenster.pdf | Donaustraße 38 | Zugang erforderlich |
| DW-892040 | 15.07.2026 | Handwerker | Rückmeldung_niemand_geöffnet.pdf | Donaustraße 38 | Klingel ohne Antwort |
| DW-892612 | 18.07.2026 | Notiz | Minderungsbewertung.docx | Donaustraße 38 | intern |
| DW-892901 | 19.07.2026 | Ausgang | Kündigung_Demir.pdf | Donaustraße 38 | Original unterzeichnet |
| DW-893411 | 22.07.2026 | Zustellung | ZU_Kündigung_Demir.pdf | Donaustraße 38 | zugestellt |
| DW-894001 | 23.07.2026 | Eingang | Mail_Widerspruch_Kündigung.pdf | Donaustraße 38 | keine Vollmacht |
| DW-894801 | 27.07.2026 | Handwerker | Protokoll_Fensterpruefung_2026-07-27.pdf | Donaustraße 38 | Einstellarbeiten ausgeführt |
| DW-894802 | 27.07.2026 | Eingang | Mail_Demir_nach_Fenstertermin.pdf | Donaustraße 38 | vollständigen Austausch verlangt |
| DW-894910 | 28.07.2026 | Rechnung | Rechnung_Fenstereinstellung_KF-2026-7714.pdf | Donaustraße 38 | 184,45 EUR; kein Austausch empfohlen |
| DW-895201 | 31.07.2026 | Objekt | Auftrag_Fensterprüfung.xlsx | Donaustraße 38 | neuer Termin offen |
| DW-896001 | 05.08.2026 | Entwurf | Klage_Demir.docx | Donaustraße 38 | Freigabe offen |
| DW-896002 | 05.08.2026 | Tabelle | Anlagenplan_Demir.xlsx | Donaustraße 38 | K 4 fehlt im Original |

## 3 Indexkonflikt

DW-890112 wurde automatisiert der Donaustraße 18 zugeordnet. Inhalt, Mietername und Wohnungsangabe betreffen jedoch die Donaustraße 38. Der Absendername „Emre Demir“ stimmt nicht mit dem Vertragspartner Cem Demir überein; eine Vollmacht oder Erläuterung liegt nicht vor.

Das Terminprotokoll vom 27.07.2026 dokumentiert ausgeführte Einstellarbeiten,
aber keinen Austauschbedarf. Die am selben Tag eingegangene Forderung nach
vollständigem Fensteraustausch ist deshalb als Parteivortrag und nicht als
technische Feststellung zu führen.
