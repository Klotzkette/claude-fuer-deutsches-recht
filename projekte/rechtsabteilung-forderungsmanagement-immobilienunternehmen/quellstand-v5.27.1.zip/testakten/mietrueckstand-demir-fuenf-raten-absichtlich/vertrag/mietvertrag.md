# Wohnraummietvertrag

**Vertragsnummer:** WBI-MV-2020-03114
**Objekt:** Donaustraße 38, 12043 Berlin, 4. OG links
**Ablage:** SAP RE-FX / DMS Vertragsakte

**Parteien**

**Vermieterin**
Wohnen Berlin Immobilien GmbH
Friedrichstraße 99
10117 Berlin
vertreten durch den Geschäftsführer Dr. Markus Lehmann

**Mieter**
Herr Cem Demir, geboren am 05.11.1988
Donaustraße 38
12043 Berlin

## 1 Mietsache

### 1.1

Vermietet wird die im Hause Donaustraße 38, 12043 Berlin, im 4. OG links gelegene Wohnung, bestehend aus drei Zimmern, Küche, Bad, Flur, Balkon und Kellerraum Nr. 38-L4.

### 1.2

Die Wohnfläche beträgt nach Wohnflächenberechnung vom 18.08.2020 **71,40 qm**. Die Wohnflächenberechnung ist Anlage 1.

### 1.3

Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Untervermietung oder gewerbliche Nutzung bedürfen der vorherigen schriftlichen Zustimmung der Vermieterin.

## 2 Mietzeit

### 2.1

Das Mietverhältnis beginnt am **01.10.2020** und läuft auf unbestimmte Zeit.

### 2.2

Die ordentliche Kündigung richtet sich nach den gesetzlichen Vorschriften, insbesondere §§ 573, 573c BGB.

## 3 Miete und Zahlung

| Position | Betrag |
|---|---:|
| Nettokaltmiete | 810,00 EUR |
| Betriebskostenvorauszahlung | 210,00 EUR |
| Heizkostenvorauszahlung | 160,00 EUR |
| **Bruttowarmmiete** | **1180,00 EUR** |

### 3.1

Die Miete ist monatlich im Voraus, spätestens am dritten Werktag des jeweiligen Monats, auf folgendes Konto zu zahlen:

| Empfängerin | IBAN | BIC | Institut |
|---|---|---|---|
| Wohnen Berlin Immobilien GmbH | DE47 1009 0000 0123 4567 89 | BEVODEBB | Berliner Volksbank |

### 3.2

Als Verwendungszweck ist anzugeben: **WBI-MV-2020-03114 Demir Donaustraße 38**.

## 4 Betriebskosten und Heizkosten

### 4.1

Der Mieter trägt die umlagefähigen Betriebskosten gemäß § 2 BetrKV und die Heizkosten nach Maßgabe der Heizkostenverordnung.

### 4.2

Über Betriebs- und Heizkosten wird jährlich abgerechnet. Nachforderungen werden nach Zugang einer formell ordnungsgemäßen Abrechnung fällig.

## 5 Mietsicherheit

### 5.1

Der Mieter leistet eine Mietsicherheit in Höhe von **2430,00 EUR**.

### 5.2

Eine Geldsicherheit kann in drei gleichen monatlichen Raten geleistet werden. Die erste Rate ist zu Mietbeginn, die weiteren Raten sind mit den beiden folgenden Mietzahlungen fällig.

### 5.3

Die Vermieterin legt die Sicherheit getrennt von ihrem Vermögen an. Über geleistete Raten und die Anlage wird gesondert Nachweis erteilt.

## 6 Hausordnung und Obhutspflichten

### 6.1

Die Hausordnung ist Anlage 2 und Bestandteil dieses Vertrages.

### 6.2

Mängel, Schäden und Störungen sind der Hausverwaltung unverzüglich mitzuteilen. Die Anzeige soll Ort, Erscheinungsbild, erstmalige Wahrnehmung und Erreichbarkeit für eine Besichtigung enthalten, soweit dies dem Mieter möglich ist. Die gesetzlichen Rechte des Mieters werden nicht von einer bestimmten Form der Anzeige abhängig gemacht.

### 6.3

Die Wohnung ist angemessen zu beheizen und zu lüften. Starre Lüftungsintervalle werden nicht vereinbart. Bei erkennbaren Feuchte- oder Geruchsproblemen stimmen die Parteien konkrete Prüf- und Schutzmaßnahmen anhand der tatsächlichen Situation ab.

## 7 Zutritt und Erhaltungsmaßnahmen

### 7.1

Zur Prüfung eines angezeigten Mangels, für Ablesungen, Wartungen und erforderliche Erhaltungsmaßnahmen ermöglicht der Mieter nach angemessener Terminankündigung Zutritt. Notfälle bleiben unberührt.

### 7.2

Kann ein abgestimmter Termin nicht eingehalten werden, teilt die verhinderte Partei dies unverzüglich mit und bietet zeitnah Ersatztermine an. Aus einer einzelnen Terminverschiebung folgt für sich allein weder ein Anerkenntnis noch ein Ausschluss von Mängelrechten.

### 7.3

Die Vermieterin dokumentiert durchgeführte Prüfungen und Arbeiten in der Objektakte. Soweit ein Dienstleister eingesetzt wird, wird dessen Terminankündigung dem Mieter in geeigneter Form mitgeteilt.

## 8 Gebrauch der Mietsache

### 8.1

Die Wohnung wird ausschließlich zu Wohnzwecken überlassen. Eine teilweise oder vollständige Gebrauchsüberlassung an Dritte richtet sich nach den gesetzlichen Vorschriften.

### 8.2

Bauliche Veränderungen, feste Balkonaufbauten und Eingriffe in Fassade, Fenster, Leitungen oder Gebäudetechnik bedürfen der vorherigen Zustimmung. Übliche bewegliche Einrichtungsgegenstände bleiben hiervon unberührt.

### 8.3

Flucht- und Rettungswege sind freizuhalten. Die Nutzung von Treppenhaus, Hof, Müllplatz und Fahrradabstellflächen richtet sich nach der Hausordnung.

## 9 Zahlungsverkehr und Forderungsmitteilungen

### 9.1

Die Vertragsnummer soll bei jeder Zahlung angegeben werden. Eine fehlende Angabe ändert die gesetzlichen Regeln zur Tilgungsbestimmung und Anrechnung nicht.

### 9.2

Beanstandungen der Mietsache und Zahlungsansprüche sind getrennt zu erklären. Die gesetzlichen Rechte bei Mängeln, einschließlich einer möglichen Minderung, bleiben unberührt; ebenso bleiben Fälligkeit und Folgen eines nicht gerechtfertigten Zahlungsrückstands nach den gesetzlichen Vorschriften bestehen.

### 9.3

Stundungen oder Ratenzahlungen gelten nur für die in der jeweiligen Vereinbarung bezeichneten Beträge und Zeiträume. Sie bedürfen einer gesonderten Dokumentation.

## 10 Übergabe und Rückgabe

### 10.1

Das Übergabeprotokoll vom 29.09.2020 bezeichnet den Zustand der Räume, die Zählerstände und die übergebenen Schlüssel. Für das Bad sind funktionsfähige Lüftung und Silikonfugen ohne sichtbaren Schimmel vermerkt; die Fenster wurden als gebrauchsfähig ohne Zusicherung eines Neubaustandards aufgenommen.

### 10.2

Bei Beendigung ist die Wohnung geräumt, besenrein und mit sämtlichen Schlüsseln zurückzugeben. Über Zustand, Zählerstände und Schlüssel wird ein Protokoll gefertigt. Dieses ersetzt keine gesonderte Prüfung möglicher Ansprüche.

## 11 Vertragsänderungen

Nebenabreden bestehen bei Unterzeichnung nicht. Änderungen und Ergänzungen werden in einer eindeutig bezeichneten Erklärung oder einem Nachtrag festgehalten. Gesetzlich vorgeschriebene Formen bleiben maßgeblich.

## 12 Anlagen

1. Wohnflächenberechnung vom 18.08.2020
2. Hausordnung
3. Betriebskostenkatalog
4. Übergabeprotokoll vom 29.09.2020
5. Energieausweis zur Einsichtnahme

**Unterschriften**

Berlin, den 24.09.2020

| Vermieterin | Mieter |
|---|---|
| Wohnen Berlin Immobilien GmbH, Dr. Markus Lehmann | Cem Demir |
