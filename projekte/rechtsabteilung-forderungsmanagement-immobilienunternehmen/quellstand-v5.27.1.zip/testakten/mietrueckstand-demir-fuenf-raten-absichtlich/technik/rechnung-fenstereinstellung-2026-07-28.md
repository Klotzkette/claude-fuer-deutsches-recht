# Kröll Fenstertechnik GmbH

Karl-Marx-Straße 188

12043 Berlin

Wohnen Berlin Immobilien GmbH

Friedrichstraße 99

10117 Berlin

**Rechnung:** KF-2026-7714

**Auftrag:** WBI-FT-2026-4481

**Rechnungsdatum:** 28.07.2026

**Leistungsdatum:** 27.07.2026

**Objekt:** Donaustraße 38, 12043 Berlin, 4. OG links

## 1. Ausgeführte Arbeiten

| Position | Menge | Einzelpreis netto | Gesamt netto |
|---|---:|---:|---:|
| Anfahrt und Funktionsprüfung zweier Fensterflügel | 1 | 58,00 EUR | 58,00 EUR |
| Nachstellen der Beschläge, Schlafzimmer | 1 | 42,00 EUR | 42,00 EUR |
| Reinigen und Fetten der Schließteile, Wohn- und Schlafzimmer | 2 | 15,00 EUR | 30,00 EUR |
| Austausch einer Anschlagdichtung, 1,2 Meter | 1 | 25,00 EUR | 25,00 EUR |
| **Zwischensumme netto** |  |  | **155,00 EUR** |
| Umsatzsteuer 19 Prozent |  |  | 29,45 EUR |
| **Rechnungsbetrag** |  |  | **184,45 EUR** |

## 2. Technischer Befund

Beim Schlafzimmerfenster war der Anpressdruck an der Griffseite ungleichmäßig. Der Flügel ließ sich schließen, erforderte jedoch im oberen Drittel erhöhten Kraftaufwand. Die Beschläge wurden nach Herstellervorgabe nachgestellt. Ein 1,2 Meter langer Abschnitt der inneren Anschlagdichtung war gequetscht und wurde ersetzt.

Am Wohnzimmerfenster waren Rahmen, Beschläge und Dichtungen funktionsfähig. Nach Reinigung und Schmierung ließ sich der Flügel ohne erhöhten Kraftaufwand öffnen und schließen. Sichtbare Glas- oder Rahmenschäden, Wassereintrittsspuren und messbare Durchfeuchtung der Leibung wurden nicht festgestellt.

## 3. Abgrenzung

Ein vollständiger Austausch der Fenster wurde nicht beauftragt und ist nach dem am 27.07.2026 erhobenen Funktionsbefund nicht empfohlen worden. Die Rechnung dokumentiert den Zustand am Termin und die ausgeführten Arbeiten. Sie enthält keine bauphysikalische Begutachtung der gesamten Wohnung und keine Bewertung behaupteter Geräusche aus dem Straßenraum.

Die Arbeiten wurden Herrn Cem Demir um 10:18 Uhr vorgeführt. Der Schlafzimmerflügel wurde gemeinsam dreimal geöffnet, gekippt und geschlossen. Herr Demir bestätigte den Zutritt, unterzeichnete aber keine Erklärung zur Mangelfreiheit oder zu offenen Mietforderungen.

Zahlbar bis 11.08.2026 unter Angabe der Rechnungsnummer.

Kröll Fenstertechnik GmbH

Kundendienst
