# Terminprotokoll Fenster- und Feuchteprüfung

Kroll Fenstertechnik GmbH

Auftrag TS-2026-18841

## 1. Termin

| Feld | Inhalt |
|---|---|
| Datum | 27.07.2026 |
| Zeit | 08:05 bis 08:51 Uhr |
| Objekt | Donaustraße 38, 12043 Berlin, 4. OG links |
| Mieter | Cem Demir |
| Monteur | Kai Kroll |
| Begleitung | Nuray Aydin, Hausverwaltung |

## 2. Prüfbereiche

| Bereich | Feststellung | Maßnahme |
|---|---|---|
| Schlafzimmerfenster | Flügel streift unten leicht; Beschlag nachstellbar | Beschlag eingestellt und geölt |
| Wohnzimmerfenster | Dichtung an einer Ecke spröde, Länge etwa 18 cm | Ersatzdichtung bestellt |
| Küchenfenster | öffnet und schließt ohne Auffälligkeit | keine |
| Balkontür | Griff schwergängig | Griffmechanik geölt |
| Innenlaibungen | keine sichtbaren Feuchteflecken | keine Materialmessung veranlasst |

## 3. Angaben des Mieters

Herr Demir erklärt, im Winter ziehe es am Wohnzimmerfenster und im Schlafzimmer sei es morgens kalt. Er zeigte auf seinem Mobiltelefon zwei Bilder einer beschlagenen Scheibe. Datum, Raum und Originaldatei konnten im Termin nicht geprüft werden.

Herr Demir verlangte einen vollständigen Austausch aller Fenster. Ihm wurde erklärt, dass darüber nicht der Monteur entscheidet.

## 4. Ergebnis

Die Einstellarbeiten wurden im Termin ausgeführt. Für die Ersatzdichtung ist ein kurzer Folgetermin erforderlich. Eine bauphysikalische Prüfung, Luftdichtheitsmessung oder Bewertung einer Mietminderung war nicht Gegenstand des Auftrags.

Kai Kroll

Kroll Fenstertechnik GmbH
