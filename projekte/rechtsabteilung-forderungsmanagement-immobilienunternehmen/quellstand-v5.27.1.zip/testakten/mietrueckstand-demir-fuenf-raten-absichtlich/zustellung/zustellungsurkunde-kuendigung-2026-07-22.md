# Zustellungsurkunde

## 1 Auftrag

| Feld | Inhalt |
|---|---|
| Absenderin | Wohnen Berlin Immobilien GmbH |
| Empfänger | Cem Demir |
| Anschrift | Donaustraße 38, 12043 Berlin, 4. OG links |
| Schriftstück | Kündigung vom 19.07.2026 |
| Geschäftsnummer Zustellung | GV-NK-26-18804 |

## 2 Zustellung

Das Schriftstück wurde am 22.07.2026 um 10:24 Uhr in einen zur Wohnung gehörenden Briefkasten eingelegt. Eine persönliche Übergabe war nicht möglich. Der Briefkasten war mit „C. Demir / E. Kaya“ beschriftet. Die Sendung passte vollständig in den Briefkasten.

Zustellungsart: Ersatzzustellung durch Einlegen in den Briefkasten.

## 3 Ausfertigungsvermerk

Die elektronische Abschrift ging am 23.07.2026 beim Forderungsmanagement ein. Auf Seite 1 ist der Eingangsstempel teilweise über das Feld „Geschäftsnummer“ gesetzt; die Nummer bleibt lesbar.
