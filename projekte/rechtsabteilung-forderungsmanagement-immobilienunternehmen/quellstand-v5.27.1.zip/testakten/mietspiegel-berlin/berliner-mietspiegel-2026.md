# Berliner Mietspiegel 2026 - amtlich nachgebildeter Testauszug

## 1. Quellenstatus

Der Berliner Mietspiegel 2026 ist ein qualifizierter Mietspiegel nach § 558d BGB. Er wurde am 28.05.2026 veröffentlicht, trat an diesem Tag in Kraft und löste den Mietspiegel 2024 ab. Diese Datei bildet nur den für die Becker-Testakte benötigten Ausschnitt nach. Für produktive Vorgänge sind der amtliche Volltext, das Straßenverzeichnis, die Orientierungshilfe und der am Zugangstag geltende Rechtsstand live zu öffnen.

Amtliche Quellen:

- [Berliner Mietspiegel 2026](https://mietspiegel.berlin.de/wp-content/uploads/2026/05/mietspiegel2026.pdf)
- [Mietspiegeltabelle 2026](https://mietspiegel.berlin.de/wp-content/uploads/2026/05/mietspiegeltabelle2026.pdf)
- [Straßenverzeichnis 2026](https://mietspiegel.berlin.de/wp-content/uploads/2026/05/strassenverzeichnis-zum-mietspiegel-2026.pdf)
- [Veröffentlichungsmitteilung vom 28.05.2026](https://www.berlin.de/sen/stadt/presse/pressemeldungen/pressemitteilung.1674998.php)

## 2. Relevanter Tabellenfall Becker

| Merkmal | Aktenwert | Amtliche Zuordnung |
|---|---|---|
| Anschrift | Manfred-von-Richthofen-Straße 18, 12101 Berlin | mittlere Wohnlage laut Straßenverzeichnis 2026 |
| Bezugsfertigkeit | 1964 | Baualtersklasse 1950 bis 1964 |
| Wohnfläche | 78,50 m² | Größenklasse ab 45 m² |
| Ausstattung | Sammelheizung sowie Bad und WC in der Wohnung | voll ausgestattet |
| Tabellenstelle | Mietspiegeltabelle 9.2 | Zeile 85 |

## 3. Amtliche Werte der Zeile 85

| Untere Spanne | Mittelwert | Obere Spanne |
|---:|---:|---:|
| 5,90 EUR/m² | 7,08 EUR/m² | 9,25 EUR/m² |

Die in der Becker-Akte verlangten 7,82 EUR/m² liegen innerhalb der Spanne, aber 0,74 EUR/m² über dem Mittelwert. Die Tabellenzuordnung allein beweist diesen Betrag nicht. Die konkrete Einordnung innerhalb der Spanne muss anhand der fünf Merkmalgruppen der amtlichen Orientierungshilfe und belastbarer Objektbelege nachvollziehbar dokumentiert werden.

## 4. Rechenregel der Orientierungshilfe

Die Orientierungshilfe ist nicht Teil des qualifizierten Mietspiegels, kann aber als Schätzgrundlage dienen. Die fünf Merkmalgruppen Bad/WC, Küche, Wohnung, Gebäude und Wohnumfeld werden mit jeweils 20 Prozent gewichtet. Überwiegen in einer Gruppe die positiven Merkmale, werden 20 Prozent der Differenz zwischen Mittelwert und Oberwert angesetzt; überwiegen die negativen, werden 20 Prozent der Differenz zwischen Mittelwert und Unterwert abgezogen. Gleichstand oder fehlende Merkmale ergeben für die Gruppe null Prozent.

Für Zeile 85 gilt:

- Differenz Mittelwert zu Oberwert: 9,25 - 7,08 = 2,17 EUR/m².
- Ein positiver Gruppensaldo von 20 Prozent entspricht 0,434 EUR/m².
- Zwei positive Gruppensalden, also plus 40 Prozent, führen rechnerisch zu 7,948 EUR/m² und kaufmännisch gerundet zu 7,95 EUR/m².
- Die Kappungsgrenze der Becker-Akte begrenzt eine ansonsten tragfähige Vergleichsmiete auf 7,82 EUR/m².

Die Rechenregel ersetzt keine Tatsachenfeststellung. Ein Merkmal wird nur gewertet, wenn Mietvertrag, Übergabeprotokoll, Rechnung, Foto, Energieausweis oder sonstiger Objektbeleg es trägt.

## 5. Prüfkarte für die Spanneneinordnung

| Prüfgruppe | Aktenstand | Freigabefolge |
|---|---|---|
| Bad/WC | Angaben zu Fenster, Lüftung und Modernisierung widersprechen sich | Gruppe offen |
| Küche | Alter und vermieterseitig gestellte Ausstattung nicht belegt | Gruppe offen |
| Wohnung | Balkon vorhanden; Größe, Verglasung und weitere Merkmale streitig | Gruppe offen |
| Gebäude | fehlender Aufzug im 2. OG ist nach der Orientierungshilfe kein Negativmerkmal; Energie- und Instandhaltungsdaten fehlen | Gruppe offen |
| Wohnumfeld | mittlere Wohnlage ist Tabellenmerkmal; besondere Lärmbelastung wird behauptet und muss gesondert belegt werden | Gruppe offen |

Ohne abgeschlossene Merkmalbewertung bleibt die Zielmiete in der Freigabekarte gelb. Ein Sachverständigenangebot im Prozess ersetzt nicht die vorherige Tatsachen- und Belegarbeit.

## 6. Kappungsgrenze

Für ganz Berlin gilt nach der Kappungsgrenzen-Verordnung vom 14.03.2023 vom 11.05.2023 bis zum 10.05.2028 eine Grenze von 15 Prozent innerhalb von drei Jahren (§ 558 Abs. 3 Satz 2 BGB).

In der Becker-Akte:

- Ausgangsmiete zu Beginn des relevanten Drei-Jahres-Zeitraums: 6,80 EUR/m²
- seit 01.10.2023 geschuldete Miete: 7,20 EUR/m²
- Zielmiete zum 01.09.2026: 7,82 EUR/m²
- Gesamtsteigerung: 15 Prozent

Die Kappungsgrenze begrenzt die Erhöhung auf 7,82 EUR/m², beweist aber nicht, dass die ortsübliche Vergleichsmiete diesen Betrag erreicht.

Amtliche Quelle: [Kappungsgrenzen-Verordnung Berlin 2023](https://gesetze.berlin.de/bsbe/document/jlr-KappGrVBE2023pP2)

## 7. Abgrenzung Mietpreisbremse

Die Mietpreisbremse der §§ 556d ff. BGB betrifft grundsätzlich die Miethöhe bei Mietbeginn und ist nicht die Rechtsgrundlage der Bestandsmieterhöhung nach § 558 BGB. Für Neuvermietungen bestimmt die Berliner Mietenbegrenzungsverordnung vom 11.11.2025 ganz Berlin vom 01.01.2026 bis zum 31.12.2029 zum angespannten Wohnungsmarkt.

Amtliche Quelle: [Mietenbegrenzungsverordnung Berlin 2026](https://gesetze.berlin.de/bsbe/document/jlr-MietBegrVBE2026pP1)
