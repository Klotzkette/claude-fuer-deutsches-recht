# Berliner Mietspiegel 2026 Kurzfassung


<!-- BEGIN gesamt-pdf-section (autogen) -->
## Akte komplett herunterladen

[Alle Testakten](../README.md) · [Plugin-Menü](../../forderungsmanagement-immobilien/README.md) · [Alle Skills](../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick) · [Zentrale Downloads](../../README.md#sofort-downloads-latest-release)

Diese Arbeitsakte gibt es in drei Formaten zum Direkt-Download. Das Gesamt-PDF eignet sich zum Lesen, Ausdrucken und für schnelle Durchsichten. Das Arbeits-ZIP enthält alle Aktenstücke ausschließlich als DOCX, XLSX oder PDF. Arbeits-ZIP und Einzel-PDF-ZIP sind flach, haben keine Unterordner und enthalten keine Markdown-Dateien. Das Einzel-PDF-ZIP enthält dieselben fachlichen Unterlagen als separat benannte PDF-Dateien.

| Was | Format | Direkt-Download | Im Repo öffnen |
| --- | --- | --- | --- |
| Gesamt-PDF (alles in einer Datei, 10 KB) | PDF | [testakte-mietspiegel-berlin-gesamt.pdf](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietspiegel-berlin-gesamt.pdf) | [`gesamt-pdf/mietspiegel-berlin_gesamt.pdf`](gesamt-pdf/mietspiegel-berlin_gesamt.pdf) |
| Arbeits-ZIP (lebensechter Formate-Mix) | ZIP | [testakte-mietspiegel-berlin.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietspiegel-berlin.zip) | - |
| Einzel-PDF-ZIP (jede Unterlage separat) | ZIP | [testakte-mietspiegel-berlin-einzel-pdfs.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/testakte-mietspiegel-berlin-einzel-pdfs.zip) | - |

Alle Release-URLs sind stabil und zeigen immer auf die aktuelle Version. Das Gesamt-PDF bleibt zusätzlich im Repo erreichbar und wird in den beiden ZIPs nicht gedoppelt.

<!-- END gesamt-pdf-section (autogen) -->

## Auf einen Blick

| Punkt | Inhalt |
|---|---|
| Zweck | Gemeinsamer Mietspiegel-Anker für Mieterhöhungsverlangen und Zustimmungsklage |
| Hauptakte | [mieterhoehung-becker-tempelhof](../mieterhoehung-becker-tempelhof/) |
| Startskills | `28-mieterhoehung-bgb-558-vorbereiten`, `29-mieterhoehungsverlangen-text`, `30-zustimmungsklage-mieterhoehung`, `31-kappungsgrenze-mietpreisbremse` |
| Besonderheit | Amtlich nachgebildeter Ausschnitt für mittlere Wohnlage, Baujahr 1964 und 78,50 m²; für produktive Fälle immer die vollständige amtliche Quelle und das Abrufdatum prüfen. |

Dieser Ordner enthält den gemeinsamen Mietspiegel-Anker für die Testakten im Plugin `forderungsmanagement-immobilien`.

## Akte

- [`berliner-mietspiegel-2026.md`](./berliner-mietspiegel-2026.md) — amtlich nachgebildeter relevanter Auszug mit Tabelle 9.2, Zeile 85, Spanneneinordnung, Kappungsgrenze und Primärquellen.
- [`gesamt-pdf/mietspiegel-berlin_gesamt.pdf`](./gesamt-pdf/mietspiegel-berlin_gesamt.pdf) — exportfähige Gesamtfassung für Release-ZIPs und schnelle Sichtprüfung.

## Verwendung

Die Datei dient als Begründungsanker für Mieterhöhungsverlangen nach § 558 BGB und für die Zustimmungsklage in der Testakte `mieterhoehung-becker-tempelhof`.
