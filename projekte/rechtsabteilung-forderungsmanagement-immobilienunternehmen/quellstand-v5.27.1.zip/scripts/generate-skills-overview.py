#!/usr/bin/env python3
"""
Generiert in jeder Plugin-README einen Abschnitt
'## Alle Skills im Überblick (automatisch generiert)'
am Ende der Datei. Der Abschnitt listet alle Skills mit Description
aus den jeweiligen SKILL.md-Dateien.

Idempotent: erkennt vorhandene Markierungsblöcke und ersetzt sie.
Bestehende, manuell gepflegte Skills-Sektionen werden NICHT angetastet.
"""

from __future__ import annotations

import os
import re
import sys
import textwrap
from pathlib import Path

from skill_frontmatter import description_from_file

BEGIN = "<!-- BEGIN SKILLS-OVERVIEW (auto-generated) -->"
END = "<!-- END SKILLS-OVERVIEW (auto-generated) -->"

DISPLAY_NAMES = {
    "01-sap-akte-importieren": "SAP-/Mietkonto-Startakte",
    "02-mietakte-rekonstruieren": "Mietvertrag und Vertragsakte",
    "03-kontoauszug-mietkonto-auslesen": "Mietkonto und Soll-Ist-Saldo",
    "04-belegmatrix-aufbauen": "Beleg- und Anlagenmatrix",
    "05-chronologie-fallakte": "Chronologie und Fristenachse",
    "06-fallziel-renofa-triage": "Pflicht-Router nach Intake",
    "07-rdg-grenzen-check": "Rollen- und RDG-Grenze",
    "08-eskalation-an-anwalt": "RA-Eskalation und Kanzleisteuerung",
    "09-mietrueckstand-mahnung-erstellen": "Mietrückstand mahnen",
    "10-zahlungsplan-stundungsvereinbarung": "Ratenplan und Kulanzsteuerung",
    "11-verzugsschaden-berechnen": "Verzugsschaden und Kostenkniff",
    "12-vorgerichtliche-letzte-frist": "Letzte Frist vor Klage/Kündigung",
    "13-fristlose-kuendigung-zahlungsverzug": "Fristlose Kündigung Zahlungsrückstand",
    "14-ordentliche-kuendigung-pflichtverletzung": "Ordentliche Kündigung Pflichtverletzung",
    "15-kuendigung-zustellung-nachweis": "Zustellung und Zugangsnachweis",
    "16-widerspruch-mieter-pruefen": "Sozialwiderspruch und Härtefall",
    "17-mahnbescheid-online-antrag": "Option Mahnverfahren",
    "18-widerspruch-vollstreckungsbescheid": "Widerspruch/Einspruch im Mahnverfahren",
    "19-vollstreckungsbescheid-antrag": "Vollstreckungsbescheid prüfen",
    "20-zahlungsklage-mietrueckstand-erstellen": "Zahlungsklage Mietrückstand",
    "21-klage-streitwert-gerichtskosten": "Streitwert und Gerichtskosten",
    "22-zustaendigkeit-amtsgericht-pruefen": "Amtsgericht und Anwaltszwang",
    "23-klage-egvp-bea-einreichen": "Einreichungspaket, Rollengate und Eingang",
    "24-raeumungsklage-erstellen": "Räumungsklage Wohnraum",
    "25-raeumungsfrist-vollstreckung": "Räumungsfrist und Schutzantrag",
    "26-berliner-modell-raeumung": "Berliner Modell Räumung",
    "27-schonfristzahlung-erkennen": "Schonfristzahlung und Kostenpfad",
    "28-mieterhoehung-bgb-558-vorbereiten": "Mieterhöhung vorbereiten",
    "29-mieterhoehungsverlangen-text": "Mieterhöhungsverlangen schreiben",
    "30-zustimmungsklage-mieterhoehung": "Zustimmungsklage Mieterhöhung",
    "31-kappungsgrenze-mietpreisbremse": "Kappung und Mietpreisbremse",
    "32-datenschutz-mieterdaten": "Datenschutz in der Mietakte",
    "33-dokumentenmix-ocr-sichten": "Autostart neuer Fall und Dokumentenmix",
    "34-sap-excel-pdf-normalisieren": "Datenexporte und E-Akten-Anschluss",
    "35-sap-belegluecken-klaeren": "Beleglücken und Rückfragen",
    "36-fallstrategie-bis-10000": "Fallstrategie bis Freigabegrenze",
    "37-klageerwiderung-auswerten": "Klageerwiderung auswerten",
    "38-replik-erstellen": "Replik und Antragsumstellung",
    "39-beweisangebot-anlagenplan": "Beweisplan und Anlagenmanifest",
    "40-urkundsprozess-pruefen": "Urkundsprozess als Ausnahme",
    "41-vergleich-raten-prozess": "Vergleich und Prozessraten",
    "42-mieterklage-verteidigen": "Verteidigung gegen Mieterklage",
    "43-mieterverein-anwalt-korrespondenz": "Mieterverein/Gegneranwalt beantworten",
    "44-betriebskosten-rueckstand-streit": "Betriebskostenforderung und Einwendungen",
    "45-hausverwaltung-schnittstelle": "Hausverwaltung und IT-Rückfragen",
    "46-kostenfestsetzung-antrag": "Kostenfestsetzungsantrag",
    "47-kostenbeschluss-pruefen": "Kostenfestsetzungsbeschluss prüfen",
    "48-titulierte-forderung-vollstrecken": "Titelvollstreckung vorbereiten",
    "49-kontoermittlung-und-drittauskunft": "Kontoermittlung und Drittauskunft",
    "50-vollstreckungsakte-monitoring": "Vollstreckungsmonitoring",
    "01-bea-ordner-annahme": "Ordnerannahme und Autostart",
    "02-schriftsatzversion-festlegen": "Fassungssperre Hauptschriftsatz",
    "03-anlagenfolge-kennzeichnen": "Anlagenfolge und Kennzeichnung",
    "04-dateien-in-pdf-umwandeln": "PDF-Konvertierung",
    "05-pdf-qualitaet-pruefen": "PDF-Sicht- und Technikprüfung",
    "06-dateinamen-manifest-erzeugen": "Dateinamen und Versandmanifest",
    "07-signatur-versandweg-pruefen": "Signatur- und Versenderprüfung",
    "08-bea-paket-freigeben": "Paket-Preflight und Übergabe",
    "09-eingang-versandakte-sichern": "Eingangsbestätigung und Versandakte",
}


def clean_description(desc: str) -> str:
    """Entfernt alte Generator-/Konsolidierungsfloskeln aus Tabellenbeschreibungen."""
    desc = re.sub(
        r"\s+[—-]\s*Arbeitskontext:\s*[^.]+,\s*Schwerpunkt\s+[^.]+\.?",
        "",
        desc,
    )
    desc = re.sub(r"\s+im Plugin\s+[^.:\"`|]+(?=[:.])", "", desc)
    desc = re.sub(r"\s+im Plugin\s+[^\"`|]+$", "", desc)
    desc = re.sub(r"\s{2,}", " ", desc)
    return desc.strip()


def read_description(skill_md: Path) -> str:
    """Liest description aus YAML-Frontmatter einer SKILL.md."""
    if not skill_md.is_file():
        return ""
    desc = description_from_file(skill_md)
    # Pipes für Tabelle escapen, Zeilenumbrueche in Spaces
    desc = clean_description(desc.replace("\n", " ").strip())
    desc = desc.replace("|", "\\|").strip()
    # Lange Beschreibungen abkuerzen
    if len(desc) > 240:
        desc = textwrap.shorten(desc, width=240, placeholder="...")
    return desc


def display_name(slug: str) -> str:
    return DISPLAY_NAMES.get(slug, slug)


def build_overview(plugin_dir: Path) -> str:
    skills_dir = plugin_dir / "skills"
    if not skills_dir.is_dir():
        return ""
    skills = sorted(
        d.name
        for d in skills_dir.iterdir()
        if d.is_dir() and (d / "SKILL.md").is_file()
    )
    if not skills:
        return ""

    lines = [
        BEGIN,
        "",
        "## Alle Skills im Überblick",
        "",
        f"Automatisch generierte Komplett-Liste aller {len(skills)} Skills in diesem Plugin. "
        "Die technische Skill-ID bleibt stabil; der Arbeitsname macht die fachliche Zuordnung lesbar. "
        "Jede Skill-ID öffnet direkt die zugehörige `SKILL.md`; die Beschreibungen stammen aus deren Frontmatter.",
        "",
        "| Skill | Arbeitsname | Beschreibung |",
        "| --- | --- | --- |",
    ]
    for s in skills:
        desc = read_description(skills_dir / s / "SKILL.md")
        lines.append(f"| [`{s}`](skills/{s}/SKILL.md) | {display_name(s)} | {desc} |")
    lines.append("")
    lines.append(END)
    return "\n".join(lines)


def update_readme(readme: Path, overview: str) -> bool:
    """Returns True if file was changed."""
    if not overview:
        return False
    original = readme.read_text(encoding="utf-8") if readme.is_file() else ""
    new = original

    if BEGIN in new and END in new:
        # Ersetze bestehende Autogen-Bloecke und ziehe versehentliche
        # Duplikate zu genau einem aktuellen Block zusammen.
        start = new.find(BEGIN)
        end = new.rfind(END) + len(END)
        new = new[:start] + overview + new[end:]
    else:
        # Anhaengen am Ende, mit Trenner
        sep = "" if new.endswith("\n\n") else ("\n" if new.endswith("\n") else "\n\n")
        new = new + sep + "\n" + overview + "\n"

    if new == original:
        return False
    readme.write_text(new, encoding="utf-8")
    return True


def main() -> int:
    repo = Path(__file__).resolve().parent.parent
    os.chdir(repo)
    changed = 0
    total = 0
    for plugin_json in sorted(repo.glob("*/.claude-plugin/plugin.json")):
        plugin_dir = plugin_json.parent.parent
        readme = plugin_dir / "README.md"
        if not readme.is_file():
            print(f"  SKIP {plugin_dir.name}: keine README.md")
            continue
        overview = build_overview(plugin_dir)
        if not overview:
            continue
        total += 1
        if update_readme(readme, overview):
            changed += 1
            print(f"  UPD  {plugin_dir.name}")
    print(f"\nFertig: {changed}/{total} READMEs aktualisiert.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
