#!/usr/bin/env python3
"""Validiert deutsche Umlaut-Schreibweise in sichtbarer Repo-Prosa."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent

PROSE_SUFFIXES = {".md", ".markdown", ".txt", ".csv", ".eml", ".yml", ".yaml"}
GENERATOR_FILES = {
    Path("scripts/build-skills-markdown-bundles.py"),
    Path("scripts/build-cloud-cowork-prompt-skills.py"),
    Path("scripts/build-testakte-gesamt-pdf.py"),
    Path("scripts/build-testakten-release-zips.py"),

    Path("scripts/inject-plugin-sofort-download-section.py"),
    Path("scripts/sync-references.py"),
    Path("scripts/testakte_file_filter.py"),
    Path("scripts/validate-testakten-financial-consistency.py"),
    Path("scripts/validate-plugin-structure.mjs"),
    Path("scripts/validate-release-zips.py"),
    Path("scripts/validate-testakten-gesamt-pdf.py"),
    Path("scripts/validate-testakten-release-zips.py"),
    Path("scripts/validate-yaml-frontmatter.py"),
}
SKIP_FILES = {
    Path("scripts/validate-umlaut-prose.py"),
    Path("scripts/fix-umlaute-protected.py"),
    Path("scripts/sweep-umlaut-welle-2.py"),
    Path("scripts/sweep-umlaut-welle-3.py"),
}

# Bewusst keine allgemeine ae/oe/ue-Regel: technische Slugs und englische Wörter
# sollen stabil bleiben. Die Liste erfasst typische deutsche Umschreibungsstämme.
TERM_HINTS = {
    "abhaeng": "abhäng",
    "aender": "änder",
    "anwaelt": "anwält",
    "ausloes": "auslös",
    "ausser": "außer",
    "bestaet": "bestät",
    "buer": "bür",
    "drittauskuenft": "Drittauskünfte",
    "duerf": "dürf",
    "einschlaeg": "einschläg",
    "enthaelt": "enthält",
    "erklaer": "erklär",
    "faellig": "fällig",
    "fliesstext": "Fließtext",
    "fuenf": "fünf",
    "fuer": "für",
    "gebaeud": "gebäud",
    "gebuehr": "gebühr",
    "geschaeft": "geschäft",
    "gewuensch": "gewünsch",
    "glaeub": "gläub",
    "groess": "größ",
    "gruen": "grün",
    "haeng": "häng",
    "haert": "härt",
    "hoehe": "höhe",
    "klaer": "klär",
    "koenn": "könn",
    "kuerz": "kürz",
    "laeng": "läng",
    "loesch": "lösch",
    "lueck": "lück",
    "maerz": "März",
    "maess": "mäß",
    "mieterhoeh": "Mieterhöh",
    "moeg": "mög",
    "muess": "müss",
    "naech": "näch",
    "neukoelln": "Neukölln",
    "noet": "nöt",
    "oeff": "öff",
    "pfaend": "pfänd",
    "pfueb": "PfÜB",
    "pruef": "prüf",
    "raeum": "räum",
    "rueck": "rück",
    "saeum": "säum",
    "schliess": "schließ",
    "schluess": "schlüss",
    "schoen": "schön",
    "spaet": "spät",
    "strasse": "Straße",
    "taet": "tät",
    "ueber": "über",
    "verguet": "vergüt",
    "verhaeltn": "verhältn",
    "verjaehr": "verjähr",
    "vollstaend": "vollständ",
    "waehr": "währ",
    "zurueck": "zurück",
    "zustaend": "zuständ",
}

TERM_RE = re.compile(
    r"\b(" + "|".join(re.escape(k) for k in sorted(TERM_HINTS, key=len, reverse=True)) + r")\w*",
    re.IGNORECASE,
)

INLINE_PROTECTORS = [
    re.compile(r"!\[[^\]\n]*\]\([^)]+\)"),
    re.compile(r"\[[^\]\n]*\]\([^)]+\)"),
    re.compile(r"`[^`\n]+`"),
    re.compile(r"https?://[^\s)\]>]+"),
    re.compile(r"<!--.*?-->"),
    re.compile(r"\b[a-z0-9]+(?:-[a-z0-9]+)+\b"),
    re.compile(r"\b[a-z0-9]+(?:_[a-z0-9]+)+\b"),
]


def tracked_files() -> list[Path]:
    result = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
        cwd=REPO_ROOT,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
    )
    files: list[Path] = []
    for raw in result.stdout.splitlines():
        rel = Path(raw)
        if rel in SKIP_FILES:
            continue
        if not (REPO_ROOT / rel).is_file():
            continue
        if rel in GENERATOR_FILES or rel.suffix.lower() in PROSE_SUFFIXES:
            files.append(rel)
    return files


def strip_inline_protected(line: str) -> str:
    for pattern in INLINE_PROTECTORS:
        line = pattern.sub(" ", line)
    return line


def check_file(rel: Path) -> list[str]:
    path = REPO_ROOT / rel
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except UnicodeDecodeError:
        return []

    errors: list[str] = []
    in_fence = False
    for number, line in enumerate(lines, start=1):
        stripped = line.lstrip()
        if stripped.startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        visible = strip_inline_protected(line)
        for match in TERM_RE.finditer(visible):
            token = match.group(0)
            key = match.group(1).lower()
            hint = TERM_HINTS[key]
            errors.append(f"{rel}:{number}: '{token}' wirkt wie ASCII-Umschreibung, erwartet etwa '{hint}'")
    return errors


def main() -> int:
    errors: list[str] = []
    for rel in tracked_files():
        errors.extend(check_file(rel))

    if errors:
        print("validate-umlaut-prose: Fehler")
        for error in errors[:200]:
            print(f"  {error}")
        if len(errors) > 200:
            print(f"  ... {len(errors) - 200} weitere Treffer")
        return 1

    print("validate-umlaut-prose OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
