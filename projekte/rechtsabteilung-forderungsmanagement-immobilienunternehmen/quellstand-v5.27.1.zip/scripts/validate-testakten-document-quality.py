#!/usr/bin/env python3
"""Schützt die Testakten vor Gerippen, Meta-Text und leeren DMS-Beifängen."""

from __future__ import annotations

import re
import sys
from pathlib import Path

from testakte_file_filter import discover_testakten, is_export_meta_file, META_MARKERS

ROOT = Path(__file__).resolve().parent.parent
TESTAKTEN = ROOT / "testakten"
SKIP_DIRS = {"formatvorlagen-paradebeispiele", "grosser-prompts"}

BANNED_SOURCE_MARKERS = {
    "rückmeldung renovar",
    "inhaltsleere seite",
    "leere rückseite",
    "notiz_neu_final_final",
    "neuerscan.pdf",
    "nur zu testzwecken",
    "ausschließlich testzwecken",
    "ausschliesslich testzwecken",
    "demonstrationsakte",
    "aufgabe für die skills",
    "trainingsziel",
}

STRUCTURED_STEM_PARTS = {
    "sap-",
    "fbl5n",
    "dms-",
    "matrix",
    "monitoring",
    "journal",
    "liste",
    "datenblatt",
    "objektdatenbogen",
    "berechnungsbogen",
    "logger",
    "rechnung",
    "abrechnung",
    "avis",
    "protokoll",
    "urkunde",
    "vermerk",
    "auskunft",
    "auftragsstatus",
}


def word_count(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text, flags=re.UNICODE))


def contract_heading_errors(text: str) -> list[str]:
    errors = []
    lines = text.splitlines()
    for index, line in enumerate(lines):
        heading = re.match(r"^(#{1,6})\s+(.+)$", line)
        if not heading:
            continue
        level = len(heading[1])
        if index == 0 and level == 1:
            continue
        number = re.match(r"([1-9]\d*(?:\.[1-9]\d*)*)(?:\s|$)", heading[2])
        if level == 1 or not number or len(number[1].split(".")) != level - 1:
            errors.append(
                f"Zeile {index + 1}: dezimale Vertragsgliederung fehlt: {line}"
            )
        if index + 1 < len(lines) and lines[index + 1].strip():
            errors.append(
                f"Zeile {index + 1}: Leerzeile nach Vertragsüberschrift fehlt"
            )
    return errors


def exported_markdown(case: Path) -> list[Path]:
    # Inhaltsfehler müssen sichtbar bleiben, auch wenn der Exportfilter sie sperrt.
    return [
        path
        for path in sorted(case.rglob("*.md"))
        if not any(part.startswith(".") for part in path.relative_to(case).parts)
        and "gesamt-pdf" not in path.relative_to(case).parts
        and not is_export_meta_file(path, case, check_content=False)
    ]


def main() -> None:
    errors: list[str] = []
    cases = discover_testakten(TESTAKTEN, SKIP_DIRS)
    for case in cases:
        docs = exported_markdown(case)
        if case.name != "mietspiegel-berlin" and len(docs) < 16:
            errors.append(
                f"{case.name}: nur {len(docs)} fachliche Aktenstücke; erwartet mindestens 16"
            )
        for path in docs:
            rel = path.relative_to(ROOT)
            text = path.read_text(encoding="utf-8", errors="replace")
            lower = text.lower()
            words = word_count(text)
            if words < 90:
                errors.append(
                    f"{rel}: nur {words} Wörter; Aktenstück wirkt wie ein Gerippe"
                )
            for marker in sorted(BANNED_SOURCE_MARKERS | set(META_MARKERS)):
                if marker in lower:
                    errors.append(
                        f"{rel}: unzulässiger Meta- oder Leerbelegmarker {marker!r}"
                    )

            if path.parent.name == "vertrag" and path.stem == "mietvertrag":
                errors.extend(
                    f"{rel}: {error}" for error in contract_heading_errors(text)
                )
                if words < 550:
                    errors.append(f"{rel}: Mietvertrag mit nur {words} Wörtern zu kurz")
                required_groups = (
                    ("Mietsache",),
                    ("Miete",),
                    ("Mietsicherheit", "Kaution"),
                    ("Übergabe",),
                )
                for alternatives in required_groups:
                    if not any(required.lower() in lower for required in alternatives):
                        errors.append(
                            f"{rel}: Vertragsabschnitt {' oder '.join(alternatives)!r} fehlt"
                        )
                if re.search(
                    r"(?:kaution|mietsicherheit)[^\n]{0,160}"
                    r"(?:wurde vollständig|vollständig gezahlt|offene kautionsraten)",
                    lower,
                ):
                    errors.append(
                        f"{rel}: ursprüngliche Vertragsurkunde enthält späteren Kautionsstatus"
                    )

            nonempty = [line for line in text.splitlines() if line.strip()]
            table_lines = [line for line in nonempty if line.lstrip().startswith("|")]
            table_ratio = len(table_lines) / max(len(nonempty), 1)
            if table_ratio > 0.72 and not any(
                part in path.stem.lower() for part in STRUCTURED_STEM_PARTS
            ):
                errors.append(
                    f"{rel}: {table_ratio:.0%} Tabellenzeilen ohne dokumenttypischen Grund"
                )

            if any(
                part in path.stem.lower()
                for part in ("email", "mieter-antwort", "mieter-widerspruch")
            ) and any(
                marker in lower
                for marker in ("## interner aktenvermerk", "| prüffeld | bewertung |")
            ):
                errors.append(
                    f"{rel}: internen Bewertungsblock aus externer Korrespondenz auslagern"
                )

    if errors:
        print("validate-testakten-document-quality: FEHLER", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        raise SystemExit(1)
    total = sum(len(exported_markdown(case)) for case in cases)
    print(
        f"validate-testakten-document-quality OK ({len(cases)} Akten, {total} Aktenstücke)"
    )


if __name__ == "__main__":
    main()
