#!/usr/bin/env python3
"""
Baut pro Plugin ein ZIP-Bundle mit allen Skill-Markdown-Dateien (SKILL.md)
und dem Plugin-README als Navigationsindex.
Diese ZIPs werden als Release-Assets unter
releases/latest/download/<plugin>-skills-markdown.zip veröffentlicht, damit
echte Datei-Downloads möglich sind (statt browser-rendered Markdown auf
GitHub).

Aufruf:
    python3 scripts/build-skills-markdown-bundles.py <output-dir>

Erzeugt:
    <output-dir>/<plugin>-skills-markdown.zip   (pro Plugin)
    <output-dir>/alle-skills-markdown.zip       (eines mit allen Plugins)
"""

import json
import sys
import zipfile
from pathlib import Path


def list_plugins(repo_root: Path) -> list[str]:
    """Lese die Plugin-Liste aus marketplace.json."""
    manifest = json.loads(
        (repo_root / ".claude-plugin" / "marketplace.json").read_text()
    )
    return sorted(p["name"] for p in manifest.get("plugins", []))


def collect_skill_files(plugin_dir: Path) -> list[Path]:
    """Alle SKILL.md unter <plugin>/skills/ einsammeln."""
    skills_dir = plugin_dir / "skills"
    if not skills_dir.is_dir():
        return []
    files = sorted(skills_dir.glob("*/SKILL.md"))
    symlinks = [path for path in files if path.is_symlink() or path.parent.is_symlink()]
    if symlinks:
        names = ", ".join(str(path) for path in symlinks[:10])
        raise SystemExit(f"Symlinks in Skill-Bundles sind unzulässig: {names}")
    return files


def bundle_files(plugin: str, repo_root: Path) -> list[tuple[Path, str]]:
    """Liefert Quellpfade und sichere Archivnamen eines Plugin-Bundles."""
    plugin_dir = repo_root / plugin
    entries: list[tuple[Path, str]] = []
    plugin_readme = plugin_dir / "README.md"
    if plugin_readme.is_file():
        entries.append((plugin_readme, f"{plugin}/README.md"))
    entries.extend(
        (skill_md, skill_md.relative_to(repo_root).as_posix())
        for skill_md in collect_skill_files(plugin_dir)
    )
    names = [name for _, name in entries]
    if len(names) != len(set(names)):
        raise SystemExit(f"{plugin}: doppelte Archivnamen im Markdown-Bundle")
    folded = [name.casefold() for name in names]
    if len(folded) != len(set(folded)):
        raise SystemExit(
            f"{plugin}: Groß-/Kleinschreibung kollidiert im Markdown-Bundle"
        )
    return entries


def build_plugin_bundle(
    plugin: str, repo_root: Path, out_dir: Path
) -> tuple[Path, int, int]:
    entries = bundle_files(plugin, repo_root)
    bundle_path = out_dir / f"{plugin}-skills-markdown.zip"
    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for source, archive_name in entries:
            zf.write(source, arcname=archive_name)
    skill_count = sum(name.endswith("/SKILL.md") for _, name in entries)
    return bundle_path, len(entries), skill_count


def build_combined_bundle(
    plugins: list[str], repo_root: Path, out_dir: Path
) -> tuple[Path, int]:
    """Baut ein direkt entpackbares Sammelpaket ohne ZIP-in-ZIP-Hürde."""
    combined = out_dir / "alle-skills-markdown.zip"
    all_entries = [
        entry for plugin in plugins for entry in bundle_files(plugin, repo_root)
    ]
    names = [name for _, name in all_entries]
    if len(names) != len(set(names)):
        raise SystemExit("Doppelte Archivnamen im Skill-Sammelpaket")
    folded = [name.casefold() for name in names]
    if len(folded) != len(set(folded)):
        raise SystemExit("Groß-/Kleinschreibung kollidiert im Skill-Sammelpaket")
    with zipfile.ZipFile(combined, "w", zipfile.ZIP_DEFLATED) as zf:
        for source, archive_name in all_entries:
            zf.write(source, arcname=archive_name)
    return combined, len(all_entries)


def main():
    if len(sys.argv) != 2:
        print("Usage: build-skills-markdown-bundles.py <output-dir>", file=sys.stderr)
        sys.exit(2)
    out_dir = Path(sys.argv[1]).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    # Repo-Root: Script liegt unter scripts/
    repo_root = Path(__file__).resolve().parent.parent

    plugins = list_plugins(repo_root)
    print(f"Plugins gefunden: {len(plugins)}")

    individual = []
    total_files = 0
    total_skills = 0
    empty = []
    for plugin in plugins:
        bundle_path, n_files, n_skills = build_plugin_bundle(plugin, repo_root, out_dir)
        if n_files == 0:
            empty.append(plugin)
            bundle_path.unlink()
            continue
        individual.append(bundle_path)
        total_files += n_files
        total_skills += n_skills

    print(f"Individual bundles erzeugt: {len(individual)}")
    print(f"SKILL.md-Dateien gesamt: {total_skills}")
    print(f"Markdown-Dateien im Bundle gesamt: {total_files} (inkl. README-Index)")
    if empty:
        print(f"Plugins ohne Skills (kein ZIP): {len(empty)}")
        for p in empty:
            print(f"  - {p}")

    combined, combined_files = build_combined_bundle(plugins, repo_root, out_dir)
    size_mb = combined.stat().st_size / 1024 / 1024
    print(
        f"Combined bundle: {combined.name} "
        f"({combined_files} direkt entpackbare Dateien, {size_mb:.1f} MB)"
    )


if __name__ == "__main__":
    main()
