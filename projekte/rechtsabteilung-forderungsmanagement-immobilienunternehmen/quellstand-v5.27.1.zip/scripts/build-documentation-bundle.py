#!/usr/bin/env python3
"""Baut ein Offline-Paket des vollständigen getrackten Repo-Inhalts."""

from __future__ import annotations

import subprocess
import sys
import zipfile
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_NAME = "immobilien-forderungsmanagement-dokumentation.zip"


def documentation_files() -> list[Path]:
    try:
        result = subprocess.run(
            ["git", "ls-files", "-z"],
            cwd=REPO_ROOT,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
        )
    except subprocess.TimeoutExpired as exc:
        raise SystemExit("git ls-files nach 30 Sekunden abgebrochen") from exc
    if result.returncode != 0:
        message = result.stderr.decode("utf-8", errors="replace")
        raise SystemExit(f"git ls-files fehlgeschlagen: {message}")
    relative_names = [
        name for name in result.stdout.decode("utf-8").split("\0") if name
    ]
    files: list[Path] = []
    for name in relative_names:
        path = REPO_ROOT / name
        if path.is_symlink():
            raise SystemExit(f"Symlink im Dokumentationspaket unzulässig: {name}")
        if not path.is_file():
            raise SystemExit(f"Getrackte Datei fehlt oder ist kein Dateityp: {name}")
        files.append(path)
    folded = [name.casefold() for name in relative_names]
    if len(folded) != len(set(folded)):
        raise SystemExit(
            "Getrackte Pfade kollidieren auf einem Dateisystem ohne "
            "Unterscheidung der Groß-/Kleinschreibung"
        )
    return sorted(files, key=lambda path: path.relative_to(REPO_ROOT).as_posix())


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: build-documentation-bundle.py <output-dir>")
    output_dir = Path(sys.argv[1]).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    files = documentation_files()
    required = {
        REPO_ROOT / "README.md",
        REPO_ROOT / "SKILLS.md",
        REPO_ROOT / "skills-index" / "README.md",
        REPO_ROOT / "forderungsmanagement-immobilien" / "README.md",
        REPO_ROOT / "schriftsatzwerkstatt-bea" / "README.md",
        REPO_ROOT / "testakten" / "README.md",
        REPO_ROOT / "forderungsmanagement-grosser-prompt.md",
        REPO_ROOT / "forderungsmanagement-kleiner-prompt.md",
        REPO_ROOT / "tests" / "smoke-tests.md",
    }
    missing = sorted(
        path.relative_to(REPO_ROOT).as_posix() for path in required if path not in files
    )
    if missing:
        raise SystemExit(f"Dokumentationspaket unvollständig: {', '.join(missing)}")

    output = output_dir / OUTPUT_NAME
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(REPO_ROOT).as_posix())
    print(f"Baue {output.name}: {len(files)} getrackte Repo-Dateien")


if __name__ == "__main__":
    main()
