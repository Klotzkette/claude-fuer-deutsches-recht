#!/usr/bin/env python3
"""Erzeugt den globalen, prüfbaren Skill-Katalog des Repositories.

Die Hauptseite bleibt kurz. Pro Plugin entsteht unter ``skills-index/`` eine
Detailseite mit allen Skills und ausschließlich real vorhandenen Downloads.
``--check`` prüft im CI, ob die getrackten Katalogdateien noch dem aktuellen
Marketplace, den Skill-Frontmattern und der Release-Struktur entsprechen.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from skill_frontmatter import description_from_file

REPO_ROOT = Path(__file__).resolve().parent.parent
GH_OWNER = "Klotzkette"
GH_REPO = "immobilien-forderungsmanagement"
GH_BLOB = f"https://github.com/{GH_OWNER}/{GH_REPO}/blob/main"
GH_RELEASE = f"https://github.com/{GH_OWNER}/{GH_REPO}/releases/latest/download"
SKILLS_INDEX_DIR = REPO_ROOT / "skills-index"
PROMPT_PLUGIN = "forderungsmanagement-immobilien"


def clean_description(desc: str) -> str:
    """Entfernt alte Generator- und Konsolidierungsfloskeln."""
    desc = re.sub(
        r"\s+[—-]\s*Arbeitskontext:\s*[^.]+,\s*Schwerpunkt\s+[^.]+\.?",
        "",
        desc,
    )
    desc = re.sub(r"\s+im Plugin\s+[^.:\"`|]+(?=[:.])", "", desc)
    desc = re.sub(r"\s+im Plugin\s+[^\"`|]+$", "", desc)
    return re.sub(r"\s{2,}", " ", desc).strip()


def read_description(skill_md: Path) -> str:
    desc = description_from_file(skill_md)
    desc = clean_description(desc.replace("\n", " ").strip())
    desc = desc.replace("|", "\\|").strip()
    if len(desc) > 280:
        shortened = desc[:277].rsplit(" ", 1)[0].rstrip(" ,;:-")
        desc = shortened + "..."
    return desc


def collect_plugins() -> list[tuple[str, list[str]]]:
    """Liest die Plugin-Reihenfolge und sammelt gültige Skill-Verzeichnisse."""
    market = json.loads(
        (REPO_ROOT / ".claude-plugin" / "marketplace.json").read_text(encoding="utf-8")
    )
    out: list[tuple[str, list[str]]] = []
    for plugin in market["plugins"]:
        name = str(plugin["name"])
        skills_dir = REPO_ROOT / name / "skills"
        if not skills_dir.is_dir():
            continue
        skills = sorted(
            path.name
            for path in skills_dir.iterdir()
            if path.is_dir() and (path / "SKILL.md").is_file()
        )
        if skills:
            out.append((name, skills))
    return out


def header(total_skills: int, total_plugins: int, version: str) -> str:
    alle_md = f"{GH_RELEASE}/alle-skills-markdown.zip"
    dokumentation = f"{GH_RELEASE}/immobilien-forderungsmanagement-dokumentation.zip"
    return f"""# Skill-Gesamtübersicht

Automatisch erzeugte Gesamtübersicht aller **{total_skills} Skills** in **{total_plugins} Plugins**.

Stand: `{version}`.

## Alle Skills auf einmal herunterladen

| Paket | Inhalt | Download |
| --- | --- | --- |
| Alle Skills als Markdown | Direkt entpackbare `SKILL.md`-Dateien beider Plugins mit je einem README-Index | [`alle-skills-markdown.zip`]({alle_md}) |
| Vollständige Offline-Dokumentation | Getrackter Repo-Inhalt mit READMEs, Skills, Referenzen, Vorlagen und Testaktenquellen | [`immobilien-forderungsmanagement-dokumentation.zip`]({dokumentation}) |

Für Cowork oder Claude Code ist das jeweilige **Plugin-ZIP** die verlässlichste Wahl, weil es neben den Skills auch die benötigten Referenzen, Prüfraster und Vorlagen enthält. Das reine Markdown-Paket eignet sich zum Lesen, Vergleichen und für Umgebungen, in denen der Skilltext zusammen mit den darin genannten Hilfsdateien bereitgestellt wird.

Wer nur ein bestimmtes Plugin benötigt, findet in der Tabelle unten dessen Plugin-ZIP, Markdown-ZIP und Detailseite. Werkstatt- und Schnellstartprompt existieren bewusst nur für das Fachplugin; die fachlich neutrale beA-Werkstatt wird ausschließlich als Plugin und Skill-Sammlung ausgeliefert.

## Skill einzeln öffnen

1. In der Plugin-Tabelle die Detailseite öffnen.
2. Beim gewünschten Skill auf **Ansehen** klicken.
3. Für einen echten Datei-Download **Herunterladen** wählen oder das Markdown-ZIP des Plugins verwenden.
4. In einer anderen KI-Umgebung zusätzlich alle im Skill genannten Referenzen und Eingabedateien bereitstellen. Ohne diese Paketdateien kann ein einzelner Skill weniger leisten als das installierte Plugin.

Die Detailseiten liegen unter [`skills-index/`](skills-index/). Der Katalog wird aus dem Marketplace und den gültigen `SKILL.md`-Frontmattern erzeugt und vor jedem Release auf Drift geprüft.

"""


def plugin_overview_table(plugins: list[tuple[str, list[str]]]) -> str:
    lines = [
        "## Alle Plugins",
        "",
        "Das Plugin-ZIP enthält den vollständigen Cowork-/Claude-Code-Lieferumfang. Das Markdown-ZIP enthält direkt entpackbare Skilltexte. Prompt-Downloads sind nur dort aufgeführt, wo die Assets tatsächlich veröffentlicht werden.",
        "",
        "| Plugin | Skills | Detailseite | Plugin-ZIP | Markdown-ZIP | Schnellstartprompt | Werkstattprompt |",
        "| --- | ---: | --- | --- | --- | --- | --- |",
    ]
    for name, skills in plugins:
        zip_url = f"{GH_RELEASE}/{name}.zip"
        md_url = f"{GH_RELEASE}/{name}-skills-markdown.zip"
        if name == PROMPT_PLUGIN:
            kleiner = (
                f"[MD]({GH_RELEASE}/{name}-kleiner-prompt-skill.md) / "
                f"[ZIP]({GH_RELEASE}/{name}-kleiner-prompt-skill.zip)"
            )
            grosser = (
                f"[MD]({GH_RELEASE}/{name}-grosser-prompt-skill.md) / "
                f"[ZIP]({GH_RELEASE}/{name}-grosser-prompt-skill.zip)"
            )
        else:
            kleiner = "nicht vorgesehen"
            grosser = "nicht vorgesehen"
        lines.append(
            f"| `{name}` | {len(skills)} | [Skills ansehen](skills-index/{name}.md) "
            f"| [Plugin]({zip_url}) | [Markdown]({md_url}) | {kleiner} | {grosser} |"
        )
    lines.append("")
    return "\n".join(lines)


def plugin_detail_page(name: str, skills: list[str], version: str) -> str:
    skills_dir = REPO_ROOT / name / "skills"
    plugin_zip = f"{GH_RELEASE}/{name}.zip"
    md_zip = f"{GH_RELEASE}/{name}-skills-markdown.zip"
    lines = [
        f"# {name}",
        "",
        f"{len(skills)} Skills · Stand `{version}`",
        "",
        "- [Zurück zur Gesamtübersicht](../SKILLS.md)",
        f"- [Plugin-README](../{name}/README.md)",
        "",
        "## Downloads",
        "",
        "| Paket | Inhalt | Link |",
        "| --- | --- | --- |",
        f"| Plugin-ZIP | Vollständiges Cowork-/Claude-Code-Plugin mit Skills und mitgelieferten Hilfsdateien | [{name}.zip]({plugin_zip}) |",
        f"| Markdown-ZIP | Plugin-README und alle `SKILL.md` direkt in einer entpackbaren Ordnerstruktur | [{name}-skills-markdown.zip]({md_zip}) |",
    ]
    if name == PROMPT_PLUGIN:
        lines.extend(
            [
                f"| Schnellstartprompt | Autarker Kurzworkflow unter 7.500 Zeichen | [{name}-kleiner-prompt-skill.md]({GH_RELEASE}/{name}-kleiner-prompt-skill.md) / [{name}-kleiner-prompt-skill.zip]({GH_RELEASE}/{name}-kleiner-prompt-skill.zip) |",
                f"| Werkstattprompt | Autarker ausführlicher Fachworkflow | [{name}-grosser-prompt-skill.md]({GH_RELEASE}/{name}-grosser-prompt-skill.md) / [{name}-grosser-prompt-skill.zip]({GH_RELEASE}/{name}-grosser-prompt-skill.zip) |",
            ]
        )
    lines.extend(
        [
            "",
            "## So benutzt man einen Skill",
            "",
            "- **Cowork oder Claude Code:** Plugin-ZIP verwenden; damit bleiben Referenzen, Vorlagen und Router zusammen.",
            "- **Einzeltext prüfen:** `Ansehen` öffnet die getrackte `SKILL.md`; `Herunterladen` liefert dieselbe Datei über GitHub.",
            "- **Andere KI-Umgebung:** Skilltext und alle darin verlangten Referenz- oder Eingabedateien gemeinsam bereitstellen.",
            "",
            "## Skills in diesem Plugin",
            "",
            "| Skill | Beschreibung | Datei |",
            "| --- | --- | --- |",
        ]
    )
    for skill_name in skills:
        skill_md = skills_dir / skill_name / "SKILL.md"
        desc = read_description(skill_md)
        rel_md = f"{name}/skills/{skill_name}/SKILL.md"
        blob_url = f"{GH_BLOB}/{rel_md}"
        lines.append(
            f"| [`{skill_name}`](../{rel_md}) | {desc} | "
            f"[Ansehen](../{rel_md}) · [Herunterladen]({blob_url}?raw=1) |"
        )
    lines.append("")
    return "\n".join(lines)


def detail_index(plugins: list[tuple[str, list[str]]], version: str) -> str:
    lines = [
        "# Skills-Index: Detailseiten pro Plugin",
        "",
        f"Eine Detailseite pro Plugin mit allen Skills, Beschreibungen und Einzel-Downloads. Stand: `{version}`.",
        "",
        "Die Aufteilung hält die Navigation schnell und vermeidet eine unnötig große Haupttabelle.",
        "",
        "- [Zurück zur Gesamtübersicht](../SKILLS.md)",
        "",
        "## Alle Detailseiten",
        "",
    ]
    for name, skills in plugins:
        lines.append(f"- [{name}](./{name}.md) ({len(skills)} Skills)")
    lines.append("")
    return "\n".join(lines)


def build_outputs() -> tuple[dict[Path, str], int, int, str]:
    plugins = collect_plugins()
    total_skills = sum(len(skills) for _, skills in plugins)
    total_plugins = len(plugins)
    marketplace = json.loads(
        (REPO_ROOT / ".claude-plugin" / "marketplace.json").read_text(encoding="utf-8")
    )
    version = "v" + str(marketplace["version"])

    main_text = header(total_skills, total_plugins, version)
    main_text += plugin_overview_table(plugins)
    outputs = {REPO_ROOT / "SKILLS.md": main_text.rstrip() + "\n"}
    for name, skills in plugins:
        outputs[SKILLS_INDEX_DIR / f"{name}.md"] = (
            plugin_detail_page(name, skills, version).rstrip() + "\n"
        )
    outputs[SKILLS_INDEX_DIR / "README.md"] = (
        detail_index(plugins, version).rstrip() + "\n"
    )
    return outputs, total_skills, total_plugins, version


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--check",
        action="store_true",
        help="Prüft getrackte Katalogdateien, ohne sie zu verändern.",
    )
    args = parser.parse_args()
    outputs, total_skills, total_plugins, version = build_outputs()
    expected_paths = set(outputs)

    if args.check:
        errors: list[str] = []
        for path, expected in outputs.items():
            if not path.is_file():
                errors.append(f"fehlt: {path.relative_to(REPO_ROOT)}")
            elif path.read_text(encoding="utf-8") != expected:
                errors.append(f"veraltet: {path.relative_to(REPO_ROOT)}")
        if SKILLS_INDEX_DIR.is_dir():
            stale = sorted(
                path.relative_to(REPO_ROOT).as_posix()
                for path in SKILLS_INDEX_DIR.glob("*.md")
                if path not in expected_paths
            )
            errors.extend(f"verwaist: {path}" for path in stale)
        if errors:
            print("\n".join(errors), file=sys.stderr)
            print(
                f"generate-skills-md --check fehlgeschlagen: {len(errors)} Fehler",
                file=sys.stderr,
            )
            return 1
        print(
            f"generate-skills-md --check OK ({total_plugins} Plugins, "
            f"{total_skills} Skills, Stand {version})"
        )
        return 0

    SKILLS_INDEX_DIR.mkdir(exist_ok=True)
    for old in SKILLS_INDEX_DIR.glob("*.md"):
        if old not in expected_paths:
            old.unlink()
    for path, text in outputs.items():
        path.write_text(text, encoding="utf-8")
    print(
        f"SKILLS.md: {len(outputs[REPO_ROOT / 'SKILLS.md'])} Zeichen "
        f"({total_plugins} Plugins). skills-index/: {total_plugins} "
        f"Detailseiten + Index. Insgesamt {total_skills} Skills, Stand {version}."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
