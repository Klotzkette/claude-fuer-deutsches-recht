#!/usr/bin/env python3
"""Validate plugin release ZIPs before publishing them."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import NoReturn

import yaml

from testakte_file_filter import TESTAKTEN_RELEASE_INDEX_SCHEMA


def fail(message: str) -> NoReturn:
    print(f"validate-release-zips failed: {message}", file=sys.stderr)
    raise SystemExit(1)


def _validated_zip_infos(zip_path: Path) -> list[zipfile.ZipInfo]:
    if not zip_path.is_file():
        fail(f"{zip_path}: missing ZIP")
    try:
        with zipfile.ZipFile(zip_path) as archive:
            infos = archive.infolist()
            bad_member = archive.testzip()
    except (OSError, zipfile.BadZipFile) as exc:
        fail(f"{zip_path}: invalid ZIP: {exc}")
    if bad_member is not None:
        fail(f"{zip_path}: corrupt ZIP member {bad_member}")

    seen: set[str] = set()
    seen_casefold: set[str] = set()
    for info in infos:
        raw_name = info.filename
        if "\\" in raw_name or "\x00" in raw_name:
            fail(f"{zip_path}: unsafe ZIP member name {raw_name!r}")
        member = PurePosixPath(raw_name)
        if member.is_absolute() or ".." in member.parts:
            fail(f"{zip_path}: unsafe ZIP member path {raw_name!r}")
        normalized = member.as_posix()
        if normalized in seen:
            fail(f"{zip_path}: duplicate ZIP member {normalized}")
        seen.add(normalized)
        folded = normalized.casefold()
        if folded in seen_casefold:
            fail(
                f"{zip_path}: ZIP members collide on case-insensitive filesystems: "
                f"{normalized}"
            )
        seen_casefold.add(folded)
    return infos


def zip_names(zip_path: Path) -> set[str]:
    return {
        PurePosixPath(info.filename).as_posix()
        for info in _validated_zip_infos(zip_path)
    }


def zip_file_bytes(zip_path: Path) -> dict[str, bytes]:
    infos = _validated_zip_infos(zip_path)
    try:
        with zipfile.ZipFile(zip_path) as archive:
            return {
                PurePosixPath(info.filename).as_posix(): archive.read(info)
                for info in infos
                if not info.is_dir()
            }
    except (OSError, zipfile.BadZipFile, RuntimeError) as exc:
        fail(f"{zip_path}: ZIP member could not be read: {exc}")


def expected_plugin_files(plugin_root: Path) -> dict[str, bytes]:
    files: dict[str, bytes] = {}
    for path in sorted(plugin_root.rglob("*")):
        if path.is_symlink():
            fail(f"{plugin_root}: symlink must not be packaged: {path}")
        if not path.is_file():
            continue
        relative = path.relative_to(plugin_root)
        if (
            path.name == ".DS_Store"
            or "__pycache__" in relative.parts
            or path.suffix == ".pyc"
            or relative.as_posix() == "CLAUDE.md"
        ):
            continue
        files[relative.as_posix()] = path.read_bytes()
    return files


def assert_exact_files(
    label: Path, actual: dict[str, bytes], expected: dict[str, bytes]
) -> None:
    actual_names = set(actual)
    expected_names = set(expected)
    if actual_names != expected_names:
        missing = sorted(expected_names - actual_names)
        extra = sorted(actual_names - expected_names)
        fail(f"{label}: file set mismatch, missing={missing[:20]}, extra={extra[:20]}")
    changed = [
        name for name in sorted(expected_names) if actual[name] != expected[name]
    ]
    if changed:
        fail(f"{label}: packaged content differs from source: {changed[:20]}")


# Cowork-/Marketplace-Upload-Limit liegt offiziell bei 50 MB. Die frühere
# Hypothese eines 1-MB-Limits war falsch — der eigentliche Bug war eine
# Zahl-Komma-Zahl-Sequenz im description-Feld (siehe validate-plugin-structure.mjs).
# Wir bleiben mit einem komfortablen Sicherheitsabstand bei 10 MB.
MAX_ZIP_BYTES = 10 * 1024 * 1024
MAX_MINI_PROMPT_CHARS = 7500
MAX_MINI_PROMPT_SOURCE_CHARS = 7200
MAX_MEGA_PROMPT_CHARS = 30_000
MAX_DESCRIPTION_CHARS = 1_024
REQUIRED_REFERENCE_FILES_BY_PLUGIN = {
    "forderungsmanagement-immobilien": {
        "references/erv-dokumentenproduktion.md",
        "references/gepruefte-bgh-anker-mietrecht.md",
        "references/leitentscheidungen-anker.md",
        "references/methodik-buergerliches-recht.md",
        "references/quellenhygiene.md",
        "references/rechtsstand-2026-verfahren-vollstreckung.md",
        "references/rechtsprechungsradar-mietrecht-2021-2026.md",
        "references/schriftsatz-und-argumentationsstandard.md",
        "references/zitierweise.md",
    },
    "schriftsatzwerkstatt-bea": {
        "references/100-punkte-fehlerkatalog.md",
        "references/dateinamen-und-manifest.md",
        "references/erv-versandstandard.md",
        "references/inhaltstreue-und-renderabgleich.md",
    },
}
DOCUMENTATION_ASSET = "immobilien-forderungsmanagement-dokumentation.zip"
RELEASE_CATALOG = "release-katalog.md"
CHECKSUMS = "checksums-sha256.txt"

PROMPT_SKILL_ASSETS = {
    "grosser-prompt": {
        "md": "forderungsmanagement-immobilien-grosser-prompt-skill.md",
        "zip": "forderungsmanagement-immobilien-grosser-prompt-skill.zip",
        "source": "forderungsmanagement-grosser-prompt.md",
        "max_chars": MAX_MEGA_PROMPT_CHARS,
    },
    "kleiner-prompt": {
        "md": "forderungsmanagement-immobilien-kleiner-prompt-skill.md",
        "zip": "forderungsmanagement-immobilien-kleiner-prompt-skill.zip",
        "source": "forderungsmanagement-kleiner-prompt.md",
        "max_chars": MAX_MINI_PROMPT_SOURCE_CHARS,
        "skill_max_chars": MAX_MINI_PROMPT_CHARS,
    },
}


def validate_plugin_zip(
    dist_dir: Path, plugin: dict[str, object], repo_root: Path
) -> None:
    plugin_name = str(plugin["name"])
    zip_path = dist_dir / f"{plugin_name}.zip"
    if not zip_path.exists():
        fail(f"{zip_path}: missing plugin ZIP")

    size = zip_path.stat().st_size
    if size > MAX_ZIP_BYTES:
        fail(
            f"{zip_path}: {size} bytes überschreitet Cowork-Uploadgrenze ({MAX_ZIP_BYTES} bytes). "
            "Große Binärdateien (z. B. PDFs) entfernen und durch Online-Verweise ersetzen."
        )

    names = zip_names(zip_path)
    if ".claude-plugin/plugin.json" not in names:
        fail(f"{zip_path}: .claude-plugin/plugin.json must be at ZIP root")
    if f"{plugin_name}/.claude-plugin/plugin.json" in names:
        fail(
            f"{zip_path}: ZIP is nested under {plugin_name}/; upload ZIPs must be flat"
        )
    if any(name.startswith(f"{plugin_name}/") for name in names):
        fail(f"{zip_path}: contains nested {plugin_name}/ root")
    if "CLAUDE.md" in names:
        fail(
            f"{zip_path}: root CLAUDE.md must not be shipped; Claude Code treats it as a warning and Cowork upload may reject it"
        )
    if any("__pycache__/" in name or name.endswith(".pyc") for name in names):
        fail(f"{zip_path}: contains Python cache files")
    required_references = REQUIRED_REFERENCE_FILES_BY_PLUGIN.get(plugin_name, set())
    missing_references = sorted(required_references - names)
    if missing_references:
        fail(f"{zip_path}: missing bundled references: {', '.join(missing_references)}")

    packaged_files = zip_file_bytes(zip_path)
    source_files = expected_plugin_files(repo_root / plugin_name)
    assert_exact_files(zip_path, packaged_files, source_files)

    manifest = json.loads(packaged_files[".claude-plugin/plugin.json"])
    if manifest.get("name") != plugin_name:
        fail(
            f"{zip_path}: manifest name {manifest.get('name')!r} does not match {plugin_name!r}"
        )
    expected_version = str(plugin.get("version", ""))
    if manifest.get("version") != expected_version:
        fail(
            f"{zip_path}: manifest version {manifest.get('version')!r} "
            f"does not match marketplace version {expected_version!r}"
        )
    description = manifest.get("description", "")
    if len(description) > 300:
        fail(
            f"{zip_path}: manifest description has {len(description)} chars; Cowork bevorzugt <= 300"
        )
    # Letzte Verteidigung gegen den 'Zahl-Komma-Zahl'-Validator-Bug.
    if re.search(r"\d\s*,\s*\d", description):
        fail(
            f"{zip_path}: manifest description enthält Zahl-Komma-Zahl-Sequenz; nutze 'Rn', 'und' oder '/'"
        )

    if plugin_name == "liquiditaetsplanung":
        generator = "skills/liquiditaetsvorschau-3-6-12-monate/werkzeuge/build_liquiditaetsplan.py"
        if generator not in names:
            fail(
                f"{zip_path}: missing standalone Liquiditätsplan generator {generator}"
            )


def validate_prompt_and_markdown_assets(
    dist_dir: Path, plugins: list[str], repo_root: Path
) -> None:
    combined_markdown = dist_dir / "alle-skills-markdown.zip"
    if not combined_markdown.exists():
        fail(f"{combined_markdown}: missing combined Markdown ZIP")

    combined_markdown_files = zip_file_bytes(combined_markdown)

    expected_combined: dict[str, bytes] = {}
    for plugin_name in plugins:
        markdown_zip = dist_dir / f"{plugin_name}-skills-markdown.zip"
        if not markdown_zip.exists():
            fail(f"{markdown_zip}: missing skill Markdown ZIP")
        packaged_files = zip_file_bytes(markdown_zip)
        names = set(packaged_files)
        if f"{plugin_name}/README.md" not in names:
            fail(f"{markdown_zip}: plugin README missing")
        if not any(
            name.startswith(f"{plugin_name}/skills/") and name.endswith("/SKILL.md")
            for name in names
        ):
            fail(f"{markdown_zip}: no SKILL.md entries")

        expected_files: dict[str, bytes] = {}
        plugin_root = repo_root / plugin_name
        plugin_readme = plugin_root / "README.md"
        if plugin_readme.is_file():
            expected_files[f"{plugin_name}/README.md"] = plugin_readme.read_bytes()
        for skill in sorted((plugin_root / "skills").glob("*/SKILL.md")):
            expected_files[skill.relative_to(repo_root).as_posix()] = skill.read_bytes()
        assert_exact_files(markdown_zip, packaged_files, expected_files)
        overlap = sorted(set(expected_combined) & set(expected_files))
        if overlap:
            fail(
                f"{combined_markdown}: duplicate paths across plugin bundles: "
                f"{overlap[:20]}"
            )
        expected_combined.update(expected_files)

    assert_exact_files(
        combined_markdown,
        combined_markdown_files,
        expected_combined,
    )
    if any(name.endswith(".zip") for name in combined_markdown_files):
        fail(
            f"{combined_markdown}: nested ZIPs are forbidden; skills must be "
            "directly extractable"
        )


def validate_documentation_bundle(dist_dir: Path, repo_root: Path) -> None:
    bundle = dist_dir / DOCUMENTATION_ASSET
    if not bundle.exists():
        fail(f"{bundle}: missing offline documentation bundle")
    packaged_files = zip_file_bytes(bundle)
    names = set(packaged_files)
    required = {
        "README.md",
        "SKILLS.md",
        "CHANGELOG.md",
        "forderungsmanagement-grosser-prompt.md",
        "forderungsmanagement-kleiner-prompt.md",
        "forderungsmanagement-immobilien/README.md",
        "forderungsmanagement-immobilien/references/bedienfuehrung-workflows.md",
        "forderungsmanagement-immobilien/references/erv-dokumentenproduktion.md",
        "forderungsmanagement-immobilien/references/schriftsatz-und-argumentationsstandard.md",
        "schriftsatzwerkstatt-bea/README.md",
        "schriftsatzwerkstatt-bea/references/100-punkte-fehlerkatalog.md",
        "schriftsatzwerkstatt-bea/references/dateinamen-und-manifest.md",
        "schriftsatzwerkstatt-bea/references/erv-versandstandard.md",
        "schriftsatzwerkstatt-bea/references/inhaltstreue-und-renderabgleich.md",
        "schriftsatzwerkstatt-bea/scripts/validate_bea_package.py",
        "schriftsatzwerkstatt-bea/templates/konvertierungsprotokoll.md",
        "schriftsatzwerkstatt-bea/templates/eingangsvermerk.md",
        "schriftsatzwerkstatt-bea/templates/signaturmanifest.csv",
        "skills-index/README.md",
        "skills-index/forderungsmanagement-immobilien.md",
        "skills-index/schriftsatzwerkstatt-bea.md",
        "references/gepruefte-bgh-anker-mietrecht.md",
        "references/rechtsstand-2026-verfahren-vollstreckung.md",
        "references/rechtsprechungsradar-mietrecht-2021-2026.md",
        "references/schriftsatz-und-argumentationsstandard.md",
        "testakten/README.md",
        "tests/smoke-tests.md",
    }
    missing = sorted(required - names)
    if missing:
        fail(f"{bundle}: missing documentation files: {', '.join(missing)}")
    marketplace = json.loads(
        (repo_root / ".claude-plugin" / "marketplace.json").read_text(encoding="utf-8")
    )
    skill_files = [
        skill
        for plugin in marketplace["plugins"]
        for skill in sorted(
            (repo_root / str(plugin["name"]) / "skills").glob("*/SKILL.md")
        )
    ]
    missing_skills = [
        path.relative_to(repo_root).as_posix()
        for path in skill_files
        if path.relative_to(repo_root).as_posix() not in names
    ]
    if missing_skills:
        fail(f"{bundle}: missing linked skill files: {', '.join(missing_skills)}")

    try:
        tracked = subprocess.run(
            ["git", "ls-files", "-z"],
            cwd=repo_root,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        fail(f"git ls-files timed out while validating {bundle}")
    if tracked.returncode != 0:
        message = tracked.stderr.decode("utf-8", errors="replace")
        fail(f"git ls-files failed while validating {bundle}: {message}")
    expected_names = {
        name for name in tracked.stdout.decode("utf-8").split("\0") if name
    }
    folded_names = [name.casefold() for name in expected_names]
    if len(folded_names) != len(set(folded_names)):
        fail(f"{bundle}: tracked paths collide on case-insensitive filesystems")
    if names != expected_names:
        missing = sorted(expected_names - names)
        extra = sorted(names - expected_names)
        fail(
            f"{bundle}: tracked file mismatch, missing={missing[:20]}, extra={extra[:20]}"
        )
    expected_files: dict[str, bytes] = {}
    for name in sorted(expected_names):
        source = repo_root / name
        if source.is_symlink():
            fail(f"{bundle}: tracked symlink must not be packaged: {name}")
        if not source.is_file():
            fail(f"{bundle}: tracked source file missing: {name}")
        expected_files[name] = source.read_bytes()
    assert_exact_files(bundle, packaged_files, expected_files)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_release_catalog(dist_dir: Path) -> None:
    catalog = dist_dir / RELEASE_CATALOG
    checksum_file = dist_dir / CHECKSUMS
    if not catalog.exists():
        fail(f"{catalog}: missing release catalog")
    if not checksum_file.exists():
        fail(f"{checksum_file}: missing release checksums")

    asset_names = {path.name for path in dist_dir.iterdir() if path.is_file()}
    catalog_text = catalog.read_text(encoding="utf-8")
    release_base = "https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download"
    for name in sorted(asset_names):
        if f"{release_base}/{name}" not in catalog_text:
            fail(f"{catalog}: missing direct link for {name}")

    checksums: dict[str, str] = {}
    for line in checksum_file.read_text(encoding="ascii").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([^/]+)", line)
        if not match:
            fail(f"{checksum_file}: invalid line {line!r}")
        digest, name = match.groups()
        if name in checksums:
            fail(f"{checksum_file}: duplicate checksum for {name}")
        checksums[name] = digest

    expected = asset_names - {CHECKSUMS}
    if set(checksums) != expected:
        missing = sorted(expected - set(checksums))
        extra = sorted(set(checksums) - expected)
        fail(f"{checksum_file}: asset mismatch, missing={missing}, extra={extra}")
    for name, expected_digest in sorted(checksums.items()):
        actual_digest = file_sha256(dist_dir / name)
        if actual_digest != expected_digest:
            fail(f"{checksum_file}: digest mismatch for {name}")


def validate_standalone_skill_frontmatter(path: Path, text: str) -> dict[str, object]:
    if not text.startswith("---\n"):
        fail(f"{path}: missing skill YAML frontmatter")
    try:
        _, frontmatter, _ = text.split("---\n", 2)
    except ValueError:
        fail(f"{path}: invalid skill YAML frontmatter")

    try:
        parsed = yaml.safe_load(frontmatter)
    except yaml.YAMLError as exc:
        fail(f"{path}: invalid skill YAML frontmatter: {exc}")
    if not isinstance(parsed, dict):
        fail(f"{path}: frontmatter is not a mapping")

    if set(parsed) != {"name", "description"}:
        fail(
            f"{path}: frontmatter must contain exactly name and description, got {sorted(parsed)}"
        )

    description_line = next(
        (line for line in frontmatter.splitlines() if line.startswith("description:")),
        "",
    )
    raw_description = (
        description_line.split(":", 1)[1].strip() if ":" in description_line else ""
    )
    if not (raw_description.startswith("'") and raw_description.endswith("'")):
        fail(f"{path}: description must be single-quoted YAML")

    name = str(parsed["name"])
    description = str(parsed["description"])
    if not re.fullmatch(r"[a-z0-9-]{1,64}", name):
        fail(f"{path}: invalid skill name {name!r}")
    if len(description) > MAX_DESCRIPTION_CHARS:
        fail(
            f"{path}: description has {len(description)} chars, max {MAX_DESCRIPTION_CHARS}"
        )
    if re.search(r"\d,\d", description):
        fail(f"{path}: description contains comma-number pattern")
    for forbidden in ['"', "<", ">"]:
        if forbidden in description:
            fail(f"{path}: description contains forbidden character {forbidden}")
    lowered = description.lower()
    for forbidden_word in ["scrape", "scraping", "crawl", "crawling"]:
        if forbidden_word in lowered:
            fail(f"{path}: description contains forbidden word {forbidden_word}")
    return parsed


def validate_cloud_cowork_prompt_skills(dist_dir: Path, repo_root: Path) -> None:
    for label, item in PROMPT_SKILL_ASSETS.items():
        source = repo_root / item["source"]
        if not source.exists():
            fail(f"{source}: missing source prompt")
        source_len = len(source.read_text(encoding="utf-8"))
        if source_len > int(item["max_chars"]):
            fail(
                f"{source}: {source_len} chars exceeds {item['max_chars']} for Cloud-Co-Work {label} skill"
            )

        md_path = dist_dir / item["md"]
        zip_path = dist_dir / item["zip"]
        if not md_path.exists():
            fail(f"{md_path}: missing standalone Cloud-Co-Work skill Markdown")
        if not zip_path.exists():
            fail(f"{zip_path}: missing standalone Cloud-Co-Work skill ZIP")

        text = md_path.read_text(encoding="utf-8")
        skill_max = item.get("skill_max_chars")
        if skill_max is not None and len(text) > int(skill_max):
            fail(
                f"{md_path}: {len(text)} chars exceeds standalone skill limit {skill_max}"
            )
        parsed = validate_standalone_skill_frontmatter(md_path, text)
        expected_name = {
            "grosser-prompt": "forderungsmanagement-immobilien-werkstattprompt",
            "kleiner-prompt": "forderungsmanagement-immobilien-schnellstartprompt",
        }[label]
        if parsed["name"] != expected_name:
            fail(
                f"{md_path}: generated skill name {parsed['name']!r} does not match {expected_name!r}"
            )
        if not text.endswith(source.read_text(encoding="utf-8").strip() + "\n"):
            fail(
                f"{md_path}: generated skill does not contain the exact current source prompt"
            )

        names = zip_names(zip_path)
        if names != {"SKILL.md"}:
            fail(
                f"{zip_path}: standalone skill ZIP must contain exactly SKILL.md at root, got {sorted(names)}"
            )
        with zipfile.ZipFile(zip_path) as archive:
            zipped = archive.read("SKILL.md").decode("utf-8")
        if zipped != text:
            fail(f"{zip_path}: SKILL.md differs from {md_path.name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dist", nargs="?", type=Path, default=Path("dist"))
    parser.add_argument(
        "marketplace",
        nargs="?",
        type=Path,
        default=Path(".claude-plugin/marketplace.json"),
    )
    parser.add_argument("--expected-tag")
    args = parser.parse_args()
    dist_dir = args.dist
    marketplace_path = args.marketplace

    marketplace = json.loads(marketplace_path.read_text(encoding="utf-8"))
    repo_root = marketplace_path.resolve().parent.parent
    version = str(marketplace.get("version", ""))
    if args.expected_tag and args.expected_tag != f"v{version}":
        fail(
            f"release tag {args.expected_tag!r} does not match marketplace version "
            f"v{version}"
        )
    plugin_entries = marketplace["plugins"]
    plugins = [str(plugin["name"]) for plugin in plugin_entries]
    for plugin in plugin_entries:
        if str(plugin.get("version", "")) != version:
            fail(
                f"marketplace plugin {plugin.get('name')}: version {plugin.get('version')!r} "
                f"does not match marketplace version {version!r}"
            )
        validate_plugin_zip(dist_dir, plugin, repo_root)
    validate_prompt_and_markdown_assets(dist_dir, plugins, repo_root)
    validate_documentation_bundle(dist_dir, repo_root)
    validate_cloud_cowork_prompt_skills(dist_dir, repo_root)

    marketplace_zip_copy = dist_dir / "marketplace.json"
    if not marketplace_zip_copy.exists():
        fail(f"{marketplace_zip_copy}: missing marketplace.json release asset")
    if marketplace_zip_copy.read_bytes() != marketplace_path.read_bytes():
        fail(
            f"{marketplace_zip_copy}: release asset differs from source marketplace.json"
        )
    json.loads(marketplace_zip_copy.read_text(encoding="utf-8"))

    testakten_index = dist_dir / "testakten-release-index.json"
    if not testakten_index.exists():
        fail(f"{testakten_index}: missing testakten release asset index")
    index = json.loads(testakten_index.read_text(encoding="utf-8"))
    if index.get("schema") != TESTAKTEN_RELEASE_INDEX_SCHEMA:
        fail(f"{testakten_index}: unexpected schema {index.get('schema')!r}")

    validate_release_catalog(dist_dir)

    print(f"validate-release-zips OK ({len(plugins)} plugin ZIPs)")


if __name__ == "__main__":
    main()
