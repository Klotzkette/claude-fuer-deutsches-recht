#!/usr/bin/env python3
"""Prüft die durchgängige Navigation zwischen README, Skills und Testakten."""

from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
PLUGIN = ROOT / "forderungsmanagement-immobilien"
BEA_PLUGIN = ROOT / "schriftsatzwerkstatt-bea"
RELEASE_BASE = "https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download"
CASE_START = (
    "Neuer Fall. Prüfe den gesamten Ordner, sichere zuerst alle Fristen und arbeite "
    "ohne Skillauswahl bis zur nächsten freigabefähigen Entscheidung weiter."
)
BEA_START = (
    "Mache diesen Ordner beA-fertig. Verändere den juristischen Inhalt nicht und "
    "frage nur nach Angaben, die du nicht sicher aus den Dateien entnehmen kannst."
)


def load_overview_generator():
    script = ROOT / "scripts" / "generate-skills-overview.py"
    spec = importlib.util.spec_from_file_location("generate_skills_overview", script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Generator kann nicht geladen werden: {script}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_global_catalog_generator():
    script = ROOT / "scripts" / "generate-skills-md.py"
    spec = importlib.util.spec_from_file_location("generate_skills_md", script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Generator kann nicht geladen werden: {script}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(text: str, needle: str, label: str, errors: list[str]) -> None:
    if needle not in text:
        errors.append(f"{label}: Pflichtnavigation fehlt: {needle}")


def markdown_section(text: str, heading: str) -> str:
    match = re.search(rf"^{re.escape(heading)}\s*$", text, flags=re.MULTILINE)
    if match is None:
        return ""
    start = match.end()
    next_heading = re.search(r"^##\s+", text[start:], flags=re.MULTILINE)
    end = start + next_heading.start() if next_heading is not None else len(text)
    return text[start:end]


def main() -> int:
    errors: list[str] = []
    overview_generator = load_overview_generator()
    catalog_generator = load_global_catalog_generator()
    root_readme = (ROOT / "README.md").read_text(encoding="utf-8")
    plugin_readme = (PLUGIN / "README.md").read_text(encoding="utf-8")
    bea_readme = (BEA_PLUGIN / "README.md").read_text(encoding="utf-8")
    testakten_readme = (ROOT / "testakten" / "README.md").read_text(encoding="utf-8")
    workflow_guide = (ROOT / "references/bedienfuehrung-workflows.md").read_text(
        encoding="utf-8"
    )
    start_skill = (PLUGIN / "skills/33-dokumentenmix-ocr-sichten/SKILL.md").read_text(
        encoding="utf-8"
    )
    bea_start_skill = (BEA_PLUGIN / "skills/01-bea-ordner-annahme/SKILL.md").read_text(
        encoding="utf-8"
    )
    prompts = {
        "forderungsmanagement-grosser-prompt.md": (
            ROOT / "forderungsmanagement-grosser-prompt.md"
        ).read_text(encoding="utf-8"),
        "forderungsmanagement-kleiner-prompt.md": (
            ROOT / "forderungsmanagement-kleiner-prompt.md"
        ).read_text(encoding="utf-8"),
    }

    catalog_outputs, _, _, _ = catalog_generator.build_outputs()
    for path, expected in catalog_outputs.items():
        label = path.relative_to(ROOT).as_posix()
        if not path.is_file():
            errors.append(f"{label}: generierter Skill-Katalog fehlt")
        elif path.read_text(encoding="utf-8") != expected:
            errors.append(f"{label}: generierter Skill-Katalog ist veraltet")

    for plugin_dir, readme_text in ((PLUGIN, plugin_readme),):
        expected = overview_generator.build_overview(plugin_dir)
        begin = overview_generator.BEGIN
        end = overview_generator.END
        start = readme_text.find(begin)
        stop = readme_text.find(end, start + len(begin)) if start >= 0 else -1
        if start < 0 or stop < 0:
            errors.append(
                f"{plugin_dir.name}/README.md: generierter Skill-Katalog fehlt"
            )
            continue
        actual = readme_text[start : stop + len(end)]
        if actual != expected:
            errors.append(
                f"{plugin_dir.name}/README.md: Skill-Katalog ist nicht mit den Frontmattern synchron"
            )

    for heading in (
        "## Direktstart: zwei klare Wege",
        "## Sofort-Downloads (latest Release)",
        "## Fach- und Betriebsreferenzen",
        "## Tagesworkflow für Bearbeiter",
        "## Anschluss an elektronische Akten",
    ):
        require(root_readme, heading, "README.md", errors)
    for heading in (
        "## In 60 Sekunden zum ersten Ergebnis",
        "## Schnellnavigation",
        "## Workflow-Phasen",
        "## Alle Skills im Überblick",
    ):
        require(
            plugin_readme, heading, "forderungsmanagement-immobilien/README.md", errors
        )
    for heading in (
        "## In 30 Sekunden starten",
        "## Verbindlicher Werkstattstandard",
        "## Die neun Skills",
        "## Downloads und Navigation",
    ):
        require(bea_readme, heading, "schriftsatzwerkstatt-bea/README.md", errors)
    require(testakten_readme, "## Download-Pakete", "testakten/README.md", errors)

    root_start_heading = "## Direktstart: zwei klare Wege"
    root_download_heading = "## Sofort-Downloads (latest Release)"
    if (
        root_start_heading in root_readme
        and root_download_heading in root_readme
        and root_readme.index(root_start_heading)
        > root_readme.index(root_download_heading)
    ):
        errors.append(
            "README.md: Direktstart muss vor dem großen Downloadkatalog stehen"
        )
    plugin_start_heading = "## In 60 Sekunden zum ersten Ergebnis"
    plugin_assets_heading = "## Release-Assets"
    if (
        plugin_start_heading in plugin_readme
        and plugin_assets_heading in plugin_readme
        and plugin_readme.index(plugin_start_heading)
        > plugin_readme.index(plugin_assets_heading)
    ):
        errors.append(
            "forderungsmanagement-immobilien/README.md: Schnellstart muss vor den Release-Assets stehen"
        )

    case_contracts = {
        "README.md": root_readme,
        "forderungsmanagement-immobilien/README.md": plugin_readme,
        "references/bedienfuehrung-workflows.md": workflow_guide,
        "forderungsmanagement-immobilien/skills/33-dokumentenmix-ocr-sichten/SKILL.md": start_skill,
        **prompts,
    }
    for label, text in case_contracts.items():
        require(text, CASE_START, label, errors)
    for label, text in {
        "references/bedienfuehrung-workflows.md": workflow_guide,
        "forderungsmanagement-immobilien/skills/33-dokumentenmix-ocr-sichten/SKILL.md": start_skill,
        **prompts,
    }.items():
        for field in ("Akten-ID/Stichtag", "Kernlücken", "`Jetzt`"):
            require(text, field, label, errors)

    for label, text in {
        "README.md": root_readme,
        "schriftsatzwerkstatt-bea/README.md": bea_readme,
        "references/bedienfuehrung-workflows.md": workflow_guide,
        "schriftsatzwerkstatt-bea/skills/01-bea-ordner-annahme/SKILL.md": bea_start_skill,
    }.items():
        require(text, BEA_START, label, errors)

    for target in (
        "./forderungsmanagement-immobilien/README.md",
        "./schriftsatzwerkstatt-bea/README.md",
        "./testakten/README.md",
        "./SKILLS.md",
        "./forderungsmanagement-grosser-prompt.md",
        "./forderungsmanagement-kleiner-prompt.md",
        "./references/100-punkte-bediencheck.md",
        "./references/bedienfuehrung-workflows.md",
        "./references/erv-dokumentenproduktion.md",
        "./references/rechtsstand-2026-verfahren-vollstreckung.md",
        "./schriftsatzwerkstatt-bea/references/100-punkte-fehlerkatalog.md",
        "./references/rechtsprechungsradar-mietrecht-2021-2026.md",
        "./references/schnittstellenprofile.md",
        "./tests/smoke-tests.md",
        "./CONTRIBUTING.md",
        "./CODE_OF_CONDUCT.md",
        "./NOTICE",
        "./LICENSE",
        "./LICENSE-APACHE",
        "./LICENSE-MIT",
        f"{RELEASE_BASE}/forderungsmanagement-immobilien.zip",
        f"{RELEASE_BASE}/schriftsatzwerkstatt-bea.zip",
        f"{RELEASE_BASE}/schriftsatzwerkstatt-bea-skills-markdown.zip",
        f"{RELEASE_BASE}/alle-skills-markdown.zip",
        f"{RELEASE_BASE}/immobilien-forderungsmanagement-dokumentation.zip",
        f"{RELEASE_BASE}/release-katalog.md",
        f"{RELEASE_BASE}/checksums-sha256.txt",
    ):
        require(root_readme, target, "README.md", errors)
    require(root_readme, "unter 7.500 Zeichen", "README.md", errors)

    for target in (
        "../README.md#sofort-downloads-latest-release",
        "../testakten/README.md#download-pakete",
        "../tests/smoke-tests.md",
        "../forderungsmanagement-grosser-prompt.md",
        "../forderungsmanagement-kleiner-prompt.md",
        "references/100-punkte-bediencheck.md",
        "references/bedienfuehrung-workflows.md",
        "references/erv-dokumentenproduktion.md",
        "references/schnittstellenprofile.md",
        "references/gepruefte-bgh-anker-mietrecht.md",
        "references/rechtsstand-2026-verfahren-vollstreckung.md",
        "references/rechtsprechungsradar-mietrecht-2021-2026.md",
        "references/leitentscheidungen-anker.md",
        "references/methodik-buergerliches-recht.md",
        "references/quellenhygiene.md",
        "references/zitierweise.md",
        f"{RELEASE_BASE}/marketplace.json",
        f"{RELEASE_BASE}/forderungsmanagement-immobilien-kleiner-prompt-skill.zip",
        f"{RELEASE_BASE}/forderungsmanagement-immobilien-grosser-prompt-skill.zip",
        f"{RELEASE_BASE}/checksums-sha256.txt",
    ):
        require(
            plugin_readme, target, "forderungsmanagement-immobilien/README.md", errors
        )
    if "29 Assets" in plugin_readme:
        errors.append(
            "forderungsmanagement-immobilien/README.md: fragile feste Asset-Anzahl entfernen"
        )

    for target in (
        "../README.md",
        "./references/erv-versandstandard.md",
        "./references/dateinamen-und-manifest.md",
        "./references/100-punkte-fehlerkatalog.md",
        "./templates/konvertierungsprotokoll.md",
        "./templates/eingangsvermerk.md",
        "../tests/smoke-tests.md#17-schriftsatzwerkstatt-bea",
        f"{RELEASE_BASE}/schriftsatzwerkstatt-bea.zip",
        f"{RELEASE_BASE}/schriftsatzwerkstatt-bea-skills-markdown.zip",
        f"{RELEASE_BASE}/marketplace.json",
        f"{RELEASE_BASE}/release-katalog.md",
        f"{RELEASE_BASE}/checksums-sha256.txt",
    ):
        require(bea_readme, target, "schriftsatzwerkstatt-bea/README.md", errors)

    skill_dirs = sorted(
        path for path in (PLUGIN / "skills").iterdir() if (path / "SKILL.md").is_file()
    )
    skill_names = {path.name for path in skill_dirs}
    for skill_dir in skill_dirs:
        target = f"skills/{skill_dir.name}/SKILL.md"
        require(
            plugin_readme, target, "forderungsmanagement-immobilien/README.md", errors
        )

    bea_skill_dirs = sorted(
        path
        for path in (BEA_PLUGIN / "skills").iterdir()
        if (path / "SKILL.md").is_file()
    )
    if len(bea_skill_dirs) > 10:
        errors.append(
            f"schriftsatzwerkstatt-bea/README.md: höchstens 10 Skills erlaubt, gefunden {len(bea_skill_dirs)}"
        )
    for skill_dir in bea_skill_dirs:
        target = f"./skills/{skill_dir.name}/SKILL.md"
        require(bea_readme, target, "schriftsatzwerkstatt-bea/README.md", errors)

    for target in (
        "../README.md#sofort-downloads-latest-release",
        "../forderungsmanagement-immobilien/README.md",
        f"{RELEASE_BASE}/alle-testakten.zip",
        f"{RELEASE_BASE}/alle-testakten-einzel-pdfs.zip",
        f"{RELEASE_BASE}/testakten-release-index.json",
    ):
        require(testakten_readme, target, "testakten/README.md", errors)

    test_dirs = sorted(
        path
        for path in (ROOT / "testakten").iterdir()
        if path.is_dir() and (path / "README.md").is_file()
    )
    for test_dir in test_dirs:
        slug = test_dir.name
        require(testakten_readme, f"./{slug}/", "testakten/README.md", errors)
        require(
            testakten_readme,
            f"{RELEASE_BASE}/testakte-{slug}.zip",
            "testakten/README.md",
            errors,
        )
        require(
            testakten_readme,
            f"{RELEASE_BASE}/testakte-{slug}-gesamt.pdf",
            "testakten/README.md",
            errors,
        )
        require(
            testakten_readme,
            f"{RELEASE_BASE}/testakte-{slug}-einzel-pdfs.zip",
            "testakten/README.md",
            errors,
        )

        text = (test_dir / "README.md").read_text(encoding="utf-8")
        label = f"testakten/{slug}/README.md"
        for referenced_skill in re.findall(
            r"`((?:\d{2}-)[a-z0-9-]+)`",
            text,
        ):
            if referenced_skill not in skill_names:
                errors.append(
                    f"{label}: unbekannter Fachskill im Codeverweis: {referenced_skill}"
                )
        for target in (
            "../README.md",
            "../../forderungsmanagement-immobilien/README.md",
            "../../forderungsmanagement-immobilien/README.md#alle-skills-im-überblick",
            "../../README.md#sofort-downloads-latest-release",
            f"testakte-{slug}.zip",
            f"testakte-{slug}-gesamt.pdf",
            f"testakte-{slug}-einzel-pdfs.zip",
        ):
            require(text, target, label, errors)
        akte_section = markdown_section(text, "## Akte")
        if not akte_section:
            errors.append(f"{label}: Abschnitt ## Akte fehlt")
        for source in sorted(test_dir.rglob("*.md")):
            if source.name == "README.md" or "gesamt-pdf" in source.parts:
                continue
            source_rel = source.relative_to(test_dir).as_posix()
            if source_rel not in akte_section:
                errors.append(
                    f"{label}: Aktenregister enthält Quelle nicht: {source_rel}"
                )
        pdf = test_dir / "gesamt-pdf" / f"{slug}_gesamt.pdf"
        if pdf.is_file():
            require(text, f"gesamt-pdf/{slug}_gesamt.pdf", label, errors)

    if errors:
        print("\n".join(errors), file=sys.stderr)
        print(
            f"validate-readme-navigation failed: {len(errors)} Fehler", file=sys.stderr
        )
        return 1
    print(
        "validate-readme-navigation OK "
        f"({len(skill_dirs)} Forderungsmanagement-Skills, "
        f"{len(bea_skill_dirs)} beA-Werkstatt-Skills, {len(test_dirs)} Testakten)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
