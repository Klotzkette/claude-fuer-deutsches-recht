#!/usr/bin/env python3
"""Erzeugt einen vollständigen Release-Katalog und SHA-256-Prüfsummen."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
RELEASE_BASE = "https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download"
CATALOG_NAME = "release-katalog.md"
CHECKSUM_NAME = "checksums-sha256.txt"


EXACT_DESCRIPTIONS = {
    "forderungsmanagement-immobilien.zip": "Komplettes Cowork-Plugin mit 50 Skills, Manifest und Quellenleitplanken.",
    "schriftsatzwerkstatt-bea.zip": "Fachlich neutrale beA-Werkstatt mit neun Skills, Delta-Lauf, 100-Punkte-Kontrollspur, Paketvalidator und Eingangssicherung.",
    "marketplace.json": "Marketplace-Definition mit derselben Version wie beide Plugins.",
    "forderungsmanagement-immobilien-skills-markdown.zip": "Alle 50 Skills mit klickbarem Plugin-README als Offline-Index.",
    "schriftsatzwerkstatt-bea-skills-markdown.zip": "Alle neun beA-Werkstatt-Skills mit klickbarem Plugin-README als Offline-Index.",
    "alle-skills-markdown.zip": "Direkt entpackbare Skilltexte beider Plugins mit getrennten Plugin-Ordnern und README-Indizes.",
    "immobilien-forderungsmanagement-dokumentation.zip": "Vollständiger getrackter Repo-Inhalt ohne Git-Metadaten und Build-Abfall; alle relativen README-Links funktionieren offline.",
    "forderungsmanagement-immobilien-grosser-prompt-skill.md": "Werkstattprompt als einzelne Standalone-Skill-Datei.",
    "forderungsmanagement-immobilien-grosser-prompt-skill.zip": "Werkstattprompt als Cowork-ZIP mit SKILL.md an der Wurzel.",
    "forderungsmanagement-immobilien-kleiner-prompt-skill.md": "Schnellstartprompt als einzelne Standalone-Skill-Datei.",
    "forderungsmanagement-immobilien-kleiner-prompt-skill.zip": "Schnellstartprompt als Cowork-ZIP mit SKILL.md an der Wurzel.",
    "alle-testakten.zip": "Alle Testakten als flaches Arbeitsdatei-Sammelpaket im lebensnahen Formate-Mix; der Akten-Slug steht im Dateinamen.",
    "alle-testakten-einzel-pdfs.zip": "Alle Aktenstücke aller Testakten als einzeln benannte PDFs.",
    "testakten-release-index.json": "Maschinenlesbare Zuordnung aller Testakten-Downloads.",
    CATALOG_NAME: "Diese vollständige, menschenlesbare Asset-Liste.",
    CHECKSUM_NAME: "SHA-256-Prüfsummen aller übrigen Release-Assets.",
}


def description(name: str) -> str:
    if name in EXACT_DESCRIPTIONS:
        return EXACT_DESCRIPTIONS[name]
    if name.startswith("testakte-") and name.endswith("-gesamt.pdf"):
        return "Einzelne Testakte als vollständiges, direkt les- und herunterladbares Gesamt-PDF."
    if name.startswith("testakte-") and name.endswith("-einzel-pdfs.zip"):
        return "Einzelne Testakte mit jeder Unterlage als separat benannter PDF-Datei."
    if name.startswith("testakte-") and name.endswith(".zip"):
        return "Einzelne Testakte als flaches Arbeits-ZIP aus DOCX, XLSX und PDF ohne Gesamt-PDF-Dublette."
    return "Weiteres geprüftes Release-Artefakt."


def category(name: str) -> str:
    if (
        name.startswith("testakte-")
        or name.startswith("alle-testakten")
        or name == "testakten-release-index.json"
    ):
        return "Testakten"
    if "prompt-skill" in name or "skills-markdown" in name or "dokumentation" in name:
        return "Dokumentation, Skills und Prompts"
    if name in {CATALOG_NAME, CHECKSUM_NAME}:
        return "Navigation und Integrität"
    return "Plugin und Marketplace"


def human_size(path: Path | None) -> str:
    if path is None or not path.exists():
        return "dynamisch"
    size = path.stat().st_size
    if size >= 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} MB"
    return f"{max(1, round(size / 1024))} KB"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: build-release-catalog.py <dist-dir>")
    dist = Path(sys.argv[1]).resolve()
    if not dist.is_dir():
        raise SystemExit(f"Release-Verzeichnis fehlt: {dist}")

    marketplace = json.loads(
        (REPO_ROOT / ".claude-plugin" / "marketplace.json").read_text(encoding="utf-8")
    )
    version = marketplace["version"]
    actual_names = {path.name for path in dist.iterdir() if path.is_file()}
    names = sorted(actual_names | {CATALOG_NAME, CHECKSUM_NAME})

    lines = [
        f"# Release-Katalog v{version}",
        "",
        "Vollständige Download-Liste für das private Repository. Die Links funktionieren nach GitHub-Anmeldung mit Repo-Zugriff und zeigen immer auf das aktuelle Release.",
        "",
        "Empfohlener Einstieg: Forderungsmanagement-Plugin für den Fachprozess, Schriftsatzwerkstatt für die rein technische beA-Endfertigung, Schnellstartprompt für einen Einzel-Skill-Test und Testakten-ZIPs für Schulung oder Abnahme.",
    ]
    for group in (
        "Plugin und Marketplace",
        "Dokumentation, Skills und Prompts",
        "Testakten",
        "Navigation und Integrität",
    ):
        group_names = [name for name in names if category(name) == group]
        if not group_names:
            continue
        lines.extend(
            ["", f"## {group}", "", "| Asset | Größe | Zweck |", "|---|---:|---|"]
        )
        for name in group_names:
            path = None if name in {CATALOG_NAME, CHECKSUM_NAME} else dist / name
            url = f"{RELEASE_BASE}/{name}"
            lines.append(
                f"| [{name}]({url}) | {human_size(path)} | {description(name)} |"
            )

    catalog = dist / CATALOG_NAME
    catalog.write_text("\n".join(lines) + "\n", encoding="utf-8")

    checksum_lines = []
    for path in sorted(
        (
            path
            for path in dist.iterdir()
            if path.is_file() and path.name != CHECKSUM_NAME
        ),
        key=lambda item: item.name,
    ):
        checksum_lines.append(f"{sha256(path)}  {path.name}")
    (dist / CHECKSUM_NAME).write_text(
        "\n".join(checksum_lines) + "\n", encoding="ascii"
    )
    print(f"Baue {CATALOG_NAME}: {len(names)} Assets verlinkt")
    print(f"Baue {CHECKSUM_NAME}: {len(checksum_lines)} Prüfsummen")


if __name__ == "__main__":
    main()
