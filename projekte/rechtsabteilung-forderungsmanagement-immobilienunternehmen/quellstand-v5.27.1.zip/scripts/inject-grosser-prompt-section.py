#!/usr/bin/env python3
"""Fuegt in jede <plugin>/README.md eine kurze Werkstattprompt-Hinweissektion ein,
sofern ein passender Werkstattprompt unter testakten/grosser-prompts/<plugin>.md
existiert und der Block noch nicht vorhanden ist.

Idempotent ueber HTML-Marker. Position: ans Ende der Datei (gleich der
ueblichen Konvention; move-grosser-prompt-block-to-end.py kann den Block
spaeter umsortieren).
"""

from __future__ import annotations
import re
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
MEGA_DIR = REPO / "testakten" / "grosser-prompts"

BEGIN = "<!-- BEGIN grosser-prompt-und-vorlagen (autogen) -->"
END = "<!-- END grosser-prompt-und-vorlagen (autogen) -->"

RELEASE_BASE = "https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download"


def block_for(plugin: str, kb: int) -> str:
    return f"""{BEGIN}
## Experimentell: dieses Plugin auch ohne Claude Code

### Schnellstartprompt und Werkstattprompt

Für normale Chatbots ohne Plugin-Installation gibt es zwei einzelne Markdown-Dateien als Release-Asset: den Schnellstartprompt (unter 7.500 Zeichen) und den Werkstattprompt (vollständiger Workflow).

- Schnellstartprompt: [`{plugin}-kleiner-prompt-skill.md`]({RELEASE_BASE}/{plugin}-kleiner-prompt-skill.md)
- Werkstattprompt: [`{plugin}-grosser-prompt-skill.md`]({RELEASE_BASE}/{plugin}-grosser-prompt-skill.md)

Für echte Plugin-Nutzung in Claude Code das Plugin-ZIP verwenden; für Ein-Datei-Nutzung Schnellstartprompt oder Werkstattprompt.

{END}
"""


def process(plugin_dir: Path) -> str:
    readme = plugin_dir / "README.md"
    if not readme.exists():
        return "skip-no-readme"
    mega = MEGA_DIR / f"{plugin_dir.name}.md"
    if not mega.exists():
        return "skip-no-grosser-prompt"
    text = readme.read_text(encoding="utf-8")
    kb = max(1, mega.stat().st_size // 1024)
    new_block = block_for(plugin_dir.name, kb)
    if BEGIN in text:
        # Update vorhandenen Block (z. B. Groessenangabe)
        new_text = re.sub(
            re.escape(BEGIN) + r".*?" + re.escape(END) + r"\n?",
            new_block,
            text,
            count=1,
            flags=re.DOTALL,
        )
        if new_text == text:
            return "unchanged"
        readme.write_text(new_text, encoding="utf-8")
        return "updated"
    # Anfuegen ans Ende
    sep = "" if text.endswith("\n") else "\n"
    readme.write_text(text + sep + "\n" + new_block, encoding="utf-8")
    return "added"


def main() -> None:
    added = updated = unchanged = skipped = 0
    for p in sorted(REPO.iterdir()):
        if not p.is_dir():
            continue
        if p.name.startswith(".") or p.name.startswith("_"):
            continue
        if p.name in {
            "scripts",
            "testakten",
            "docs",
            "audits",
            "node_modules",
            "recherche",
            "references",
            "skills-index",
            "tests",
            "anthropic-lessons",
            "anlagen-zu-schriftsaetzen-archiv",
        }:
            continue
        result = process(p)
        if result == "added":
            added += 1
            print(f"  added: {p.name}")
        elif result == "updated":
            updated += 1
        elif result == "unchanged":
            unchanged += 1
        else:
            skipped += 1
    print(f"\nadded={added} updated={updated} unchanged={unchanged} skipped={skipped}")


if __name__ == "__main__":
    main()
