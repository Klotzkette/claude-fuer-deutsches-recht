#!/usr/bin/env python3
"""Regression check for YAML frontmatter parser consumers.

Standalone and regular skills may use quoted YAML descriptions. Generators must
parse them through YAML, not through ad hoc line splitting, otherwise valid
description values containing colon-space or escaped single quotes are corrupted.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from tempfile import TemporaryDirectory


SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import skill_frontmatter  # noqa: E402
from skill_frontmatter import split_frontmatter  # noqa: E402


def fail(message: str) -> None:
    print(f"validate-skill-frontmatter-parsers failed: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, SCRIPT_DIR / filename)
    if spec is None or spec.loader is None:
        fail(f"cannot load {filename}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    generate_overview = load_module("generate_skills_overview", "generate-skills-overview.py")
    generate_skills_md = load_module("generate_skills_md", "generate-skills-md.py")
    inject_ausformulierung = load_module("inject_ausformulierungspflicht", "inject-ausformulierungspflicht.py")

    expected = "Klage: O'Brien sauber pruefen"
    sample = """---
name: test-skill
description: 'Klage: O''Brien sauber pruefen'
---

# Body
"""

    with TemporaryDirectory() as tmp:
        path = Path(tmp) / "SKILL.md"
        path.write_text(sample, encoding="utf-8")
        checks = {
            "helper": skill_frontmatter.description_from_file(path),
            "overview": generate_overview.read_description(path),
            "skills_md": generate_skills_md.read_description(path),
            "inject": inject_ausformulierung.extract_description(sample),
        }
        frontmatter, body = split_frontmatter(sample)
        checks["split_frontmatter"] = frontmatter.get("description", "")

    for name, value in checks.items():
        if value != expected:
            fail(f"{name}: {value!r} != {expected!r}")
    if body != "# Body":
        fail(f"body mismatch: {body!r}")

    print("validate-skill-frontmatter-parsers OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
