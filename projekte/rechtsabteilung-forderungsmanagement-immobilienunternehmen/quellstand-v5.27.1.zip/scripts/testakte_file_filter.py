#!/usr/bin/env python3
"""Gemeinsamer Filter für Testakten-Exportdateien.

Die Repo-README und redaktionelle Übersichten sind für GitHub wichtig, sollen
aber nicht in den Arbeitsmaterial-Dump gelangen. Gesamt-PDFs und Testakten-ZIPs
müssen wie eine Anwaltsakte aufgehen: Aktenstücke, Anlagen, E-Mail-Ausdrucke,
Tabellen und Belege, aber keine Vorführ- oder Download-Hinweise. Das direkte
Gesamt-PDF bleibt ein eigenes Asset und wird nicht im Arbeits-ZIP gedoppelt.
"""

from __future__ import annotations

from pathlib import Path

TEXT_EXTS = {".md", ".txt", ".csv", ".eml"}
TESTAKTEN_RELEASE_INDEX_SCHEMA = (
    "immobilien-forderungsmanagement.testakten-release-assets.v2"
)
MAX_EXPORT_FILES_PER_CASE = 250
MAX_TEXT_SOURCE_BYTES = 5 * 1024 * 1024
MAX_BINARY_SOURCE_BYTES = 50 * 1024 * 1024
MAX_CASE_SOURCE_BYTES = 250 * 1024 * 1024

META_MARKERS = (
    "demonstrationsakte",
    "demonstrations-testakte",
    "demonstrationszweck",
    "plugin-test",
    "plugin-testing",
    "plugin-testsystem",
    "plugin demonstration",
    "plugin-demonstration",
    "demo-akte",
    "vorfuehrziel",
    "vorführziel",
    "testzweck",
    "ausschließlich testzwecken",
    "ausschliesslich testzwecken",
    "nur zu testzwecken",
    "diese akte eignet sich",
    "direkt-download",
    "download der akte",
    "github-release",
)

META_NAME_PARTS = (
    "readme",
    "qualitaetsstandard",
    "qualitätsstandard",
    "direkt-download",
    "download",
)

INITIAL_OVERVIEW_PARTS = (
    "aktenuebersicht",
    "aktenübersicht",
    "akte-uebersicht",
    "akte-übersicht",
    "soforttriage",
)


def _safe_text(path: Path, limit: int = 80_000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")[:limit].lower()
    except Exception:
        return ""


def _is_initial_overview(path: Path, testakte_dir: Path) -> bool:
    try:
        rel = path.relative_to(testakte_dir)
    except ValueError:
        return False
    if len(rel.parts) != 1:
        return False
    stem = path.stem.lower()
    compact = stem.replace("_", "-")
    starts_as_front_piece = compact.startswith(("00-", "01-", "00.", "01."))
    return starts_as_front_piece and any(
        part in stem for part in INITIAL_OVERVIEW_PARTS
    )


def is_export_meta_file(
    path: Path, testakte_dir: Path, *, check_content: bool = True
) -> bool:
    """True, wenn die Datei nicht in PDF/ZIP-Arbeitsmaterial gehoert."""
    name = path.name.lower()
    stem = path.stem.lower()
    if name == "readme.md":
        return True
    if any(part in stem for part in META_NAME_PARTS):
        return True
    if _is_initial_overview(path, testakte_dir):
        return True
    if check_content and path.suffix.lower() in TEXT_EXTS:
        text = _safe_text(path)
        if any(marker in text for marker in META_MARKERS):
            return True
    return False


def include_in_working_dump(
    path: Path, testakte_dir: Path, *, include_gesamt_pdf: bool = False
) -> bool:
    """Export-Entscheidung für eine einzelne Datei innerhalb einer Testakte."""
    if not path.is_file():
        return False
    try:
        rel = path.relative_to(testakte_dir)
    except ValueError:
        return False
    if any(part.startswith(".") for part in rel.parts):
        return False
    if "__pycache__" in rel.parts or path.name == ".DS_Store":
        return False
    if "gesamt-pdf" in rel.parts:
        return include_gesamt_pdf and path.name == f"{testakte_dir.name}_gesamt.pdf"
    if is_export_meta_file(path, testakte_dir):
        return False
    return True


def discover_testakten(testakten_root: Path, skip_dirs: set[str]) -> list[Path]:
    """Findet nur dokumentierte, nicht versteckte Testaktenordner."""
    candidates = [
        path
        for path in testakten_root.iterdir()
        if not path.name.startswith(".") and path.name not in skip_dirs
    ]
    symlinks = [path for path in candidates if path.is_symlink()]
    if symlinks:
        names = ", ".join(path.name for path in symlinks[:10])
        raise ValueError(f"Symlink als Testaktenordner unzulässig: {names}")
    undocumented = [
        path.name
        for path in candidates
        if path.is_dir() and not (path / "README.md").is_file()
    ]
    if undocumented:
        raise ValueError(
            "Testaktenordner ohne README würden im Release fehlen: "
            + ", ".join(sorted(undocumented)[:10])
        )
    return sorted(
        path for path in candidates if path.is_dir() and (path / "README.md").is_file()
    )


def validate_testakte_source(testakte_dir: Path) -> None:
    """Sperrt Symlinks und versehentlich übergroße Release-Quellen."""
    export_files: list[Path] = []
    total_size = 0
    for path in testakte_dir.rglob("*"):
        if path.is_symlink():
            raise ValueError(
                f"{testakte_dir.name}: Symlink in Testakte unzulässig: "
                f"{path.relative_to(testakte_dir)}"
            )
        if not include_in_working_dump(path, testakte_dir, include_gesamt_pdf=False):
            continue
        export_files.append(path)
        size = path.stat().st_size
        total_size += size
        limit = (
            MAX_TEXT_SOURCE_BYTES
            if path.suffix.lower() in TEXT_EXTS
            else MAX_BINARY_SOURCE_BYTES
        )
        if size > limit:
            raise ValueError(
                f"{testakte_dir.name}: Quelldatei zu groß "
                f"({size} Bytes): {path.relative_to(testakte_dir)}"
            )
    if len(export_files) > MAX_EXPORT_FILES_PER_CASE:
        raise ValueError(
            f"{testakte_dir.name}: {len(export_files)} Exportdateien "
            f"überschreiten das Limit {MAX_EXPORT_FILES_PER_CASE}"
        )
    if total_size > MAX_CASE_SOURCE_BYTES:
        raise ValueError(
            f"{testakte_dir.name}: Exportquellen mit {total_size} Bytes "
            f"überschreiten das Falllimit {MAX_CASE_SOURCE_BYTES}"
        )
