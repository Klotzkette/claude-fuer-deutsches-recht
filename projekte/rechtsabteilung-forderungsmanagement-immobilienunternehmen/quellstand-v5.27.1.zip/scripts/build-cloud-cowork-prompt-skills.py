#!/usr/bin/env python3
"""Build standalone Cloud-Co-Work skill assets from root prompts.

The full plugin ZIP is the preferred installation path. These two assets are
for environments where a user can upload only one standalone skill:

- forderungsmanagement-grosser-prompt.md -> forderungsmanagement-immobilien-grosser-prompt-skill.zip
- forderungsmanagement-kleiner-prompt.md -> forderungsmanagement-immobilien-kleiner-prompt-skill.zip

Each ZIP contains a single SKILL.md at the archive root.
"""

from __future__ import annotations

import argparse
import re
import sys
import zipfile
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
MAX_GROSSER_PROMPT_CHARS = 30_000
MAX_GROSSER_SKILL_CHARS = 30_000
# Lässt genug Platz für Frontmatter und Skill-Einleitung unter dem 7.500-Zeichen-Limit.
MAX_KLEINER_PROMPT_CHARS = 7_110
MAX_MINI_SKILL_CHARS = 7_500
MAX_DESCRIPTION_CHARS = 1_024


PROMPTS = [
    {
        "source": "forderungsmanagement-grosser-prompt.md",
        "kind": "grosser-prompt",
        "name": "forderungsmanagement-immobilien-werkstattprompt",
        "description": (
            "Vollworkflow für Immobilienakten. Startet Ordner, SAP/DMS oder Neuzugang ohne Skillauswahl "
            "mit Fristkarte und führt zu Entwurf, Freigabe, Gerichtspaket, Kosten und Vollstreckung."
        ),
        "max_chars": MAX_GROSSER_PROMPT_CHARS,
        "skill_max_chars": MAX_GROSSER_SKILL_CHARS,
    },
    {
        "source": "forderungsmanagement-kleiner-prompt.md",
        "kind": "kleiner-prompt",
        "name": "forderungsmanagement-immobilien-schnellstartprompt",
        "description": (
            "Schnellstart für Immobilienakten. Startet Ordner, SAP/DMS, Neuzugang oder Gerichtspost ohne "
            "Skillauswahl mit Fristkarte und führt zu Entwurf, Freigabe, Kosten oder Vollstreckung."
        ),
        "max_chars": MAX_KLEINER_PROMPT_CHARS,
        "skill_max_chars": MAX_MINI_SKILL_CHARS,
    },
]


def fail(message: str) -> None:
    print(f"build-cloud-cowork-prompt-skills failed: {message}", file=sys.stderr)
    raise SystemExit(1)


def validate_description(name: str, description: str) -> None:
    if len(description) > MAX_DESCRIPTION_CHARS:
        fail(
            f"{name}: description has {len(description)} chars, max {MAX_DESCRIPTION_CHARS}"
        )
    if re.search(r"\d,\d", description):
        fail(f"{name}: description contains comma-number pattern")
    for forbidden in ['"', "<", ">"]:
        if forbidden in description:
            fail(f"{name}: description contains forbidden character {forbidden}")
    lowered = description.lower()
    for forbidden_word in ["scrape", "scraping", "crawl", "crawling"]:
        if forbidden_word in lowered:
            fail(f"{name}: description contains forbidden word {forbidden_word}")


def yaml_single_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def skill_text(item: dict[str, object], prompt: str) -> str:
    description = str(item["description"])
    validate_description(str(item["name"]), description)
    return (
        "---\n"
        f"name: {item['name']}\n"
        f"description: {yaml_single_quote(description)}\n"
        "---\n\n"
        f"# {item['name']}\n\n"
        "Standalone-Skill für Immobilien-Forderungsmanagement.\n\n"
        f"{prompt.strip()}\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("dist", type=Path, help="Output directory, usually dist/")
    args = parser.parse_args()
    dist = args.dist
    dist.mkdir(parents=True, exist_ok=True)

    for item in PROMPTS:
        source = REPO_ROOT / str(item["source"])
        prompt = source.read_text(encoding="utf-8")
        limit = int(item["max_chars"])
        if len(prompt) > limit:
            fail(
                f"{source.name}: {len(prompt)} chars exceeds Cloud-Co-Work guardrail {limit}"
            )

        text = skill_text(item, prompt)
        skill_max_chars = item.get("skill_max_chars")
        if skill_max_chars is not None and len(text) > int(skill_max_chars):
            fail(
                f"{item['name']}: generated skill has {len(text)} chars, max {skill_max_chars}"
            )
        asset_base = f"forderungsmanagement-immobilien-{item['kind']}-skill"
        md_path = dist / f"{asset_base}.md"
        zip_path = dist / f"{asset_base}.zip"

        md_path.write_text(text, encoding="utf-8")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("SKILL.md", text)
        print(f"{md_path.name}: {len(text)} Zeichen")
        print(f"{zip_path.name}: {zip_path.stat().st_size} Bytes")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
