#!/usr/bin/env python3
"""Konvertiert Markdown-Aktenstuecke in lebensechte Dateiformate.

Verbindliche Regel fuer alle Testakten (siehe testakten/README.md und
CLAUDE.md): Das Arbeits-ZIP einer Testakte enthaelt KEINE Markdown-Dateien,
sondern den realistischen Formate-Mix, wie er im Anwalts- und
Forderungsmanagement-Alltag anfaellt. Die Markdown-Dateien im Repo bleiben
die redaktionelle Quelle (Validatoren, Gesamt-PDF, Einzel-PDFs); dieser
Konverter erzeugt daraus beim ZIP-Bau inhaltsgleiche Echtformat-Dateien:

- SAP-Statusauszug und Mietkonto FBL5N        -> .xlsx (openpyxl)
- Urteile, Beschluesse, Mietspiegel,
  Betriebskostenabrechnung, Behoerdenschreiben -> .pdf (reportlab)
- E-Mails und externe Korrespondenz            -> .pdf (reportlab)
- Eigene Schreiben, Vertraege, Schriftsaetze,
  Vermerke und Aktennotizen                    -> .docx (python-docx)

Alle erzeugten Arbeitsdateien sind DOCX, XLSX oder PDF. Die Zuordnung ist
deterministisch ueber Dateinamens-Schluesselwoerter (ziel_suffix). Neue
Aktenstuecke muessen einen Namen tragen, der genau eine Regel trifft, oder die
Regelliste wird ergaenzt. ZIP-Pfade werden spaeter flach aus dem redaktionellen
Ordnerpfad gebildet; der Ordnername bleibt dabei als lesbares Namenssegment
erhalten.
"""

from __future__ import annotations

import importlib.util
import io
import re
import unicodedata
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

REPO_ROOT = Path(__file__).resolve().parent.parent

ABSENDER_KONZERN = "Wohnen Berlin Immobilien GmbH"
BERLIN = ZoneInfo("Europe/Berlin")

# Reihenfolge ist verbindlich: die erste passende Regel gewinnt.
SUFFIX_REGELN: list[tuple[tuple[str, ...], str]] = [
    (
        (
            "sap-statusauszug",
            "fbl5n",
            "dms-exportliste",
            "mieterdatenblatt",
            "objektdatenbogen",
            "belegliste",
            "buchungsklaerung",
            "ratenmonitoring",
            "tilgungsjournal",
            "berechnungsbogen",
            "kontrollliste",
            "raumklima-logger",
            "beweismatrix",
        ),
        ".xlsx",
    ),
    # Interne Aktennotizen bleiben bearbeitbare Word-Dateien. Diese Regel
    # muss vor inhaltlichen Stichworten wie "Jobcenter" oder "E-Mail" stehen.
    (("aktennotiz",), ".docx"),
    (
        (
            "urteil",
            "beschluss",
            "mietspiegel",
            "abrechnung",
            "jobcenter",
            "email",
            "mieter-antwort",
            "mieter-widerspruch",
            "widerspruch-mieter",
            "mieter-zahlungsstopp",
            "bank-avis",
            "kontoauszug",
            "ruecklastschrift",
            "zahlungsavis",
            "einwurfprotokoll",
            "zustellungsnachricht",
            "zustellungsurkunde",
            "rechtskraftvermerk",
            "wohnflaechenberechnung",
            "fotoliste",
            "rechnung-",
            "kostenvoranschlag",
            "zahlungsbeleg",
            "gerichtsvollzieher-protokoll",
            "meldeauskunft",
            "mieter-maengelanzeige",
            "mieter-terminverschiebung",
            "mieterverein",
            "klageschrift-mieter",
            "gerichtliche-verfuegung",
            "arbeitsauftrag",
            "abnahmeprotokoll",
            "messprotokoll",
            "ortstermin-feuchte",
            "grundriss",
        ),
        ".pdf",
    ),
    (("vermerk",), ".docx"),
]


def ziel_suffix(stem: str) -> str:
    s = stem.lower()
    for schluessel, suffix in SUFFIX_REGELN:
        if any(k in s for k in schluessel):
            return suffix
    return ".docx"


def ziel_relpfad(rel: Path) -> Path:
    """Arbeits-ZIP-Pfad fuer eine Quelldatei (md wird konvertiert)."""
    if rel.suffix.lower() == ".md":
        return rel.with_suffix(ziel_suffix(rel.stem))
    return rel


def flacher_exportname(
    rel: Path,
    *,
    ziel_name: str | None = None,
    akten_slug: str | None = None,
) -> str:
    """Bildet einen eindeutigen ZIP-Dateinamen ohne Unterordner.

    Im Einzelpaket bleibt der redaktionelle Bereich als Präfix erhalten,
    beispielsweise ``korrespondenz__mahnung.docx``. Im Sammelpaket wird davor
    zusätzlich der Akten-Slug gesetzt. So bleiben alle Namen sprechend und
    kollisionsfrei, obwohl jedes ZIP nur eine Ebene hat.
    """

    def ascii_segment(value: str) -> str:
        translated = value.translate(
            str.maketrans(
                {
                    "ä": "ae",
                    "ö": "oe",
                    "ü": "ue",
                    "Ä": "Ae",
                    "Ö": "Oe",
                    "Ü": "Ue",
                    "ß": "ss",
                }
            )
        )
        normalized = unicodedata.normalize("NFKD", translated)
        ascii_value = normalized.encode("ascii", errors="ignore").decode("ascii")
        safe = re.sub(r"[^A-Za-z0-9._-]+", "-", ascii_value).strip(" .-_")
        if not safe:
            raise ValueError(f"Leeres ASCII-Dateinamensegment aus {value!r}")
        return safe

    target = ascii_segment(Path(ziel_name or ziel_relpfad(rel).name).name)
    parts = [ascii_segment(part) for part in rel.parent.parts if part not in {"", "."}]
    if akten_slug:
        parts.insert(0, ascii_segment(akten_slug))
    parts.append(target)
    name = "__".join(parts)
    if "/" in name or "\\" in name:
        raise ValueError(f"ZIP-Dateiname ist nicht flach: {name}")
    return name


# ---------------------------------------------------------------- Markdown ---


def _inline_plain(text: str) -> str:
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"\*(.+?)\*", r"\1", text)
    text = re.sub(r"`(.+?)`", r"\1", text)
    text = re.sub(r"\[(.+?)\]\([^)]*\)", r"\1", text)
    return text


def _tabellenzeile(zeile: str) -> list[str]:
    return [z.strip() for z in zeile.strip().strip("|").split("|")]


def parse_bloecke(text: str) -> list[tuple]:
    """Zerlegt das Markdown-Subset der Testakten in Bloecke."""
    bloecke: list[tuple] = []
    zeilen = text.splitlines()
    i = 0
    while i < len(zeilen):
        zeile = zeilen[i]
        strip = zeile.strip()
        if not strip:
            i += 1
            continue
        if strip.startswith("```"):
            code: list[str] = []
            i += 1
            while i < len(zeilen) and not zeilen[i].strip().startswith("```"):
                code.append(zeilen[i])
                i += 1
            i += 1
            bloecke.append(("code", code))
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", strip)
        if m:
            bloecke.append(("h", len(m.group(1)), _inline_plain(m.group(2))))
            i += 1
            continue
        if strip == "---":
            bloecke.append(("hr",))
            i += 1
            continue
        if strip.startswith("|"):
            rows = []
            while i < len(zeilen) and zeilen[i].strip().startswith("|"):
                zellen = _tabellenzeile(zeilen[i])
                if not all(re.fullmatch(r":?-{2,}:?", z or "---") for z in zellen):
                    rows.append(zellen)
                i += 1
            bloecke.append(("table", rows))
            continue
        m = re.match(r"^(?:[-*]|\d+\.)\s+(.*)$", strip)
        if m:
            items = []
            while i < len(zeilen):
                m2 = re.match(r"^(?:[-*]|\d+\.)\s+(.*)$", zeilen[i].strip())
                if not m2:
                    break
                items.append(m2.group(1))
                i += 1
            bloecke.append(("list", items))
            continue
        # Zeilentreue: In den Testakten ist jede Zeile eine eigene Aussage
        # (Adressblöcke, Briefkopf, Betreffzeilen). Zeilen werden deshalb
        # nicht zu Fliesstext zusammengezogen.
        bloecke.append(("p", strip))
        i += 1
    return bloecke


def als_klartext(text: str) -> str:
    teile: list[str] = []
    for block in parse_bloecke(text):
        art = block[0]
        if art == "h":
            teile.append(_inline_plain(block[2]))
            teile.append("")
        elif art == "p":
            teile.append(_inline_plain(block[1]))
            teile.append("")
        elif art == "list":
            teile.extend(f"- {_inline_plain(item)}" for item in block[1])
            teile.append("")
        elif art == "table":
            for row in block[1]:
                teile.append("  ".join(_inline_plain(z) for z in row))
            teile.append("")
        elif art == "code":
            teile.extend(block[1])
            teile.append("")
        elif art == "hr":
            teile.append("-" * 40)
            teile.append("")
    return "\n".join(teile).strip() + "\n"


def _erstes_datum(text: str) -> datetime:
    """Ermittelt das Dokumentdatum, ohne Geburtsdaten zu übernehmen."""

    def parse(match: re.Match[str]) -> datetime | None:
        try:
            return datetime(
                int(match.group(3)),
                int(match.group(2)),
                int(match.group(1)),
                9,
                30,
                tzinfo=BERLIN,
            )
        except ValueError:
            return None

    date = r"([0-3]?\d)\.([01]?\d)\.(\d{4})"
    preferred_patterns = (
        rf"(?im)^\s*\|?\s*(?:stand|datum|auszugsdatum|erstellt am|bearbeitungsstand)"
        rf"\s*(?:\||:)\s*{date}",
        rf"(?im)^\s*berlin,\s*(?:den\s+)?{date}",
        rf"(?im)^\s*(?:mietvertrag|nachtrag|mahnung|kündigung|klageschrift|"
        rf"beschluss|urteil|abrechnung)[^\n]{{0,100}}\bvom\s+{date}",
    )
    for pattern in preferred_patterns:
        match = re.search(pattern, text)
        if match:
            parsed = parse(match)
            if parsed is not None:
                return parsed

    for line in text.splitlines():
        lowered = line.lower()
        if (
            "geburtsdatum" in lowered
            or "geboren" in lowered
            or re.search(r"\bgeb\.", lowered)
        ):
            continue
        for match in re.finditer(date, line):
            parsed = parse(match)
            if parsed is not None:
                return parsed
    return datetime(2026, 8, 1, 9, 30, tzinfo=BERLIN)


def _normalisiere_ooxml_daten(data: bytes, document_date: datetime) -> bytes:
    timestamp = document_date.strftime("%Y-%m-%dT%H:%M:%SZ")
    source_buffer = io.BytesIO(data)
    target_buffer = io.BytesIO()
    with (
        zipfile.ZipFile(source_buffer) as source,
        zipfile.ZipFile(target_buffer, "w") as target,
    ):
        for info in source.infolist():
            content = source.read(info)
            if info.filename == "docProps/core.xml":
                text = content.decode("utf-8")
                for field in ("created", "modified"):
                    pattern = rf"(<dcterms:{field}\b[^>]*>)[^<]*(</dcterms:{field}>)"
                    text, replacements = re.subn(
                        pattern,
                        rf"\g<1>{timestamp}\g<2>",
                        text,
                        count=1,
                    )
                    if replacements != 1:
                        raise RuntimeError(f"OOXML-Metadatum {field} fehlt")
                content = text.encode("utf-8")
            target.writestr(info, content)
    return target_buffer.getvalue()


# ------------------------------------------------------------------- DOCX ---


def _docx_bold_runs(absatz, text: str) -> None:
    for teil in re.split(r"(\*\*.+?\*\*)", text):
        if not teil:
            continue
        if teil.startswith("**") and teil.endswith("**"):
            run = absatz.add_run(_inline_plain(teil[2:-2]))
            run.bold = True
        else:
            absatz.add_run(_inline_plain(teil))


def nach_docx(text: str) -> bytes:
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    doc = Document()
    # Das von python-docx geladene Basistemplate kann getrennte gerade und
    # ungerade Kopfzeilen vorsehen. Testakten brauchen dagegen auf jeder Seite
    # denselben Briefkopf und Registerfuß.
    doc.settings.odd_and_even_pages_header_footer = False
    stil = doc.styles["Normal"]
    stil.font.name = "Arial"
    stil.font.size = Pt(10.5)
    stil.paragraph_format.space_after = Pt(6)
    stil.paragraph_format.line_spacing = 1.08
    for sektion in doc.sections:
        sektion.different_first_page_header_footer = False
        sektion.top_margin = Cm(2.2)
        sektion.bottom_margin = Cm(2.0)
        sektion.left_margin = Cm(2.5)
        sektion.right_margin = Cm(2.0)
        sektion.header_distance = Cm(0.75)
        sektion.footer_distance = Cm(0.75)

    kopfzeilen = text.splitlines()[:15]
    if any(ABSENDER_KONZERN in z for z in kopfzeilen):
        kopf = doc.sections[0].header.paragraphs[0]
        kopf.alignment = WD_ALIGN_PARAGRAPH.LEFT
        kopf.paragraph_format.space_after = Pt(2)
        lauf = kopf.add_run(ABSENDER_KONZERN)
        lauf.bold = True
        lauf.font.name = "Arial"
        lauf.font.size = Pt(11.5)
        lauf.font.color.rgb = RGBColor(0x01, 0x69, 0x6F)
        lauf = kopf.add_run("\nFriedrichstraße 99 · 10117 Berlin · 030 2055 4810")
        lauf.font.name = "Arial"
        lauf.font.size = Pt(7.5)
        lauf.font.color.rgb = RGBColor(0x6E, 0x6E, 0x6E)

        footer = doc.sections[0].footer.paragraphs[0]
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer.paragraph_format.space_before = Pt(2)
        lauf = footer.add_run(
            "Wohnen Berlin Immobilien GmbH · AG Charlottenburg HRB 198765 B · "
            "Geschäftsführer Dr. Markus Lehmann"
        )
        lauf.font.name = "Arial"
        lauf.font.size = Pt(7)
        lauf.font.color.rgb = RGBColor(0x7A, 0x79, 0x74)

    def schattiere(zelle, farbe: str) -> None:
        tc_pr = zelle._tc.get_or_add_tcPr()
        shd = tc_pr.find(qn("w:shd"))
        if shd is None:
            shd = OxmlElement("w:shd")
            tc_pr.append(shd)
        shd.set(qn("w:fill"), farbe)

    def code_absatz(zeile: str) -> None:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(1.5)
        if not zeile.strip():
            p.paragraph_format.space_after = Pt(3)
            return
        einzug = len(zeile) - len(zeile.lstrip(" "))
        inhalt = zeile.strip() if einzug >= 20 else zeile.rstrip()
        if einzug >= 20:
            p.paragraph_format.left_indent = Cm(9.0)
        if re.match(r"^Berlin,\s*\d", inhalt):
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            p.paragraph_format.left_indent = None
        lauf = p.add_run(inhalt)
        lauf.font.name = "Arial"
        lauf.font.size = Pt(10.2)
        if re.fullmatch(r"[A-ZÄÖÜ0-9 .:/()§-]{8,}", inhalt) and len(inhalt) < 90:
            lauf.bold = True
        if re.search(r"\S\s{2,}\S", inhalt) and einzug < 20:
            lauf.font.name = "Courier New"
            lauf.font.size = Pt(9.2)

    for block in parse_bloecke(text):
        art = block[0]
        if art == "h":
            p = doc.add_paragraph()
            lauf = p.add_run(_inline_plain(block[2]))
            lauf.bold = True
            lauf.font.name = "Arial"
            lauf.font.size = Pt({1: 15, 2: 12.5, 3: 11.5, 4: 10.5}[block[1]])
            lauf.font.color.rgb = (
                RGBColor(0x01, 0x69, 0x6F)
                if block[1] <= 2
                else RGBColor(0x22, 0x22, 0x22)
            )
            p.paragraph_format.space_before = Pt(8 if block[1] > 1 else 0)
            p.paragraph_format.space_after = Pt(5)
            p.paragraph_format.keep_with_next = True
        elif art == "p":
            _docx_bold_runs(doc.add_paragraph(), block[1])
        elif art == "list":
            for item in block[1]:
                _docx_bold_runs(doc.add_paragraph(style="List Bullet"), item)
        elif art == "table":
            rows = block[1]
            if not rows:
                continue
            breite = max(len(r) for r in rows)
            tabelle = doc.add_table(rows=len(rows), cols=breite)
            tabelle.style = "Table Grid"
            tabelle.alignment = WD_TABLE_ALIGNMENT.CENTER
            tabelle.autofit = True
            # Kopfzeile nicht allein am Seitenende lassen und bei Fortsetzung wiederholen.
            tabelle.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
            for ri, row in enumerate(rows):
                for ci in range(breite):
                    zelle = tabelle.cell(ri, ci)
                    zelle.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                    zelle.text = ""
                    p = zelle.paragraphs[0]
                    p.paragraph_format.space_after = Pt(0)
                    inhalt = row[ci] if ci < len(row) else ""
                    if ri == 0:
                        p.paragraph_format.keep_with_next = True
                        schattiere(zelle, "E7F0F1")
                        lauf = p.add_run(_inline_plain(inhalt))
                        lauf.bold = True
                    else:
                        _docx_bold_runs(p, inhalt)
                    for run in p.runs:
                        run.font.name = "Arial"
                        run.font.size = Pt(8.8)
            doc.add_paragraph()
        elif art == "code":
            for zeile in block[1]:
                code_absatz(zeile)
        elif art == "hr":
            doc.add_paragraph("_" * 48)

    props = doc.core_properties
    props.author = "Forderungsmanagement"
    document_date = _erstes_datum(text).replace(tzinfo=None)
    props.created = document_date
    props.modified = document_date
    puffer = io.BytesIO()
    doc.save(puffer)
    return _normalisiere_ooxml_daten(puffer.getvalue(), document_date)


# ------------------------------------------------------------------- XLSX ---


def nach_xlsx(text: str) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Auszug"
    fett = Font(name="Arial", size=10, bold=True, color="163A3D")
    normal = Font(name="Arial", size=9.5)
    kopf_fuellung = PatternFill("solid", fgColor="DCEEEF")
    randseite = Side(style="thin", color="B0B0B0")
    rand = Border(left=randseite, right=randseite, top=randseite, bottom=randseite)
    zeile = 1
    max_breite: dict[int, int] = {}
    max_spalten = 1
    tabellenbereiche: list[tuple[int, int, int]] = []

    def excel_wert(wert: str):
        plain = _inline_plain(wert).strip()
        if re.fullmatch(r"-?\d{1,9},\d{2}", plain):
            return float(plain.replace(",", "."))
        if re.fullmatch(r"-?\d{1,9}", plain):
            return int(plain)
        return plain

    def schreibe(
        werte: list[str], *, kopf: bool = False, tabelle: bool = False
    ) -> None:
        nonlocal zeile, max_spalten
        max_spalten = max(max_spalten, len(werte))
        for ci, wert in enumerate(werte, start=1):
            zelle = ws.cell(row=zeile, column=ci, value=excel_wert(wert))
            zelle.font = normal
            zelle.alignment = Alignment(vertical="top", wrap_text=True)
            if kopf:
                zelle.font = fett
                if tabelle:
                    zelle.fill = kopf_fuellung
            if tabelle:
                zelle.border = rand
            if isinstance(zelle.value, float):
                zelle.number_format = "#,##0.00"
            max_breite[ci] = max(max_breite.get(ci, 0), len(str(zelle.value or "")))
        zeile += 1

    for block in parse_bloecke(text):
        art = block[0]
        if art == "h":
            schreibe([block[2]], kopf=True)
            zeile += 0 if block[1] > 2 else 0
        elif art == "p":
            schreibe([block[1]])
        elif art == "list":
            for item in block[1]:
                schreibe([f"- {item}"])
        elif art == "table":
            startzeile = zeile
            rows = block[1]
            for ri, row in enumerate(rows):
                schreibe(row, kopf=(ri == 0), tabelle=True)
            if len(rows) >= 2:
                tabellenbereiche.append(
                    (startzeile, zeile - 1, max(len(row) for row in rows))
                )
            zeile += 1
        elif art == "code":
            for code_zeile in block[1]:
                schreibe([code_zeile])
        elif art == "hr":
            zeile += 1

    for ci, breite in max_breite.items():
        ws.column_dimensions[get_column_letter(ci)].width = min(max(10, breite + 2), 60)
    ws.sheet_view.showGridLines = False
    if tabellenbereiche:
        # Der größte fachliche Datenblock erhält Filter und fixierte Kopfzeile.
        # Überschriften oberhalb der Tabelle dürfen nicht versehentlich als
        # Excel-Spaltenkopf behandelt werden.
        start, ende, spalten = max(
            tabellenbereiche,
            key=lambda bereich: (bereich[1] - bereich[0] + 1) * bereich[2],
        )
        ws.freeze_panes = f"A{start + 1}"
        ws.print_title_rows = f"{start}:{start}"
        if spalten > 1:
            ws.auto_filter.ref = f"A{start}:{get_column_letter(spalten)}{ende}"
    else:
        ws.freeze_panes = "A2"
    ws.page_setup.orientation = "landscape" if max_spalten >= 5 else "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_area = f"A1:{get_column_letter(max_spalten)}{ws.max_row}"
    ws.page_margins.left = 0.25
    ws.page_margins.right = 0.25
    ws.page_margins.top = 0.5
    ws.page_margins.bottom = 0.5
    ws.page_margins.header = 0.2
    ws.page_margins.footer = 0.2
    ws.oddHeader.center.text = "&BWohnen Berlin Immobilien GmbH - Aktenauszug"
    ws.oddFooter.center.text = "Seite &P von &N"
    ws.print_options.horizontalCentered = True
    wb.properties.creator = "SAP-Export Forderungsmanagement"
    document_date = _erstes_datum(text).replace(tzinfo=None)
    wb.properties.created = document_date
    wb.properties.modified = document_date
    puffer = io.BytesIO()
    wb.save(puffer)
    return _normalisiere_ooxml_daten(puffer.getvalue(), document_date)


# -------------------------------------------------------------------- PDF ---

_GESAMT_PDF_MODUL = None


def _gesamt_pdf_modul():
    global _GESAMT_PDF_MODUL
    if _GESAMT_PDF_MODUL is None:
        pfad = REPO_ROOT / "scripts" / "build-testakte-gesamt-pdf.py"
        spec = importlib.util.spec_from_file_location("gesamt_pdf_renderer_real", pfad)
        if spec is None or spec.loader is None:
            raise RuntimeError(
                f"Gesamt-PDF-Renderer konnte nicht geladen werden: {pfad}"
            )
        modul = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(modul)
        _GESAMT_PDF_MODUL = modul
    return _GESAMT_PDF_MODUL


def nach_pdf(text: str, titel: str, dokumentname: str | None = None) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate

    modul = _gesamt_pdf_modul()
    puffer = io.BytesIO()
    doc = SimpleDocTemplate(
        puffer,
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        title=titel,
        author="Aktenexemplar",
    )
    doc.build(
        modul.md_to_flowables(text, document_label=dokumentname or titel),
        onFirstPage=modul.header_footer_factory(titel),
        onLaterPages=modul.header_footer_factory(titel),
    )
    return puffer.getvalue()


# ------------------------------------------------------------ Konvertierung -


def konvertiere_md(quelle: Path, akten_slug: str) -> tuple[Path, bytes]:
    """Liefert (Ziel-Relativpfad-Suffix, Bytes) fuer eine Markdown-Quelle."""
    text = quelle.read_text(encoding="utf-8", errors="replace")
    suffix = ziel_suffix(quelle.stem)
    if suffix == ".xlsx":
        return Path(quelle.stem + suffix), nach_xlsx(text)
    if suffix == ".pdf":
        titel = quelle.stem.replace("-", " ").strip().capitalize()
        return Path(quelle.stem + suffix), nach_pdf(text, titel, quelle.stem)
    return Path(quelle.stem + suffix), nach_docx(text)
