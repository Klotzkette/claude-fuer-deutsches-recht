#!/usr/bin/env python3
"""Baut die Testakten-ZIPs für Releases.

Die Arbeits-ZIPs enthalten ausschließlich die fachlichen Arbeitsdateien als
DOCX, XLSX oder PDF. Sie enthalten weder Markdown noch das separat angebotene
Gesamt-PDF. Alle ZIPs sind flach: Ordnernamen werden als lesbare Segmente in
den Dateinamen übernommen, aber im Archiv werden keine Unterordner angelegt.

Zusätzlich werden das Gesamt-PDF als eigenes Release-Asset und pro Testakte ein
Einzel-PDF-ZIP gebaut. Das Einzel-PDF-ZIP enthält jedes fachliche Aktenstück
der jeweiligen Testakte als separate PDF-Datei: nicht als
Markdown-/Excel-/Text-Mix und nicht als ein Gesamt-PDF. Seit v1.9.0 gibt es
dafür auch ein Sammelpaket für alle Einzel-PDFs.
"""

from __future__ import annotations

import json
import io
import importlib.util
import sys
import zipfile
from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate

from testakte_file_filter import (
    TESTAKTEN_RELEASE_INDEX_SCHEMA,
    TEXT_EXTS,
    discover_testakten,
    include_in_working_dump,
    validate_testakte_source,
)
import testakte_realformate

REPO_ROOT = Path(__file__).resolve().parent.parent
TESTAKTEN = REPO_ROOT / "testakten"
SKIP_DIRS = {
    "formatvorlagen-paradebeispiele",
    "grosser-prompts",
}


def _load_gesamt_pdf_renderer():
    module_path = REPO_ROOT / "scripts" / "build-testakte-gesamt-pdf.py"
    spec = importlib.util.spec_from_file_location("gesamt_pdf_renderer", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Gesamt-PDF-Renderer konnte nicht geladen werden")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_RENDERER = _load_gesamt_pdf_renderer()
FONT_REG = "Helvetica"
MUTED = HexColor("#7A7974")
BORDER = HexColor("#D4D1CA")


def iter_export_files(testakte_dir: Path):
    for path in sorted(
        testakte_dir.rglob("*"), key=lambda p: str(p.relative_to(testakte_dir)).lower()
    ):
        if include_in_working_dump(path, testakte_dir, include_gesamt_pdf=False):
            yield path


def iter_individual_pdf_source_files(testakte_dir: Path):
    for path in sorted(
        testakte_dir.rglob("*"), key=lambda p: str(p.relative_to(testakte_dir)).lower()
    ):
        if include_in_working_dump(path, testakte_dir, include_gesamt_pdf=False):
            yield path


def add_testakte(
    zipf: zipfile.ZipFile,
    testakte_dir: Path,
    real_cache: dict[Path, tuple[Path, bytes]] | None = None,
    *,
    include_slug: bool = False,
) -> int:
    """Arbeits-ZIP: Markdown-Aktenstuecke werden als lebensechte Formate
    (DOCX, XLSX, PDF) exportiert; das Arbeits-ZIP enthält kein Markdown und
    keine Unterordner (verbindliche Regel, siehe testakten/README.md)."""
    count = 0
    seen: set[str] = set()
    for path in iter_export_files(testakte_dir):
        rel = path.relative_to(testakte_dir)
        if path.suffix.lower() == ".md":
            cached = real_cache.get(path) if real_cache is not None else None
            if cached is None:
                ziel_name, daten = testakte_realformate.konvertiere_md(
                    path, testakte_dir.name
                )
                cached = (ziel_name, daten)
                if real_cache is not None:
                    real_cache[path] = cached
            ziel_name, daten = cached
            arcname = testakte_realformate.flacher_exportname(
                rel,
                ziel_name=ziel_name.name,
                akten_slug=testakte_dir.name if include_slug else None,
            )
            folded = arcname.casefold()
            if folded in seen:
                raise SystemExit(
                    f"{testakte_dir.name}: doppelter Arbeitsdateiname {arcname}"
                )
            seen.add(folded)
            if not arcname.isascii():
                raise SystemExit(
                    f"{testakte_dir.name}: Arbeitsdateiname ist nicht ASCII: {arcname}"
                )
            zipf.writestr(arcname, daten)
        else:
            if path.suffix.lower() not in {".docx", ".xlsx", ".pdf"}:
                raise SystemExit(f"{path}: Arbeits-ZIP erlaubt nur DOCX, XLSX und PDF")
            arcname = testakte_realformate.flacher_exportname(
                rel,
                ziel_name=path.name,
                akten_slug=testakte_dir.name if include_slug else None,
            )
            folded = arcname.casefold()
            if folded in seen:
                raise SystemExit(
                    f"{testakte_dir.name}: doppelter Arbeitsdateiname {arcname}"
                )
            seen.add(folded)
            if not arcname.isascii():
                raise SystemExit(
                    f"{testakte_dir.name}: Arbeitsdateiname ist nicht ASCII: {arcname}"
                )
            zipf.write(path, arcname)
        count += 1
    return count


def build_single(
    testakte_dir: Path, dist: Path, real_cache: dict[Path, tuple[Path, bytes]]
) -> tuple[Path, int]:
    out = dist / f"testakte-{testakte_dir.name}.zip"
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zipf:
        count = add_testakte(zipf, testakte_dir, real_cache)
    return out, count


def build_gesamt_pdf_asset(testakte_dir: Path, dist: Path) -> Path:
    source = testakte_dir / "gesamt-pdf" / f"{testakte_dir.name}_gesamt.pdf"
    if not source.is_file():
        raise SystemExit(f"{testakte_dir.name}: Gesamt-PDF fehlt: {source}")
    out = dist / f"testakte-{testakte_dir.name}-gesamt.pdf"
    out.write_bytes(source.read_bytes())
    return out


def _single_pdf_footer(canv, doc) -> None:
    canv.saveState()
    canv.setFont(FONT_REG, 8)
    canv.setFillColor(MUTED)
    canv.drawRightString(19 * cm, 1.2 * cm, f"Seite {doc.page}")
    canv.setStrokeColor(BORDER)
    canv.setLineWidth(0.3)
    canv.line(2 * cm, 1.6 * cm, 19 * cm, 1.6 * cm)
    canv.restoreState()


def render_text_pdf(title: str, suffix: str, text: str) -> bytes:
    display_title = title.replace("-", " ").replace("_", " ").strip()
    if display_title:
        display_title = display_title[:1].upper() + display_title[1:]
    else:
        display_title = "Aktenstück"
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        title=display_title,
        author="Kanzleiakte",
    )
    if suffix == ".md":
        flow = _RENDERER.md_to_flowables(text, document_label=title)
    else:
        flow = _RENDERER.txt_to_flowables(text)
    if not flow:
        raise SystemExit(f"{title}: leeres Einzel-PDF-Dokument")
    doc.build(
        flow,
        onFirstPage=_single_pdf_footer,
        onLaterPages=_single_pdf_footer,
    )
    return buffer.getvalue()


def _pdf_arcname_for_source(
    testakte_dir: Path, source: Path, *, include_slug: bool = False
) -> str:
    rel = source.relative_to(testakte_dir)
    return testakte_realformate.flacher_exportname(
        rel,
        ziel_name=rel.with_suffix(".pdf").name,
        akten_slug=testakte_dir.name if include_slug else None,
    )


def add_individual_pdfs(
    zipf: zipfile.ZipFile,
    testakte_dir: Path,
    pdf_cache: dict[Path, bytes] | None = None,
    *,
    include_slug: bool = False,
) -> int:
    count = 0
    seen: set[str] = set()
    for source in iter_individual_pdf_source_files(testakte_dir):
        arcname = _pdf_arcname_for_source(
            testakte_dir, source, include_slug=include_slug
        )
        folded = arcname.casefold()
        if folded in seen:
            raise SystemExit(
                f"{testakte_dir.name}: doppelter Einzel-PDF-Name {arcname}"
            )
        seen.add(folded)
        if not arcname.isascii():
            raise SystemExit(
                f"{testakte_dir.name}: Einzel-PDF-Name ist nicht ASCII: {arcname}"
            )

        suffix = source.suffix.lower()
        if suffix == ".pdf":
            zipf.write(source, arcname)
        elif suffix in TEXT_EXTS:
            rel = source.relative_to(testakte_dir)
            pdf = pdf_cache.get(source) if pdf_cache is not None else None
            if pdf is None:
                pdf = render_text_pdf(
                    source.stem,
                    rel.suffix.lower(),
                    source.read_text(encoding="utf-8", errors="replace"),
                )
                if pdf_cache is not None:
                    pdf_cache[source] = pdf
            zipf.writestr(arcname, pdf)
        else:
            raise SystemExit(
                f"{source}: Dateityp kann nicht als Einzel-PDF exportiert werden"
            )
        count += 1
    return count


def build_individual_pdfs(
    testakte_dir: Path, dist: Path, pdf_cache: dict[Path, bytes]
) -> tuple[Path, int]:
    out = dist / f"testakte-{testakte_dir.name}-einzel-pdfs.zip"
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zipf:
        count = add_individual_pdfs(zipf, testakte_dir, pdf_cache)
    return out, count


def write_release_index(dist: Path, dirs: list[Path]) -> None:
    index = {
        "schema": TESTAKTEN_RELEASE_INDEX_SCHEMA,
        "download_forms": {
            "working_zip": "Fachliche Aktenstücke als flacher Formate-Mix aus DOCX, XLSX und PDF; ohne Markdown, Unterordner oder Gesamt-PDF-Dublette.",
            "gesamt_pdf": "Vollständige Testakte als eine direkt herunterladbare PDF-Datei.",
            "individual_pdfs_zip": "Fachliche Aktenstücke als einzeln benannte PDFs, ohne Gesamt-PDF.",
            "combined_working_zip": "Alle Arbeitsdateien in einem flachen Sammel-ZIP; der Akten-Slug steht im Dateinamen.",
            "combined_individual_pdfs_zip": "Alle Einzel-PDFs in einem flachen Sammel-ZIP; der Akten-Slug steht im Dateinamen.",
        },
        "testakten": [],
        "combined_assets": {
            "working_zip": "alle-testakten.zip",
            "individual_pdfs_zip": "alle-testakten-einzel-pdfs.zip",
        },
    }
    for d in dirs:
        index["testakten"].append(
            {
                "slug": d.name,
                "working_zip": f"testakte-{d.name}.zip",
                "gesamt_pdf_asset": f"testakte-{d.name}-gesamt.pdf",
                "individual_pdfs_zip": f"testakte-{d.name}-einzel-pdfs.zip",
                "gesamt_pdf": f"{d.name}/gesamt-pdf/{d.name}_gesamt.pdf",
                "working_files": len(list(iter_export_files(d))),
                "individual_pdfs": len(list(iter_individual_pdf_source_files(d))),
            }
        )
    (dist / "testakten-release-index.json").write_text(
        json.dumps(index, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    dist = Path(sys.argv[1]) if len(sys.argv) > 1 else REPO_ROOT / "dist"
    dist.mkdir(parents=True, exist_ok=True)
    try:
        dirs = discover_testakten(TESTAKTEN, SKIP_DIRS)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    if not dirs:
        print("Keine Testakten gefunden.")
        return
    for testakte_dir in dirs:
        try:
            validate_testakte_source(testakte_dir)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc

    total_files = 0
    total_individual_pdfs = 0
    pdf_cache: dict[Path, bytes] = {}
    real_cache: dict[Path, tuple[Path, bytes]] = {}
    for d in dirs:
        out, count = build_single(d, dist, real_cache)
        if count == 0:
            raise SystemExit(f"{d}: keine exportfähigen Dateien")
        total_files += count
        print(f"Baue {out.name}: {count} Dateien")
        gesamt_pdf_out = build_gesamt_pdf_asset(d, dist)
        print(f"Baue {gesamt_pdf_out.name}: direktes Gesamt-PDF")
        pdf_out, pdf_count = build_individual_pdfs(d, dist, pdf_cache)
        if pdf_count == 0:
            raise SystemExit(f"{d}: keine Einzel-PDF-Quellen")
        total_individual_pdfs += pdf_count
        print(f"Baue {pdf_out.name}: {pdf_count} Einzel-PDFs")

    all_out = dist / "alle-testakten.zip"
    with zipfile.ZipFile(all_out, "w", compression=zipfile.ZIP_DEFLATED) as zipf:
        all_count = 0
        for d in dirs:
            all_count += add_testakte(zipf, d, real_cache, include_slug=True)
    all_individual_pdf_out = dist / "alle-testakten-einzel-pdfs.zip"
    with zipfile.ZipFile(
        all_individual_pdf_out, "w", compression=zipfile.ZIP_DEFLATED
    ) as zipf:
        all_individual_pdf_count = 0
        for d in dirs:
            all_individual_pdf_count += add_individual_pdfs(
                zipf, d, pdf_cache, include_slug=True
            )
    write_release_index(dist, dirs)
    print(f"Baue {all_out.name}: {all_count} Dateien aus {len(dirs)} Testakten")
    print(
        f"Baue {all_individual_pdf_out.name}: {all_individual_pdf_count} Einzel-PDFs aus {len(dirs)} Testakten"
    )
    print("Baue testakten-release-index.json: Download-Index für Release-Assets")
    print(
        f"Fertig: {len(dirs)} Arbeits-ZIPs, {len(dirs)} Gesamt-PDF-Assets, "
        f"{total_files} Dateien, {total_individual_pdfs} Einzel-PDFs"
    )


if __name__ == "__main__":
    main()
