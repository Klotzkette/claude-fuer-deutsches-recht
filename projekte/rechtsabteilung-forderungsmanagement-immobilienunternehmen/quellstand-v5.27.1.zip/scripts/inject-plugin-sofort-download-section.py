#!/usr/bin/env python3
"""Fügt in jede <plugin>/README.md ganz oben (direkt nach dem H1) eine
prominente 'Sofort-Download'-Sektion ein.

Inhalt der Sektion:
- Plugin-ZIP-Direktdownload (immer, für ALLE Plugins)
- Pro zugeordnete Testakte: Gesamt-PDF, Arbeits-ZIP und Einzel-PDF-ZIP

Quelle der Akten-Zuordnung: jede testakten/<slug>/README.md und die zentrale
testakten/README.md, soweit dort bestehende Plugin-Namen per Backtick
(`plugin-name`) referenziert werden. Identisch zur Logik in
inject-plugin-testakten-section.py.

Idempotent über HTML-Marker. Position: ZWISCHEN H1 und der Testakten-Sektion.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
TESTAKTEN_DIR = REPO_ROOT / "testakten"

SKIP_TESTAKTEN_DIRS = {
    "formatvorlagen-paradebeispiele",
    "grosser-prompts",
}

MARKER_BEGIN = "<!-- BEGIN plugin-sofort-download-section (autogen) -->"
MARKER_END = "<!-- END plugin-sofort-download-section (autogen) -->"
TESTAKTEN_MARKER_BEGIN = "<!-- BEGIN plugin-testakten-section (autogen) -->"

RELEASE_BASE = "https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download"

H1_RE = re.compile(r"^# .+$", re.MULTILINE)

# Einzelne ältere Akten nennen Skill- oder Sachgebietsnamen, die fachlich einem
# bestehenden Plugin entsprechen. Diese Aliase werden nur für README-
# Downloadsektionen verwendet; die Akten selbst bleiben unverändert.
PLUGIN_ALIASES = {
    "bauplanungsrecht": ["normenkontrolle-bauleitplanung"],
    "cisg-handelskauf": ["urteilsbauer-relationsmacher"],
    "dsgvo": ["datenschutzrecht"],
    "internationales-privatrecht": ["urteilsbauer-relationsmacher"],
}


def add_mapping(
    mapping: dict[str, set[str]],
    plugin_names: set[str],
    slug: str,
    text: str,
) -> None:
    """Füge alle Plugin-Backticks aus text für slug in mapping ein."""
    tokens = set(re.findall(r"`([^`]+)`", text))
    for token in tokens:
        if token in plugin_names:
            mapping.setdefault(token, set()).add(slug)
        for alias_target in PLUGIN_ALIASES.get(token, []):
            if alias_target in plugin_names:
                mapping.setdefault(alias_target, set()).add(slug)


def testakte_sort_key(slug: str) -> tuple[int, int | str]:
    """Sortiere Akten für Schulungstabellen fachlich statt alphabetisch."""
    title = get_akte_title(slug)
    number_match = re.search(r"\bTestakte\s+(\d+)\b", title, flags=re.IGNORECASE)
    if number_match:
        return (0, int(number_match.group(1)))
    if slug == "mietspiegel-berlin":
        return (1, 0)
    return (2, slug)


def discover_mapping() -> dict[str, list[str]]:
    """Sammle Plugin->Akten-Verbindungen aus Einzel-README und Gesamtübersicht."""
    mapping: dict[str, set[str]] = {}
    if not TESTAKTEN_DIR.exists():
        return {}
    marketplace = json.loads(
        (REPO_ROOT / ".claude-plugin" / "marketplace.json").read_text(encoding="utf-8")
    )
    plugin_names = {p["name"] for p in marketplace["plugins"]}
    all_testakten = sorted(
        sub.name
        for sub in TESTAKTEN_DIR.iterdir()
        if sub.is_dir() and sub.name not in SKIP_TESTAKTEN_DIRS
    )

    for sub in sorted(TESTAKTEN_DIR.iterdir()):
        if not sub.is_dir():
            continue
        if sub.name in SKIP_TESTAKTEN_DIRS:
            continue
        readme = sub / "README.md"
        if readme.exists():
            add_mapping(
                mapping, plugin_names, sub.name, readme.read_text(encoding="utf-8")
            )

    overview = TESTAKTEN_DIR / "README.md"
    if overview.exists():
        for line in overview.read_text(encoding="utf-8").splitlines():
            m = re.match(r"\| \[`([^/]+)/`\]\(\./\1/\) \|", line)
            if m:
                # Die zentrale Testakten-Tabelle hat im Lauf der Releases
                # verschiedene Spaltenzuschnitte bekommen. Darum nicht auf
                # eine bestimmte Plugin-Spalte verlassen, sondern die ganze
                # Zeile nach Plugin-Backticks durchsuchen.
                add_mapping(mapping, plugin_names, m.group(1), line)
    if len(plugin_names) == 1 and all_testakten:
        # Ein-Plugin-Repos wie dieses Immobilien-Forderungsmanagement ordnen
        # alle Testakten dem einzigen Plugin zu. Sonst hängt die Downloadsektion
        # zufällig davon ab, ob Einzel-READMEs den Plugin-Namen backticken.
        only_plugin = next(iter(plugin_names))
        mapping[only_plugin] = set(all_testakten)
    return {p: sorted(v, key=testakte_sort_key) for p, v in mapping.items()}


def get_akte_title(akte_slug: str) -> str:
    """Lese den H1-Titel aus testakten/<slug>/README.md und bereinige Präfixe."""
    readme = TESTAKTEN_DIR / akte_slug / "README.md"
    if not readme.exists():
        return akte_slug
    for line in readme.read_text(encoding="utf-8").splitlines():
        if line.startswith("# "):
            title = line[2:].strip()
            return re.sub(
                r"^(Akte|Beispielakte|Testakte)\s*[:–-]\s*",
                "",
                title,
                flags=re.IGNORECASE,
            )
    return akte_slug


def build_section(plugin_name: str, akten_slugs: list[str]) -> str:
    lines: list[str] = []
    lines.append(MARKER_BEGIN)
    lines.append("## Release-Assets")
    lines.append("")
    lines.append("| Einstieg | Link |")
    lines.append("|---|---|")
    lines.append(
        f"| Plugin sofort installieren | [{plugin_name}.zip]({RELEASE_BASE}/{plugin_name}.zip) |"
    )
    lines.append(
        f"| Marketplace einbinden | [marketplace.json]({RELEASE_BASE}/marketplace.json) |"
    )
    lines.append(
        f"| Schnellstartprompt einzeln testen | [{plugin_name}-kleiner-prompt-skill.zip]({RELEASE_BASE}/{plugin_name}-kleiner-prompt-skill.zip) |"
    )
    lines.append(
        f"| Werkstattprompt einzeln testen | [{plugin_name}-grosser-prompt-skill.zip]({RELEASE_BASE}/{plugin_name}-grosser-prompt-skill.zip) |"
    )
    lines.append(
        "| Alle Pakete auswählen | [Zentrale Sofort-Downloads](../README.md#sofort-downloads-latest-release) |"
    )
    lines.append(
        "| Testakte einzeln laden | [Testakten-Downloads](../testakten/README.md#download-pakete) |"
    )
    lines.append(
        f"| Vollständiges Offline-Paket | [immobilien-forderungsmanagement-dokumentation.zip]({RELEASE_BASE}/immobilien-forderungsmanagement-dokumentation.zip) |"
    )
    lines.append(
        f"| Vollständige Asset-Liste | [release-katalog.md]({RELEASE_BASE}/release-katalog.md) |"
    )
    lines.append(
        f"| Downloads prüfen | [checksums-sha256.txt]({RELEASE_BASE}/checksums-sha256.txt) |"
    )
    lines.append("")
    lines.append(MARKER_END)
    return "\n".join(lines)


def inject_section(readme: Path, plugin_name: str, akten_slugs: list[str]) -> str:
    """Returns one of: 'INSERTED', 'UPDATED', 'UNCHANGED', 'SKIPPED'."""
    if not readme.exists():
        return "SKIPPED"
    text = readme.read_text(encoding="utf-8")
    new_block = build_section(plugin_name, akten_slugs)

    def insert_after_h1(current_text: str) -> str:
        h1 = H1_RE.search(current_text)
        if not h1:
            return current_text
        insert_pos = h1.end()
        after = current_text[insert_pos:]
        blank = re.match(r"\n+", after)
        if blank:
            insert_pos += blank.end()
        return (
            current_text[:insert_pos]
            + "\n"
            + new_block
            + "\n\n"
            + current_text[insert_pos:]
        )

    if MARKER_BEGIN in text and MARKER_END in text:
        # Replace existing and keep the block directly after the H1.
        pattern = re.compile(
            r"\n*" + re.escape(MARKER_BEGIN) + r".*?" + re.escape(MARKER_END) + r"\n*",
            re.DOTALL,
        )
        without_old_block = pattern.sub("\n", text, count=1)
        new_text = insert_after_h1(without_old_block)
        if new_text == text:
            return "UNCHANGED"
        readme.write_text(new_text, encoding="utf-8")
        return "UPDATED"

    # Insert directly after H1 line (before any other content)
    if not H1_RE.search(text):
        return "SKIPPED"
    new_text = insert_after_h1(text)
    readme.write_text(new_text, encoding="utf-8")
    return "INSERTED"


def main() -> int:
    mapping = discover_mapping()
    marketplace = json.loads(
        (REPO_ROOT / ".claude-plugin" / "marketplace.json").read_text(encoding="utf-8")
    )
    plugin_names = [p["name"] for p in marketplace["plugins"]]

    counts = {"INSERTED": 0, "UPDATED": 0, "UNCHANGED": 0, "SKIPPED": 0}

    for name in plugin_names:
        plugin_dir = REPO_ROOT / name
        readme = plugin_dir / "README.md"
        akten = mapping.get(name, [])
        status = inject_section(readme, name, akten)
        counts[status] += 1
        if status in ("INSERTED", "UPDATED"):
            count_str = f"  ({len(akten)} Akte/n)" if akten else "  (keine Akte)"
            print(f"  {status:8s}  {name}{count_str}")

    print(
        f"\nFertig: {counts['INSERTED']} neu, {counts['UPDATED']} aktualisiert, "
        f"{counts['UNCHANGED']} unverändert, {counts['SKIPPED']} übersprungen"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
