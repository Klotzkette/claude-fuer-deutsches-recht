#!/usr/bin/env python3
"""Mutationstests für die Release-Validatoren.

Der Test beschädigt temporäre Kopien eines vollständig gebauten Release-Satzes.
Jede Mutation muss durch den zuständigen Validator zuverlässig blockiert werden.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from collections.abc import Callable
from pathlib import Path
from typing import NoReturn


REPO_ROOT = Path(__file__).resolve().parent.parent
RELEASE_VALIDATOR = REPO_ROOT / "scripts" / "validate-release-zips.py"
TESTAKTEN_VALIDATOR = REPO_ROOT / "scripts" / "validate-testakten-release-zips.py"
ZipTransform = Callable[[str, bytes], tuple[str, bytes] | None]


def fail(message: str) -> NoReturn:
    print(f"validate-release-guardrails failed: {message}", file=sys.stderr)
    raise SystemExit(1)


def copy_dist(source: Path, parent: Path, name: str) -> Path:
    target = parent / name
    shutil.copytree(source, target)
    return target


def rewrite_zip(path: Path, transform: ZipTransform) -> None:
    try:
        with zipfile.ZipFile(path) as source:
            entries = [
                (info.filename, source.read(info))
                for info in source.infolist()
                if not info.is_dir()
            ]
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as target:
            for entry_name, data in entries:
                transformed = transform(entry_name, data)
                if transformed is not None:
                    target.writestr(*transformed)
    except (OSError, zipfile.BadZipFile) as exc:
        fail(f"Mutation von {path} fehlgeschlagen: {exc}")


def expect_failure(label: str, command: list[str], needle: str) -> None:
    result = subprocess.run(
        command,
        cwd=REPO_ROOT,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if result.returncode == 0:
        fail(f"{label}: beschädigtes Paket wurde akzeptiert")
    if needle not in result.stdout:
        fail(f"{label}: erwarteter Fehler {needle!r} fehlt; Ausgabe: {result.stdout}")
    print(f"  ok: {label}")


def release_command(dist: Path, marketplace: Path, expected_tag: str) -> list[str]:
    return [
        sys.executable,
        str(RELEASE_VALIDATOR),
        str(dist),
        str(marketplace),
        "--expected-tag",
        expected_tag,
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("dist", type=Path)
    parser.add_argument(
        "marketplace",
        nargs="?",
        type=Path,
        default=REPO_ROOT / ".claude-plugin" / "marketplace.json",
    )
    args = parser.parse_args()
    dist = args.dist.resolve()
    marketplace = args.marketplace.resolve()
    if not dist.is_dir():
        fail(f"Release-Verzeichnis fehlt: {dist}")
    marketplace_data = json.loads(marketplace.read_text(encoding="utf-8"))
    expected_tag = f"v{marketplace_data['version']}"

    with tempfile.TemporaryDirectory(prefix="ifm-release-guardrails-") as temp:
        temp_root = Path(temp)

        target = copy_dist(dist, temp_root, "missing-skill")
        plugin_zip = target / "forderungsmanagement-immobilien.zip"
        with zipfile.ZipFile(plugin_zip) as archive:
            skills = sorted(
                name
                for name in archive.namelist()
                if name.startswith("skills/") and name.endswith("/SKILL.md")
            )
        if not skills:
            fail(f"{plugin_zip}: keine Skill-Datei für Mutation gefunden")
        removed_skill = skills[-1]
        rewrite_zip(
            plugin_zip,
            lambda name, data: None if name == removed_skill else (name, data),
        )
        expect_failure(
            "fehlender Skill im Plugin-ZIP",
            release_command(target, marketplace, expected_tag),
            "file set mismatch",
        )

        target = copy_dist(dist, temp_root, "missing-bea-workshop-skill")
        plugin_zip = target / "schriftsatzwerkstatt-bea.zip"
        with zipfile.ZipFile(plugin_zip) as archive:
            workshop_skills = sorted(
                name
                for name in archive.namelist()
                if name.startswith("skills/") and name.endswith("/SKILL.md")
            )
        if not workshop_skills:
            fail(f"{plugin_zip}: keine Werkstatt-Skill-Datei für Mutation gefunden")
        removed_workshop_skill = workshop_skills[-1]
        rewrite_zip(
            plugin_zip,
            lambda name, data: None if name == removed_workshop_skill else (name, data),
        )
        expect_failure(
            "fehlender Skill im beA-Werkstatt-ZIP",
            release_command(target, marketplace, expected_tag),
            "file set mismatch",
        )

        target = copy_dist(dist, temp_root, "path-traversal")
        plugin_zip = target / "forderungsmanagement-immobilien.zip"
        with zipfile.ZipFile(plugin_zip, "a", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("../escape.txt", "unzulässig")
        expect_failure(
            "ZIP-Pfadtraversal",
            release_command(target, marketplace, expected_tag),
            "unsafe ZIP member path",
        )

        target = copy_dist(dist, temp_root, "marketplace-drift")
        asset = target / "marketplace.json"
        stale = json.loads(asset.read_text(encoding="utf-8"))
        stale["version"] = "0.0.0"
        asset.write_text(
            json.dumps(stale, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        expect_failure(
            "abweichendes Marketplace-Asset",
            release_command(target, marketplace, expected_tag),
            "differs from source marketplace.json",
        )

        target = copy_dist(dist, temp_root, "wrong-office-content")
        working_zips = sorted(
            path
            for path in target.glob("testakte-*.zip")
            if not path.name.endswith("-einzel-pdfs.zip")
        )
        office_zip: Path | None = None
        office_names: list[str] = []
        for candidate in working_zips:
            with zipfile.ZipFile(candidate) as archive:
                names = sorted(
                    name for name in archive.namelist() if name.endswith(".docx")
                )
            if len(names) >= 2:
                office_zip = candidate
                office_names = names
                break
        if office_zip is None:
            fail(f"{target}: kein Arbeits-ZIP mit zwei DOCX-Dateien gefunden")
        with zipfile.ZipFile(office_zip) as archive:
            wrong_content = archive.read(office_names[1])
        rewrite_zip(
            office_zip,
            lambda name, data: (
                (name, wrong_content) if name == office_names[0] else (name, data)
            ),
        )
        expect_failure(
            "fachlich falsche, technisch gültige DOCX",
            [sys.executable, str(TESTAKTEN_VALIDATOR), str(target)],
            "Office-Inhalt unterscheidet sich von der Markdown-Quelle",
        )

        target = copy_dist(dist, temp_root, "broken-pdf")
        pdf_zips = sorted(target.glob("testakte-*-einzel-pdfs.zip"))
        if not pdf_zips:
            fail(f"{target}: kein Einzel-PDF-ZIP für Mutation gefunden")
        changed = False

        def corrupt_first_pdf(name: str, data: bytes) -> tuple[str, bytes]:
            nonlocal changed
            if not changed and name.endswith(".pdf"):
                changed = True
                return name, b"%PDF-1.7\nnot-a-real-pdf"
            return name, data

        rewrite_zip(pdf_zips[0], corrupt_first_pdf)
        if not changed:
            fail(f"{pdf_zips[0]}: keine PDF-Datei für Mutation gefunden")
        expect_failure(
            "strukturell defektes PDF",
            [sys.executable, str(TESTAKTEN_VALIDATOR), str(target)],
            "kein vollständig lesbares PDF",
        )

        target = copy_dist(dist, temp_root, "missing-total-pdf-asset")
        total_pdf_assets = sorted(target.glob("testakte-*-gesamt.pdf"))
        if not total_pdf_assets:
            fail(f"{target}: kein Gesamt-PDF-Asset für Mutation gefunden")
        total_pdf_assets[0].unlink()
        expect_failure(
            "fehlendes direktes Gesamt-PDF-Asset",
            [sys.executable, str(TESTAKTEN_VALIDATOR), str(target)],
            "direktes Gesamt-PDF-Asset fehlt",
        )

        target = copy_dist(dist, temp_root, "wrong-index")
        index_path = target / "testakten-release-index.json"
        index = json.loads(index_path.read_text(encoding="utf-8"))
        testakten = index.get("testakten")
        if not isinstance(testakten, list) or not testakten:
            fail(f"{index_path}: keine Testakte für Mutation gefunden")
        testakten[0]["gesamt_pdf"] = "falsch.pdf"
        index_path.write_text(
            json.dumps(index, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        expect_failure(
            "falscher Gesamt-PDF-Pfad",
            [sys.executable, str(TESTAKTEN_VALIDATOR), str(target)],
            "gesamt_pdf mismatch",
        )

    print("validate-release-guardrails OK (8 absichtliche Defekte abgefangen)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
