"""Small YAML frontmatter helpers for SKILL.md maintenance scripts."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def split_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Return parsed YAML frontmatter and body.

    Maintenance generators should read SKILL.md metadata the same way the
    validators do. Regex-based parsing breaks on valid quoted YAML such as
    colon-space inside descriptions.
    """
    if not text.startswith("---\n"):
        return {}, text.strip()
    end_idx = text.find("\n---", 4)
    if end_idx == -1:
        return {}, text.strip()

    raw = text[4:end_idx]
    body_start = end_idx + len("\n---")
    if body_start < len(text) and text[body_start] == "\n":
        body_start += 1
    parsed = yaml.safe_load(raw) or {}
    if not isinstance(parsed, dict):
        return {}, text[body_start:].strip()
    return parsed, text[body_start:].strip()


def frontmatter_from_text(text: str) -> dict[str, Any]:
    return split_frontmatter(text)[0]


def body_from_text(text: str) -> str:
    return split_frontmatter(text)[1]


def description_from_text(text: str) -> str:
    value = frontmatter_from_text(text).get("description", "")
    return value if isinstance(value, str) else ""


def description_from_file(path: Path) -> str:
    return description_from_text(path.read_text(encoding="utf-8", errors="ignore"))
