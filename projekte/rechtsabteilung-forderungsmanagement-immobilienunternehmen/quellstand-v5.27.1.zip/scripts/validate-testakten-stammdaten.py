#!/usr/bin/env python3
"""Validiert die Stammdaten-Konsistenz innerhalb jeder Testakte.

Eine Testakte muss wie eine echte Akte in sich stimmig sein: Vertragsnummer,
Vertrags-/Mietbeginn und Geburtsdatum je Person duerfen zwischen README,
SAP-Auszug, Mietvertrag, Mietkonto und Korrespondenz nicht voneinander
abweichen. DMS-Exportlisten muessen ausserdem eine plausible Exportchronologie
und eine zur Trefferangabe passende Zeilenzahl haben. Gewollte
Uebungskonflikte muessen im README der Akte ausdruecklich als Trainingsziel
benannt sein und werden dann ueber die Ausnahmeliste unten freigeschaltet.

Erfasste Formate (siehe Selbsttest):
- Tabellen: | Vertragsbeginn | 01.08.2019 |  und  | Mietbeginn | ... |
- Doppelpunkt und Bullet: Mietbeginn : 01.08.2019  /  - Vertragsbeginn: ...
- Fliesstext: Das Mietverhaeltnis beginnt am 01.08.2019
- Geburtsdaten mit Name (Thomas Meier, geb. 14.03.1972), mit Titel und
  Markdown-Auszeichnung (**Frau Aleksandra Kowalska**, geb. ...), invertiert
  (Becker, Wolfgang, geb. 14.03.1962), mit Geburtsname (Becker, Heike geb.
  Schubert, geb. 09.11.1964) sowie namenlos (Geburtsdatum : 14.03.1972,
  Geboren: 22.07.1985, | Geburtsdatum | 14.03.1972 |). Namenlose Daten muessen
  in der Menge der benannten Geburtsdaten der Akte enthalten sein. Gibt es
  keine benannten Daten, duerfen namenlose Quellen nicht voneinander abweichen.

Der Check nutzt nur die Python-Standardbibliothek, damit er in GitHub Actions
ohne zusaetzliche Abhaengigkeiten laeuft. Aufruf mit --selbsttest fuehrt die
eingebauten Positiv- und Negativ-Fixtures aus.
"""

from __future__ import annotations

import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TESTAKTEN = ROOT / "testakten"

# Hilfsmaterial-Ordner unterhalb testakten/ ohne Akten-Struktur.
SKIP_DIRS = {
    "mietspiegel-berlin",
    "formatvorlagen-paradebeispiele",
    "grosser-prompts",
}

# Akten mit dokumentierten, gewollten Uebungskonflikten. Schluessel ist der
# Akten-Slug, Wert die Menge der freigeschalteten Pruefungen
# ("vertragsnummer", "vertragsbeginn", "geburtsdatum").
ERLAUBTE_KONFLIKTE: dict[str, set[str]] = {}

DATUM = r"([0-3]?\d\.[01]?\d\.\d{4})"
NAME_TEIL = r"[A-ZÄÖÜ][\wäöüß-]+"

VERTRAGSNR = re.compile(r"WBI-MV-\d{4}-\d{5}")
VERTRAGSBEGINN = re.compile(
    r"(?:Vertragsbeginn|Mietbeginn)\s*[:|]?\s*\**"
    + DATUM
    + r"|Mietverhältnis beginnt am\s+\**"
    + DATUM
)
# Benannte Geburtsdaten: "Vorname Nachname, geb. DATUM" (Titel, Markdown und
# eingeschobener Geburtsname erlaubt) sowie invertiert "Nachname, Vorname,
# geb. DATUM".
GEB_INVERTIERT = re.compile(
    rf"({NAME_TEIL}),\s*({NAME_TEIL})(?:\s+geb\.\s+{NAME_TEIL})?,\s*geb(?:oren am|\.)\s*{DATUM}"
)
GEB_BENANNT = re.compile(
    rf"({NAME_TEIL}(?:\s{NAME_TEIL})?)(?:\s+geb\.\s+{NAME_TEIL})?\s*,?\s*geb(?:oren am|\.)\s*{DATUM}"
)
# Namenlose Geburtsdaten: "Geburtsdatum : DATUM", "Geboren: DATUM" und
# Tabellenfelder wie "| Geburtsdatum | DATUM |".
GEB_NAMENLOS = re.compile(rf"(?:Geburtsdatum|Geboren)\s*(?::|\|)?\s*{DATUM}")

TITEL = re.compile(r"\b(?:Herrn?|Frau)\s+")
DMS_EXPORT_DATUM = (
    re.compile(r"\|\s*(?:Exportdatum|Exportzeitpunkt)\s*\|\s*" + DATUM),
    re.compile(r"\*\*Erstellt:\*\*\s*" + DATUM),
)
DMS_TREFFERZAHL = re.compile(
    r"\|\s*(?:Ergebnis|Treffer|Dokumente)\s*\|\s*(\d+)"
    r"(?:\s+Dokumenttreffer)?\s*\|",
    re.IGNORECASE,
)
DMS_DOKUMENTZEILE = re.compile(
    r"^\|\s*(?:DW-\d+|\d{6})\s*\|.*$",
    re.MULTILINE,
)
DMS_ZEILENDATUM = re.compile(DATUM)


def akten_dateien(akte: Path) -> list[Path]:
    return [f for f in sorted(akte.rglob("*.md")) if "gesamt-pdf" not in f.parts]


def geburtsdaten_der_zeile(zeile: str) -> tuple[list[tuple[str, str]], list[str]]:
    """Liefert (benannte Treffer als (Name, Datum), namenlose Daten)."""
    text = TITEL.sub("", zeile.replace("*", ""))
    benannt: list[tuple[str, str]] = []
    spans: list[tuple[int, int]] = []
    for m in GEB_INVERTIERT.finditer(text):
        benannt.append((f"{m.group(2)} {m.group(1)}", m.group(3)))
        spans.append(m.span())
    for m in GEB_BENANNT.finditer(text):
        if any(a <= m.start() < b for a, b in spans):
            continue
        benannt.append((m.group(1), m.group(2)))
    namenlos = [m.group(1) for m in GEB_NAMENLOS.finditer(text)]
    return benannt, namenlos


def pruefe_dms_export(rel: str, text: str, slug: str) -> list[str]:
    """Prueft Trefferzahl und zeitliche Plausibilitaet einer DMS-Liste."""
    if not rel.startswith("dms/"):
        return []

    fehler: list[str] = []
    exportdatum_text = next(
        (
            treffer.group(1)
            for muster in DMS_EXPORT_DATUM
            if (treffer := muster.search(text))
        ),
        None,
    )
    if exportdatum_text is None:
        return [f"{slug}/{rel}: DMS-Exportdatum fehlt"]

    exportdatum = datetime.strptime(exportdatum_text, "%d.%m.%Y").date()
    dokumentzeilen = DMS_DOKUMENTZEILE.findall(text)
    trefferzahl = DMS_TREFFERZAHL.search(text)
    if trefferzahl and int(trefferzahl.group(1)) != len(dokumentzeilen):
        fehler.append(
            f"{slug}/{rel}: Trefferangabe {trefferzahl.group(1)} passt nicht "
            f"zu {len(dokumentzeilen)} Dokumentzeilen"
        )

    for zeile in dokumentzeilen:
        datumstreffer = DMS_ZEILENDATUM.search(zeile)
        if not datumstreffer:
            fehler.append(f"{slug}/{rel}: DMS-Zeile ohne Dokumentdatum: {zeile}")
            continue
        dokumentdatum = datetime.strptime(datumstreffer.group(1), "%d.%m.%Y").date()
        if dokumentdatum > exportdatum:
            dms_id = zeile.split("|")[1].strip()
            fehler.append(
                f"{slug}/{rel}: {dms_id} vom {datumstreffer.group(1)} liegt "
                f"nach dem Export vom {exportdatum_text}"
            )

    return fehler


def pruefe_text(dateien: list[tuple[str, str]], frei: set[str], slug: str) -> list[str]:
    """Prueft eine Akte anhand von (relativer Pfad, Inhalt)-Paaren."""
    fehler: list[str] = []

    vertragsnummern: dict[str, set[str]] = defaultdict(set)
    beginne: dict[str, set[str]] = defaultdict(set)
    geburtsdaten: dict[str, set[str]] = defaultdict(set)
    namenlose: dict[str, set[str]] = defaultdict(set)

    for rel, text in dateien:
        fehler.extend(pruefe_dms_export(rel, text, slug))
        for m in VERTRAGSNR.finditer(text):
            vertragsnummern[m.group(0)].add(rel)
        for m in VERTRAGSBEGINN.finditer(text):
            beginne[m.group(1) or m.group(2)].add(rel)
        for zeile in text.splitlines():
            benannt, ohne_name = geburtsdaten_der_zeile(zeile)
            for name, datum in benannt:
                geburtsdaten[name].add(datum)
            for datum in ohne_name:
                namenlose[datum].add(rel)

    if "vertragsnummer" not in frei and len(vertragsnummern) > 1:
        detail = "; ".join(
            f"{nr} in {', '.join(sorted(orte))}"
            for nr, orte in sorted(vertragsnummern.items())
        )
        fehler.append(f"{slug}: mehrere Vertragsnummern ({detail})")

    if "vertragsbeginn" not in frei and len(beginne) > 1:
        detail = "; ".join(
            f"{d} in {', '.join(sorted(orte))}" for d, orte in sorted(beginne.items())
        )
        fehler.append(f"{slug}: mehrere Vertragsbeginne ({detail})")

    if "geburtsdatum" not in frei:
        for name, daten in sorted(geburtsdaten.items()):
            if len(daten) > 1:
                fehler.append(
                    f"{slug}: {name} hat mehrere Geburtsdaten ({', '.join(sorted(daten))})"
                )
        bekannte = {d for daten in geburtsdaten.values() for d in daten}
        if bekannte:
            for datum, orte in sorted(namenlose.items()):
                if datum not in bekannte:
                    fehler.append(
                        f"{slug}: namenloses Geburtsdatum {datum} in {', '.join(sorted(orte))} "
                        f"passt zu keiner benannten Person ({', '.join(sorted(bekannte))})"
                    )
        elif len(namenlose) > 1:
            detail = "; ".join(
                f"{datum} in {', '.join(sorted(orte))}"
                for datum, orte in sorted(namenlose.items())
            )
            fehler.append(f"{slug}: mehrere namenlose Geburtsdaten ({detail})")

    return fehler


def pruefe_akte(akte: Path) -> list[str]:
    frei = ERLAUBTE_KONFLIKTE.get(akte.name, set())
    dateien = [
        (str(f.relative_to(akte)), f.read_text(encoding="utf-8", errors="replace"))
        for f in akten_dateien(akte)
    ]
    return pruefe_text(dateien, frei, akte.name)


def selbsttest() -> int:
    """Eingebaute Fixtures fuer alle erfassten Formate."""
    ok = True

    def erwarte(
        name: str, dateien: list[tuple[str, str]], fehler_erwartet: bool
    ) -> None:
        nonlocal ok
        fehler = pruefe_text(dateien, set(), "fixture")
        if bool(fehler) != fehler_erwartet:
            ok = False
            print(f"  FEHLGESCHLAGEN: {name} -> {fehler or 'keine Fehler gefunden'}")
        else:
            print(f"  ok: {name}")

    erwarte(
        "konsistente Akte mit allen Formaten",
        [
            (
                "README.md",
                "| Mieter | Thomas Meier, geb. 14.03.1972 |\n| Vertragsbeginn | 01.08.2019 |",
            ),
            ("sap.md", "Mietbeginn     : 01.08.2019\nGeburtsdatum  : 14.03.1972"),
            (
                "vertrag.md",
                "**Mieter**: Herr Thomas Meier, geb. 14.03.1972\nMietverhältnis beginnt am 01.08.2019",
            ),
        ],
        False,
    )

    erwarte(
        "Konflikt im Doppelpunkt-Format Vertragsbeginn",
        [
            ("README.md", "- Vertragsbeginn: 01.10.2014"),
            ("vertrag.md", "Das Mietverhältnis beginnt am **01.10.2015**."),
        ],
        True,
    )

    erwarte(
        "namenloses SAP-Geburtsdatum widerspricht Vertrag",
        [
            ("sap.md", "Geburtsdatum  : 14.03.1972"),
            ("vertrag.md", "Herr Thomas Meier, geb. 15.03.1972"),
        ],
        True,
    )

    erwarte(
        "Tabellenform Geburtsdatum widerspricht Vertrag",
        [
            ("README.md", "| Geburtsdatum | 14.03.1972 |"),
            ("vertrag.md", "Herr Thomas Meier, geb. 15.03.1972"),
        ],
        True,
    )

    erwarte(
        "mehrere namenlose Geburtsdaten",
        [
            ("README.md", "| Geburtsdatum | 14.03.1972 |"),
            ("sap.md", "Geburtsdatum : 15.03.1972"),
        ],
        True,
    )

    erwarte(
        "invertierter Name und Geburtsname konsistent",
        [
            (
                "sap.md",
                "- Hauptmieter: Becker, Wolfgang, geb. 14.03.1962\n- Mitmieterin: Becker, Heike geb. Schubert, geb. 09.11.1964",
            ),
            (
                "vertrag.md",
                "**Herrn Wolfgang Becker**, geb. 14.03.1962\n**Frau Heike Becker**, geb. 09.11.1964",
            ),
        ],
        False,
    )

    erwarte(
        "invertierter Name mit abweichendem Datum",
        [
            ("sap.md", "- Hauptmieter: Becker, Wolfgang, geb. 14.03.1963"),
            ("vertrag.md", "**Herrn Wolfgang Becker**, geb. 14.03.1962"),
        ],
        True,
    )

    erwarte(
        "Kinder mit Jahresangabe stoeren nicht",
        [
            (
                "sap.md",
                "- Geboren: 22.07.1985\n- Familienstand: zwei Kinder (Jakub geb. 2014, Maja geb. 2018)",
            ),
            ("vertrag.md", "**Frau Aleksandra Kowalska**, geb. 22.07.1985"),
        ],
        False,
    )

    erwarte(
        "mehrere Vertragsnummern",
        [
            ("sap.md", "Vertrag WBI-MV-2021-01876"),
            ("vertrag.md", "Vertragsnummer: WBI-MV-2021-01877"),
        ],
        True,
    )

    erwarte(
        "DMS-Export mit passender Trefferzahl",
        [
            (
                "dms/export.md",
                "| Exportzeitpunkt | 21.07.2026, 08:16 Uhr |\n"
                "| Dokumente | 1 |\n"
                "| DMS-ID | Datum | Klasse |\n"
                "|---|---|---|\n"
                "| DW-731900 | 20.04.2021 | Vertrag |",
            )
        ],
        False,
    )

    erwarte(
        "DMS-Dokument nach Export",
        [
            (
                "dms/export.md",
                "| Exportzeitpunkt | 21.07.2026, 08:16 Uhr |\n"
                "| Dokumente | 1 |\n"
                "| DW-731900 | 22.07.2026 | Vertrag |",
            )
        ],
        True,
    )

    erwarte(
        "DMS-Trefferzahl widerspricht Dokumentzeilen",
        [
            (
                "dms/export.md",
                "| Exportzeitpunkt | 21.07.2026, 08:16 Uhr |\n"
                "| Dokumente | 2 |\n"
                "| DW-731900 | 20.04.2021 | Vertrag |",
            )
        ],
        True,
    )

    print("Selbsttest", "OK" if ok else "FEHLGESCHLAGEN")
    return 0 if ok else 1


def main() -> int:
    if "--selbsttest" in sys.argv:
        return selbsttest()

    fehler: list[str] = []
    geprueft = 0
    for akte in sorted(TESTAKTEN.iterdir()):
        if not akte.is_dir() or akte.name in SKIP_DIRS:
            continue
        geprueft += 1
        fehler.extend(pruefe_akte(akte))

    if fehler:
        print("validate-testakten-stammdaten FEHLER:")
        for f in fehler:
            print(f"  - {f}")
        return 1

    print(f"validate-testakten-stammdaten OK ({geprueft} Testakten)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
