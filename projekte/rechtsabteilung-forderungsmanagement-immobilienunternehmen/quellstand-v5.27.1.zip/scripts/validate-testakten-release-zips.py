#!/usr/bin/env python3
"""Validate release ZIPs for testakten before publishing.

The release builder intentionally strips README/download/meta files from
testakten ZIPs. This validator mirrors that export filter and verifies that the
single testakte ZIPs and the combined alle-testakten.zip contain exactly the
files that the working-dump contract promises.

Zusatzregel seit v1.8.0: Jede Testakte braucht außerdem ein eigenes
`testakte-<slug>-einzel-pdfs.zip`. Es enthält dieselben fachlichen
Aktenstücke wie der Arbeitsdump, aber ausschließlich als einzeln benannte
PDFs. Sämtliche Testakten-ZIPs sind flach und enthalten keine Unterordner.

Seit v5.15.0 liegt das Gesamt-PDF zusätzlich als direktes Release-Asset
`testakte-<slug>-gesamt.pdf` vor. Es muss bytegleich mit der getrackten
Gesamt-PDF-Quelle sein.

Seit v4.0.0 werden diese Einzel-PDFs zusätzlich nur noch im Sammelpaket
`alle-testakten-einzel-pdfs.zip` validiert.
"""

from __future__ import annotations

import hashlib
import io
import json
import re
import sys
import zipfile
from pathlib import Path
from pathlib import PurePosixPath
from typing import NoReturn

from pypdf import PdfReader

from testakte_file_filter import (
    TESTAKTEN_RELEASE_INDEX_SCHEMA,
    discover_testakten,
    include_in_working_dump,
    validate_testakte_source,
)
import testakte_realformate

REPO_ROOT = Path(__file__).resolve().parent.parent
TESTAKTEN = REPO_ROOT / "testakten"
SKIP_DIRS = {
    "formatvorlagen-paradebeispiele",
    "grosser-prompts",
}
FORBIDDEN_RELEASE_ASSETS = {
    "testakten-immobilien-forderungsmanagement.zip",
    "testakten-immobilien-forderungsmanagement-einzel-pdfs.zip",
}


def fail(message: str) -> NoReturn:
    print(f"validate-testakten-release-zips failed: {message}", file=sys.stderr)
    raise SystemExit(1)


def expected_entries(testakte_dir: Path, *, include_slug: bool = False) -> list[str]:
    entries: list[str] = []
    for path in sorted(
        testakte_dir.rglob("*"), key=lambda p: str(p.relative_to(testakte_dir)).lower()
    ):
        if include_in_working_dump(path, testakte_dir, include_gesamt_pdf=False):
            source_rel = path.relative_to(testakte_dir)
            rel = testakte_realformate.ziel_relpfad(source_rel)
            entries.append(
                testakte_realformate.flacher_exportname(
                    source_rel,
                    ziel_name=rel.name,
                    akten_slug=testakte_dir.name if include_slug else None,
                )
            )
    return entries


def expected_individual_pdf_entries(
    testakte_dir: Path, *, include_slug: bool = False
) -> list[str]:
    entries: list[str] = []
    for path in sorted(
        testakte_dir.rglob("*"), key=lambda p: str(p.relative_to(testakte_dir)).lower()
    ):
        if include_in_working_dump(path, testakte_dir, include_gesamt_pdf=False):
            source_rel = path.relative_to(testakte_dir)
            entries.append(
                testakte_realformate.flacher_exportname(
                    source_rel,
                    ziel_name=source_rel.with_suffix(".pdf").name,
                    akten_slug=testakte_dir.name if include_slug else None,
                )
            )
    return entries


def zip_entries(zip_path: Path) -> list[str]:
    if not zip_path.exists():
        fail(f"{zip_path}: missing ZIP")
    if zip_path.stat().st_size <= 0:
        fail(f"{zip_path}: empty ZIP")
    try:
        with zipfile.ZipFile(zip_path) as archive:
            raw_names = archive.namelist()
            normalized: list[str] = []
            seen: set[str] = set()
            seen_casefold: set[str] = set()
            for raw_name in raw_names:
                if "\\" in raw_name or "\x00" in raw_name:
                    fail(f"{zip_path}: unsafe ZIP member name {raw_name!r}")
                member = PurePosixPath(raw_name)
                if member.is_absolute() or ".." in member.parts:
                    fail(f"{zip_path}: unsafe ZIP member path {raw_name!r}")
                if not raw_name.endswith("/") and len(member.parts) != 1:
                    fail(f"{zip_path}: ZIP-Unterordner verboten: {raw_name!r}")
                name = member.as_posix()
                if name in seen:
                    fail(f"{zip_path}: duplicate ZIP member {name}")
                seen.add(name)
                folded = name.casefold()
                if folded in seen_casefold:
                    fail(
                        f"{zip_path}: Dateinamen kollidieren ohne "
                        f"Groß-/Kleinschreibung: {name}"
                    )
                seen_casefold.add(folded)
                if not raw_name.endswith("/"):
                    if not name.isascii():
                        fail(f"{zip_path}: nicht-ASCII-Dateiname: {name}")
                    normalized.append(name)
            bad = archive.testzip()
            if bad is not None:
                fail(f"{zip_path}: corrupt member {bad}")
            return sorted(normalized)
    except (OSError, zipfile.BadZipFile) as exc:
        fail(f"{zip_path}: invalid ZIP: {exc}")


def assert_same(label: str, expected: list[str], actual: list[str]) -> None:
    expected_set = set(expected)
    actual_set = set(actual)
    missing = sorted(expected_set - actual_set)
    extra = sorted(actual_set - expected_set)
    if missing or extra:
        details = []
        if missing:
            details.append(f"missing={missing[:10]}")
        if extra:
            details.append(f"extra={extra[:10]}")
        fail(f"{label}: entry mismatch ({'; '.join(details)})")
    if len(actual) != len(actual_set):
        fail(f"{label}: duplicate ZIP entries detected")


def assert_streamlined_asset_names(dist: Path) -> None:
    if not dist.exists():
        fail(f"{dist}: missing dist directory")
    present = {path.name for path in dist.iterdir() if path.is_file()}
    forbidden = sorted(present & FORBIDDEN_RELEASE_ASSETS)
    if forbidden:
        fail(f"{dist}: obsolete duplicate release assets present: {forbidden}")


def assert_converter_regressions() -> None:
    if (
        testakte_realformate.ziel_suffix(
            "aktennotiz-02-hausverwaltung-schluessel-und-jobcenter"
        )
        != ".docx"
    ):
        fail("Aktennotiz mit Jobcenter-Bezug wird nicht als DOCX geroutet")
    ascii_name = testakte_realformate.flacher_exportname(
        Path("aktennotiz/aktennotiz-01-mieterhöhungsprüfung.md"),
        ziel_name="aktennotiz-01-mieterhöhungsprüfung.docx",
    )
    expected_ascii = "mieterh" + "oe" + "hungspr" + "ue" + "fung"
    if not ascii_name.isascii() or expected_ascii not in ascii_name:
        fail(f"Umlaut-Dateiname wird nicht sicher transliteriert: {ascii_name}")
    document_date = testakte_realformate._erstes_datum(
        "Mieter: geb. 14.03.1972\nBerlin, den 17.07.2019\n"
    )
    if document_date.date().isoformat() != "2019-07-17":
        fail(
            "OOXML-Dokumentdatum übernimmt ein Geburtsdatum statt des "
            "Unterschriftsdatums"
        )


def assert_office_package(zip_path: Path, name: str, data: bytes, suffix: str) -> None:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as office:
            bad = office.testzip()
            names = set(office.namelist())
    except zipfile.BadZipFile as exc:
        fail(f"{zip_path.name}: {name} ist kein gültiges Office-Paket: {exc}")
    if bad is not None:
        fail(f"{zip_path.name}: {name} enthält defekten Office-Eintrag {bad}")
    required = {"[Content_Types].xml"}
    if suffix == ".docx":
        required.update({"word/document.xml", "word/styles.xml"})
    else:
        required.update(
            {"xl/workbook.xml", "xl/worksheets/sheet1.xml", "xl/styles.xml"}
        )
    missing = sorted(required - names)
    if missing:
        fail(f"{zip_path.name}: {name} fehlen Office-Kernbestandteile {missing}")


def assert_pdf_document(zip_path: Path, name: str, data: bytes) -> None:
    try:
        reader = PdfReader(io.BytesIO(data), strict=False)
        if reader.is_encrypted:
            fail(f"{zip_path.name}: {name} ist verschlüsselt")
        if len(reader.pages) < 1:
            fail(f"{zip_path.name}: {name} enthält keine PDF-Seite")
        extracted: list[str] = []
        for page in reader.pages:
            _ = page.mediabox
            extracted.append(page.extract_text() or "")
        text = "\n".join(extracted)
        if "Arbeitsakte: Einzel-PDF:" in text:
            fail(f"{zip_path.name}: {name} enthält veralteten internen Pfad-Footer")
        if re.search(r"(?m)^Quelle:\s+\S+\.md\s*$", text):
            fail(f"{zip_path.name}: {name} enthält veralteten Markdown-Quellpfad")
    except Exception as exc:
        fail(f"{zip_path.name}: {name} ist kein vollständig lesbares PDF: {exc}")


def assert_gesamt_pdf_asset(dist: Path, testakte_dir: Path) -> None:
    source = testakte_dir / "gesamt-pdf" / f"{testakte_dir.name}_gesamt.pdf"
    asset = dist / f"testakte-{testakte_dir.name}-gesamt.pdf"
    if not asset.is_file():
        fail(f"{asset}: direktes Gesamt-PDF-Asset fehlt")
    data = asset.read_bytes()
    assert_pdf_document(asset, asset.name, data)
    if data != source.read_bytes():
        fail(f"{asset.name}: unterscheidet sich vom getrackten Gesamt-PDF")


def office_signature(data: bytes, suffix: str) -> dict[str, bytes]:
    with zipfile.ZipFile(io.BytesIO(data)) as office:
        names = ["docProps/core.xml"]
        if suffix == ".docx":
            names.extend(["word/document.xml", "word/styles.xml"])
        else:
            names.extend(
                [
                    "xl/workbook.xml",
                    "xl/worksheets/sheet1.xml",
                    "xl/styles.xml",
                ]
            )
        return {name: office.read(name) for name in names}


def pdf_signature(data: bytes) -> tuple[tuple[float, float, str, str], ...]:
    reader = PdfReader(io.BytesIO(data), strict=False)
    signature: list[tuple[float, float, str, str]] = []
    for page in reader.pages:
        contents = page.get_contents()
        stream = contents.get_data() if contents is not None else b""
        signature.append(
            (
                float(page.mediabox.width),
                float(page.mediabox.height),
                (page.extract_text() or "").strip(),
                hashlib.sha256(stream).hexdigest(),
            )
        )
    return tuple(signature)


def expected_working_sources(
    testakte_dirs: list[Path], *, include_slug: bool
) -> dict[str, tuple[Path, Path]]:
    sources: dict[str, tuple[Path, Path]] = {}
    source_names_casefold: set[str] = set()
    for testakte_dir in testakte_dirs:
        for path in sorted(
            testakte_dir.rglob("*"),
            key=lambda item: str(item.relative_to(testakte_dir)).lower(),
        ):
            if not include_in_working_dump(
                path, testakte_dir, include_gesamt_pdf=False
            ):
                continue
            source_rel = path.relative_to(testakte_dir)
            relative = testakte_realformate.ziel_relpfad(source_rel)
            archive_name = testakte_realformate.flacher_exportname(
                source_rel,
                ziel_name=relative.name,
                akten_slug=testakte_dir.name if include_slug else None,
            )
            folded = archive_name.casefold()
            if folded in source_names_casefold:
                fail(f"doppelte Arbeitsdatei-Zielbezeichnung: {archive_name}")
            sources[archive_name] = (testakte_dir, path)
            source_names_casefold.add(folded)
    return sources


def assert_source_fidelity(
    zip_path: Path,
    name: str,
    actual: bytes,
    testakte_dir: Path,
    source: Path,
    conversion_cache: dict[Path, bytes],
) -> None:
    suffix = Path(name).suffix.lower()
    if source.suffix.lower() != ".md":
        expected = source.read_bytes()
        if actual != expected:
            fail(f"{zip_path.name}: {name} unterscheidet sich von der Originaldatei")
        return

    expected = conversion_cache.get(source)
    if expected is None:
        _, expected = testakte_realformate.konvertiere_md(source, testakte_dir.name)
        conversion_cache[source] = expected
    if suffix in {".docx", ".xlsx"}:
        if office_signature(actual, suffix) != office_signature(expected, suffix):
            fail(
                f"{zip_path.name}: {name} Office-Inhalt unterscheidet sich von der Markdown-Quelle"
            )
    elif suffix == ".pdf":
        if pdf_signature(actual) != pdf_signature(expected):
            fail(
                f"{zip_path.name}: {name} PDF-Inhalt unterscheidet sich von der Markdown-Quelle"
            )
    else:
        fail(f"{zip_path.name}: unerwartetes Arbeitsformat für {name}")


def assert_working_zip_formats(
    zip_path: Path,
    testakte_dirs: list[Path],
    conversion_cache: dict[Path, bytes],
    *,
    include_slug: bool,
) -> None:
    """Arbeits-ZIPs müssen den lebensechten Formate-Mix enthalten:
    kein Markdown, keine Unterordner und ausschließlich DOCX, XLSX oder PDF
    (verbindliche Regel, siehe testakten/README.md)."""
    sources = expected_working_sources(testakte_dirs, include_slug=include_slug)
    with zipfile.ZipFile(zip_path) as archive:
        for name in archive.namelist():
            if name.endswith("/"):
                continue
            suffix = Path(name).suffix.lower()
            if suffix == ".md":
                fail(f"{zip_path.name}: Markdown im Arbeits-ZIP verboten: {name}")
            if suffix not in {".docx", ".xlsx", ".pdf"}:
                fail(
                    f"{zip_path.name}: unzulässiges Arbeitsformat {suffix or '[ohne Endung]'}: {name}"
                )
            data = archive.read(name)
            if not data:
                fail(f"{zip_path.name}: leere Arbeitsdatei {name}")
            if suffix in {".docx", ".xlsx"}:
                assert_office_package(zip_path, name, data, suffix)
            elif suffix == ".pdf":
                assert_pdf_document(zip_path, name, data)
            if name not in sources:
                fail(f"{zip_path.name}: keine Quelldatei für {name}")
            testakte_dir, source = sources[name]
            assert_source_fidelity(
                zip_path,
                name,
                data,
                testakte_dir,
                source,
                conversion_cache,
            )


def assert_pdf_zip(zip_path: Path, expected: list[str]) -> None:
    actual = zip_entries(zip_path)
    assert_same(zip_path.name, expected, actual)
    if not actual:
        fail(f"{zip_path.name}: Einzel-PDF-ZIP has no entries")
    with zipfile.ZipFile(zip_path) as archive:
        for name in actual:
            if not name.endswith(".pdf"):
                fail(f"{zip_path.name}: non-PDF entry {name}")
            assert_pdf_document(zip_path, name, archive.read(name))


def assert_release_index(dist: Path, dirs: list[Path], expected_pdf_total: int) -> None:
    index_path = dist / "testakten-release-index.json"
    if not index_path.exists():
        fail(f"{index_path}: missing release asset index")
    try:
        index = json.loads(index_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"{index_path}: invalid JSON: {exc}")
    if index.get("schema") != TESTAKTEN_RELEASE_INDEX_SCHEMA:
        fail(f"{index_path}: unexpected schema {index.get('schema')!r}")
    testakten = index.get("testakten")
    if not isinstance(testakten, list) or len(testakten) != len(dirs):
        fail(f"{index_path}: expected {len(dirs)} testakten entries")
    by_slug = {
        entry.get("slug"): entry for entry in testakten if isinstance(entry, dict)
    }
    if set(by_slug) != {d.name for d in dirs}:
        fail(f"{index_path}: testakten slugs mismatch")
    pdf_sum = 0
    for d in dirs:
        entry = by_slug[d.name]
        expected_working = len(expected_entries(d))
        expected_individual = len(expected_individual_pdf_entries(d))
        if entry.get("working_zip") != f"testakte-{d.name}.zip":
            fail(f"{index_path}: {d.name} working_zip mismatch")
        if entry.get("gesamt_pdf_asset") != f"testakte-{d.name}-gesamt.pdf":
            fail(f"{index_path}: {d.name} gesamt_pdf_asset mismatch")
        if entry.get("individual_pdfs_zip") != f"testakte-{d.name}-einzel-pdfs.zip":
            fail(f"{index_path}: {d.name} individual_pdfs_zip mismatch")
        expected_gesamt_pdf = f"{d.name}/gesamt-pdf/{d.name}_gesamt.pdf"
        if entry.get("gesamt_pdf") != expected_gesamt_pdf:
            fail(f"{index_path}: {d.name} gesamt_pdf mismatch")
        if entry.get("working_files") != expected_working:
            fail(f"{index_path}: {d.name} working_files mismatch")
        if entry.get("individual_pdfs") != expected_individual:
            fail(f"{index_path}: {d.name} individual_pdfs mismatch")
        pdf_sum += int(entry.get("individual_pdfs", 0))
    if pdf_sum != expected_pdf_total:
        fail(f"{index_path}: individual PDF total mismatch")
    expected_download_forms = {
        "working_zip",
        "gesamt_pdf",
        "individual_pdfs_zip",
        "combined_working_zip",
        "combined_individual_pdfs_zip",
    }
    download_forms = index.get("download_forms")
    if (
        not isinstance(download_forms, dict)
        or set(download_forms) != expected_download_forms
    ):
        fail(f"{index_path}: download_forms mismatch")
    if any(
        not isinstance(value, str) or not value.strip()
        for value in download_forms.values()
    ):
        fail(f"{index_path}: download_forms descriptions must be non-empty strings")

    combined_assets = index.get("combined_assets", {})
    expected_combined_assets = {
        "working_zip": "alle-testakten.zip",
        "individual_pdfs_zip": "alle-testakten-einzel-pdfs.zip",
    }
    if combined_assets != expected_combined_assets:
        fail(f"{index_path}: combined_assets mismatch")
    asset_names: list[str] = []
    for asset in (
        "alle-testakten.zip",
        "alle-testakten-einzel-pdfs.zip",
    ):
        if asset not in combined_assets.values():
            fail(f"{index_path}: combined asset {asset} missing")
    asset_names.extend(str(value) for value in combined_assets.values())
    for entry in testakten:
        if isinstance(entry, dict):
            asset_names.append(str(entry.get("working_zip", "")))
            asset_names.append(str(entry.get("gesamt_pdf_asset", "")))
            asset_names.append(str(entry.get("individual_pdfs_zip", "")))
    forbidden = sorted(set(asset_names) & FORBIDDEN_RELEASE_ASSETS)
    if forbidden:
        fail(f"{index_path}: obsolete duplicate release assets listed: {forbidden}")
    non_empty_assets = [name for name in asset_names if name]
    if len(non_empty_assets) != len(set(non_empty_assets)):
        fail(f"{index_path}: duplicate asset names in release index")
    missing_assets = sorted(
        name for name in non_empty_assets if not (dist / name).is_file()
    )
    if missing_assets:
        fail(f"{index_path}: listed release assets missing: {missing_assets}")


def main() -> None:
    dist = Path(sys.argv[1]) if len(sys.argv) > 1 else REPO_ROOT / "dist"
    assert_converter_regressions()
    assert_streamlined_asset_names(dist)
    try:
        dirs = discover_testakten(TESTAKTEN, SKIP_DIRS)
    except ValueError as exc:
        fail(str(exc))
    if not dirs:
        fail("no testakten directories found")
    for testakte_dir in dirs:
        try:
            validate_testakte_source(testakte_dir)
        except ValueError as exc:
            fail(str(exc))

    combined_expected: list[str] = []
    combined_individual_pdf_expected: list[str] = []
    empty_dirs: list[str] = []
    gesamt_pdf_count = 0
    individual_pdf_count = 0
    conversion_cache: dict[Path, bytes] = {}

    for testakte_dir in dirs:
        entries = expected_entries(testakte_dir)
        individual_entries = expected_individual_pdf_entries(testakte_dir)
        if not entries:
            empty_dirs.append(testakte_dir.name)
            continue
        if not individual_entries:
            fail(f"{testakte_dir.name}: no individual PDF source files")
        gesamt_pdf = testakte_dir / "gesamt-pdf" / f"{testakte_dir.name}_gesamt.pdf"
        if not gesamt_pdf.is_file():
            fail(f"{testakte_dir.name}: verbindliches Gesamt-PDF fehlt")
        assert_gesamt_pdf_asset(dist, testakte_dir)
        gesamt_pdf_count += 1
        combined_expected.extend(expected_entries(testakte_dir, include_slug=True))
        combined_individual_pdf_expected.extend(
            expected_individual_pdf_entries(testakte_dir, include_slug=True)
        )
        actual = zip_entries(dist / f"testakte-{testakte_dir.name}.zip")
        assert_same(f"testakte-{testakte_dir.name}.zip", entries, actual)
        assert_working_zip_formats(
            dist / f"testakte-{testakte_dir.name}.zip",
            [testakte_dir],
            conversion_cache,
            include_slug=False,
        )
        assert_pdf_zip(
            dist / f"testakte-{testakte_dir.name}-einzel-pdfs.zip", individual_entries
        )
        individual_pdf_count += len(individual_entries)

    if empty_dirs:
        fail(f"testakten without exportable files: {empty_dirs[:20]}")
    if gesamt_pdf_count != len(dirs):
        fail(f"expected {len(dirs)} Gesamt-PDFs, found {gesamt_pdf_count}")

    combined_actual = zip_entries(dist / "alle-testakten.zip")
    assert_same("alle-testakten.zip", combined_expected, combined_actual)
    assert_working_zip_formats(
        dist / "alle-testakten.zip",
        dirs,
        conversion_cache,
        include_slug=True,
    )

    assert_pdf_zip(
        dist / "alle-testakten-einzel-pdfs.zip", combined_individual_pdf_expected
    )
    assert_release_index(dist, dirs, individual_pdf_count)

    print(
        "validate-testakten-release-zips OK "
        f"({len(dirs)} Arbeits-ZIPs, {len(dirs)} Gesamt-PDF-Assets, "
        f"{len(dirs)} Einzel-PDF-ZIPs, 1 Sammel-Einzel-PDF-ZIP, "
        f"{len(combined_expected)} files, "
        f"{gesamt_pdf_count} Gesamt-PDFs, {individual_pdf_count} Einzel-PDFs)"
    )


if __name__ == "__main__":
    main()
