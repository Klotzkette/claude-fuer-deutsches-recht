#!/usr/bin/env python3
"""Verify GitHub Release assets after upload.

The release workflow uploads several dozen assets. A green upload command is not
quite enough: GitHub may throttle, replace assets slowly, or leave stale assets
on an existing release. This script is meant to run in the same job that built
the files: it polls the Release API until every expected local asset exists
remotely with uploaded state, matching size and matching sha256 digest.

If a different runner later rebuilds and replaces ZIPs, byte digests can differ
although the logical content is valid. For post-workflow manual checks, download
the published assets first and run validate-testakten-release-zips.py plus
validate-release-zips.py against that download directory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


ASSET_NAMES = {
    "marketplace.json",
    "testakten-release-index.json",
    "release-katalog.md",
    "checksums-sha256.txt",
}
GH_API_TIMEOUT_SECONDS = 60
MAX_ASSET_PAGES = 100


def fail(message: str) -> None:
    print(f"validate-release-assets failed: {message}", file=sys.stderr)
    raise SystemExit(1)


def run_gh_api(resource: str) -> Any:
    try:
        proc = subprocess.run(
            ["gh", "api", resource],
            check=False,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=GH_API_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        fail(f"gh api {resource!r} exceeded {GH_API_TIMEOUT_SECONDS} seconds")
    if proc.returncode != 0:
        fail(f"gh api {resource!r} failed: {proc.stderr.strip()}")
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        fail(f"gh api {resource!r} returned invalid JSON: {exc}")


def expected_assets(dist: Path) -> dict[str, dict[str, Any]]:
    expected: dict[str, dict[str, Any]] = {}
    for path in sorted(dist.iterdir(), key=lambda p: p.name):
        if not path.is_file():
            continue
        is_prompt_skill = path.name.endswith("prompt-skill.md")
        is_testakte_pdf = path.name.startswith("testakte-") and path.name.endswith(
            "-gesamt.pdf"
        )
        if (
            path.suffix != ".zip"
            and path.name not in ASSET_NAMES
            and not is_prompt_skill
            and not is_testakte_pdf
        ):
            continue
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                size += len(chunk)
                digest.update(chunk)
        expected[path.name] = {
            "size": size,
            "digest": "sha256:" + digest.hexdigest(),
        }
    if not expected:
        fail(f"{dist}: no release assets found")
    return expected


def fetch_assets(repo: str, tag: str) -> dict[str, dict[str, Any]]:
    release = run_gh_api(f"repos/{repo}/releases/tags/{tag}")
    release_id = release.get("id")
    if not release_id:
        fail(f"{repo}@{tag}: release id missing")

    assets: dict[str, dict[str, Any]] = {}
    page = 1
    while True:
        if page > MAX_ASSET_PAGES:
            fail(
                f"{repo}@{tag}: more than {MAX_ASSET_PAGES * 100} release "
                "assets; pagination aborted"
            )
        batch = run_gh_api(
            f"repos/{repo}/releases/{release_id}/assets?per_page=100&page={page}"
        )
        if not isinstance(batch, list):
            fail(f"{repo}@{tag}: assets response page {page} is not a list")
        for asset in batch:
            name = asset.get("name")
            if not name:
                fail(f"{repo}@{tag}: asset without name on page {page}")
            if name in assets:
                fail(f"{repo}@{tag}: duplicate asset name {name}")
            assets[name] = asset
        if len(batch) < 100:
            break
        page += 1
    return assets


def diff_assets(
    expected: dict[str, dict[str, Any]], actual: dict[str, dict[str, Any]]
) -> list[str]:
    problems: list[str] = []
    expected_names = set(expected)
    actual_names = set(actual)

    missing = sorted(expected_names - actual_names)
    extra = sorted(actual_names - expected_names)
    if missing:
        problems.append(f"missing assets: {missing[:20]}")
    if extra:
        problems.append(f"unexpected stale assets: {extra[:20]}")

    for name in sorted(expected_names & actual_names):
        asset = actual[name]
        want = expected[name]
        if asset.get("state") != "uploaded":
            problems.append(f"{name}: state={asset.get('state')!r}")
        if int(asset.get("size") or 0) != int(want["size"]):
            problems.append(
                f"{name}: size remote={asset.get('size')} local={want['size']}"
            )
        remote_digest = asset.get("digest")
        if remote_digest != want["digest"]:
            problems.append(
                f"{name}: digest remote={remote_digest!r} local={want['digest']!r}"
            )
    return problems


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dist", type=Path)
    parser.add_argument("tag")
    parser.add_argument("--repo", default=os.environ.get("GITHUB_REPOSITORY"))
    parser.add_argument("--timeout-seconds", type=int, default=900)
    parser.add_argument("--poll-seconds", type=int, default=10)
    args = parser.parse_args()

    if not args.repo:
        fail("--repo or GITHUB_REPOSITORY is required")
    if args.timeout_seconds <= 0:
        fail("--timeout-seconds must be positive")
    if args.poll_seconds <= 0:
        fail("--poll-seconds must be positive")
    if args.poll_seconds > args.timeout_seconds:
        fail("--poll-seconds must not exceed --timeout-seconds")

    marketplace_path = args.dist / "marketplace.json"
    if not marketplace_path.is_file():
        fail(f"{marketplace_path}: missing marketplace release asset")
    marketplace = json.loads(marketplace_path.read_text(encoding="utf-8"))
    expected_tag = f"v{marketplace.get('version', '')}"
    if args.tag != expected_tag:
        fail(
            f"release tag {args.tag!r} does not match marketplace version {expected_tag!r}"
        )

    expected = expected_assets(args.dist)
    deadline = time.monotonic() + args.timeout_seconds
    last_problems: list[str] = []

    while True:
        actual = fetch_assets(args.repo, args.tag)
        last_problems = diff_assets(expected, actual)
        if not last_problems:
            print(
                f"validate-release-assets OK ({len(expected)} assets verified on {args.repo}@{args.tag})"
            )
            return
        if time.monotonic() >= deadline:
            break
        print(
            f"Waiting for release assets ({len(last_problems)} issue(s)); "
            f"first issue: {last_problems[0]}",
            flush=True,
        )
        time.sleep(args.poll_seconds)

    for problem in last_problems[:50]:
        print(problem, file=sys.stderr)
    fail(f"{len(last_problems)} release asset problem(s) after polling")


if __name__ == "__main__":
    main()
