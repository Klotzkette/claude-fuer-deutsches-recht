#!/usr/bin/env python3
"""Baut für jeden Marketplace-Eintrag ein flaches Plugin-ZIP."""

from __future__ import annotations

import json
import shutil
import sys
import zipfile
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
MARKETPLACE = REPO_ROOT / ".claude-plugin" / "marketplace.json"


def plugin_files(plugin_root: Path) -> list[Path]:
    files: list[Path] = []
    for path in plugin_root.rglob("*"):
        if path.is_symlink():
            raise SystemExit(
                f"Symlink im Plugin ist für Release-ZIPs unzulässig: {path}"
            )
        if not path.is_file():
            continue
        relative = path.relative_to(plugin_root)
        if (
            path.name == ".DS_Store"
            or "__pycache__" in relative.parts
            or path.suffix == ".pyc"
            or relative.as_posix() == "CLAUDE.md"
        ):
            continue
        files.append(path)
    files.sort(key=lambda item: item.relative_to(plugin_root).as_posix())
    folded: dict[str, Path] = {}
    for path in files:
        relative = path.relative_to(plugin_root).as_posix()
        key = relative.casefold()
        if key in folded:
            raise SystemExit(
                "Plugin-Dateien kollidieren ohne Beachtung der Großschreibung: "
                f"{folded[key]} und {path}"
            )
        folded[key] = path
    return files


def build_plugin_zip(output_dir: Path, plugin: dict[str, object]) -> Path:
    name = str(plugin["name"])
    source = str(plugin["source"])
    plugin_root = (REPO_ROOT / source).resolve()
    if not plugin_root.is_relative_to(REPO_ROOT) or plugin_root.name != name:
        raise SystemExit(f"Unsichere oder widersprüchliche Plugin-Quelle: {source}")
    if output_dir == plugin_root or output_dir.is_relative_to(plugin_root):
        raise SystemExit(f"Ausgabeordner darf nicht im Plugin liegen: {output_dir}")
    manifest = plugin_root / ".claude-plugin" / "plugin.json"
    if not manifest.is_file():
        raise SystemExit(f"Plugin-Manifest fehlt: {manifest}")
    manifest_data = json.loads(manifest.read_text(encoding="utf-8"))
    if manifest_data.get("name") != name:
        raise SystemExit(f"Plugin-Manifestname passt nicht zum Marketplace: {name}")
    if manifest_data.get("version") != plugin.get("version"):
        raise SystemExit(f"Plugin-Version passt nicht zum Marketplace: {name}")

    output = output_dir / f"{name}.zip"
    temporary = output.with_suffix(".zip.tmp")
    files = plugin_files(plugin_root)
    temporary.unlink(missing_ok=True)
    try:
        with zipfile.ZipFile(
            temporary, "w", compression=zipfile.ZIP_DEFLATED
        ) as archive:
            for path in files:
                archive.write(path, path.relative_to(plugin_root).as_posix())
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    print(f"Baue {output.name}: {len(files)} Dateien")
    return output


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: build-plugin-zips.py <output-dir>")
    output_dir = Path(sys.argv[1]).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    marketplace = json.loads(MARKETPLACE.read_text(encoding="utf-8"))
    plugins = marketplace.get("plugins")
    if not isinstance(plugins, list) or not plugins:
        raise SystemExit("Marketplace enthält keine Plugins")
    seen_names: set[str] = set()
    for plugin in plugins:
        if not isinstance(plugin, dict):
            raise SystemExit("Ungültiger Plugin-Eintrag im Marketplace")
        name = plugin.get("name")
        if not isinstance(name, str) or not name:
            raise SystemExit("Marketplace-Plugin ohne gültigen Namen")
        if name in seen_names:
            raise SystemExit(f"Marketplace-Plugin doppelt: {name}")
        seen_names.add(name)
        build_plugin_zip(output_dir, plugin)
    shutil.copy2(MARKETPLACE, output_dir / "marketplace.json")


if __name__ == "__main__":
    main()
