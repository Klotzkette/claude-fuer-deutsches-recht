#!/usr/bin/env python3
"""Synchronisiert die Repo-Root-Referenzen in die Plugin-Spiegel.

Hintergrund: Das Immobilien-Plugin verweist in mehreren Skills per relativem
Pfad auf references/*. Diese Dateien müssen im Plugin-ZIP enthalten sein,
sonst funktionieren die Quellen- und Zitierleitplanken nach Installation nicht.

Aufruf: python3 scripts/sync-references.py
Exit 0 wenn nichts zu tun war oder erfolgreich synchronisiert.
Exit 1 wenn Quelldateien fehlen.
"""

from __future__ import annotations
import shutil
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent

ROOT_REFERENCE_FILES = [
    "100-punkte-bediencheck.md",
    "bedienfuehrung-workflows.md",
    "erv-dokumentenproduktion.md",
    "gepruefte-bgh-anker-mietrecht.md",
    "leitentscheidungen-anker.md",
    "methodik-buergerliches-recht.md",
    "quellenhygiene.md",
    "rechtsstand-2026-verfahren-vollstreckung.md",
    "rechtsprechungsradar-mietrecht-2021-2026.md",
    "schriftsatz-und-argumentationsstandard.md",
    "schnittstellenprofile.md",
    "zitierweise.md",
]

PLUGIN_REFERENCE_DIRS = [
    REPO / "forderungsmanagement-immobilien" / "references",
]

PAIRS = [
    (REPO / "references" / file_name, plugin_references / file_name)
    for plugin_references in PLUGIN_REFERENCE_DIRS
    for file_name in ROOT_REFERENCE_FILES
]


def main() -> int:
    changed = 0
    for src, dst in PAIRS:
        if not src.exists():
            print(f"FEHLER: Quelldatei fehlt: {src}", file=sys.stderr)
            return 1
        if not dst.parent.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists() or src.read_bytes() != dst.read_bytes():
            shutil.copy2(src, dst)
            print(f"sync: {src.relative_to(REPO)} -> {dst.relative_to(REPO)}")
            changed += 1
        else:
            print(f"ok:   {dst.relative_to(REPO)} ist aktuell")
    if changed == 0:
        print("Alle Plugin-Spiegel sind aktuell. Nichts zu tun.")
    else:
        print(f"Synchronisiert: {changed} Datei(en).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
