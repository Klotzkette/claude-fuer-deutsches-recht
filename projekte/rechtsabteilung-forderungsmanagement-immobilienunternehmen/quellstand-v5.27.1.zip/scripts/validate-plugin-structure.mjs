#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const textExt = new Set(['.md', '.json', '.yaml', '.yml', '.py', '.sh']);
const errors = [];
const SLUG_RE = /^[a-z0-9-]{1,64}$/;
const COMMA_NUMBER_RE = /\d\s*,\s*\d/;
const FORBIDDEN_SYMBOL_RE = /[\u00a7\u2190-\u21ff\u2600-\u27bf\p{Extended_Pictographic}]/u;
const FORBIDDEN_WEB_WORD_RE = new RegExp(`\\b(${[
  'sc' + 'rape',
  'sc' + 'raping',
  'cr' + 'awl',
  'cr' + 'awling',
].join('|')})\\b`, 'i');
const REQUIRED_PLUGIN_REFERENCES = new Map([
  ['forderungsmanagement-immobilien', [
    'references/erv-dokumentenproduktion.md',
    'references/gepruefte-bgh-anker-mietrecht.md',
    'references/leitentscheidungen-anker.md',
    'references/methodik-buergerliches-recht.md',
    'references/quellenhygiene.md',
    'references/rechtsstand-2026-verfahren-vollstreckung.md',
    'references/rechtsprechungsradar-mietrecht-2021-2026.md',
    'references/schriftsatz-und-argumentationsstandard.md',
    'references/zitierweise.md',
  ]],
  ['schriftsatzwerkstatt-bea', [
    'references/100-punkte-fehlerkatalog.md',
    'references/dateinamen-und-manifest.md',
    'references/erv-versandstandard.md',
    'references/inhaltstreue-und-renderabgleich.md',
  ]],
]);

function rel(file) {
  return path.relative(root, file).replaceAll(path.sep, '/');
}

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

function exists(file) {
  return fs.existsSync(file);
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function stripEnclosingQuotes(value) {
  if (value.length >= 2 && ((value[0] === '"' && value.at(-1) === '"') || (value[0] === "'" && value.at(-1) === "'"))) {
    return value.slice(1, -1);
  }
  return value;
}

function checkSlug(file, label, value) {
  if (typeof value !== 'string' || !SLUG_RE.test(value)) {
    errors.push(`${file}: ${label} '${value}' must match [a-z0-9-] and be at most 64 chars`);
  }
}

function checkDescription(file, label, value, maxLength) {
  if (typeof value !== 'string') {
    errors.push(`${file}: ${label} must be a string`);
    return;
  }
  if (value.length === 0) {
    errors.push(`${file}: ${label} must not be empty`);
  }
  if (value.length > maxLength) {
    errors.push(`${file}: ${label} exceeds ${maxLength} chars (${value.length})`);
  }
  if (COMMA_NUMBER_RE.test(value)) {
    errors.push(`${file}: ${label} darf keine Zahl-Komma-Zahl-Sequenz enthalten`);
  }
  if (/[<>]/.test(value)) {
    errors.push(`${file}: ${label} contains forbidden angle brackets`);
  }
  if (value.includes('"')) {
    errors.push(`${file}: ${label} contains forbidden double quotes`);
  }
  if (FORBIDDEN_SYMBOL_RE.test(value)) {
    errors.push(`${file}: ${label} contains forbidden symbol or emoji`);
  }
  if (FORBIDDEN_WEB_WORD_RE.test(value)) {
    errors.push(`${file}: ${label} enthält verbotenen Web-Auslese-Begriff`);
  }
}

function walk(dir, predicate, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === '.git') continue;
    if (entry.name === 'dist') continue;
    if (entry.name === 'node_modules') continue;
    if (entry.name === '__pycache__') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, predicate, out);
    else if (!predicate || predicate(full)) out.push(full);
  }
  return out;
}

function parseJson(file) {
  try {
    return JSON.parse(read(file));
  } catch (err) {
    errors.push(`${rel(file)}: invalid JSON: ${err.message}`);
    return null;
  }
}

function parseFrontmatter(file) {
  const text = read(file);
  const match = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n/);
  if (!match) {
    errors.push(`${rel(file)}: missing YAML frontmatter`);
    return null;
  }
  return match[1];
}

function topLevelField(frontmatter, field) {
  return new RegExp(`^${field}\\s*:`, 'm').test(frontmatter);
}

function checkMarketplace() {
  const marketplacePath = path.join(root, '.claude-plugin', 'marketplace.json');
  const marketplace = parseJson(marketplacePath);
  if (!marketplace) return;
  if (!Array.isArray(marketplace.plugins) || marketplace.plugins.length === 0) {
    errors.push('.claude-plugin/marketplace.json: plugins must be a non-empty array');
    return;
  }
  if (typeof marketplace.description === 'string') {
    checkDescription('.claude-plugin/marketplace.json', 'description', marketplace.description, 300);
  }
  const names = new Set();
  for (const plugin of marketplace.plugins) {
    checkSlug('.claude-plugin/marketplace.json', 'plugin name', plugin.name);
    if (typeof plugin.description === 'string') {
      checkDescription('.claude-plugin/marketplace.json', `${plugin.name} description`, plugin.description, 300);
    } else {
      errors.push(`.claude-plugin/marketplace.json: ${plugin.name} missing string description`);
    }
    if (names.has(plugin.name)) {
      errors.push(`.claude-plugin/marketplace.json: duplicate plugin name ${plugin.name}`);
    }
    names.add(plugin.name);
    if (typeof plugin.source !== 'string' || !plugin.source.startsWith('./')) {
      errors.push(`${plugin.name}: source must be a relative path starting with ./`);
      continue;
    }
    const pluginRoot = path.resolve(root, plugin.source);
    if (!exists(pluginRoot)) errors.push(`${plugin.name}: source path missing: ${plugin.source}`);
    if (exists(pluginRoot) && path.basename(pluginRoot) !== plugin.name) {
      errors.push(`${plugin.name}: source directory '${path.basename(pluginRoot)}' must match plugin name`);
    }
    if (exists(pluginRoot)) {
      const skillsDir = path.join(pluginRoot, 'skills');
      const pluginSkills = exists(skillsDir) ? walk(skillsDir, f => path.basename(f) === 'SKILL.md') : [];
      const usesReferences = pluginSkills.some(skill => read(skill).includes('references/'));
      if (usesReferences) {
        for (const ref of REQUIRED_PLUGIN_REFERENCES.get(plugin.name) || []) {
          if (!exists(path.join(pluginRoot, ref))) errors.push(`${plugin.name}: missing bundled reference ${ref}`);
        }
      }
    }
    const manifestPath = path.join(pluginRoot, '.claude-plugin', 'plugin.json');
    if (!exists(manifestPath)) {
      errors.push(`${plugin.name}: missing .claude-plugin/plugin.json`);
      continue;
    }
    const manifest = parseJson(manifestPath);
    if (!manifest) continue;
    checkSlug(rel(manifestPath), 'name', manifest.name);
    if (manifest.name !== plugin.name) {
      errors.push(`${rel(manifestPath)}: name does not match marketplace entry ${plugin.name}`);
    }
    if (!manifest.version || typeof manifest.version !== 'string') {
      errors.push(`${rel(manifestPath)}: missing string version`);
    }
    if (manifest.author && (typeof manifest.author !== 'object' || Array.isArray(manifest.author) || !manifest.author.name)) {
      errors.push(`${rel(manifestPath)}: author must be an object with name`);
    }
    for (const unsupported of ['language', 'rechtsgebiet', 'adapted_from']) {
      if (Object.hasOwn(manifest, unsupported)) {
        errors.push(`${rel(manifestPath)}: unsupported manifest key ${unsupported}`);
      }
    }
    const legacyAgentsDir = path.join(pluginRoot, 'agenten');
    if (exists(legacyAgentsDir)) {
      errors.push(`${plugin.name}: use agents/ instead of legacy agenten/`);
    }
    if (manifest.agents) {
      for (const agentPath of Array.isArray(manifest.agents) ? manifest.agents : [manifest.agents]) {
        const resolved = path.resolve(pluginRoot, agentPath);
        if (!exists(resolved)) errors.push(`${rel(manifestPath)}: agents path missing: ${agentPath}`);
      }
    }
    if (plugin.name === 'liquiditaetsplanung') {
      // liquiditaetsplanung is the standalone Power-Plugin Liquiditätsvorschau.
      // It MUST work without insolvenzrecht/steuerberater-werkzeuge. Dependencies are
      // therefore optional (recommended companions, not required), but its own skills
      // must exist and be self-contained.
      const skills = walk(path.join(pluginRoot, 'skills'), f => path.basename(f) === 'SKILL.md');
      if (skills.length === 0) errors.push(`${plugin.name}: expected autark Liquiditätsvorschau skills`);
      for (const required of ['liquiditaetsvorschau-3wochen', 'liquiditaetsvorschau-3-6-12-monate', 'liquiditaetsvorschau-insolvenzrechtlich']) {
        const sp = path.join(pluginRoot, 'skills', required, 'SKILL.md');
        if (!exists(sp)) errors.push(`${plugin.name}: missing required standalone skill ${required}`);
      }
      for (const asset of ['assets/excel/Liquiditaetsplan-Wochenbasis.xlsx', 'assets/padlet/liquiditaets-padlet.html', 'assets/markdown/liquiditaets-artefakt-vorlage.md']) {
        if (!exists(path.join(pluginRoot, asset))) errors.push(`${plugin.name}: missing standalone asset ${asset}`);
      }
      const generator = 'skills/liquiditaetsvorschau-3-6-12-monate/werkzeuge/build_liquiditaetsplan.py';
      if (!exists(path.join(pluginRoot, generator))) errors.push(`${plugin.name}: missing standalone generator ${generator}`);
      // BGH-Volltexte werden als PDF mitgeliefert (Plugin-ZIP bleibt unter Cowork-Upload-Limit).
      // Zusätzlich ist eine INDEX.md mit Online-Verweisen auf die BGH-Datenbank Pflicht — sie ist
      // die Tabula-Rasa-Quelle, falls einzelne PDFs nicht gerendert werden oder offline nicht
      // verfügbar sind.
      const idx = path.join(pluginRoot, 'references', 'rechtsprechung', 'INDEX.md');
      if (!exists(idx)) errors.push(`${plugin.name}: missing references/rechtsprechung/INDEX.md (BGH-Onlinequellenverzeichnis)`);
    }
  }
}

function checkSkills() {
  // Offiziell von Claude Code/Cowork akzeptierte Frontmatter-Felder.
  // Quelle: code.claude.com/docs/en/plugins-reference und anthropics/skills.
  // Strikt: nur name + description; alles andere wird abgelehnt.
  const ALLOWED_SKILL_FIELDS = new Set([
    'name', 'description',
  ]);
  const skills = walk(root, f => path.basename(f) === 'SKILL.md');
  for (const skill of skills) {
    const fm = parseFrontmatter(skill);
    if (!fm) continue;
    if (!topLevelField(fm, 'name')) errors.push(`${rel(skill)}: missing name`);
    if (!topLevelField(fm, 'description')) errors.push(`${rel(skill)}: missing description`);
    // Verbotene Felder explizit benennen für klare Fehlermeldung.
    for (const forbidden of ['triggers', 'when_to_use', 'language', 'rechtsgebiet',
                              'license', 'argument-hint', 'user-invocable',
                              'related_skills', 'allowed-tools', 'version']) {
      if (topLevelField(fm, forbidden)) {
        errors.push(`${rel(skill)}: forbidden frontmatter field '${forbidden}' — merge into description or remove`);
      }
    }
    // Unbekannte Top-Level-Felder erkennen (zusätzliche Sicherung).
    for (const line of fm.split(/\r?\n/)) {
      const m = line.match(/^([A-Za-z][\w-]*)\s*:/);
      if (!m) continue;
      if (!ALLOWED_SKILL_FIELDS.has(m[1])) {
        // Nur wenn nicht schon als forbidden gemeldet.
        const already = errors.some(e => e.includes(`'${m[1]}'`) && e.startsWith(rel(skill)));
        if (!already) {
          errors.push(`${rel(skill)}: unknown frontmatter field '${m[1]}' (only allowed: name, description)`);
        }
      }
    }
    const nameMatch = fm.match(/^name\s*:\s*['"]?([^\r\n'"]+)/m);
    if (nameMatch && !SLUG_RE.test(nameMatch[1].trim())) {
      errors.push(`${rel(skill)}: invalid skill name ${nameMatch[1].trim()}`);
    }
    // description muss einzeilig sein (Cowork-Parser-Bug bei Multi-Line).
    const descMatch = fm.match(/^description\s*:\s*(.*)$/m);
    if (descMatch) {
      const v = descMatch[1].trim();
      if (v === '|' || v === '>' || v.startsWith('|') || v.startsWith('>')) {
        errors.push(`${rel(skill)}: description must be single-line (no | or > block style)`);
      }
      if (!['"', "'"].includes(v[0]) && /:\s/.test(v)) {
        errors.push(`${rel(skill)}: quote description because plain YAML scalars cannot safely contain ": "`);
      }
      checkDescription(rel(skill), 'description', stripEnclosingQuotes(v), 1024);
    }
  }
}

function checkPluginManifests() {
  // Strenge Semver-Prüfung für plugin.json: x.y.z ohne Pre-Release-Suffix.
  const manifests = walk(root, f => f.endsWith(path.join('.claude-plugin', 'plugin.json')));
  for (const m of manifests) {
    const data = parseJson(m);
    if (!data) continue;
    if (data.version && !/^\d+\.\d+\.\d+$/.test(data.version)) {
      errors.push(`${rel(m)}: version '${data.version}' must be strict semver x.y.z (no pre-release suffix)`);
    }
    checkSlug(rel(m), 'name', data.name);
    checkDescription(rel(m), 'description', data.description, 300);
  }
}

function checkManagedAgentReferences() {
  const base = path.join(root, 'verwaltete-agentenrezepte');
  if (!exists(base)) return;
  const files = walk(base, f => ['.yaml', '.yml'].includes(path.extname(f)));
  const refPattern = /\b(from_plugin|path|manifest):\s*([^}\r\n]+)/g;
  for (const file of files) {
    const text = read(file);
    for (const match of text.matchAll(refPattern)) {
      let target = match[2].trim().replace(/,$/, '').trim().replace(/^["']|["']$/g, '');
      if (!target.startsWith('.')) continue;
      const resolved = path.resolve(path.dirname(file), target);
      if (!exists(resolved)) errors.push(`${rel(file)}: ${match[1]} target missing: ${target}`);
    }
  }
}

function checkMarkdownLinks() {
  const files = walk(root, f => ['.md', '.yaml', '.yml', '.json'].includes(path.extname(f)));
  const linkPattern = /\[[^\]]*]\(([^)]+)\)/g;
  for (const file of files) {
    const text = read(file);
    for (const match of text.matchAll(linkPattern)) {
      const target = match[1].trim();
      if (/^(https?:|mailto:|#|\/)/.test(target)) continue;
      const clean = target.split('#')[0].replaceAll('%20', ' ');
      if (!clean || /^[A-Za-z]+:/.test(clean)) continue;
      const resolved = path.resolve(path.dirname(file), clean);
      if (!exists(resolved)) errors.push(`${rel(file)}: relative markdown link missing: ${target}`);
    }
  }
}

function checkSuspiciousCharacters() {
  const suspicious = /[\u0400-\u04ff\u200b-\u200f\u202a-\u202e\u2066-\u2069]/;
  for (const file of walk(root, f => textExt.has(path.extname(f)))) {
    const lines = read(file).split(/\r?\n/);
    lines.forEach((line, index) => {
      if (suspicious.test(line)) errors.push(`${rel(file)}:${index + 1}: suspicious unicode character`);
    });
  }
}

function checkTestaktenReadme() {
  const testaktenDir = path.join(root, 'testakten');
  if (!exists(testaktenDir)) return;
  const zipOptionalFolders = new Set(['grosser-prompts']);
  const readmePath = path.join(testaktenDir, 'README.md');
  if (!exists(readmePath)) {
    errors.push('testakten/README.md fehlt');
    return;
  }
  const entries = fs.readdirSync(testaktenDir, { withFileTypes: true });
  const folders = entries
    .filter(e => e.isDirectory() && !e.name.startsWith('.') && !zipOptionalFolders.has(e.name))
    .map(e => e.name)
    .sort();
  const readme = read(readmePath);
  const missing = [];
  for (const folder of folders) {
    const linkPattern = new RegExp('\\[`' + escapeRegex(folder) + '/`\\]');
    if (!linkPattern.test(readme)) missing.push(folder);
  }
  if (missing.length) {
    errors.push(`testakten/README.md: ${missing.length} Akten-Ordner fehlen in der Tabelle: ${missing.join(', ')}`);
  }
  const tableMatches = readme.match(/^\| \[`[a-z0-9][a-z0-9-]*\/`\]/gm) || [];
  if (tableMatches.length !== folders.length) {
    errors.push(`testakten/README.md: ${tableMatches.length} Tabellen-Zeilen vs. ${folders.length} Ordner auf dem Dateisystem (Drift)`);
  }
  const zipPattern = /testakte-([a-z0-9][a-z0-9-]*)\.zip/g;
  const zipNames = new Set();
  for (const m of readme.matchAll(zipPattern)) zipNames.add(m[1]);
  const zipMissing = folders.filter(f => !zipNames.has(f) && !zipOptionalFolders.has(f));
  if (zipMissing.length) {
    errors.push(`testakten/README.md: ${zipMissing.length} Akten ohne ZIP-Download-Eintrag: ${zipMissing.join(', ')}`);
  }
  const pdfZipPattern = /testakte-([a-z0-9][a-z0-9-]*)-einzel-pdfs\.zip/g;
  const pdfZipNames = new Set();
  for (const m of readme.matchAll(pdfZipPattern)) pdfZipNames.add(m[1]);
  const pdfZipMissing = folders.filter(f => !pdfZipNames.has(f) && !zipOptionalFolders.has(f));
  if (pdfZipMissing.length) {
    errors.push(`testakten/README.md: ${pdfZipMissing.length} Akten ohne Einzel-PDF-ZIP-Eintrag: ${pdfZipMissing.join(', ')}`);
  }

  for (const folder of folders) {
    if (zipOptionalFolders.has(folder)) continue;
    const folderReadmePath = path.join(testaktenDir, folder, 'README.md');
    if (!exists(folderReadmePath)) {
      errors.push(`testakten/${folder}/README.md fehlt`);
      continue;
    }
    const folderReadme = read(folderReadmePath);
    const expectedZip = `testakte-${folder}.zip`;
    const expectedPdfZip = `testakte-${folder}-einzel-pdfs.zip`;
    const expectedPdf = `gesamt-pdf/${folder}_gesamt.pdf`;
    if (!folderReadme.includes(expectedZip)) {
      errors.push(`testakten/${folder}/README.md: Arbeits-ZIP-Link fehlt (${expectedZip})`);
    }
    if (!folderReadme.includes(expectedPdfZip)) {
      errors.push(`testakten/${folder}/README.md: Einzel-PDF-ZIP-Link fehlt (${expectedPdfZip})`);
    }
    if (exists(path.join(testaktenDir, folder, expectedPdf)) && !folderReadme.includes(expectedPdf)) {
      errors.push(`testakten/${folder}/README.md: Gesamt-PDF-Link fehlt (${expectedPdf})`);
    }
  }
}

function checkForderungsmanagementSafetyGates() {
  const pluginRoot = path.join(root, 'forderungsmanagement-immobilien');
  if (!exists(pluginRoot)) return;

  const releaseGateSkills = [
    '09-mietrueckstand-mahnung-erstellen',
    '10-zahlungsplan-stundungsvereinbarung',
    '12-vorgerichtliche-letzte-frist',
    '13-fristlose-kuendigung-zahlungsverzug',
    '14-ordentliche-kuendigung-pflichtverletzung',
    '15-kuendigung-zustellung-nachweis',
    '18-widerspruch-vollstreckungsbescheid',
    '20-zahlungsklage-mietrueckstand-erstellen',
    '23-klage-egvp-bea-einreichen',
    '24-raeumungsklage-erstellen',
    '25-raeumungsfrist-vollstreckung',
    '26-berliner-modell-raeumung',
    '27-schonfristzahlung-erkennen',
    '29-mieterhoehungsverlangen-text',
    '30-zustimmungsklage-mieterhoehung',
    '38-replik-erstellen',
    '41-vergleich-raten-prozess',
    '42-mieterklage-verteidigen',
    '43-mieterverein-anwalt-korrespondenz',
    '46-kostenfestsetzung-antrag',
    '48-titulierte-forderung-vollstrecken',
  ];
  for (const slug of releaseGateSkills) {
    const file = path.join(pluginRoot, 'skills', slug, 'SKILL.md');
    if (!exists(file)) {
      errors.push(`forderungsmanagement-immobilien: Freigabegate-Skill fehlt: ${slug}`);
      continue;
    }
    const contents = read(file);
    for (const required of ['Freigabekarte', 'ENTWURF - NICHT VERSENDEN/EINREICHEN']) {
      if (!contents.includes(required)) {
        errors.push(`${rel(file)}: Freigabegate unvollständig, Pflichttext fehlt: ${required}`);
      }
    }
  }

  const paymentTimingSkills = [
    '02-mietakte-rekonstruieren',
    '03-kontoauszug-mietkonto-auslesen',
    '09-mietrueckstand-mahnung-erstellen',
    '11-verzugsschaden-berechnen',
    '13-fristlose-kuendigung-zahlungsverzug',
    '14-ordentliche-kuendigung-pflichtverletzung',
    '20-zahlungsklage-mietrueckstand-erstellen',
    '24-raeumungsklage-erstellen',
  ];
  for (const slug of paymentTimingSkills) {
    const file = path.join(pluginRoot, 'skills', slug, 'SKILL.md');
    if (exists(file) && !read(file).includes('VIII ZR 222/15')) {
      errors.push(`${rel(file)}: BGH-Anker VIII ZR 222/15 zur Rechtzeitigkeit der Mietzahlung fehlt`);
    }
  }

  for (const prompt of ['forderungsmanagement-grosser-prompt.md', 'forderungsmanagement-kleiner-prompt.md']) {
    const file = path.join(root, prompt);
    if (!exists(file)) continue;
    const contents = read(file);
    for (const required of ['Freigabekarte', 'ENTWURF - NICHT VERSENDEN/EINREICHEN', 'VIII ZR 222/15', 'Anlage K 1', '1.000 Dateien', 'nicht selbst aus beA']) {
      if (!contents.includes(required)) errors.push(`${prompt}: Pflichtanker fehlt: ${required}`);
    }
  }

  const filingSkill = path.join(pluginRoot, 'skills', '23-klage-egvp-bea-einreichen', 'SKILL.md');
  for (const required of ['Anlagenmanifest', 'Originaldatei unverändert', 'V ZR 261/23', '1.000 Dateien', 'nicht selbst aus einem beA']) {
    if (!read(filingSkill).includes(required)) errors.push(`${rel(filingSkill)}: Dokumentenproduktionsanker fehlt: ${required}`);
  }
  const evidenceSkill = path.join(pluginRoot, 'skills', '39-beweisangebot-anlagenplan', 'SKILL.md');
  for (const required of ['Anlagenmanifest', 'Bereits eingereicht', 'Version/Hash', 'höchste vergebene Nummer fort']) {
    if (!read(evidenceSkill).includes(required)) errors.push(`${rel(evidenceSkill)}: Anlagenübergabe unvollständig: ${required}`);
  }

  const intakeSkill = path.join(pluginRoot, 'skills', '33-dokumentenmix-ocr-sichten', 'SKILL.md');
  for (const required of ['höchstens 20 Dateien oder 30 PDF-Seiten', 'Fortsetzungsmarke', 'höchstens sieben Spalten', 'Unveränderte Dokumente']) {
    if (!read(intakeSkill).includes(required)) errors.push(`${rel(intakeSkill)}: robuste Stapelverarbeitung unvollständig: ${required}`);
  }
  const workflowReference = path.join(root, 'references', 'bedienfuehrung-workflows.md');
  for (const required of ['höchstens 20 Dateien oder 30 PDF-Seiten', 'Fortsetzungsmarke', 'höchstens sieben Spalten', 'Außergerichtliches Mietervereinsschreiben']) {
    if (!read(workflowReference).includes(required)) errors.push(`${rel(workflowReference)}: Bedienführung unvollständig: ${required}`);
  }
  for (const prompt of ['forderungsmanagement-grosser-prompt.md', 'forderungsmanagement-kleiner-prompt.md']) {
    const contents = read(path.join(root, prompt));
    for (const required of ['20 Dateien', '30 PDF-Seiten', 'Fortsetzungsmarke']) {
      if (!contents.includes(required)) errors.push(`${prompt}: Stapelanker fehlt: ${required}`);
    }
  }

  for (const reference of ['100-punkte-bediencheck.md', 'bedienfuehrung-workflows.md', 'erv-dokumentenproduktion.md', 'gepruefte-bgh-anker-mietrecht.md', 'leitentscheidungen-anker.md', 'rechtsprechungsradar-mietrecht-2021-2026.md', 'schriftsatz-und-argumentationsstandard.md']) {
    const rootCopy = path.join(root, 'references', reference);
    const pluginCopy = path.join(pluginRoot, 'references', reference);
    if (exists(rootCopy) && exists(pluginCopy) && read(rootCopy) !== read(pluginCopy)) {
      errors.push(`references/${reference}: Repo- und Plugin-Kopie sind nicht identisch`);
    }
  }

  const usabilityCatalog = path.join(root, 'references', '100-punkte-bediencheck.md');
  if (exists(usabilityCatalog)) {
    const points = [...read(usabilityCatalog).matchAll(/^\| (\d{3}) \|/gm)].map(match => match[1]);
    const expected = Array.from({ length: 100 }, (_, index) => String(index + 1).padStart(3, '0'));
    if (points.length !== 100 || points.some((point, index) => point !== expected[index])) {
      errors.push(`${rel(usabilityCatalog)}: Bediencheck muss exakt die Punkte 001 bis 100 enthalten`);
    }
  }
}

function checkSchriftsatzwerkstattSafetyGates() {
  const pluginRoot = path.join(root, 'schriftsatzwerkstatt-bea');
  if (!exists(pluginRoot)) return;

  const expectedSkills = [
    '01-bea-ordner-annahme',
    '02-schriftsatzversion-festlegen',
    '03-anlagenfolge-kennzeichnen',
    '04-dateien-in-pdf-umwandeln',
    '05-pdf-qualitaet-pruefen',
    '06-dateinamen-manifest-erzeugen',
    '07-signatur-versandweg-pruefen',
    '08-bea-paket-freigeben',
    '09-eingang-versandakte-sichern',
  ];
  const skillsDir = path.join(pluginRoot, 'skills');
  const actualSkills = exists(skillsDir)
    ? fs.readdirSync(skillsDir, { withFileTypes: true })
      .filter(entry => entry.isDirectory() && exists(path.join(skillsDir, entry.name, 'SKILL.md')))
      .map(entry => entry.name)
      .sort()
    : [];
  if (actualSkills.length > 10) {
    errors.push(`schriftsatzwerkstatt-bea: höchstens 10 Skills erlaubt, gefunden ${actualSkills.length}`);
  }
  for (const slug of expectedSkills) {
    if (!actualSkills.includes(slug)) errors.push(`schriftsatzwerkstatt-bea: Pflicht-Skill fehlt: ${slug}`);
  }

  const requiredContent = new Map([
    ['README.md', ['höchstens 80 Zeichen einschließlich', 'höchstens 1.000 Dateien und 200 MB', 'verändert niemals die Quellen', '100-Punkte-Fehlerkatalog', 'höchstens 100 Dateien oder 250 MB Rohdaten', 'Fortsetzungsmarke', 'höchstens sieben Spalten', 'signaturmanifest.csv']],
    ['skills/01-bea-ordner-annahme/SKILL.md', ['Eine manuelle Auswahl weiterer Skills ist nicht nötig', 'SHA-256', 'Delta-Status', 'höchstens 100 Dateien oder 250 MB Rohdaten', 'Fortsetzungsmarke', 'höchstens sieben Spalten']],
    ['skills/03-anlagenfolge-kennzeichnen/SKILL.md', ['rechts oben', 'höchsten vergebenen K-/B-Nummer']],
    ['skills/04-dateien-in-pdf-umwandeln/SKILL.md', ['höchstens vier Arbeitsaufträgen', 'höchstens 20 Dateien', 'atomar', 'Zeitlimit']],
    ['skills/05-pdf-qualitaet-pruefen/SKILL.md', ['gerendert und visuell', 'JavaScript', 'höchstens 30 Seiten', 'Fortsetzungsmarke']],
    ['skills/06-dateinamen-manifest-erzeugen/SKILL.md', ['höchstens 80 Zeichen', 'versandmanifest.csv']],
    ['skills/07-signatur-versandweg-pruefen/SKILL.md', ['tatsächlichen Versender', 'Einfache Signatur', 'qeS', 'signaturmanifest.csv', '.pkcs7']],
    ['skills/08-bea-paket-freigeben/SKILL.md', ['1.000 Dateien oder 200 MB', 'ENTWURF - NICHT VERSENDEN/EINREICHEN', 'signaturmanifest.csv', 'CAdES']],
    ['skills/09-eingang-versandakte-sichern/SKILL.md', ['automatisierte Eingangsbestätigung', 'nicht allein die Anzeige']],
    ['scripts/validate_bea_package.py', ['MAX_NAME_LENGTH = 80', 'MAX_SIGNATURE_NAME_LENGTH = 90', 'MAX_FILES = 1_000', 'MAX_BYTES = 200_000_000', 'MAX_MANIFEST_BYTES = 2_000_000', 'EXPECTED_COLUMNS', 'SIGNATURE_COLUMNS', 'SIGNATURE_SUFFIXES', 'ThreadPoolExecutor']],
    ['templates/konvertierungsprotokoll.md', ['SHA-256 Quelle', 'Werkzeug und Version', 'Delta-Entscheidung']],
    ['templates/eingangsvermerk.md', ['Automatisierte Eingangsbestätigung', 'EINGANG TECHNISCH BESTÄTIGT']],
    ['templates/signaturmanifest.csv', ['Signaturdatei,Zieldokument,Zieldokument_SHA256,Bytes,SHA256,Format,Signaturniveau,Prüfstatus,Unterzeichner,Prüfprotokoll']],
  ]);
  for (const [relative, needles] of requiredContent) {
    const file = path.join(pluginRoot, relative);
    if (!exists(file)) {
      errors.push(`schriftsatzwerkstatt-bea: Pflichtdatei fehlt: ${relative}`);
      continue;
    }
    const contents = read(file);
    for (const needle of needles) {
      if (!contents.includes(needle)) errors.push(`${rel(file)}: Werkstatt-Gate fehlt: ${needle}`);
    }
  }

  const catalog = path.join(pluginRoot, 'references', '100-punkte-fehlerkatalog.md');
  if (exists(catalog)) {
    const points = [...read(catalog).matchAll(/^\| (\d{3}) \|/gm)].map(match => match[1]);
    const expected = Array.from({ length: 100 }, (_, index) => String(index + 1).padStart(3, '0'));
    if (points.length !== 100 || points.some((point, index) => point !== expected[index])) {
      errors.push(`${rel(catalog)}: Fehlerkatalog muss exakt die Punkte 001 bis 100 enthalten`);
    }
  }

  const courtCitationPattern = /\b(?:BGH|Bundesgerichtshof|BVerfG|Bundesverfassungsgericht|EuGH|Gerichtshof der Europäischen Union|OLG|Oberlandesgericht|Kammergericht|Landgericht)\b/;
  for (const file of walk(pluginRoot, candidate => ['.md', '.json'].includes(path.extname(candidate)))) {
    if (courtCitationPattern.test(read(file))) {
      errors.push(`${rel(file)}: fachlich neutrale Schriftsatzwerkstatt darf keine Rechtsprechungsanker enthalten`);
    }
  }
}

checkMarketplace();
checkSkills();
checkPluginManifests();
checkManagedAgentReferences();
// Relative Markdown links are validated by scripts/validate-markdown-links.py.
// Keep that scan in one fast, dedicated validator instead of duplicating it here.
checkSuspiciousCharacters();
checkTestaktenReadme();
checkForderungsmanagementSafetyGates();
checkSchriftsatzwerkstattSafetyGates();

if (errors.length) {
  console.error(`validate-plugin-structure failed with ${errors.length} issue(s):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('validate-plugin-structure OK');
