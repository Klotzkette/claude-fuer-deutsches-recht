#!/usr/bin/env python3
"""Prüft fachliche Rechenlogik in sämtlichen finanziellen Fach-Testakten.

Der Validator ist fallnah: Er liest die strukturierten Markdown-Tabellen der
jeweiligen Akte und stimmt Vertrag, Mietkonto, Forderung, Teilzahlung,
Ratenplan, Abrechnung oder Titel gegeneinander ab. Dadurch fallen inhaltliche
Widersprüche auf, die reine Datei- und Stammdatenprüfungen nicht erkennen.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import re
import sys
from pathlib import Path
from typing import NoReturn

ROOT = Path(__file__).resolve().parent.parent
TESTAKTEN = ROOT / "testakten"
CENT = Decimal("0.01")


def fail(message: str) -> NoReturn:
    print(
        f"validate-testakten-financial-consistency failed: {message}",
        file=sys.stderr,
    )
    raise SystemExit(1)


def money(value: Decimal) -> Decimal:
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def parse_amount(text: str) -> Decimal:
    cleaned = text.replace("**", "").replace("EUR", "").replace("\u00a0", " ")
    match = re.search(r"-?\d[\d.,]*", cleaned)
    if not match:
        fail(f"Betrag nicht lesbar: {text!r}")
    token = match.group(0)
    if "," in token and "." in token:
        if token.rfind(",") > token.rfind("."):
            token = token.replace(".", "").replace(",", ".")
        else:
            token = token.replace(",", "")
    elif "," in token:
        integer, decimal = token.rsplit(",", 1)
        token = (
            f"{integer.replace(',', '')}.{decimal}"
            if len(decimal) <= 2
            else token.replace(",", "")
        )
    elif "." in token:
        integer, decimal = token.rsplit(".", 1)
        token = (
            f"{integer.replace('.', '')}.{decimal}"
            if len(decimal) <= 2
            else token.replace(".", "")
        )
    try:
        return money(Decimal(token))
    except InvalidOperation:
        fail(f"Betrag nicht normalisierbar: {text!r}")


def clean_cell(text: str) -> str:
    return text.replace("**", "").replace("`", "").strip()


def markdown_tables_from_text(text: str) -> list[list[list[str]]]:
    tables: list[list[list[str]]] = []
    current: list[list[str]] = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("|"):
            cells = [cell.strip() for cell in stripped.strip("|").split("|")]
            is_separator = all(
                re.fullmatch(r":?-{2,}:?", cell.strip()) for cell in cells
            )
            if not is_separator:
                current.append(cells)
            continue
        if current:
            tables.append(current)
            current = []
    if current:
        tables.append(current)
    return tables


def markdown_tables(path: Path) -> list[list[list[str]]]:
    return markdown_tables_from_text(path.read_text(encoding="utf-8"))


def markdown_table_rows(path: Path) -> list[list[str]]:
    return [row for table in markdown_tables(path) for row in table]


def table_records(path: Path, required_headers: set[str]) -> list[dict[str, str]]:
    for table in markdown_tables(path):
        if not table:
            continue
        headers = [clean_cell(cell) for cell in table[0]]
        if not required_headers.issubset(set(headers)):
            continue
        records: list[dict[str, str]] = []
        for row in table[1:]:
            padded = row + [""] * (len(headers) - len(row))
            records.append(
                {
                    header: clean_cell(padded[index])
                    for index, header in enumerate(headers)
                }
            )
        return records
    wanted = ", ".join(sorted(required_headers))
    fail(f"{path.relative_to(ROOT)}: Tabelle mit Spalten {wanted} fehlt")


def record_for(
    path: Path,
    required_headers: set[str],
    key: str,
    value: str,
) -> dict[str, str]:
    for record in table_records(path, required_headers):
        if record.get(key) == value:
            return record
    fail(f"{path.relative_to(ROOT)}: Tabellenzeile {key}={value!r} fehlt")


def value_for_label(path: Path, label: str) -> Decimal:
    for cells in markdown_table_rows(path):
        if cells and clean_cell(cells[0]) == label:
            return parse_amount(cells[-1])
    fail(f"{path.relative_to(ROOT)}: Zeile {label!r} fehlt")


def regex_amount(path: Path, pattern: str, *, flags: int = 0) -> Decimal:
    text = path.read_text(encoding="utf-8")
    match = re.search(pattern, text, flags)
    if match is None:
        fail(f"{path.relative_to(ROOT)}: Betragsmuster fehlt: {pattern}")
    return parse_amount(match.group(1))


def assert_amount(case: str, label: str, actual: Decimal, expected: Decimal) -> None:
    if money(actual) != money(expected):
        fail(f"{case}: {label} ist {money(actual)}, erwartet {money(expected)}")


def last_balance(path: Path) -> Decimal:
    records = table_records(path, {"Saldo"})
    if not records:
        fail(f"{path.relative_to(ROOT)}: Mietkonto enthält keine Buchungen")
    return parse_amount(records[-1]["Saldo"])


def check_lange_bankwechsel() -> None:
    slug = "mietrueckstand-lange-zwei-raten-versehen"
    base = TESTAKTEN / slug
    lease = base / "vertrag" / "mietvertrag.md"
    account = base / "konto" / "mietkonto-fbl5n.md"

    gross = value_for_label(lease, "Bruttowarmmiete")
    open_principal = value_for_label(account, "Offene Hauptforderung")
    assert_amount(slug, "zwei offene Bruttowarmmieten", open_principal, gross * 2)
    assert_amount(slug, "Mietkonto-Endsaldo", last_balance(account), open_principal)


def check_demir_five_installments() -> None:
    slug = "mietrueckstand-demir-fuenf-raten-absichtlich"
    base = TESTAKTEN / slug
    lease = base / "vertrag" / "mietvertrag.md"
    account = base / "konto" / "mietkonto-fbl5n.md"
    readme = base / "README.md"

    gross = value_for_label(lease, "Bruttowarmmiete")
    open_principal = value_for_label(account, "Offene Hauptforderung")
    assert_amount(slug, "fünf offene Bruttowarmmieten", open_principal, gross * 5)
    assert_amount(slug, "Mietkonto-Endsaldo", last_balance(account), open_principal)
    assert_amount(
        slug, "README-Summe", value_for_label(readme, "Summe offen"), open_principal
    )


def check_meier_partial_payment() -> None:
    slug = "mietrueckstand-meier-wilhelmstrasse"
    base = TESTAKTEN / slug
    readme = base / "README.md"
    lease = base / "vertrag" / "mietvertrag.md"
    sap = base / "sap" / "sap-statusauszug.md"
    account = base / "konto" / "mietkonto-fbl5n.md"

    gross = value_for_label(readme, "Bruttowarmmiete")
    expected = gross * 4 - Decimal("500.00")
    account_balance = regex_amount(
        account,
        r"Saldo per 18\.06\.2026\s+([0-9.,]+)\s+H",
    )
    assert_amount(slug, "Teilzahlungsrechnung", account_balance, expected)
    assert_amount(slug, "README-Summe", value_for_label(readme, "Summe"), expected)

    lease_security = regex_amount(
        lease,
        r"Kaution in Höhe von \*\*EUR\s+([0-9.,]+)\*\*",
    )
    sap_security = regex_amount(sap, r"Höhe\s*:\s*EUR\s+([0-9.,]+)")
    assert_amount(slug, "Kaution im Vertrag", lease_security, Decimal("1980.00"))
    assert_amount(slug, "Kaution im SAP", sap_security, lease_security)
    if "2160" in lease.read_text(encoding="utf-8") + sap.read_text(encoding="utf-8"):
        fail(f"{slug}: unzulässige automatische Kautionsaufstockung verblieben")


def check_kowalska_rent_and_jobcenter() -> None:
    slug = "raeumungsklage-kowalski-friedrichshain"
    base = TESTAKTEN / slug
    readme = base / "README.md"
    lease = base / "vertrag" / "mietvertrag.md"
    account = base / "konto" / "mietkonto-fbl5n.md"
    jobcenter = base / "jobcenter" / "berechnungsbogen-schonfristzahlung.md"

    gross = value_for_label(readme, "Bruttowarmmiete")
    current_lease_gross = regex_amount(
        lease,
        r"Gesamtmiete neu:\s*([0-9.,]+) EUR",
    )
    assert_amount(slug, "aktuelle Gesamtmiete im Vertrag", current_lease_gross, gross)
    records = table_records(account, {"Buchungstext", "Soll", "Haben", "Saldo"})
    june = next(
        (
            record
            for record in records
            if record["Buchungstext"] == "Miete 06/2026 fällig"
        ),
        None,
    )
    if june is None:
        fail(f"{slug}: Buchung der Junimiete fehlt")
    rent_arrears = parse_amount(june["Saldo"])
    assert_amount(
        slug,
        "Mietrückstand Februar bis Juni",
        rent_arrears,
        gross * 5 - Decimal("200.00"),
    )
    assert_amount(
        slug,
        "Gesamtsaldo mit Nebenpositionen",
        last_balance(account),
        rent_arrears + Decimal("200.00"),
    )

    payment_records = table_records(
        jobcenter,
        {"Zeitraum oder Position", "Zahlbetrag"},
    )
    payment_parts = [
        parse_amount(record["Zahlbetrag"])
        for record in payment_records
        if record["Zeitraum oder Position"] != "Summe"
    ]
    payment_total = parse_amount(
        next(
            record["Zahlbetrag"]
            for record in payment_records
            if record["Zeitraum oder Position"] == "Summe"
        )
    )
    assert_amount(slug, "Jobcenter-Summe", sum(payment_parts), payment_total)
    assert_amount(
        slug,
        "Jobcenter-Aufteilung",
        payment_total,
        rent_arrears + gross + Decimal("200.00"),
    )


def check_becker_rent_increase() -> None:
    slug = "mieterhoehung-becker-tempelhof"
    readme = TESTAKTEN / slug / "README.md"
    complaint = TESTAKTEN / slug / "korrespondenz" / "zustimmungsklage.md"

    current = regex_amount(
        readme,
        r"Aktuelle Nettokaltmiete:\s*7,20 EUR/qm\s*=\s*([0-9.,]+) EUR",
    )
    target = regex_amount(
        readme,
        r"Neue Soll-Nettokaltmiete:\s*7,82 EUR/qm\s*=\s*([0-9.,]+) EUR",
    )
    partial = regex_amount(
        complaint,
        r"Erhöhung auf monatlich\s+([0-9.,]+) EUR zugestimmt",
    )
    disputed = regex_amount(
        complaint,
        r"Die Differenz der auf Cent festgelegten Monatsmieten beträgt\s+([0-9.,]+) EUR",
    )
    claim_value = regex_amount(
        complaint,
        r"\*\*Streitwert:\s*([0-9.,]+) EUR\*\*",
    )

    area = Decimal("78.50")
    assert_amount(slug, "aktuelle Nettokaltmiete", current, Decimal("7.20") * area)
    assert_amount(slug, "Ziel-Nettokaltmiete", target, Decimal("7.82") * area)
    assert_amount(slug, "Teilzustimmung", partial, money(Decimal("7.55") * area))
    assert_amount(slug, "streitige Monatsdifferenz", disputed, target - partial)
    assert_amount(slug, "Streitwert", claim_value, disputed * 12)


def check_braun_operating_costs() -> None:
    slug = "nebenkosten-braun-nachzahlung-unbezahlt"
    base = TESTAKTEN / slug
    lease = base / "vertrag" / "mietvertrag.md"
    statement = base / "nebenkosten" / "betriebskostenabrechnung-2025.md"

    monthly_bk = value_for_label(lease, "Betriebskostenvorauszahlung")
    monthly_hk = value_for_label(lease, "Heizkostenvorauszahlung")
    expected_advances = (monthly_bk + monthly_hk) * Decimal(12)

    detail_records = table_records(
        statement,
        {"Kostenart", "Gesamtkosten Objekt", "Verteilerschlüssel", "Ihr Anteil"},
    )
    cold_positions = [
        record
        for record in detail_records
        if record["Kostenart"] != "Summe kalte Betriebskosten"
    ]
    position_sum = sum(
        (parse_amount(record["Ihr Anteil"]) for record in cold_positions),
        Decimal("0.00"),
    )
    cold_total = next(
        (
            record
            for record in detail_records
            if record["Kostenart"] == "Summe kalte Betriebskosten"
        ),
        None,
    )
    if cold_total is None:
        fail(f"{slug}: Summenzeile der kalten Betriebskosten fehlt")
    stated_cold = parse_amount(cold_total["Ihr Anteil"])

    summary_records = table_records(
        statement,
        {"Abrechnungsbereich", "Ihr Kostenanteil", "Ihre Vorauszahlungen", "Ergebnis"},
    )
    summary = {record["Abrechnungsbereich"]: record for record in summary_records}
    for label in ("Kalte Betriebskosten", "Heizkosten", "Gesamtergebnis"):
        if label not in summary:
            fail(f"{slug}: Abrechnungsergebnis {label!r} fehlt")
    stated_sum = parse_amount(summary["Gesamtergebnis"]["Ihr Kostenanteil"])
    stated_advances = parse_amount(summary["Gesamtergebnis"]["Ihre Vorauszahlungen"])
    stated_claim = parse_amount(summary["Gesamtergebnis"]["Ergebnis"])
    heating_share = parse_amount(summary["Heizkosten"]["Ihr Kostenanteil"])

    assert_amount(slug, "Summe der kalten Betriebskosten", position_sum, stated_cold)
    assert_amount(
        slug,
        "Gesamtkostenanteil",
        stated_sum,
        stated_cold + heating_share,
    )
    assert_amount(
        slug, "Vorauszahlungen aus Mietvertrag", stated_advances, expected_advances
    )
    assert_amount(slug, "Nachzahlung", stated_claim, stated_sum - stated_advances)

    area = Decimal("52.10")
    object_area = Decimal("2736.40")
    area_based = {
        "Grundsteuer",
        "Hausmeister",
        "Gartenpflege",
        "Gebäudereinigung",
        "Gebäude- und Haftpflichtversicherung",
    }
    for record in cold_positions:
        if record["Kostenart"] not in area_based:
            continue
        expected = money(
            parse_amount(record["Gesamtkosten Objekt"]) * area / object_area
        )
        assert_amount(
            slug,
            f"Flächenanteil {record['Kostenart']}",
            parse_amount(record["Ihr Anteil"]),
            expected,
        )

    water_sheet = base / "nebenkosten" / "berechnungsbogen-wasser-wohnung-braun-2025.md"
    heating_sheet = base / "nebenkosten" / "heizkosten-gesamtabrechnung-2025.md"
    assert_amount(
        slug,
        "Wasseranteil Verteilungsblatt",
        value_for_label(water_sheet, "Anteil Wasser und Abwasser"),
        next(
            parse_amount(record["Ihr Anteil"])
            for record in cold_positions
            if record["Kostenart"] == "Wasser und Abwasser"
        ),
    )
    assert_amount(
        slug,
        "Heizkosten-Einzelabrechnung",
        value_for_label(heating_sheet, "Heizkosten Wohnung"),
        heating_share,
    )
    heating_blocks = table_records(
        heating_sheet,
        {
            "Kostenblock",
            "Objektbetrag",
            "Berechnungsgrundlage Wohnung",
            "Anteil Wohnung",
        },
    )
    allocated = Decimal("0.00")
    total_cost = value_for_label(heating_sheet, "Umlagefähige Gesamtkosten")
    for label, percentage in (
        ("Grundkosten 30 Prozent", 30),
        ("Verbrauchskosten 70 Prozent", 70),
    ):
        row = next((row for row in heating_blocks if row["Kostenblock"] == label), None)
        if row is None:
            fail(f"{slug}: Heizkostenblock {label!r} fehlt")
        block_cost = parse_amount(row["Objektbetrag"])
        assert_amount(slug, label, block_cost, money(total_cost * percentage / 100))
        parts = row["Berechnungsgrundlage Wohnung"].split("/")
        if len(parts) != 2:
            fail(f"{slug}: Verteilungsquote nicht lesbar: {row}")
        numerator, denominator = (parse_amount(part) for part in parts)
        if denominator <= 0 or numerator < 0 or numerator > denominator:
            fail(f"{slug}: ungültige Verteilungsquote in {label}")
        expected = money(block_cost * numerator / denominator)
        assert_amount(
            slug,
            f"Wohnungsanteil {label}",
            parse_amount(row["Anteil Wohnung"]),
            expected,
        )
        if percentage == 30:
            assert_amount(slug, "beheizbare Wohnfläche", numerator, area)
            assert_amount(slug, "beheizbare Objektfläche", denominator, object_area)
        else:
            readings = table_records(
                heating_sheet, {"Raum oder Gerät", "Ablesung 2025"}
            )
            measured = sum(
                (
                    parse_amount(row["Ablesung 2025"])
                    for row in readings
                    if row["Raum oder Gerät"] != "Summe bewertete Einheiten"
                ),
                Decimal("0.00"),
            )
            assert_amount(slug, "Verbrauch aus Einzelgeräten", numerator, measured)
        allocated += expected
    assert_amount(slug, "Heizkosten aus Verteilungsquoten", heating_share, allocated)


def check_riedel_installment_plan() -> None:
    slug = "ratenplan-riedel-gebrochen"
    base = TESTAKTEN / slug
    monitoring = base / "konto" / "ratenmonitoring-kulanz.md"
    account = base / "konto" / "mietkonto-fbl5n.md"

    records = table_records(monitoring, {"Rate", "Soll", "Ist", "Status"})
    installments = [record for record in records if record["Rate"].isdigit()]
    planned = sum(parse_amount(record["Soll"]) for record in installments)
    paid = sum(parse_amount(record["Ist"]) for record in installments)
    summary = next((record for record in records if record["Rate"] == "Summe"), None)
    if summary is None:
        fail(f"{slug}: Summenzeile im Ratenmonitoring fehlt")

    assert_amount(slug, "Planbetrag", planned, Decimal("2600.00"))
    assert_amount(slug, "gezahlte Raten", paid, Decimal("1300.00"))
    assert_amount(
        slug, "offener Ratenrest", parse_amount(summary["Status"]), planned - paid
    )
    assert_amount(slug, "Mietkonto-Endsaldo", last_balance(account), planned - paid)


def check_krueger_enforcement() -> None:
    slug = "vollstreckung-krueger-titel-teilzahlung"
    base = TESTAKTEN / slug
    account = base / "konto" / "mietkonto-fbl5n.md"
    journal = base / "konto" / "tilgungsjournal-nach-teilzahlung.md"
    judgment = base / "titel" / "versaeumnisurteil-ag-wedding.md"
    cost_order = base / "titel" / "kostenfestsetzungsbeschluss.md"
    payment = base / "zahlung" / "zahlungsavis-teilzahlung-500.md"

    principal = regex_amount(
        judgment,
        r"verurteilt, an die Klägerin\s+([0-9.,]+) EUR",
    )
    costs = regex_amount(
        cost_order,
        r"erstattenden Kosten werden auf \*\*([0-9.,]+) EUR\*\*",
    )
    paid = value_for_label(payment, "Betrag")
    assert_amount(
        slug,
        "SAP-Buchsaldo ohne Zinsen",
        last_balance(account),
        principal + costs - paid,
    )

    records = table_records(
        journal,
        {
            "Forderungsbestandteil",
            "Ausgangsbetrag",
            "Zinslauf bis 15.06.2026",
            "Zahlung",
            "Rest",
        },
    )
    total = next(
        (record for record in records if record["Forderungsbestandteil"] == "Summe"),
        None,
    )
    principal_row = next(
        (
            record
            for record in records
            if record["Forderungsbestandteil"] == "Hauptforderung Versäumnisurteil"
        ),
        None,
    )
    if total is None or principal_row is None:
        fail(f"{slug}: Summen- oder Hauptforderungszeile im Tilgungsjournal fehlt")
    interest = parse_amount(total["Zinslauf bis 15.06.2026"])
    assert_amount(slug, "Tilgungsjournal-Zahlung", parse_amount(total["Zahlung"]), paid)
    assert_amount(
        slug,
        "Hauptforderungsrest nach Kosten und Zinsen",
        parse_amount(principal_row["Rest"]),
        principal - (paid - costs - interest),
    )


def check_schulz_mold_claim() -> None:
    slug = "mieterklage-schimmel-schulz-verteidigung"
    base = TESTAKTEN / slug
    lease = base / "vertrag" / "mietvertrag.md"
    account = base / "konto" / "mietkonto-fbl5n.md"
    complaint = base / "gericht" / "klageschrift-mieter-schimmel.md"
    logger = base / "technik" / "raumklima-logger-2026-02-19-bis-03-04.md"

    net = value_for_label(lease, "Nettokaltmiete")
    operating = value_for_label(lease, "Betriebskostenvorauszahlung")
    heating = value_for_label(lease, "Heizkostenvorauszahlung")
    gross = value_for_label(lease, "Bruttowarmmiete")
    assert_amount(slug, "Bruttowarmmiete", gross, net + operating + heating)

    account_records = table_records(account, {"Periode", "Soll", "Ist", "Saldo"})
    paid_months = [
        record
        for record in account_records
        if re.fullmatch(r"0[1-6] 2026", record["Periode"])
    ]
    if len(paid_months) != 6:
        fail(
            f"{slug}: erwartet sechs Mietmonate Januar bis Juni, gefunden {len(paid_months)}"
        )
    for record in paid_months:
        assert_amount(
            slug, f"Soll {record['Periode']}", parse_amount(record["Soll"]), gross
        )
        assert_amount(
            slug, f"Ist {record['Periode']}", parse_amount(record["Ist"]), gross
        )
        assert_amount(
            slug,
            f"Saldo {record['Periode']}",
            parse_amount(record["Saldo"]),
            Decimal("0"),
        )

    claim = record_for(
        complaint,
        {
            "Zeitraum",
            "Bruttowarmmiete",
            "Quote",
            "Monatsbetrag",
            "Monate",
            "Rückforderung",
        },
        "Zeitraum",
        "Januar bis Mai 2026",
    )
    monthly_reduction = money(gross * Decimal("0.20"))
    assert_amount(
        slug,
        "monatliche Minderungsbehauptung",
        parse_amount(claim["Monatsbetrag"]),
        monthly_reduction,
    )
    assert_amount(
        slug,
        "Rückforderungsantrag",
        parse_amount(claim["Rückforderung"]),
        monthly_reduction * Decimal(5),
    )

    gap_match = re.search(
        r"Zwischen (\d{2}\.\d{2}\.\d{4}), (\d{2}:\d{2}) Uhr, und "
        r"(\d{2}\.\d{2}\.\d{4}), (\d{2}:\d{2}) Uhr fehlen (\d+) Stunden",
        logger.read_text(encoding="utf-8"),
    )
    if gap_match is None:
        fail(f"{slug}: Zeitangaben der Logger-Datenlücke fehlen")
    start = datetime.strptime(
        f"{gap_match.group(1)} {gap_match.group(2)}",
        "%d.%m.%Y %H:%M",
    )
    end = datetime.strptime(
        f"{gap_match.group(3)} {gap_match.group(4)}",
        "%d.%m.%Y %H:%M",
    )
    stated_gap = int(gap_match.group(5))
    actual_gap = int((end - start).total_seconds() / 3600)
    if actual_gap != stated_gap:
        fail(
            f"{slug}: Logger-Lücke ist rechnerisch {actual_gap} Stunden, "
            f"angegeben sind {stated_gap}"
        )


CHECKS = (
    check_lange_bankwechsel,
    check_demir_five_installments,
    check_meier_partial_payment,
    check_kowalska_rent_and_jobcenter,
    check_becker_rent_increase,
    check_braun_operating_costs,
    check_riedel_installment_plan,
    check_krueger_enforcement,
    check_schulz_mold_claim,
)


def selftest() -> int:
    amount_cases = {
        "1.234,56 EUR": Decimal("1234.56"),
        "1234.56": Decimal("1234.56"),
        "1,234.56": Decimal("1234.56"),
        "1.234 EUR": Decimal("1234.00"),
        "-12,50 EUR": Decimal("-12.50"),
    }
    for raw, expected in amount_cases.items():
        actual = parse_amount(raw)
        if actual != expected:
            fail(f"Selbsttest {raw!r}: erwartet {expected}, erhalten {actual}")

    tables = markdown_tables_from_text(
        "# Beispiel\n\n"
        "| Feld | Betrag |\n"
        "|---|---:|\n"
        "| Hauptforderung | 1.000,00 EUR |\n\n"
        "Text\n\n"
        "| Rate | Soll | Ist |\n"
        "|---:|---:|---:|\n"
        "| 1 | 500,00 | 250,00 |\n"
    )
    if len(tables) != 2 or tables[1][1][0] != "1":
        fail(f"Tabellenparser-Selbsttest fehlgeschlagen: {tables!r}")

    print(
        "validate-testakten-financial-consistency Selbsttest OK "
        f"({len(amount_cases)} Betragsformate, 2 Tabellen)"
    )
    return 0


def main() -> int:
    if "--selbsttest" in sys.argv:
        return selftest()
    for check in CHECKS:
        check()
    print(
        "validate-testakten-financial-consistency OK "
        f"({len(CHECKS)} finanzielle Fachakten)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
