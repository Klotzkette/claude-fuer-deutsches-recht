#!/usr/bin/env python3
"""Prüft lokale Markdown-Ziele und Sprungmarken ohne Netzwerkzugriff."""

from __future__ import annotations

import html
import re
import sys
import tempfile
import unicodedata
import urllib.parse
from pathlib import Path


LINK_RE = re.compile(r"\[[^\]]*\]\(([^)\n]+)\)")
EXTERNAL_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*:")
ATX_HEADING_RE = re.compile(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$")
SETEXT_HEADING_RE = re.compile(r"^ {0,3}(?:=+|-+)[ \t]*$")
HTML_ID_RE = re.compile(
    r"<[a-z][a-z0-9:-]*\b[^>]*\bid\s*=\s*"
    r"(?:\"([^\"]+)\"|'([^']+)'|([^\s>]+))",
    re.IGNORECASE,
)
HTML_NAME_RE = re.compile(
    r"<a\b[^>]*\bname\s*=\s*"
    r"(?:\"([^\"]+)\"|'([^']+)'|([^\s>]+))",
    re.IGNORECASE,
)
FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})")


def iter_markdown_files(root: Path):
    for path in sorted(root.rglob("*.md")):
        if ".git" in path.parts:
            continue
        yield path


def link_destination(raw: str) -> str:
    """Entfernt einen optionalen Markdown-Linktitel vom eigentlichen Ziel."""

    target = raw.strip()
    if target.startswith("<"):
        end = target.find(">")
        if end != -1:
            return target[1:end]
    return target.split(maxsplit=1)[0] if target else ""


def github_slug(value: str) -> str:
    """Bildet für Repo-Überschriften die relevante GitHub-Slug-Teilmenge nach."""

    value = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", value)
    value = re.sub(r"<[^>]+>", "", value)
    value = html.unescape(value).strip().lower()
    value = value.replace("`", "").replace("*", "").replace("~", "")
    kept: list[str] = []
    for char in value:
        category = unicodedata.category(char)
        if char in {"-", "_"} or char.isspace():
            kept.append(char)
        elif category[0] in {"L", "M", "N"}:
            kept.append(char)
    return re.sub(r"\s+", "-", "".join(kept))


def markdown_anchors(path: Path) -> set[str]:
    anchors: set[str] = set()
    lines = path.read_text(encoding="utf-8").splitlines()
    fence: str | None = None

    def add_heading(value: str) -> None:
        base = github_slug(value)
        if not base:
            return
        candidate = base
        suffix = 1
        while candidate in anchors:
            candidate = f"{base}-{suffix}"
            suffix += 1
        anchors.add(candidate)

    for index, line in enumerate(lines):
        fence_match = FENCE_RE.match(line)
        if fence_match:
            marker = fence_match.group(1)[0]
            if fence is None:
                fence = marker
            elif marker == fence:
                fence = None
            continue
        if fence is not None:
            continue

        for pattern in (HTML_ID_RE, HTML_NAME_RE):
            for match in pattern.finditer(line):
                anchor = next(group for group in match.groups() if group is not None)
                anchors.add(html.unescape(anchor))

        heading_match = ATX_HEADING_RE.match(line)
        if heading_match:
            add_heading(heading_match.group(1))
            continue
        if index and SETEXT_HEADING_RE.match(line) and lines[index - 1].strip():
            add_heading(lines[index - 1].strip())

    return anchors


def resolve_markdown_target(path: Path, destination: str, root: Path):
    parsed = urllib.parse.urlsplit(destination)
    fragment = urllib.parse.unquote(parsed.fragment)
    relative = urllib.parse.unquote(parsed.path)
    candidate = path if not relative else path.parent / relative
    resolved = candidate.resolve()

    try:
        resolved.relative_to(root.resolve())
    except ValueError:
        return None, fragment, "link target escapes repository root"

    if resolved.is_dir() and (resolved / "README.md").is_file():
        resolved = resolved / "README.md"
    return resolved, fragment, None


def validate_root(root: Path) -> list[str]:
    errors: list[str] = []
    anchor_cache: dict[Path, set[str]] = {}

    for path in iter_markdown_files(root):
        text = path.read_text(encoding="utf-8")
        for match in LINK_RE.finditer(text):
            destination = link_destination(match.group(1))
            if not destination or EXTERNAL_RE.match(destination):
                continue

            line_no = text[: match.start()].count("\n") + 1
            resolved, fragment, resolution_error = resolve_markdown_target(
                path, destination, root
            )
            if resolution_error:
                errors.append(f"{path}:{line_no}: {resolution_error}: {destination}")
                continue
            if resolved is None or not resolved.exists():
                target = urllib.parse.unquote(urllib.parse.urlsplit(destination).path)
                errors.append(
                    f"{path}:{line_no}: missing local link target: {target or destination}"
                )
                continue
            if fragment and resolved.is_file() and resolved.suffix.lower() == ".md":
                anchors = anchor_cache.setdefault(resolved, markdown_anchors(resolved))
                if fragment not in anchors:
                    errors.append(
                        f"{path}:{line_no}: missing Markdown anchor "
                        f"#{fragment} in {resolved.relative_to(root.resolve())}"
                    )

    return errors


def selftest() -> int:
    with tempfile.TemporaryDirectory(prefix="markdown-links-") as temporary:
        base = Path(temporary)
        root = base / "repo"
        root.mkdir()
        (root / "README.md").write_text(
            "# Überblick\n\n"
            "## Wiederholt\n\n"
            "## Wiederholt\n\n"
            '<a id="direkt"></a>\n\n'
            "[Datei](ziel.md#ziel)\n"
            "[Dieselbe Datei](#überblick)\n"
            "[Doppelte Überschrift](#wiederholt-1)\n"
            "[Expliziter Anker](#direkt)\n",
            encoding="utf-8",
        )
        (root / "ziel.md").write_text("# Ziel\n", encoding="utf-8")
        if errors := validate_root(root):
            print(
                "validate-markdown-links selftest: gültige Links abgewiesen",
                file=sys.stderr,
            )
            print("\n".join(errors), file=sys.stderr)
            return 1

        (base / "ausserhalb.md").write_text("# Außerhalb\n", encoding="utf-8")
        (root / "defekt.md").write_text(
            "[Fehlende Datei](fehlt.md)\n"
            "[Fehlender Anker](ziel.md#fehlt)\n"
            "[Pfadflucht](../ausserhalb.md)\n",
            encoding="utf-8",
        )
        errors = validate_root(root)
        expected = (
            "missing local link target",
            "missing Markdown anchor",
            "escapes repository root",
        )
        if len(errors) != len(expected) or not all(
            any(marker in error for error in errors) for marker in expected
        ):
            print(
                "validate-markdown-links selftest: Defekte nicht vollständig erkannt",
                file=sys.stderr,
            )
            print("\n".join(errors), file=sys.stderr)
            return 1

    print("validate-markdown-links selftest OK")
    return 0


def main() -> int:
    if sys.argv[1:] == ["--selftest"]:
        return selftest()
    if sys.argv[1:]:
        print("Aufruf: validate-markdown-links.py [--selftest]", file=sys.stderr)
        return 2

    errors = validate_root(Path.cwd())
    if errors:
        print("\n".join(errors), file=sys.stderr)
        print(f"validate-markdown-links failed: {len(errors)} Fehler", file=sys.stderr)
        return 1

    print("validate-markdown-links OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
