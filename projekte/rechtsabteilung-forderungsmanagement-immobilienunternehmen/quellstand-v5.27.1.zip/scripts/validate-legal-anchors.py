#!/usr/bin/env python3
"""Prüft bekannte Rechtsfehler, Quellenstatus und Skill-Ankerzuordnung."""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
PLUGIN = ROOT / "forderungsmanagement-immobilien"

TEXT_ROOTS = [
    ROOT / "CLAUDE.md",
    ROOT / "README.md",
    ROOT / "forderungsmanagement-grosser-prompt.md",
    ROOT / "forderungsmanagement-kleiner-prompt.md",
    PLUGIN / "README.md",
    ROOT / "references",
    ROOT / "testakten",
    PLUGIN / "skills",
]

BANNED = {
    re.compile(r"7 U 173/25"): "nicht amtlich verifizierter Zukunftsanker",
    re.compile(r"C-732/22"): "falsch zugeordneter EuGH-Anker",
    re.compile(
        r"20\.06\.2024[^\n]*C-741/21"
    ): "falsches Entscheidungsdatum für EuGH C-741/21",
    re.compile(
        r"(?:Paragraf|§) 6 (?:Abs\.|Absatz) 2 RDG"
    ): "Paragraf 6 Abs. 2 RDG ist kein Inhouse-Privileg",
    re.compile(
        r"Kappungsgrenzen(?:verordnung|-Verordnung) vom 07\.05\.2018"
    ): "veraltete Berliner Verordnung",
    re.compile(
        r"(?<![0-9])(?:über|ab) (?:5\.000|5000) EUR"
    ): "veraltete allgemeine AG/LG-Grenze",
    re.compile(
        r"Amtsgericht Tempelhof-Kreuzberg|Amtsgericht Pankow/Weißensee|AG Berlin-Mitte"
    ): "veraltete oder falsche Berliner Gerichtsbezeichnung",
    re.compile(
        r"Mietspiegelfeld I3|Feld K3"
    ): "nicht amtliche Feldbezeichnung einer Berliner Mietspiegeltabelle",
    re.compile(
        r"berliner-mietspiegel-2024\.md"
    ): "veralteter Testanker nach Inkrafttreten des Berliner Mietspiegels 2026",
    re.compile(
        r"10963 Berlin-Mitte|Wilhelmstraße 14[^\n]*Amtsgericht Mitte"
    ): "falsche Orts- oder Gerichtszuordnung für die Wilhelmstraße-Testanschrift",
    re.compile(
        r"(?:Urt\.|Urteil)[^\n]{0,60}VIII ZR 17/25"
    ): "VIII ZR 17/25 ist für den Härtefallanker ein Beschluss",
    re.compile(
        r"(?:Urt\.|Urteil)[^\n]{0,60}VIII ZB 17/25"
    ): "VIII ZB 17/25 ist ein Beschluss",
    re.compile(
        r"24\.09\.2024[^\n]{0,80}VIII ZR 289/23|VIII ZR 289/23[^\n]{0,80}24\.09\.2024"
    ): "falsches Entscheidungsjahr für VIII ZR 289/23",
    re.compile(
        r"künftige Nutzungsentschädigung[^\n]{0,120}(?:stets|immer|zwingend)[^\n]{0,40}(?:Paragraf|§) 9 ZPO",
        re.IGNORECASE,
    ): "XII ZR 71/24 lässt bei künftiger Nutzungsentschädigung Paragraf 3 oder 9 ZPO offen",
    re.compile(
        r"Schriftformklausel bei Befristung prüfen"
    ): "Nutzungsart vor Formprüfung trennen; Gewerberaum unterliegt aktuell der Textform",
    re.compile(
        r"Gewinnerzielende Untervermietung ist nicht"
    ): "VIII ZR 228/23 erfasst nur Gewinn oberhalb der wohnungsbezogenen Aufwendungen",
    re.compile(
        r"Anker gegen gewinnbringende Untervermietung"
    ): "VIII ZR 228/23 nicht als pauschales Gewinnverbot verkürzen",
    re.compile(
        r"Bei Verzug einer Rate über 14 Tage wird der gesamte Restbetrag fällig"
    ): "Verfallklausel nicht als automatische Rechtsfolge ausgeben",
    re.compile(
        r"\| bis 5 Jahre \| 3 Monate \||\| 5 bis 8 Jahre \| 6 Monate \||\| über 8 Jahre \| 9 Monate \|"
    ): "Grenzen des Paragrafen 573c Abs. 1 BGB überlappen oder lassen den Achtjahresstichtag offen",
    re.compile(
        r"Widerspruchsfrist abgelaufen"
    ): "Widerspruch gegen Mahnbescheid ist bis zur Verfügung des Vollstreckungsbescheids möglich",
    re.compile(
        r"06-mandatsziel-renofa-triage"
    ): "interner Router heißt Fallziel, nicht Mandatsziel",
    re.compile(
        r"Frist 14 Tage|letzte Frist von 14 Tagen"
    ): "keine starre gesetzliche 14-Tage-Frist behaupten",
    re.compile(
        r"2 Monate plus Restmonat"
    ): "Zustimmungsfrist kalendarisch nach Paragraf 558b BGB formulieren",
    re.compile(
        r"Kostenfeststellungsurteil"
    ): "materielles Kostenurteil und prozessuale Kostengrundentscheidung trennen",
    re.compile(
        r"verlangt aber keine Belegeinsicht"
    ): "Braun-Akte enthält ein konkretes Belegeinsichtsverlangen",
    re.compile(
        r"unstreitige Zahlungspflicht bleibt zu prüfen"
    ): "bei offener Belegeinsicht keinen pauschal unstreitigen Teil unterstellen",
    re.compile(
        r"Vor Zustellung Skill 11 oder 23"
    ): "vor Zustellung erst Kostenpfad und Antragsreaktion klären; Einreichungspaket folgt danach",
    re.compile(
        r"Klageerwiderung, Mieterverein, Anwaltsschreiben oder gerichtlicher Hinweis"
    ): "gerichtliche Prozessreaktion und außergerichtliche Korrespondenz getrennt routen",
    re.compile(
        r"Skill 37 wertet Klageerwiderung, Mietervereinsschreiben oder Anwaltsschriftsatz aus"
    ): "Mieterverein und außergerichtlicher Anwalt gehören zu Skill 43",
    re.compile(
        r"klare Menüs, kurze Prüffragen, Tabellen, Ampel, Lückenliste und nächster Schritt"
    ): "veraltete generische Bedienformel; Arbeitskarte und Klartextaktion verwenden",
    re.compile(
        r"(?:seit|ab) (?:dem )?01\.06\.2025(?:(?!Jahresbetrag)[^\n]){0,160}42-fach",
        re.IGNORECASE,
    ): "seit 01.06.2025 gilt für Mietpreisbremsen-Feststellungen der Jahresbetrag nach Paragraf 41 Abs. 5 GKG; 42-fach ist nur Altfallrecht",
}

DOCKET_RE = re.compile(
    r"(?:"
    r"(?:[IVX]{1,4}|[1-9][0-9]{0,2})\s+"
    r"(?:ZR|ZB|ARZ|BvR|BvF|U|W|S|O|C)\s+[0-9]+/[0-9]{2}"
    r"|C-[0-9]+/[0-9]{2}"
    r")"
)

INTERNAL_TEST_DOCKETS = {
    "9 C 118/26",
    "12 C 187/26",
    "217 C 166/26",
}

REQUIRED = {
    "references/schriftsatz-und-argumentationsstandard.md": (
        "III ZR 81/24",
        "IX ZR 129/22",
        "IX ZR 209/23",
        "VII ZR 191/23",
        "§ 138 Abs. 1 bis 4 ZPO",
        "Kein Anlagenverweis ohne zugehörigen Tatsachensatz",
    ),
    "forderungsmanagement-immobilien/skills/06-fallziel-renofa-triage/SKILL.md": (
        "name: 06-fallziel-renofa-triage",
        "Fallziel",
        "genau eine nächste Arbeitsaktion in Klartext",
        "weder Skillnummern kennen noch einen Skill auswählen",
    ),
    "forderungsmanagement-immobilien/skills/07-rdg-grenzen-check/SKILL.md": (
        "Paragraf 2 Abs. 3 Nr. 6 RDG",
        "Paragraf 79 Abs. 2 S. 2 Nr. 1 ZPO",
    ),
    "forderungsmanagement-immobilien/skills/16-widerspruch-mieter-pruefen/SKILL.md": (
        "in Textform",
        "VIII ZR 270/22",
        "VIII ZR 17/25",
        "VIII ZR 277/25",
        "Paragraf 144 ZPO",
    ),
    "forderungsmanagement-immobilien/skills/02-mietakte-rekonstruieren/SKILL.md": (
        "Paragraf 578 Abs. 1 und 2 BGB",
        "Art. 229 Paragraf 70 Abs. 1 EGBGB",
        "XII ZR 51/25",
        "Gewerberaum",
        "BT-Drs. 21/6807 ist am 09.08.2026 nur an die Ausschüsse überwiesener Entwurf",
        "vorgeschlagene Sechsmonatsgrenze",
    ),
    "forderungsmanagement-immobilien/skills/11-verzugsschaden-berechnen/SKILL.md": (
        "Paragraf 13e Abs. 1 RDG",
        "VII ZR 93/25",
        "Bonitätsauskunft",
    ),
    "forderungsmanagement-immobilien/skills/14-ordentliche-kuendigung-pflichtverletzung/SKILL.md": (
        "VIII ZR 206/04",
        "VIII ZR 4/23",
        "| unter 5 Jahren | 3 Monate |",
        "| ab 5 bis unter 8 Jahren | 6 Monate |",
        "| ab 8 Jahren | 9 Monate |",
        "vorgeschlagene einmalige Schonfristwirkung auf die ordentliche Kündigung ist am 09.08.2026 nicht geltendes Recht",
    ),
    "forderungsmanagement-immobilien/skills/10-zahlungsplan-stundungsvereinbarung/SKILL.md": (
        "Paragraf 212 Abs. 1 Nr. 1 BGB",
        "Paragrafen 305c und 307 BGB",
        "Eine Gesamtfälligkeits- oder Verfallklausel ist optional",
    ),
    "forderungsmanagement-immobilien/skills/12-vorgerichtliche-letzte-frist/SKILL.md": (
        "Paragraf 543 Abs. 2 S. 1 Nr. 3 Buchst. a und b",
        "keine gesetzliche Wirksamkeitsvoraussetzung",
        "keine starre gesetzliche 14-Tage-Frist",
        "Paragraf 36 SGB XII",
    ),
    "forderungsmanagement-immobilien/skills/09-mietrueckstand-mahnung-erstellen/SKILL.md": (
        "keine starre gesetzliche 14-Tage-Frist",
        "Interne Bearbeitungskosten oder angebliche Kosten einer Kündigung",
    ),
    "forderungsmanagement-immobilien/skills/13-fristlose-kuendigung-zahlungsverzug/SKILL.md": (
        "fälligen Nutzungsentschädigung nach Paragraf 546a Abs. 1 BGB",
        "Eine bloße Zahlungsankündigung genügt nicht",
        "Paragraf 574 Abs. 1 S. 2 BGB",
    ),
    "forderungsmanagement-immobilien/skills/18-widerspruch-vollstreckungsbescheid/SKILL.md": (
        "Paragraf 694 Abs. 1 ZPO",
        "Paragraf 700 Abs. 3 ZPO",
        "Paragraf 339 Abs. 1 ZPO",
        "keine Ausschluss- oder Notfrist",
        "Paragraf 696 Abs. 1 ZPO",
        "Paragraf 697 Abs. 1 ZPO",
    ),
    "forderungsmanagement-immobilien/skills/17-mahnbescheid-online-antrag/SKILL.md": (
        "Paragraf 688 Abs. 2 ZPO",
        "Paragraf 689 Abs. 2 und 3 ZPO",
        "Paragraf 204 Abs. 1 Nr. 3 BGB",
        "Paragraf 167 ZPO",
        "kein gesetzliches Verbot",
    ),
    "forderungsmanagement-immobilien/skills/19-vollstreckungsbescheid-antrag/SKILL.md": (
        "Paragraf 699 Abs. 1 ZPO",
        "Paragraf 701 ZPO",
        "binnen sechs Monaten",
    ),
    "forderungsmanagement-immobilien/skills/20-zahlungsklage-mietrueckstand-erstellen/SKILL.md": (
        "Paragrafen 1122 bis 1125 ZPO",
        "Amtsgericht Schöneberg nur für seinen Gerichtsbezirk",
        "Eigenvertretung einer privaten GmbH durch Beschäftigte nicht automatisch",
        "reguläre Klage nach Paragraf 253 ZPO",
    ),
    "forderungsmanagement-immobilien/skills/21-klage-streitwert-gerichtskosten/SKILL.md": (
        "VIII ZB 80/20",
        "Betriebskostenvorauszahlungen bleiben",
        "XII ZR 71/24",
        "Für künftige Nutzungsentschädigung bis zur Herausgabe lässt XII ZR 71/24 ausdrücklich offen",
        "nie automatisch den Dreieinhalbjahreswert ansetzen",
        "VIII ZR 211/23",
        "seit dem 01.06.2025 unmittelbar der Jahresbetrag nach Paragraf 41 Abs. 5 GKG",
        "KV Nr. 1216 GKG mit 2.0 Gebühren",
        "KV Nr. 1217 GKG auf 1.0",
        "Eine bloß elektronisch eingereichte reguläre Klage bleibt bei KV Nr. 1210",
    ),
    "forderungsmanagement-immobilien/skills/23-klage-egvp-bea-einreichen/SKILL.md": (
        "VIII ZB 17/25",
        "geschlossene Störungskarte",
        "Paragraf 130a Abs. 4 S. 1 Nr. 3 ZPO",
        "Paragraf 10 ERVV",
        "Eine private GmbH fällt nicht allein wegen ihrer Rechtsform unter Paragraf 130d ZPO",
        "tatsächlich eingerichtetes eBO",
        "Paragrafen 1122 bis 1125 ZPO",
        "vorhandene Word- oder PDF-Klage darf nicht bloß als `Online-Verfahren` umbenannt werden",
        "REGULÄRES VERFAHREN",
    ),
    "forderungsmanagement-immobilien/skills/27-schonfristzahlung-erkennen/SKILL.md": (
        "Zahlung vor Zustellung ist kein Schonfristfall",
        "Skill `23` baut erst danach",
        "BT-Drs. 21/6807 schlägt eine einmalige Übertragung der Schonfristwirkung auf die ordentliche Kündigung vor",
        "nur Ausschussvorlage und nicht geltendes Recht",
    ),
    "forderungsmanagement-immobilien/skills/33-dokumentenmix-ocr-sichten/SKILL.md": (
        "Sofortscan über den gesamten sichtbaren Bestand",
        "Interne Skillnummern gehören nicht in die Nutzerentscheidung",
        "höchstens 20 Dateien oder 30 PDF-Seiten",
        "Fortsetzungsmarke",
    ),
    "forderungsmanagement-immobilien/skills/36-fallstrategie-bis-10000/SKILL.md": (
        "Kein Intake- oder Standard-Router",
        "Keine Skillnummern zur Auswahl stellen",
    ),
    "forderungsmanagement-immobilien/skills/29-mieterhoehungsverlangen-text/SKILL.md": (
        "VIII ZB 74/16",
        "kein gesetzliches Textformerfordernis",
        "01.09.2026",
        "Paragraf 561 BGB",
    ),
    "forderungsmanagement-immobilien/skills/30-zustimmungsklage-mieterhoehung/SKILL.md": (
        "innerhalb von drei weiteren Monaten",
        "30.11.2026",
        "Paragraf 558b Abs. 3 BGB",
        "01.09.2026",
    ),
    "forderungsmanagement-immobilien/skills/31-kappungsgrenze-mietpreisbremse/SKILL.md": (
        "Mietenbegrenzungsverordnung vom 11.11.2025",
        "seit dem 01.01.2026 bis zum 31.12.2029",
        "Miete zu Beginn des Dreijahreszeitraums",
        "VIII ZR 125/23",
        "VIII ZR 211/23",
        "seit dem 01.06.2025 der Jahresbetrag nach Paragraf 41 Abs. 5 GKG",
        "42-fachen Überschreitungsbetrag nach Paragraf 9 ZPO",
        "vorgeschlagene Möblierungszuschlagsformel nach Paragraf 556d Abs. 1a BGB-E",
        "am 09.08.2026 nicht geltendes Recht",
    ),
    "forderungsmanagement-immobilien/skills/22-zustaendigkeit-amtsgericht-pruefen/SKILL.md": (
        "bis einschließlich 10.000 EUR",
        "über 10.000 EUR",
        "Paragraf 29a Abs. 2 ZPO",
        "Paragraf 511 Abs. 2 ZPO",
        "Paragraf 517 ZPO",
        "Paragraf 520 Abs. 2 ZPO",
        "Online-Verfahren nach Paragrafen 1122 bis 1134 ZPO ist eine alternative Verfahrensart",
        "Das Amtsgericht Schöneberg nimmt seit 15.04.2026 ausschließlich für seinen eigenen Gerichtsbezirk teil",
        "regulärer oder Online-Verfahrensweg",
    ),
    "forderungsmanagement-immobilien/skills/25-raeumungsfrist-vollstreckung/SKILL.md": (
        "spätestens zwei Wochen",
        "ein Jahr",
        "Paragraf 765a",
    ),
    "forderungsmanagement-immobilien/skills/26-berliner-modell-raeumung/SKILL.md": (
        "ohne Abtransport durch den Gerichtsvollzieher",
        "binnen eines Monats",
        "Vorsatz und grobe Fahrlässigkeit",
        "Unpfändbare Sachen",
    ),
    "forderungsmanagement-immobilien/skills/32-datenschutz-mieterdaten/SKILL.md": (
        "keine pauschale datenschutzrechtliche Mindestaufbewahrung",
    ),
    "forderungsmanagement-immobilien/skills/37-klageerwiderung-auswerten/SKILL.md": (
        "VIII ZR 155/11",
    ),
    "forderungsmanagement-immobilien/skills/42-mieterklage-verteidigen/SKILL.md": (
        "VIII ZR 155/11",
        "VIII ZR 67/18",
        "VIII ZR 271/17",
        "VIII ZR 4/23",
        "VIII ZR 118/19",
        "VIII ZR 189/17",
        "VIII ZR 125/23",
        "VIII ZR 211/23",
        "Jahresbetrag nach Paragraf 41 Abs. 5 GKG",
    ),
    "forderungsmanagement-immobilien/skills/40-urkundsprozess-pruefen/SKILL.md": (
        "Paragrafen 592 bis 600 ZPO",
        "Paragraf 597 ZPO",
        "Paragraf 599 ZPO",
        "Paragraf 600 ZPO",
    ),
    "forderungsmanagement-immobilien/skills/41-vergleich-raten-prozess/SKILL.md": (
        "Paragraf 278 Abs. 6 ZPO",
        "Paragraf 794 Abs. 1 Nr. 1 ZPO",
        "Eine Gesamtfälligkeits- oder Verfallklausel ist optional",
    ),
    "forderungsmanagement-immobilien/skills/43-mieterverein-anwalt-korrespondenz/SKILL.md": (
        "VIII ZR 189/17",
        "VIII ZR 118/19",
    ),
    "forderungsmanagement-immobilien/skills/24-raeumungsklage-erstellen/SKILL.md": (
        "VIII ZR 4/23",
        "wohnungsbezogene Aufwendungen",
        "VIII ZR 277/25",
        "Paragraf 144 ZPO",
    ),
    "forderungsmanagement-immobilien/skills/46-kostenfestsetzung-antrag/SKILL.md": (
        "VIII ZR 4/23",
        "nicht automatisch eine Kostengrundentscheidung",
    ),
    "forderungsmanagement-immobilien/skills/44-betriebskosten-rueckstand-streit/SKILL.md": (
        "Paragraf 556 Abs. 4 Satz 2 BGB",
        "elektronische Bereitstellung",
        "VIII ZR 6/24",
        "VIII ZR 66/20",
        "VIII ZR 118/19",
        "VIII ZR 189/17",
        "rote Einreichungssperre",
        "vorgeschlagene Verweisung des Paragrafen 578 Abs. 1 BGB-E",
        "am 09.08.2026 nicht geltendes Recht",
    ),
    "forderungsmanagement-immobilien/skills/48-titulierte-forderung-vollstrecken/SKILL.md": (
        "Paragraf 366 BGB",
        "Paragraf 367 BGB",
        "Paragraf 750 ZPO",
        "Paragraf 751 ZPO",
        "Paragraf 798 ZPO",
        "Bis einschließlich 30.09.2026",
        "Paragrafen 754a und 829a ZPO",
        "Paragrafen 752a und 753a ZPO nennt nicht Beschäftigte",
        "PDF/XML nach Paragraf 829 Abs. 5 ZPO ist erst ab 01.01.2027",
    ),
    "forderungsmanagement-immobilien/skills/47-kostenbeschluss-pruefen/SKILL.md": (
        "Paragraf 104 Abs. 3 ZPO",
        "Beschwerdewert 300 EUR übersteigt",
        "Paragraf 11 Abs. 2 RPflG",
    ),
    "forderungsmanagement-immobilien/skills/50-vollstreckungsakte-monitoring/SKILL.md": (
        "Paragraf 197 Abs. 1 Nr. 3 BGB",
        "Paragraf 197 Abs. 2 BGB",
        "Paragraf 212 Abs. 1 Nr. 2 BGB",
        "Paragraf 212 Abs. 2 und 3 BGB",
        "Umstellungs-Wiedervorlage",
        "Pfändungsfreigrenzenbekanntmachung 2026",
        "PDF-/XML-Übermittlung des PfÜB-Formulars als Zukunftstermin",
    ),
    "forderungsmanagement-immobilien/skills/49-kontoermittlung-und-drittauskunft/SKILL.md": (
        "Paragraf 802l Abs. 1 S. 2 ZPO",
        "Kontenstammdatenabruf",
        "keine Kontostände",
        "keine solche Wertgrenze",
        "seit 01.07.2026 geltende Pfändungsfreigrenzenbekanntmachung 2026",
        "1.587,40 EUR",
        "Bis 30.09.2026 keine Erleichterung des neuen Paragrafen 829a ZPO",
        "PDF/XML nach Paragraf 829 Abs. 5 ZPO erst ab 01.01.2027",
    ),
    "references/rechtsstand-2026-verfahren-vollstreckung.md": (
        "15.04.2026",
        "01.07.2026",
        "01.10.2026",
        "01.01.2027",
        "Amtsgericht Schöneberg für seinen eigenen Gerichtsbezirk",
        "KV Nr. 1216 GKG",
        "1.587,40 EUR",
        "BGBl. 2026 I Nr. 152",
        "Beschäftigte einer Partei oder eines verbundenen Unternehmens nach § 79 Abs. 2 S. 2 Nr. 1 ZPO werden dort nicht genannt",
        "BT-Drs. 21/6807 nach erster Beratung an die Ausschüsse überwiesen",
        "ENTWURF - NICHT ANWENDEN",
        "Kein zukünftiger Stichtag und kein Gesetzesentwurf wird als bereits geltendes Recht formuliert",
    ),
    "references/gepruefte-bgh-anker-mietrecht.md": (
        "Berliner Mietspiegel 2026 ist am 28.05.2026 in Kraft getreten",
        "Hinweisbeschl. nach Paragraf 552a ZPO v. 28.11.2023 - VIII ZR 77/23",
        "Hinweisbeschl. nach Paragraf 552a ZPO v. 22.10.2024 - VIII ZR 249/23",
        "Hinweisbeschl. nach Paragraf 552a ZPO v. 07.10.2025 - VIII ZR 11/24",
        "Urt. v. 11.06.2026 - VII ZR 93/25",
        "Beschl. v. 28.10.2025 - VIII ZR 17/25",
        "VIII_ZR__17-25A.pdf",
        "Urt. v. 01.07.2026 - VIII ZR 125/23",
        "Urt. v. 01.07.2026 - VIII ZR 211/23",
        "Beschl. v. 07.07.2026 - VIII ZR 277/25",
        "seit 01.06.2025 der Jahresbetrag der Überschreitung nach Paragraf 41 Abs. 5 GKG",
        "Urt. v. 11.03.2026 - XII ZR 51/25",
        "Beschl. v. 27.05.2026 - XII ZR 71/24",
        "Für künftige Nutzungsentschädigung bis zur Herausgabe lässt der BGH ausdrücklich offen",
        "Urt. v. 24.09.2025 - VIII ZR 289/23",
        "Urt. v. 01.07.2026 - VIII ZR 4/23",
        "Mietenbegrenzungsverordnung vom 11.11.2025",
        "Urt. v. 07.02.2018 - VIII ZR 189/17",
        "Urt. v. 09.12.2020 - VIII ZR 118/19",
        "Urt. v. 05.12.2018 - VIII ZR 67/18",
        "Urt. v. 05.12.2018 - VIII ZR 271/17",
        "Wert des Beschwerdegegenstands 1.000 EUR übersteigt",
        "Pfändungsfreigrenzenbekanntmachung 2026",
        "Neue Paragrafen 754a und 829a ZPO nicht vorzeitig anwenden",
        "BT-Drs. 21/6807",
        "nur an die Ausschüsse überwiesener Entwurf",
    ),
    "references/leitentscheidungen-anker.md": (
        "EuGH, Urt. v. 11.04.2024 - C-741/21",
        "BGH, Urt. v. 11.06.2026 - VII ZR 93/25",
        "BGH, Beschl. v. 28.10.2025 - VIII ZR 17/25",
        "BGH, Urt. v. 01.07.2026 - VIII ZR 125/23",
        "BGH, Urt. v. 01.07.2026 - VIII ZR 211/23",
        "BGH, Beschl. v. 07.07.2026 - VIII ZR 277/25",
        "BGH, Urt. v. 01.07.2026 - VIII ZR 4/23",
        "BGH, Urt. v. 07.02.2018 - VIII ZR 189/17",
        "BGH, Urt. v. 09.12.2020 - VIII ZR 118/19",
        "BGH, Urt. v. 05.12.2018 - VIII ZR 67/18",
        "BGH, Urt. v. 05.12.2018 - VIII ZR 271/17",
        "Online-Verfahren: Paragrafen 1122 bis 1125 ZPO",
        "Elektronische Zwangsvollstreckung: Paragrafen 754a und 829a ZPO erst ab 01.10.2026",
        "Mietrechtsnovelle: BT-Drs. 21/6807",
        "bis Verkündung und einschlägigem Inkrafttreten gesperrt",
    ),
    "references/erv-dokumentenproduktion.md": (
        "zuletzt geändert durch Art. 2 des Gesetzes vom 22.06.2026",
        "BGH, Beschluss vom 02.12.2025 - VIII ZB 17/25",
        "Paragraf 130a Abs. 4 S. 1 Nr. 3 ZPO",
        "Paragraf 10 ERVV",
        "Eine private GmbH wird nicht allein wegen ihrer Rechtsform von Paragraf 130d ZPO erfasst",
    ),
    "forderungsmanagement-grosser-prompt.md": (
        "VII ZR 93/25",
        "VIII ZR 4/23",
        "VIII ZR 155/11",
        "VIII ZR 67/18",
        "VIII ZR 271/17",
        "VIII ZR 277/25",
        "VIII ZR 125/23",
        "VIII ZR 211/23",
        "§ 41 Abs. 5 GKG ab 01.06.2025",
        "VIII ZB 17/25",
        "XII ZR 51/25",
        "MietBegrV BE 2026",
        "Beschwer über 1.000 EUR",
        "VIII ZR 189/17",
        "§§ 592 bis 600 ZPO",
        "§ 130a Abs. 4 Nr. 3 ZPO/§ 10 ERVV",
        "Eine private GmbH ist nicht allein wegen ihrer Rechtsform nach § 130d aktiv nutzungspflichtig",
        "kurze Sofortkarte",
        "eine nächste Arbeitsaktion in Klartext",
        "2026-Onlineweg: §§ 1122 bis 1125 ZPO",
        "Neue §§ 754a, 829a ZPO erst ab 01.10.2026",
        "PDF/XML nach § 829 Abs. 5 erst ab 01.01.2027",
        "BT-Drs. 21/6807 ist am 09.08.2026 ein Regierungsentwurf, der nach erster Beratung an die Ausschüsse überwiesen wurde",
        "geplante Regeln zu Kurzzeitmiete, Möblierung, Indexmiete, Modernisierung und ordentlicher Kündigung nicht anwenden",
        "Aktuelle 2026-Entscheidungskarten",
        "Quellenstatus in jeder Fallkarte",
        "Phasensteuerung ohne manuelle Skillwahl",
    ),
    "forderungsmanagement-kleiner-prompt.md": (
        "VII ZR 93/25",
        "VIII ZR 4/23",
        "VIII ZR 155/11",
        "VIII ZR 67/18",
        "VIII ZR 271/17",
        "VIII ZR 277/25",
        "VIII ZR 125/23",
        "VIII ZR 211/23",
        "aktueller Streitwert Jahresüberschreitung nach § 41 Abs. 5 GKG",
        "VIII ZB 17/25",
        "XII ZR 51/25",
        "MietBegrV vom 11.11.2025",
        "Beschwer über 1.000 EUR",
        "189/17",
        "§ 688-Ausschlüsse",
        "§ 130a Abs. 4 Nr. 3 ZPO/§ 10 ERVV",
        "Eine private GmbH unterliegt § 130d nicht allein wegen ihrer Rechtsform",
        "Sofortkarte",
        "eine nächste Arbeitsaktion in Klartext",
        "Online 2026: §§ 1122 ff.",
        "§§ 754a/829a erst ab 01.10.",
        "PDF/XML erst ab 01.01.2027",
        "BT-Drs. 21/6807: am 09.08.2026 Regierungsentwurf, an Ausschüsse überwiesen",
        "BGB-E zu Kurzzeitmiete, Möblierung, Indexmiete, Modernisierung und ordentlicher Kündigung nicht anwenden",
    ),
    "testakten/mieterhoehung-becker-tempelhof/korrespondenz/mieterhoehungsverlangen.md": (
        "Kappungsgrenzen-Verordnung vom 14.03.2023",
        "Mietspiegeltabelle: **9.2, Zeile 85**",
        "§ 558b Abs. 1 BGB",
    ),
    "testakten/mietspiegel-berlin/berliner-mietspiegel-2026.md": (
        "mittlere Wohnlage laut Straßenverzeichnis 2026",
        "5,90 EUR/m²",
        "7,08 EUR/m²",
        "9,25 EUR/m²",
    ),
    "testakten/mieterhoehung-becker-tempelhof/objekt/merkmalbewertung-mietspiegel-2026.md": (
        "NICHT ZUR EINREICHUNG FREIGEGEBEN",
        "Tabelle | 9.2, Zeile 85",
    ),
    "testakten/nebenkosten-braun-nachzahlung-unbezahlt/aktennotiz/aktennotiz-01-nebenkostenwiderspruch-klagereife.md": (
        "Einreichungsampel bleibt rot",
        "VIII ZR 189/17",
        "VIII ZR 118/19",
    ),
    "testakten/nebenkosten-braun-nachzahlung-unbezahlt/README.md": (
        "verlangt mit Nachtrag vom 21.07.2026 Einsicht",
        "kein angeblich unstreitiger Teilbetrag unterstellt",
    ),
    "testakten/mieterhoehung-becker-tempelhof/aktennotiz/aktennotiz-01-mieterhöhungsprüfung.md": (
        "zwei getrennte Zeitgates",
        "30.11.2026",
    ),
    "testakten/vollstreckung-krueger-titel-teilzahlung/titel/kostenfestsetzungsbeschluss.md": (
        "300,00 EUR übersteigt",
    ),
}


def markdown_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    return sorted(path.rglob("*.md"))


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def main() -> int:
    errors: list[str] = []
    scanned: set[Path] = set()

    for source in TEXT_ROOTS:
        for path in markdown_files(source):
            if path in scanned or "gesamt-pdf" in path.parts:
                continue
            scanned.add(path)
            text = path.read_text(encoding="utf-8")
            for pattern, reason in BANNED.items():
                for match in pattern.finditer(text):
                    line = text.count("\n", 0, match.start()) + 1
                    errors.append(f"{rel(path)}:{line}: {reason}: {match.group(0)}")

    for name, needles in REQUIRED.items():
        path = ROOT / name
        if not path.is_file():
            errors.append(f"{name}: Pflichtdatei fehlt")
            continue
        text = path.read_text(encoding="utf-8")
        for needle in needles:
            if needle not in text:
                errors.append(f"{name}: Pflichtanker fehlt: {needle}")

    commercial_anchor = "XII ZR 51/25"
    for skill_number in ("28", "29", "30", "31"):
        path = next((PLUGIN / "skills").glob(f"{skill_number}-*/SKILL.md"), None)
        if path is not None and commercial_anchor in path.read_text(encoding="utf-8"):
            errors.append(
                f"{rel(path)}: Gewerberaumanker {commercial_anchor} ist einem Wohnraum-Mieterhöhungsskill zugeordnet"
            )

    reference_files = sorted((ROOT / "references").glob("*.md"))
    verified_reference_files = [
        ROOT / "references" / "gepruefte-bgh-anker-mietrecht.md",
        ROOT / "references" / "rechtsprechungsradar-mietrecht-2021-2026.md",
        ROOT / "references" / "erv-dokumentenproduktion.md",
        ROOT / "references" / "schriftsatz-und-argumentationsstandard.md",
    ]
    reference_text = "\n".join(
        path.read_text(encoding="utf-8") for path in verified_reference_files
    )
    skill_files = sorted((PLUGIN / "skills").glob("*/SKILL.md"))
    used_dockets: set[str] = set()
    operational_files = [
        path
        for path in scanned
        if "references" not in path.parts and path.suffix == ".md"
    ]
    for path in operational_files:
        text = path.read_text(encoding="utf-8")
        for docket in DOCKET_RE.findall(text):
            used_dockets.add(docket)
            if docket not in reference_text and docket not in INTERNAL_TEST_DOCKETS:
                errors.append(
                    f"{rel(path)}: Aktenzeichen ohne Zuordnung in einer geprüften Referenz: {docket}"
                )

    root_refs = {path.name: path for path in reference_files}
    plugin_refs = {path.name: path for path in (PLUGIN / "references").glob("*.md")}
    for name in sorted(root_refs.keys() | plugin_refs.keys()):
        root_ref = root_refs.get(name)
        plugin_ref = plugin_refs.get(name)
        if root_ref is None or plugin_ref is None:
            errors.append(f"references/{name}: Repo- oder Plugin-Spiegel fehlt")
        elif root_ref.read_bytes() != plugin_ref.read_bytes():
            errors.append(
                f"forderungsmanagement-immobilien/references/{name}: nicht mit Repo-Quelle synchron"
            )

    if errors:
        print("validate-legal-anchors: FEHLER")
        for error in errors:
            print(f"  {error}")
        return 1

    print(
        "validate-legal-anchors OK "
        f"({len(skill_files)} Skills, "
        f"{len(used_dockets - INTERNAL_TEST_DOCKETS)} zugeordnete Rechtsprechungsanker)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
