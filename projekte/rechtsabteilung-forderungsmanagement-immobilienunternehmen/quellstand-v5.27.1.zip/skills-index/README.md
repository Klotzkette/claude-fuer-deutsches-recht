# Skills-Index: Detailseiten pro Plugin

Eine Detailseite pro Plugin mit allen Skills, Beschreibungen und Einzel-Downloads. Stand: `v5.27.1`.

Die Aufteilung hält die Navigation schnell und vermeidet eine unnötig große Haupttabelle.

- [Zurück zur Gesamtübersicht](../SKILLS.md)

## Alle Detailseiten

- [forderungsmanagement-immobilien](./forderungsmanagement-immobilien.md) (50 Skills)
- [schriftsatzwerkstatt-bea](./schriftsatzwerkstatt-bea.md) (9 Skills)
