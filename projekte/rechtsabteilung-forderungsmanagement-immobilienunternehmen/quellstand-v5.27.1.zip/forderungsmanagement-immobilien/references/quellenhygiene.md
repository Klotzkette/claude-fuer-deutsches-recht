# Quellenhygiene

Diese Regeln gelten repo-weit für alle Skills, sobald Normen, Rechtsprechung, Literatur, Verwaltungsquellen, Register oder behördliche Praxis tragend werden.

- Keine halluzinierten Aktenzeichen, Fundstellen oder Randnummern.
- Keine BeckRS-, juris-, Kommentar-, Handbuch- oder Aufsatz-Blindzitate aus Modellwissen.
- Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle ausgeben, sofern sie tragend ist.
- Normenstand, Behördenhinweise, Formulare und Verfahrensrecht live oder anhand bereitgestellter Quellen prüfen, wenn das Ergebnis davon abhängt.
- Unsicherheiten, Annahmen und fehlende Unterlagen offen markieren.
- Mieter-, Personal-, Gesundheits-, Strafakten- und vertrauliche Unternehmensdaten nur in rechtskonformer Umgebung verarbeiten.
- Zitierweise nach `references/zitierweise.md`; Methodik bei Subsumtion nach `references/methodik-buergerliches-recht.md`.
