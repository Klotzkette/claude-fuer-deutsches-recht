# forderungsmanagement-immobilien

## In 60 Sekunden zum ersten Ergebnis

1. [Plugin-ZIP herunterladen](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien.zip) und in der vorgesehenen Plugin-Verwaltung laden.
2. Den neuen Aktenordner oder bei einer laufenden Akte den bisherigen Arbeitsstand zusammen mit dem Neuzugang bereitstellen.
3. Senden: `Neuer Fall. Prüfe den gesamten Ordner, sichere zuerst alle Fristen und arbeite ohne Skillauswahl bis zur nächsten freigabefähigen Entscheidung weiter.`

Das Plugin fragt nicht nach einer Skillnummer. Es zeigt zuerst Aktenmodus, Akten-ID/Stichtag, früheste mögliche Frist samt Quelle, Ampel und Grund, Dateistand, höchstens drei Kernlücken und genau eine nächste Arbeitsaktion. Danach inventarisiert und triagiert es automatisch weiter. Für Neuzugänge, Gerichtspost und fertige Schriftsätze stehen unter [Schnellstart](#schnellstart) weitere Ein-Satz-Aufträge.

Bei klarer Aufgabe folgt sofort der passende Entwurf: neue Zahlung → Restrechnung; fehlender Betriebskostenbeleg → konkrete Anfrage; Mieterpost → Antwort; Gerichtspost → Frist und Prozessreaktion. Bereits gelesene Unterlagen und beantwortete Fragen werden übernommen. Ein blockiertes Außendokument hindert nicht die Bearbeitung unabhängiger Unterlagen.

<!-- BEGIN plugin-sofort-download-section (autogen) -->
## Release-Assets

| Einstieg | Link |
|---|---|
| Plugin sofort installieren | [forderungsmanagement-immobilien.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien.zip) |
| Nur technische beA-Endfertigung installieren | [schriftsatzwerkstatt-bea.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/schriftsatzwerkstatt-bea.zip) |
| Marketplace einbinden | [marketplace.json](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/marketplace.json) |
| Schnellstartprompt einzeln testen | [forderungsmanagement-immobilien-kleiner-prompt-skill.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.zip) |
| Werkstattprompt einzeln testen | [forderungsmanagement-immobilien-grosser-prompt-skill.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-grosser-prompt-skill.zip) |
| Alle Pakete auswählen | [Zentrale Sofort-Downloads](../README.md#sofort-downloads-latest-release) |
| Testakte einzeln laden | [Testakten-Downloads](../testakten/README.md#download-pakete) |
| Vollständiges Offline-Paket | [immobilien-forderungsmanagement-dokumentation.zip](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/immobilien-forderungsmanagement-dokumentation.zip) |
| Vollständige Asset-Liste | [release-katalog.md](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/release-katalog.md) |
| Downloads prüfen | [checksums-sha256.txt](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/checksums-sha256.txt) |

<!-- END plugin-sofort-download-section (autogen) -->

Plugin für die Immobilien-Rechtsabteilung eines deutschen Immobiliengroßkonzerns. Zielgruppe sind Rechtsanwalts- und Notarfachangestellte, Renofas und Rechtsfachwirte, die Forderungsmanagement, Mieterhöhungen, Räumung, Prozessreaktion, Kostenfestsetzung und Vollstreckung der Konzerngesellschaften bearbeiten — von SAP- und DMS-Intake bis zur Vollstreckungsakte.

Der Bedienmodus ist für starke Fachangestellte gebaut, nicht für abgehobene Anwaltskommunikation: kurze Arbeitskarten, begründete Entscheidungsfragen, kompakte Tabellen, Ampeln, Beleglücken und genau eine nächste Arbeitsaktion. Nur echte Unternehmensentscheidungen erscheinen als kleine Auswahl. Die Bearbeitung bleibt juristisch korrekt, aber sie spricht die Arbeitssprache einer Forderungsabteilung.

## Schnellnavigation

| Ich will ... | Link | Was dort steht |
|---|---|---|
| Alle Downloads sehen | [Zentrale Sofort-Downloads](../README.md#sofort-downloads-latest-release) | Plugin, Prompt-Skills, Dokumentationspaket, Testakten, Katalog und Prüfsummen |
| Plugin installieren | [Installation im Konzern](#installation-im-konzern) | Release-Asset, Marketplace-Datei, Pilotgruppe und Rollout-Regel |
| Einzel-Skill-Fallback nutzen | [Cloud-Co-Work und Einzel-Skill-Fallback](#cloud-co-work-und-einzel-skill-fallback) | Schnellstart- und Werkstattprompt als Standalone-Skills |
| Akten hochladen | [Welche Unterlagen die Bearbeitung braucht](#welche-unterlagen-die-bearbeitung-braucht) | SAP, FBL5N, DMS, Vertrag, Korrespondenz und Gerichtsunterlagen |
| Ohne Skillauswahl loslegen | [Schnellstart](#schnellstart) | Autostart für neuen Fall, Projektordner, SAP-Input und Triage |
| Fachpfad finden | [Workflow-Phasen](#workflow-phasen) und [Bedienmuster im Tagesgeschäft](#bedienmuster-im-tagesgeschäft) | Pfade für Zahlung, Räumung, Mieterhöhung, Prozessreaktion, Kosten und Vollstreckung |
| Schriftsatz gerichtsfertig machen | [Gerichtsfertiges Dokumentenpaket](#gerichtsfertiges-dokumentenpaket) | K-/B-Anlagen, Einzel-PDFs, Rollengate, beA/eBO/schriftlicher Weg, Signatur und Eingang |
| Bereits fachlich fertige Unterlagen nur technisch endfertigen | [Eigenständige beA-Schriftsatzwerkstatt](../schriftsatzwerkstatt-bea/README.md) | neun Skills ohne Rechtsprüfung für Konvertierung, Anlagen, Manifest, Signaturweg und Eingang |
| Pilotbetrieb abnehmen | [Abnahme im Pilotbetrieb](#abnahme-im-pilotbetrieb) und [Smoke-Tests](../tests/smoke-tests.md) | Prüffälle, Kontrollpunkte und Rollout-Abnahme |
| Testakten laden | [Testakten](#testakten) und [Testakten-README](../testakten/README.md) | Neun Fachfälle, Mietspiegel-Referenz und Downloadformen |
| Quellen kontrollieren | [Quellen und Konsistenz](#quellen-und-konsistenz) | Zitierweise, BGH-Anker und mitgelieferte Plugin-Referenzen |
| Einzelnen Skill öffnen | [Alle Skills im Überblick](#alle-skills-im-überblick) | 50 Arbeitsnamen mit Beschreibung und direktem Link zur jeweiligen `SKILL.md` |

## Zweck

Die Abteilung übernimmt für den Konzern Mieter-Forderungs- und Vertragsangelegenheiten bis einschließlich Amtsgerichts-Verfahren. Wohnraummietsachen sind nach Paragraf 23 Nr. 2a GVG stets AG-Sache. Eigene Angelegenheit nach Paragraf 2 Abs. 1 RDG, Konzernverbund nach Paragraf 2 Abs. 3 Nr. 6 RDG und Prozessvertretung nach Paragraf 79 Abs. 2 ZPO werden getrennt geprüft. Eine interne 10.000-EUR-Grenze dient als Bearbeitungs- und Freigabekriterium.

Schwerpunkte:

- Mietrückstände außergerichtlich (Zahlungserinnerung, Mahnung, Ratenvereinbarung) und gerichtlich (regelmäßig Zahlungsklage; Mahnverfahren nur optional)
- Fristlose und ordentliche Kündigungen bei Zahlungsverzug, Pflichtverletzung
- Räumungsklagen einschließlich Berliner Modell Paragraf 885a ZPO
- Mieterhöhungen nach Paragraf 558 BGB inklusive Zustimmungsklage
- Klageerwiderung, Replik und Verteidigung gegen Mieterklagen
- Kostenfestsetzung und Vollstreckung nach Urteil, Vergleich, Vollstreckungsbescheid oder Kostenfestsetzungsbeschluss
- Korrespondenz mit Hausverwaltung, Buchhaltung, Gerichtsvollziehern, Sozialämtern, Jobcentern, Mieterverein, Anwalt der Gegenseite und eigener externer Kanzlei

Was die Abteilung nicht ohne Eskalation macht: Landgerichts-Verfahren, Berufung/Revision, BGH-Sachen, Insolvenzanmeldungen, Strafrecht und umfangreiche Sachverständigenstreitigkeiten — dafür gibt es den Skill `08-eskalation-an-anwalt`.

## Installation im Konzern

1. Das [Plugin-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien.zip) aus dem aktuellen GitHub-Release herunterladen.
2. Vor dem Rollout prüfen: Der Release-Workflow und die Stufe `Release-Assets remote validieren` müssen grün sein. [Release-Katalog](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/release-katalog.md) und [SHA-256-Prüfsummen](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/checksums-sha256.txt) müssen den veröffentlichten Asset-Satz vollständig abbilden.
3. Das ZIP in der vorgesehenen Plugin-Verwaltung der Zielumgebung hochladen.
4. Optional die [Marketplace-Datei](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/marketplace.json) für einen internen Marketplace verwenden.
5. Pilotgruppe aktivieren: Forderungsmanagement, Mietrecht, Prozesskoordination, eine fachliche Freigabeperson.
6. Testlauf mit den neun Fachfällen und der Mietspiegel-Referenzakte aus dem Release durchführen, bevor Live-Akten verwendet werden.

Für produktive Nutzung immer ein getaggtes Release verwenden. Branches sind Arbeitsstände und nicht der empfohlene Rollout-Stand. Das [Offline-Paket](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/immobilien-forderungsmanagement-dokumentation.zip) enthält den vollständigen getrackten Repo-Inhalt ohne Git-Metadaten und Build-Abfall; relative Links funktionieren nach dem Entpacken.

## Cloud-Co-Work und Einzel-Skill-Fallback

Wenn die Zielumgebung kein komplettes Plugin laden kann, gibt es zwei Standalone-Skill-Assets:

| Asset | Einsatz |
|---|---|
| [Schnellstartprompt-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-kleiner-prompt-skill.zip) | Cloud-Co-Work, kleine Kontexte und schneller Pilot |
| [Werkstattprompt-ZIP](https://github.com/Klotzkette/immobilien-forderungsmanagement/releases/latest/download/forderungsmanagement-immobilien-grosser-prompt-skill.zip) | großer Kontext und vollständiger Workflow von Intake bis Vollstreckung |

Beide ZIPs enthalten genau eine `SKILL.md` an der ZIP-Wurzel. Der Schnellstartprompt ist die robuste Fallback-Variante und muss unter 7.500 Zeichen bleiben. Das volle Plugin-ZIP bleibt der Produktivstandard, weil es alle 50 Skills und die mitgelieferten Quellenleitplanken enthält.

## Welche Unterlagen die Bearbeitung braucht

Ein guter Upload-Satz besteht aus:

- SAP-Statusauszug mit Objekt, Mieter, Vermieterin, Vertragsnummer, Saldo und Bearbeitungsstand.
- FBL5N- oder vergleichbarer Mietkontoauszug mit Sollstellung, Ist-Zahlung, Buchungstexten und Saldo.
- DocuWeb-, DATEV-, RA-MICRO-, DocuWare- oder sonstiger E-Akte-/DMS-Export mit Dokumenten, Registern und Metadaten.
- Mietvertrag, Nachträge, Mieterhöhungsverlangen, Betriebskostenunterlagen und sonstige Vertragsdokumente.
- Korrespondenz: Mahnung, Zahlungsvereinbarung, Kündigung, Schreiben des Mieters, Mieterverein, Rechtsanwalt, Jobcenter, Sozialamt.
- Gerichtsunterlagen: Klage, Klageerwiderung, Verfügungen, Hinweise, Vergleich, Urteil, Kostenfestsetzungsbeschluss, Vollstreckungsunterlagen.

Unvollständige Unterlagen sind kein Abbruchgrund. Die Intake-Skills erzeugen dann eine Beleglückenliste und stellen Rückfragen an die Hausverwaltung, Buchhaltung oder Prozesskoordination.

## E-Akte- und DMS-Anschluss

Für DocuWeb/DocuWare-artige DMS, DATEV-Dokumentenablage, RA-MICRO E-Akte, SAP DMS, Datenbankexporte, XML-Importe, Middleware und MCP-/Kontext-Gateways gilt derselbe Anschlussmodus:

1. Skills 01 und 33 sichern Herkunftssystem, Fremd-Aktenzeichen, Dokument-ID, Register, Exportdatum, Dateipfad und Fristbezug.
2. Skill 34 erzeugt neutrale Übergabeformate: `fallakte.json`, `dms-register.csv`, bei Legacy-Bedarf `fallakte.xml`, bei MCP-Planung `mcp-context-manifest.json` und bei offenen Fragen `schnittstellenauftrag.md`.
3. Originaldateien bleiben unverändert; PDF/A oder OCR-PDF wird nur als Arbeitskopie ausgewiesen.
4. Importfähigkeit wird erst grün markiert, wenn Feldmapping, Rechte, Pflichtfelder, Importweg, Testsystem, Dublettenlogik und Rückexport bekannt sind.
5. Schreibende Aktionen in Zielsystemen bleiben gesperrt, bis Freigabe, Protokollierung und Rollback geklärt sind.

## Workflow-Phasen

| Phase | Skills | Inhalt |
|---|---|---|
| A | 01-05 | SAP-Akten-Intake (Statusauszug, Mietvertrag, Mietkonto, Belegmatrix, Chronologie) |
| B | 06-08 | Triage und Rollen-Check (RDG, Eskalation, externe RA-Steuerung) |
| C | 09-12 | Außergerichtliche Forderungssteuerung |
| D | 13-16 | Kündigung (fristlos, ordentlich, Zustellung, Widerspruch) |
| E | 17-19 | Optionales gerichtliches Mahnverfahren nur nach Rückfrage |
| F | 20-23 und 39 | Zahlungsklage, Beweis-/Anlagenmanifest und gerichtsfertiges Einreichungspaket |
| G | 24-27 | Räumungsklage |
| H | 28-31 | Mieterhöhung |
| I | 32 | Datenschutz |
| J | 33-36 | Dokumentenmix, SAP-Normalisierung, Beleglücken, Fallstrategie bis 10.000 EUR |
| K | 37-45 | Klageerwiderung, Replik, Beweisplan, Urkundsprozess, Vergleich, Mieterklage, Betriebskosten, Hausverwaltung |
| L | 46-50 | Kostenfestsetzung, Kostenbeschluss, Vollstreckung, Kontoermittlung, Monitoring |

## Schnellstart

Autostart-Regel: Die Bearbeiter sollen keinen Skill auswählen müssen. Der universelle Auftrag lautet: `Neuer Fall. Prüfe den gesamten Ordner, sichere zuerst alle Fristen und arbeite ohne Skillauswahl bis zur nächsten freigabefähigen Entscheidung weiter.` Auch kürzere Formulierungen wie "neuer Fall", "hier ist der Ordner", "mach die Akte fertig" oder "prüf das Projekt" und mehrere hochgeladene Dateien starten `33-dokumentenmix-ocr-sichten`. Dieser Skill liefert zuerst die einheitliche fristzentrierte Sofortkarte und arbeitet danach automatisch bis zur Start- oder Änderungskarte weiter. Dem Nutzer wird genau eine nächste Arbeitsaktion in Klartext gezeigt; die Skill-ID bleibt interne Routinginformation.

Discovery-Regel: Bei einem neuen Akten-Upload sind nur drei Startpunkte favorisiert. `33-dokumentenmix-ocr-sichten` ist der Default für gemischte oder unklare Dateien und Projektordner. `01-sap-akte-importieren` wird nur bei sauberem SAP-/Mietkonto-Input geladen. `06-fallziel-renofa-triage` folgt nach abgeschlossenem Intake oder wenn der Nutzer schon eine klare Fallkarte liefert. Fachskills `09` bis `50` werden erst nach Startkarte und Routing geladen.

Vertrag für die erste Antwort: Vor jeder langen Analyse erscheint genau eine Sofortkarte mit `Modus`, `Akten-ID/Stichtag`, `Fallart`, `Frist/Quelle`, `Ampel/Grund`, `Dateistand`, `Kernlücken` und `Jetzt`. `Jetzt` enthält genau eine verständliche Arbeitsaktion. Nicht blockierende Unsicherheiten werden als gelbe Lücke notiert; nur Fragen, deren Antwort die sofortige Frist-, Rollen- oder Maßnahmenentscheidung ändert, werden gebündelt gestellt. Danach läuft die Bearbeitung ohne den Befehl "weiter" fort.

### Direkt nutzbare Startaufträge

Diese Sätze sind für Schulung und Tagesgeschäft gedacht. Sie lösen den richtigen Startskill aus, ohne dass Bearbeiter eine Skill-Liste kennen müssen.

| Situation | Nutzersatz | Erwarteter Start |
|---|---|---|
| Neuer Aktenordner oder Upload-Bundle | `Neuer Fall. Prüfe den gesamten Ordner, sichere zuerst alle Fristen und arbeite ohne Skillauswahl bis zur nächsten freigabefähigen Entscheidung weiter.` | sofort einheitliche Sofortkarte, danach automatisch Dokumenteninventar, Startkarte und Fachpfad |
| SAP-Statusauszug plus Mietkonto | `Bitte lies den SAP-Auszug und das Mietkonto ein und prüfe den Rückstand.` | `01-sap-akte-importieren`, danach Konto, Belegmatrix und Triage |
| Neue Zahlung oder Unterlage zur laufenden Akte | `Hier ist der bisherige Stand mit einer neuen Zahlung und neuer Post. Bitte nur fortschreiben.` | Änderungskarte über `33`, bei sauberem SAP-/Mietkonto-Delta über `01` oder `03`; danach ereignisbezogener Fachskill |
| Schon sortierte Fallkarte | `Hier ist die Fallkarte. Bitte entscheide den nächsten Forderungsmanagement-Schritt.` | `06-fallziel-renofa-triage` |
| Gerichtspost oder Klageerwiderung | `Bitte werte die neue Gerichtspost aus und zeige Frist, Einwendungen, Beweise und nächsten Schriftsatz.` | Fristen- und Dokumentencheck, danach Prozesskarte und Reaktionsentwurf |
| Fertiger Schriftsatz mit Anlagen | `Bitte finalisiere den Schriftsatz als gerichtsfertiges Einreichungspaket.` | Beweis-/Anlagenmanifest, danach Rollengate und technischer Einreichungspfad |
| Nach Urteil, Vergleich oder KFB | `Bitte prüfe Kosten, Fristen, Zahlung und den nächsten Vollstreckungsschritt.` | `46-kostenfestsetzung-antrag`, `47-kostenbeschluss-pruefen` oder `48-titulierte-forderung-vollstrecken` |

### Schneller Zwei-Phasen-Start

Bei großen Uploads nicht warten, bis jedes Dokument vollständig ausgewertet ist. Erst kommt die Sofortkarte, dann die tiefe Aktenarbeit.

1. Phase 1: gesamten sichtbaren Bestand auf Gerichtspost, Zustellung, Frist, Zahlung, Kündigung und defekte Dateien scannen; dann eine kurze Sofortkarte liefern.
2. Phase 2: ohne erneute Aufforderung zuerst Gerichts- und Zustelldokumente, dann Zahlung/Konto, Kündigung/Vertrag und übrige Belege vertiefen.
3. Je Stapel höchstens 20 Dateien oder 30 PDF-Seiten vertiefen; bei einem neuen roten Risiko sofort stoppen.
4. Nach jedem Stapel eine Fortsetzungsmarke mit Akten-ID, Stichtag, verarbeitet/offen, letzter Quelle/Seite, frühester Frist und nächstem Stapel sichern. Nach Unterbrechung dort fortsetzen und unveränderte Unterlagen nicht erneut ausgeben.
5. Wenn OCR oder Scanqualität bremst: Lesbarkeitsproblem markieren, aber die übrigen lesbaren Unterlagen weiter auswerten.
6. Sichtbare Tabellen auf höchstens sieben Spalten begrenzen; technische Metadaten getrennt ausgeben.
7. Niemals zuerst fragen, welchen Skill die Bearbeiter nutzen wollen. Das Plugin wählt den Startpfad und begründet ihn kurz.

### Laufende Akte ohne Neustart

Wenn Akten-ID, Startkarte, Chronologie oder Prozesskarte vorliegen, verarbeitet das Plugin neue Zahlung, Gerichtspost, Korrespondenz, KFB oder DMS-Datei als Delta. Es hält den letzten Stichtag fest, vergleicht Alt und Neu für Saldo, Frist, Beweisstatus und Prozesslage, markiert überholte Entwürfe und schreibt nur die betroffenen Tabellen fort. Fehlt ein belastbarer Altstand, fällt der Vorgang kontrolliert auf den Vollintake zurück.

Die erste Ausgabe ist eine kompakte Sofortkarte. Danach folgt die Änderungskarte mit Stichtag alt/neu, Neuzugang, geänderten Tatsachen und Beträgen, unverändertem Kernstand, überholter Annahme, Sofortfrist und genau einer nächsten Arbeitsaktion in Klartext. Dadurch bleibt die Akte schnell, prüfbar und ohne stillen Zustandsverlust bearbeitbar.

### Vollintake in acht Schritten

1. Projektordner oder Upload-Bundle mit `33-dokumentenmix-ocr-sichten` inventarisieren.
2. Saubere SAP-/Mietkonto-Teile per `01-sap-akte-importieren` strukturieren.
3. Mietakte mit `02-mietakte-rekonstruieren` zusammenfügen.
4. Konto auslesen `03-kontoauszug-mietkonto-auslesen`.
5. Belegmatrix `04-belegmatrix-aufbauen`.
6. Chronologie `05-chronologie-fallakte`.
7. Triage `06-fallziel-renofa-triage` — Fallziel, Rollenbefugnis und RA-Eskalation.
8. Bei eigener Bearbeitung: passenden Pfad C bis L wählen.

Jeder Schritt soll ein bedienbares Ergebnis liefern: Sofortkarte, Ampel, Tabelle, Lückenliste, Kontrollpunkte vor Versand und klare Eskalation, wenn anwaltliche Freigabe nötig ist. Die Referenz `references/bedienfuehrung-workflows.md` gibt dafür Rückfragegrenzen, automatische Pfadwahl, Klartext-Aktionen und Übergabestandards vor.

## Bedienmuster im Tagesgeschäft

### Mietrückstand und Zahlungsklage

1. Skills 01 bis 05 für Stammdaten, Mietkonto, Belege und Chronologie.
2. Skill 06 für Fallziel und interne Freigabegrenze.
3. Skill 20 für Zahlungsklage, Skill 21 für Streitwert/Gerichtskosten und Skill 22 für Amtsgericht.
4. Skill 39 schließt Beweise und fortlaufende K-/B-Nummern; Skill 23 baut Einzel-PDFs, Anlagenverzeichnis, Manifest, ERV-/Signaturcheck und Eingangsnachlauf.
5. Ergebnis prüfen: Forderungsposten, Zeitraum, Zahlungseingänge, Anlagen, Zinsen, Zustellung.

Rechtzeitigkeitsregel: Bei Wohnraummiete zählt Sonnabend für die Zahlungsfrist des Paragrafen 556b BGB nicht. Bei gedecktem Konto genügt der bis zum dritten Werktag erteilte Überweisungsauftrag; ein späterer SAP-Kontoeingang beweist allein keine Verspätung. Kontrollanker sind BGH VIII ZR 129/09, VIII ZR 291/09 und VIII ZR 222/15.

### Räumung wegen Zahlungsverzug

1. Skills 13 bis 16 für Kündigung, Zustellung und Widerspruch.
2. Skill 24 für Räumungsklage, Skill 25 für Räumungsfrist und Vollstreckung, Skill 26 für Berliner Modell, Skill 27 für Schonfristzahlung.
3. Ergebnis prüfen: Kündigungszugang, Rückstandshöhe, Schonfristzahlung, Erledigungserklärung, Kostenfolge.

### Mieterhöhung

1. Skill 28 für Vorbereitung nach Paragraf 558 BGB.
2. Skill 29 für Mieterhöhungsverlangen.
3. Skill 30 für Zustimmungsklage.
4. Skill 31 für Kappungsgrenze, Mietpreisbremse und Berliner Besonderheiten.
5. Ergebnis prüfen: Ausgangsmiete, Vergleichsmiete, Sperrfrist, Kappungsgrenze, Begründung durch Mietspiegel.

### Prozessreaktion und Verteidigung

1. Skill 37 wertet gerichtliche Klageerwiderungen, gerichtliche Hinweise und gegnerische Schriftsätze in der eigenen Klage aus. Außergerichtliche Schreiben von Mieterverein oder gegnerischem Anwalt führt Skill 43; Mieterklage oder Widerklage führt Skill 42.
2. Skill 38 erstellt die Replik.
3. Skill 39 ordnet Beweise und Anlagen.
4. Skills 40 bis 45 decken Urkundsprozess, Vergleich, Mieterklage, Mieterverein, Betriebskosten und Hausverwaltung ab.
5. Ergebnis prüfen: Bestreiten, Beweislast, Fristen, Beleglücken, Vergleichsrisiko.

### Gerichtsfertiges Dokumentenpaket

Wenn die Rechtsarbeit noch Teil des Auftrags ist, bleibt dieser Fachpfad maßgeblich. Sind Inhalt, Anträge, Vortrag, Beweisentscheidung und Fristen dagegen bereits vollständig freigegeben, kann unmittelbar die [eigenständige beA-Schriftsatzwerkstatt](../schriftsatzwerkstatt-bea/README.md) verwendet werden; sie nimmt keine fachlichen Änderungen vor.

1. Ein finaler Auftrag beginnt mit `Bitte finalisiere den Schriftsatz mit allen Anlagen als gerichtsfertiges Einreichungspaket.`
2. Skill 39 ordnet jede erhebliche Tatsache einem Beweis zu, sperrt bereits eingereichte K-/B-Nummern und erzeugt ein Manifest mit Originalquelle, Version, Hash, Seiten und Beschaffungsstatus.
3. Skill 23 fragt Gericht/Aktenzeichen, Frist, Erscheinungsbild und vor allem die Einreichungsrolle ab: Eigenvertretung der privaten Konzerngesellschaft oder beauftragte Kanzlei.
4. Hauptschriftsatz und jede Anlage entstehen als eigene PDF-Arbeitskopie. Auf der ersten Anlagenseite steht rechts oben `Anlage K 1` oder `Anlage B 1`, ohne Originalinhalt zu verdecken; Originale bleiben unverändert.
5. Dateinamen bleiben unter 80 Zeichen, nutzen ASCII und Unterstriche, etwa `02_Anlage_K01_Mietvertrag_2022-05-01.pdf`.
6. Kanzleiweg: beA und Paragraf 130d ZPO; bei einfacher Signatur muss dieselbe verantwortende anwaltliche Person selbst versenden. Eigenvertretung: Beschäftigtenstatus/Vollmacht nach Paragraf 79 ZPO und ein tatsächlich eingerichtetes eBO nach Paragraf 130a Abs. 4 S. 1 Nr. 3 ZPO/Paragraf 10 ERVV oder ein im konkreten Verfahren zulässiger schriftlicher Weg. Eine private GmbH unterliegt Paragraf 130d nicht allein wegen ihrer Rechtsform.
7. Das Paket enthält Anlagenverzeichnis, Hashmanifest, PDF-/Form-/Signaturcheck, getrennte Freigabekarte und Versandauftrag. Das Plugin sendet nicht selbst. Nach Versand werden automatisierte Eingangsbestätigung oder sonstiger Zugangsnachweis, tatsächlich gesendete Dateiliste, Prüfprotokoll, Zustellung und Wiedervorlage gesichert. Maßgeblich ist [ERV-, eBO- und beA-Dokumentenproduktion](references/erv-dokumentenproduktion.md).

### Kostenpfad nach Klageeinreichung

1. Bei Zahlung, Aufrechnung, dauernder Einrede, Unmöglichkeit oder Wegfall des Rechtsschutzbedürfnisses nach Klageeinreichung nicht automatisch erledigen oder zurücknehmen.
2. Skill 05 trennt Klageeinreichung, Zustellung und Rechtshängigkeit. Skill 11 prüft Verzugsschaden. Skill 37 erstellt die Kostenpfad-Matrix. Skill 38 formuliert die passende Antragsumstellung.
3. Die Matrix enthält mindestens Ereignis, Datum, vor/nach Rechtshängigkeit, vollständig/teilweise, Vorverzug, Forderungs- und Kenntnisstand bei Einreichung, Kausalität und Erforderlichkeit der Kosten, Paragraf 91a ZPO, Paragraf 269 Abs. 3 S. 3 ZPO, materiell-rechtliche Kostenerstattung und RA-Eskalation.
4. Materiell-rechtliche Kostenerstattung als Verzugsschaden nur bei Vorverzug und kausalen, aus damaliger Sicht erforderlichen Klagekosten prüfen. Grün ist der bei Einreichung noch offene Anspruch. Eine unmittelbar zuvor eingegangene, objektiv noch nicht erkennbare Zahlung bleibt gelb und geht mit Zahlungsweg, Buchungszeitpunkt und Kenntnisstand zur RA-Prüfung.
5. Ampel setzen: grün bei belegtem Vorverzug, offener Forderung bei Einreichung und klarer Kausalität, gelb bei Beleg-, Erkennbarkeits- oder Zeitachsenlücke, rot bei fehlendem Vorverzug oder vermeidbaren Kosten.
6. Bei unsicherem Kostenweg, streitiger Kausalität oder drohendem Kostenverlust Skill 08 einschalten, bevor eine Erklärung an das Gericht abgegeben wird.

### Kosten und Vollstreckung

1. Skill 46 für Kostenfestsetzungsantrag.
2. Skill 47 für Prüfung des Kostenfestsetzungsbeschlusses.
3. Skill 48 für Vollstreckung aus Urteil, Vergleich, Vollstreckungsbescheid oder Kostenfestsetzungsbeschluss.
4. Skill 49 für Konto- und Drittauskünfte nach Titel.
5. Skill 50 für Monitoring von Zahlungen, Raten, Verjährung und nächsten Maßnahmen.
6. Bei abweisendem oder teilweise abweisendem Amtsgerichtsurteil keine Vollstreckung starten, sondern Tenor, Frist, Beschwer, Wert, Zulassung und Kostenrisiko als Rechtsmittel-Skizze an Skill 08 und die Stammkanzlei übergeben.
7. Bei externer eigener Kanzlei Auftrag, Budget, Honorargrundlage, Reporting, Rechnung und Stunden-Narrative mit Skill 08 prüfen und monieren.
8. KFA, gegnerischen KFA, KFB, Streitwertfestsetzung, Kostenrechnung, Berichtigung und Beschwerde immer als Fristen- und Entscheidungsvorlage führen.

## Erwartete Outputs

Das Plugin soll nicht nur Text entwerfen, sondern die Akte beherrschbar machen. Typische Zwischenergebnisse sind:

- Stammdatenblatt mit Objekt, Mietpartei, Vermieterin, Vertrag und Bearbeitungsrolle.
- Forderungsaufstellung mit Soll, Ist, Saldo, Zeitraum und Beleganker.
- Chronologie mit Datum, Ereignis, Quelle, Frist und nächstem Schritt.
- Beleg- und Anlagenmatrix für Schriftsätze.
- Entscheidungsvermerk zu Eskalation, Mahnverfahren-Abzweigung, Klagepfad oder Vergleich.
- Kostenpfad-Matrix nach Klageeinreichung mit Rechtshängigkeit, Verzug, Kostenweg und Eskalation.
- Vollständig ausformulierter Entwurf für Schreiben, Klage, Replik, Antrag oder Vollstreckungsauftrag.
- Gerichtsfertiges Paket aus Hauptschriftsatz, einzelnen K-/B-Anlagen-PDFs, Anlagenverzeichnis, Hashmanifest, ERV-/Signaturcheck, Freigabekarte, Versandauftrag und Eingangsnachlauf.
- Rechtsmittel- und Eskalationsspur bei abweisendem oder teilweise abweisendem Urteil, getrennt von Vollstreckung.
- Kanzlei-Auftrag, Rechnungsvotum und Monierungstabelle für externe eigene Anwälte.
- Kostenrechtsvermerk zu KFA, KFB, Streitwert, Berichtigung, Beschwerde und Frist.
- Kontrollliste für fachliche Freigabe vor Versand.
- Getrennte Freigabekarte mit Status, Aktenstichtag, Adressat, Rechtsfolge, Betragskontrolle, Beweisen/Anlagen, Frist/Weg, Rollencheck und realer Freigabeperson.
- Sofort- und Startkarte mit Fallart, Ampel, kurzer Begründung, Frist, fehlenden Kernstücken und genau einer nächsten Arbeitsaktion.

## Kontrollpunkte vor Versand

Jeder außenwirksame Entwurf beginnt im Arbeitspaket mit einer internen Freigabekarte; sie ist nicht Teil des Mieter- oder Gerichtsdokuments. Standardstatus ist `ENTWURF - NICHT VERSENDEN/EINREICHEN`. Grün bedeutet nur freigabefähig. Erst eine benannte reale Person setzt `FREIGEGEBEN`; das Plugin erteilt keine eigene Freigabe.

- Stimmen Namen, Anschriften, Objekt, Vertragsnummer und Gericht?
- Sind Forderungszeiträume, Zahlungen, Teilzahlungen und Verrechnung nachvollziehbar?
- Gibt es Belege für jede erhebliche Tatsachenbehauptung?
- Sind Kündigung, Zugang, Fristen und Schonfristzahlung sauber dokumentiert?
- Ist die interne 10.000-EUR-Grenze eingehalten oder freigegeben?
- Muss wegen Landgericht, Berufung, Insolvenz, Strafrecht oder Sachverständigenfrage eskaliert werden?
- Sind Datenschutz, Datenminimierung und interne Freigabe dokumentiert?
- Stimmen Datenstichtag und letzte berücksichtigte Zahlung mit Forderung und Antrag überein?
- Wurde eine frühere Freigabe nach Änderung von Betrag, Antrag, Partei, Frist, Beweis, Anlage oder Zustellweg aufgehoben und neu geprüft?

## Abnahme im Pilotbetrieb

Vor Produktivfreigabe sollte die Pilotgruppe mindestens eine Testakte je Hauptpfad bearbeiten:

1. Mietrückstand bis Zahlungsklage.
2. Räumung bis Reaktion auf Schonfristzahlung.
3. Zahlung nach Klageeinreichung bis Kostenpfad-Entscheidung.
4. Mieterhöhung bis Zustimmungsklage.
5. Klageerwiderung bis Replikplan.
6. Kostenfestsetzung bis Vollstreckungsmonitoring.

Die fachliche Leitung prüft dabei nicht nur den Textentwurf, sondern auch Chronologie, Belegmatrix, Fristen, Eskalationsentscheidung und Kontrollliste vor Versand. Die [Smoke-Tests](../tests/smoke-tests.md) liefern dafür eine kompakte Abnahmeliste.

## Workflow-Prompts

Im Repo-Root liegen die zwei Steuerungs-Prompts:

- [forderungsmanagement-grosser-prompt.md](../forderungsmanagement-grosser-prompt.md) — Werkstattprompt für den Gesamtprozess von SAP-Eingang bis Kostenfestsetzung und Vollstreckung; wird im Release auch als Standalone-Skill verpackt.
- [forderungsmanagement-kleiner-prompt.md](../forderungsmanagement-kleiner-prompt.md) — Schnellstartprompt bis 7.500 Zeichen für schnelle Fälle und Einzelprompt-Upload; wird im Release ebenfalls als Standalone-Skill verpackt.

Die Standalone-Skill-ZIPs enthalten jeweils genau eine `SKILL.md` an der ZIP-Wurzel. Der Release-Validator hält den Schnellstart einschließlich Frontmatter unter 7.500 Zeichen und den vertieften Werkstattprompt einschließlich Frontmatter unter 30.000 Zeichen.

## Testakten

Neun realitätsnahe Fach-Testakten unter `testakten/` (Berlin):

| Akte | Trainiert vor allem | Startskills |
|---|---|---|
| [mietrueckstand-meier-wilhelmstrasse](../testakten/mietrueckstand-meier-wilhelmstrasse/) | klassischer Zahlungs- und Klagefall mit Kündigungsoption | `01` bis `06`, `09`, `20` bis `23` |
| [raeumungsklage-kowalski-friedrichshain](../testakten/raeumungsklage-kowalski-friedrichshain/) | Kündigung, Räumungsklage, Schonfristzahlung und Erledigungsreaktion | `13` bis `16`, `24`, `27`, `37` |
| [mieterhoehung-becker-tempelhof](../testakten/mieterhoehung-becker-tempelhof/) | Mieterhöhung nach Paragraf 558 BGB mit Mietspiegel-Begründung | `28` bis `31` |
| [mietrueckstand-lange-zwei-raten-versehen](../testakten/mietrueckstand-lange-zwei-raten-versehen/) | zwei offene Mieten nach Bankwechsel und Kulanz-Ratenplan | `01` bis `06`, `10`, `12` |
| [mietrueckstand-demir-fuenf-raten-absichtlich](../testakten/mietrueckstand-demir-fuenf-raten-absichtlich/) | bewusster Zahlungsstopp, Kündigung, Zahlung und Räumung | `13`, `15`, `20`, `24`, `39` |
| [nebenkosten-braun-nachzahlung-unbezahlt](../testakten/nebenkosten-braun-nachzahlung-unbezahlt/) | Betriebskosten-Nachzahlung, Belegeinsicht und Zahlungsklage | `04`, `35`, `44`, `20` |
| [ratenplan-riedel-gebrochen](../testakten/ratenplan-riedel-gebrochen/) | gebrochener Kulanzplan bei stabiler laufender Miete | `10`, `11`, `12`, `20` |
| [vollstreckung-krueger-titel-teilzahlung](../testakten/vollstreckung-krueger-titel-teilzahlung/) | Titelverwaltung, KFB, Teilzahlung und Vollstreckungsmonitoring | `46` bis `50` |
| [mieterklage-schimmel-schulz-verteidigung](../testakten/mieterklage-schimmel-schulz-verteidigung/) | zugestellte Schimmelklage, technische Ursachenklärung, Beweisplan und Klageerwiderung | `33`, `42`, `39`, `45`, danach `23` |

Mit dem bei Zugang des Erhöhungsverlangens geltenden Berliner Mietspiegel 2026 als Anlage.

Jede Testakte steht im Release in drei direkt verlinkten Formen zur Verfügung: Gesamt-PDF, Arbeits-ZIP und Einzel-PDF-ZIP. Die [Downloadmatrix](../testakten/README.md#direktdownloads-je-testakte) führt ohne Repo-Suche zur gewünschten Akte. Für Schulungen ist das Einzel-PDF-ZIP besonders nützlich, weil es die typische Situation abbildet: viele einzelne Unterlagen, sauber benannt, aber noch nicht zu einer Prozessakte verschmolzen.

Die Akten sind nicht glattgebügelt: E-Mail-Nachträge, DocuWeb-/DMS-Dubletten, Rückrufnotizen, unscharfe Zahlungsbehauptungen, angekündigte fehlende Fotos und P-Konto-Hinweise trainieren genau den Einstieg, den die Abteilung im Alltag braucht. `33-dokumentenmix-ocr-sichten` erstellt das Dokumenteninventar, `04-belegmatrix-aufbauen` sortiert Beweiswert und Beifang, `05-chronologie-fallakte` trennt sichere Ereignisse von bloßen Behauptungen und `06-fallziel-renofa-triage` gibt erst danach die Ampel für Kulanz, Klage, Kündigung oder Vollstreckung.

## Quellen und Konsistenz

Dieses Repo übernimmt die Qualitätsstandards aus [`claude-fuer-deutsches-recht`](https://github.com/Klotzkette/claude-fuer-deutsches-recht):

| Mitgelieferte Referenz | Einsatz im Workflow |
|---|---|
| [Bedienführung und Workflows](references/bedienfuehrung-workflows.md) | Sofortkarte, automatische Pfadwahl, Fortsetzungsmarke, Rückfragen, Übergabe und Freigabekarte |
| [100-Punkte-Bediencheck](references/100-punkte-bediencheck.md) | Abnahme für Einstieg, Fristen, Stapel, Lesbarkeit, Quellen, DMS, Prompts, Testakten und Downloads |
| [Schnittstellenprofile](references/schnittstellenprofile.md) | SAP-, DMS-, DATEV-, RA-MICRO-, XML- und MCP-Anschluss |
| [Geprüfte BGH-Anker Mietrecht](references/gepruefte-bgh-anker-mietrecht.md) | verifizierte Primärquellen und Kontrollbefunde |
| [Rechtsprechungsradar 2021 bis 2026](references/rechtsprechungsradar-mietrecht-2021-2026.md) | BGH-/BVerfG-/EuGH-, KG-, OLG- und LG-Suchspur mit Quellenstatus |
| [Rechtsstand 2026: Verfahren, Vollstreckung und Mietrechtsnovelle](references/rechtsstand-2026-verfahren-vollstreckung.md) | Online-Verfahren, Pfändungsfreigrenzen, elektronische Zwangsvollstreckung und Entwurfs-Gate für BT-Drs. 21/6807 |
| [Schriftsatz- und Argumentationsstandard](references/schriftsatz-und-argumentationsstandard.md) | Tatsachenkarte, Substantiierung, Bestreiten, Beweisangebot, Subsumtion und Endkontrolle |
| [ERV-, eBO- und beA-Dokumentenproduktion](references/erv-dokumentenproduktion.md) | PDF-Paket, Anlagenkennzeichnung, Dateinamen, Rollengate, Signatur und Eingang |
| [Leitentscheidungen-Anker](references/leitentscheidungen-anker.md) | Sucheinstieg nach Falltyp und Norm |
| [Methodik Bürgerliches Recht](references/methodik-buergerliches-recht.md) | Anspruchsaufbau, Beweislast und Rechtsfolge |
| [Quellenhygiene](references/quellenhygiene.md) | Quellenstatus und Live-Verifikation |
| [Zitierweise](references/zitierweise.md) | einheitliche Fundstellen in Vermerk und Schriftsatz |

- Keine BeckRS- oder Aufsatz-Blindzitate
- Rechtsprechung nur verifiziert
- Quellenhygiene wie im Mutter-Repo
- Quellenleitplanken im Plugin-ZIP unter `references/`
- Geprüfte mietrechtliche Kontrollspur mit BGH-Feed-Abgleich vom 09.08.2026 zu Härtefall, Vormiete, Auskunft und Mietpreisbremsen-Streitwert
- Datierte 2026-Kontrollspur für Online-Klagen, Pfändungsfreigrenzen und die erst ab 01.10.2026 anwendbare Vollstreckungsreform
- Harte Sperre gegen die vorzeitige Anwendung der am 09.07.2026 nur an die Ausschüsse überwiesenen Mietrechtsnovelle BT-Drs. 21/6807
- Angepasste Build- und Validierungsskripte für Plugin, Prompts, Testakten und Release-Assets
- Markdown-Skills mit YAML-Frontmatter `name` und `description`

## Lizenz

Apache-2.0 oder MIT (siehe [LICENSE-APACHE](../LICENSE-APACHE) und [LICENSE-MIT](../LICENSE-MIT) im Repo-Root).


<!-- BEGIN SKILLS-OVERVIEW (auto-generated) -->

## Alle Skills im Überblick

Automatisch generierte Komplett-Liste aller 50 Skills in diesem Plugin. Die technische Skill-ID bleibt stabil; der Arbeitsname macht die fachliche Zuordnung lesbar. Jede Skill-ID öffnet direkt die zugehörige `SKILL.md`; die Beschreibungen stammen aus deren Frontmatter.

| Skill | Arbeitsname | Beschreibung |
| --- | --- | --- |
| [`01-sap-akte-importieren`](skills/01-sap-akte-importieren/SKILL.md) | SAP-/Mietkonto-Startakte | SAP-Start bei sauberem SAP-Statusauszug, FBL5N, Mietkonto, Vertragsnummer, Saldo oder neuem SAP-Stand zu laufender Akte. Stammdaten, Delta, Herkunftssystem und Rückexportbedarf erfassen. Bei neuem Ordner oder gemischtem Upload zuerst... |
| [`02-mietakte-rekonstruieren`](skills/02-mietakte-rekonstruieren/SKILL.md) | Mietvertrag und Vertragsakte | Mietvertrag mit Nachträgen rekonstruieren. Wohnraum und Gewerberaum, Form, Indexklausel, Staffelmiete, Schönheitsreparaturen und Betriebskostenkatalog prüfen. Fehlende Anlagen aus SAP DMS erkennen. Output Anlagenverzeichnis für spätere... |
| [`03-kontoauszug-mietkonto-auslesen`](skills/03-kontoauszug-mietkonto-auslesen/SKILL.md) | Mietkonto und Soll-Ist-Saldo | Mietkonto, OP-Liste, Buchungsjournal oder neuen Zahlungseingang auslesen und fortschreiben. Saldo, Teilzahlung, Storno, Guthaben, Tilgungsbestimmung und Paragraf 366 BGB prüfen. Bei laufender Akte Alt-Neu-Delta ausgeben, bei... |
| [`04-belegmatrix-aufbauen`](skills/04-belegmatrix-aufbauen/SKILL.md) | Beleg- und Anlagenmatrix | Belegmatrix nach Mietkonto und Aktenrekonstruktion aufbauen, wenn Forderungsposten, Tatsachen, SAP- oder DMS-Fundstellen und spätere K-/B-Anlagen verknüpft werden müssen. Nicht für Rohdatenintake oder PDF-Finalisierung. Output Beweis-... |
| [`05-chronologie-fallakte`](skills/05-chronologie-fallakte/SKILL.md) | Chronologie und Fristenachse | Chronologie, Ereignisachse und Fristenhistorie aufbauen oder mit neuer Zahlung, Gerichtspost und Korrespondenz fortschreiben. Klageeinreichung, Zustellung, Rechtshängigkeit, Delta, überholte Annahmen und Kostenpfad zeitlich ordnen.... |
| [`06-fallziel-renofa-triage`](skills/06-fallziel-renofa-triage/SKILL.md) | Pflicht-Router nach Intake | Verbindlicher interner Router nach Intake, Fallkarte oder Änderungskarte. Prüft Fallziel, Rolle, RDG, Paragraf 79 ZPO, interne 10000-EUR-Freigabe und Eskalation. Wählt automatisch Zahlung, Kündigung, Räumung, Mieterhöhung, Verteidigung,... |
| [`07-rdg-grenzen-check`](skills/07-rdg-grenzen-check/SKILL.md) | Rollen- und RDG-Grenze | RDG-Prüfung der Renofa-Tätigkeit. Eigene Angelegenheit nach Paragraf 2 Abs. 1 RDG, Konzernverbund nach Paragraf 2 Abs. 3 Nr. 6 RDG und Prozessvertretung nach Paragraf 79 ZPO trennen. Drittinkasso erfordert Erlaubnis. Output Befugnisvermerk. |
| [`08-eskalation-an-anwalt`](skills/08-eskalation-an-anwalt/SKILL.md) | RA-Eskalation und Kanzleisteuerung | Eskalation und Steuerung eigener externer Rechtsanwaltskanzlei. Trigger Insolvenz, Berufung, abweisendes oder teilabweisendes AG Urteil, Landgericht, Sachverständiger, Strafrecht, Kostenstreit, RA-Honorar und Stunden-Narrativ. Output... |
| [`09-mietrueckstand-mahnung-erstellen`](skills/09-mietrueckstand-mahnung-erstellen/SKILL.md) | Mietrückstand mahnen | Mahnung wegen Mietrückstand. Erste Mahnung freundlich. Zweite Mahnung mit Klageandrohung. Verzugszinsen Paragraf 288 BGB. Konkrete Forderungsaufstellung Monat für Monat. Output Mahnschreiben als Brief mit Zugangsnachweis-Protokoll. |
| [`10-zahlungsplan-stundungsvereinbarung`](skills/10-zahlungsplan-stundungsvereinbarung/SKILL.md) | Ratenplan und Kulanzsteuerung | Zahlungsplan, Ratenplan, Teilzahlungsvereinbarung, Stundung, Schuldanerkenntnis und Verfallklausel aufsetzen oder gebrochenen Ratenplan auswerten. Restbetrag, laufende Miete und Wiedervorlage steuern. Output Vereinbarung. |
| [`11-verzugsschaden-berechnen`](skills/11-verzugsschaden-berechnen/SKILL.md) | Verzugsschaden und Kostenkniff | Verzugsschaden nach Paragraf 280 und 286 BGB. Zinsen, Inkasso- und Anwaltskosten, Bonitätsauskunft und Prozesskosten nach erledigendem Ereignis prüfen. Mahnpauschale nicht bei Verbrauchern. Output Schadenstabelle. |
| [`12-vorgerichtliche-letzte-frist`](skills/12-vorgerichtliche-letzte-frist/SKILL.md) | Letzte Frist vor Klage/Kündigung | Letzte kalendarische Frist mit Klageandrohung aus einer geprüften Mietforderung erstellen. Zugang, angemessene Fristlänge, Kündigungsschwelle, gesetzliche Folgekosten und Sozialleistungshinweise trennen. Keine Mahnung als... |
| [`13-fristlose-kuendigung-zahlungsverzug`](skills/13-fristlose-kuendigung-zahlungsverzug/SKILL.md) | Fristlose Kündigung Zahlungsrückstand | Fristlose Kündigung wegen Mietzahlungsverzug nach Paragraf 543 und 569 BGB erstellen. Rückstandsschwelle, zwei Termine, längerer Zeitraum, hilfsweise ordentliche Kündigung und Pflicht-Handoff zu Zustellung Skill 15. Output Kündigung. |
| [`14-ordentliche-kuendigung-pflichtverletzung`](skills/14-ordentliche-kuendigung-pflichtverletzung/SKILL.md) | Ordentliche Kündigung Pflichtverletzung | Ordentliche Kündigung wegen schuldhafter Pflichtverletzung nach Paragraf 573 BGB erstellen. Frist Paragraf 573c, Sozialklausel-Hinweis, Pflichtverletzung, Untervermietung, Schonfrist-Abgrenzung und Pflicht-Handoff zu Zustellung Skill 15.... |
| [`15-kuendigung-zustellung-nachweis`](skills/15-kuendigung-zustellung-nachweis/SKILL.md) | Zustellung und Zugangsnachweis | Pflichtskill nach freigegebenem Kündigungsentwurf. Freigabekarte, Zugang, Botenvermerk, Einwurf, Zeuge, Briefkasten, Rückscheinrisiko, Einwurf-Einschreiben und Zustellnachweis für alle Mieter sichern. Keine Email oder SMS. Output... |
| [`16-widerspruch-mieter-pruefen`](skills/16-widerspruch-mieter-pruefen/SKILL.md) | Sozialwiderspruch und Härtefall | Sozialwiderspruch des Mieters gegen Kündigung nach Paragraf 574 BGB prüfen. Härtefall, Ersatzwohnraum, Krankheit, Alter, Suizidgefahr, Räumungsaufschub und fristlose Kündigung abgrenzen. Nicht Mahnbescheid-Widerspruch. Output Empfehlung. |
| [`17-mahnbescheid-online-antrag`](skills/17-mahnbescheid-online-antrag/SKILL.md) | Option Mahnverfahren | Optionale Mahnverfahren-Abzweigung für bestimmte Euro-Geldforderung prüfen. Ausschlüsse nach Paragraf 688 ZPO, Mahngericht, späteres Streitgericht, erwarteten Widerspruch, Zustellung und Verjährungshemmung trennen. Output... |
| [`18-widerspruch-vollstreckungsbescheid`](skills/18-widerspruch-vollstreckungsbescheid/SKILL.md) | Widerspruch/Einspruch im Mahnverfahren | Mahnbescheid-Widerspruch oder Einspruch gegen Vollstreckungsbescheid auswerten. Abgabe an Streitgericht, Anspruchsbegründung, Fristsetzung, Einwendungen, Anlagenplan und Rücksprung zur Zahlungsklage vorbereiten. Output Anspruchsbegründung. |
| [`19-vollstreckungsbescheid-antrag`](skills/19-vollstreckungsbescheid-antrag/SKILL.md) | Vollstreckungsbescheid prüfen | Vollstreckungsbescheid nur als optionale Folge eines zuvor gewählten Mahnverfahrens prüfen. Fristen, Einspruchsrisiko und Titelqualität bewerten. Output Entscheidungsvorlage und Vollstreckungs-Übergabe. |
| [`20-zahlungsklage-mietrueckstand-erstellen`](skills/20-zahlungsklage-mietrueckstand-erstellen/SKILL.md) | Zahlungsklage Mietrückstand | Reine Zahlungsklage wegen Mietrückstand ohne Räumungsantrag erstellen. Mietkonto, Belegmatrix, Rubrum, Zahlungsantrag, Zinsen, Aufrechnung und Kostenpfad verarbeiten. Bei Räumung, Herausgabe, Kündigung oder Kombiklage führt Skill 24.... |
| [`21-klage-streitwert-gerichtskosten`](skills/21-klage-streitwert-gerichtskosten/SKILL.md) | Streitwert und Gerichtskosten | Streitwert und Gerichtskosten für Zahlungsklage, Räumung, Mieterhöhung und Mietpreisbremse prüfen. Geldforderung als Hauptforderung, mietrechtliche GKG-Spezialwerte, Stichtag und Vorschuss nach Paragraf 12 GKG kontrollieren. Output... |
| [`22-zustaendigkeit-amtsgericht-pruefen`](skills/22-zustaendigkeit-amtsgericht-pruefen/SKILL.md) | Amtsgericht und Anwaltszwang | Sachliche und örtliche Zuständigkeit prüfen plus Anwaltszwang nach Paragraf 78 ZPO. Wohnraummietsachen stets AG Paragraf 23 Nr. 2a GVG ohne Anwaltszwang. Gewerberaum streitwertabhängig. Output Zuständigkeitsvermerk mit Norm-Anker. |
| [`23-klage-egvp-bea-einreichen`](skills/23-klage-egvp-bea-einreichen/SKILL.md) | Einreichungspaket, Rollengate und Eingang | Gerichtsfertige Dokumentenproduktion für Klage, Replik, Antrag und sonstigen Schriftsatz. Nutze ihn bei fertig zur Einreichung, beA-ready, eBO, Schriftsatz finalisieren oder Anlagenpaket. Prüft Eigenvertretung oder Kanzlei,... |
| [`24-raeumungsklage-erstellen`](skills/24-raeumungsklage-erstellen/SKILL.md) | Räumungsklage Wohnraum | Leadskill für Räumungsklage Wohnraum nach Kündigung. Wohnung räumen und herausgeben, Kombiklage mit Zahlung, Kündigungszustellung, Sozialwiderspruch, Räumungsstreitwert, Zahlung vor Zustellung und Schonfrist nach Rechtshängigkeit prüfen.... |
| [`25-raeumungsfrist-vollstreckung`](skills/25-raeumungsfrist-vollstreckung/SKILL.md) | Räumungsfrist und Schutzantrag | Räumungstitel, Räumungsfrist Paragraf 721 ZPO, Räumungstermin, Gerichtsvollzieherauftrag, GV-Auftrag, Vollstreckungsschutz Paragraf 765a ZPO, Attest, Suizidgefahr, Sozialdienst und Fristverlängerung prüfen. Output Antrag. |
| [`26-berliner-modell-raeumung`](skills/26-berliner-modell-raeumung/SKILL.md) | Berliner Modell Räumung | Berliner Räumung als beschränkten Vollstreckungsauftrag nach Paragraf 885a ZPO prüfen. Besitzübergabe ohne Abtransport durch den Gerichtsvollzieher, Dokumentation, Verwahrung, Herausgabe, Monatsfrist, Verwertung, Vernichtung, Haftung und... |
| [`27-schonfristzahlung-erkennen`](skills/27-schonfristzahlung-erkennen/SKILL.md) | Schonfristzahlung und Kostenpfad | Schonfristzahlung erst nach Rechtshängigkeit der Räumungsklage prüfen. Jobcenter-Zahlung, vollständige Befriedigung, fristlose und ordentliche Kündigung, Kostenpfad und Klageumstellung trennen. Zahlung vor Zustellung als eigenes... |
| [`28-mieterhoehung-bgb-558-vorbereiten`](skills/28-mieterhoehung-bgb-558-vorbereiten/SKILL.md) | Mieterhöhung vorbereiten | Verwenden vor dem ersten Mieterhöhungsverlangen, wenn Ausgangsmiete, Sperrfrist, Kappungsgrenze, Mietspiegelfeld, Wohnlage oder Merkmalgruppen noch geprüft werden müssen. Berechnet die Obergrenzen nach Paragraf 558 BGB und erzeugt eine... |
| [`29-mieterhoehungsverlangen-text`](skills/29-mieterhoehungsverlangen-text/SKILL.md) | Mieterhöhungsverlangen schreiben | Verwenden, wenn die Prüfung aus Skill 28 abgeschlossen ist und das Mieterhöhungsverlangen nach Paragrafen 558 und 558a BGB versandfertig entworfen werden soll. Übernimmt nur belegte Wohnungsmerkmale, berechnet Zustimmungs-, Wirkungs- und... |
| [`30-zustimmungsklage-mieterhoehung`](skills/30-zustimmungsklage-mieterhoehung/SKILL.md) | Zustimmungsklage Mieterhöhung | Verwenden erst nach wirksamem Mieterhöhungsverlangen und abgelaufener Zustimmungsfrist, wenn Zustimmung fehlt oder nur teilweise vorliegt. Prüft Zugang, materielle Zielmiete, Klagefrist nach Paragraf 558b Abs. 2 BGB, Teilzustimmung,... |
| [`31-kappungsgrenze-mietpreisbremse`](skills/31-kappungsgrenze-mietpreisbremse/SKILL.md) | Kappung und Mietpreisbremse | Kappungsgrenze bei Bestandsmieterhöhung und Mietpreisbremse bei Neuvermietung getrennt prüfen. 15 Prozent oder 20 Prozent Cap, 10 Prozent Grenze, Landesverordnung, Berlin, Vormiete, Neubau und Modernisierung berechnen. Output Normcheck. |
| [`32-datenschutz-mieterdaten`](skills/32-datenschutz-mieterdaten/SKILL.md) | Datenschutz in der Mietakte | Datenschutz für Miet-, Prozess- und Vollstreckungsakten nach DSGVO und BDSG prüfen. Rechtsgrundlage, Zweckbindung, Datenminimierung, Auskunft, Aufbewahrung, Löschung, Auskunftei-Meldung und Schadenersatzrisiko mit EuGH-Ankern steuern.... |
| [`33-dokumentenmix-ocr-sichten`](skills/33-dokumentenmix-ocr-sichten/SKILL.md) | Autostart neuer Fall und Dokumentenmix | Verbindlicher Default-Start für neuen Fall, Projektordner, Aktenordner, Upload-Bundle und gemischten Neuzugang. Aktiviert bei kurzen Aufträgen wie neuer Fall, Ordner prüfen oder Akte fertig machen. Fragt nie nach einer Skillauswahl,... |
| [`34-sap-excel-pdf-normalisieren`](skills/34-sap-excel-pdf-normalisieren/SKILL.md) | Datenexporte und E-Akten-Anschluss | Technischer Anschluss-Skill nach Autostart oder SAP-Intake. Normalisiert SAP, Excel, PDF, DocuWeb, DATEV, RA-MICRO, XML, JSON, Datenbankexport, DMS-Register und MCP-Planung. Kein Fachpfad. Output fallakte.json, dms-register.csv,... |
| [`35-sap-belegluecken-klaeren`](skills/35-sap-belegluecken-klaeren/SKILL.md) | Beleglücken und Rückfragen | Beleglücke, fehlende Anlage, fehlende SAP-Belegnummer, Kontoauszugslücke, DMS-Treffer fehlt oder Buchhaltungsbeleg unklar. Forderung, Vertrag, Zustellung und Zahlung absichern. Rückfragen formulieren. Output priorisierte Liste. |
| [`36-fallstrategie-bis-10000`](skills/36-fallstrategie-bis-10000/SKILL.md) | Fallstrategie bis Freigabegrenze | Strategieentscheidung erst nach Triage für Forderungs- und Vertragsstreitigkeiten an der internen 10000-EUR-Grenze. Nutzen, Risiko, Kulanz, Direktklage, Kündigung, Vergleich oder Eskalation abwägen. Kein Intake- oder Standard-Router.... |
| [`37-klageerwiderung-auswerten`](skills/37-klageerwiderung-auswerten/SKILL.md) | Klageerwiderung auswerten | Neue Klageerwiderung, Gerichtspost oder gegnerischen Schriftsatz im laufenden Prozess als Delta auswerten. Frist, Einwendungen, Zahlung nach Klage, Aufrechnung, Kostenpfad, Beweisrisiken und überholte Prozesspositionen extrahieren.... |
| [`38-replik-erstellen`](skills/38-replik-erstellen/SKILL.md) | Replik und Antragsumstellung | Replik auf Klageerwiderung oder gerichtlichen Hinweis erstellen. Gegenvortrag, Beweise, Anlagen, Anträge und Kostenpfad bei erledigender Zahlung aktualisieren. Output Schriftsatz. |
| [`39-beweisangebot-anlagenplan`](skills/39-beweisangebot-anlagenplan/SKILL.md) | Beweisplan und Anlagenmanifest | Beweisangebote und fortlaufenden Anlagenplan für Klage, Replik und Verteidigung erzeugen. Ordnet jede erhebliche Tatsache einem zulässigen Beweismittel, Beweislast, Original, K- oder B-Nummer, Dateiversion und Beschaffungsstatus zu.... |
| [`40-urkundsprozess-pruefen`](skills/40-urkundsprozess-pruefen/SKILL.md) | Urkundsprozess als Ausnahme | Urkundenprozess nach Paragrafen 592 bis 600 ZPO für Mietforderungen prüfen. Bestimmte Geldforderung, vollständiger Urkundenbeweis, Klagekennzeichnung, Beweismittelgrenzen, Unstatthaftigkeitsrisiko, Vorbehaltsurteil und Nachverfahren... |
| [`41-vergleich-raten-prozess`](skills/41-vergleich-raten-prozess/SKILL.md) | Vergleich und Prozessraten | Außergerichtlichen oder gerichtlichen Vergleich mit Raten, Zahlung, Räumung und Kosten strukturieren. Vollstreckbarer Inhalt nach Paragrafen 278 Abs. 6 und 794 ZPO, optionale Verfallklausel, Abschlussbefugnis, Kostenquote, Monitoring und... |
| [`42-mieterklage-verteidigen`](skills/42-mieterklage-verteidigen/SKILL.md) | Verteidigung gegen Mieterklage | Nur bei umgekehrter Prozesslage: Mieter verklagt Vermieterin oder erhebt Widerklage. Verteidigung gegen Mietminderung, Rückzahlung, Kaution, Mängel, Mietpreisbremse, Eigenbedarfsschaden, Vorkaufsrecht oder Unterlassung. Nicht bloße... |
| [`43-mieterverein-anwalt-korrespondenz`](skills/43-mieterverein-anwalt-korrespondenz/SKILL.md) | Mieterverein/Gegneranwalt beantworten | Außergerichtliche Schreiben von Mieter, Mieterverein oder Anwalt beantworten. Vollmacht, Datenschutz, Beleganforderung, Mietminderung, Vergleichsangebot, Zahlungsbereitschaft und Fristen prüfen. Nicht gerichtliche Klageerwiderung. Output... |
| [`44-betriebskosten-rueckstand-streit`](skills/44-betriebskosten-rueckstand-streit/SKILL.md) | Betriebskostenforderung und Einwendungen | Prüft Betriebskosten-Nachforderungen, Vorauszahlungen und Einwendungen. Rechnet Kostenanteile nach, klärt digitale Belegeinsicht und trennt Abrechnungsfehler von vorläufigen Zahlungshindernissen. Liefert eine konkrete Beleganforderung,... |
| [`45-hausverwaltung-schnittstelle`](skills/45-hausverwaltung-schnittstelle/SKILL.md) | Hausverwaltung und IT-Rückfragen | Leadskill für operative Rückfragen an Hausverwaltung, Objektbetreuung, Buchhaltung, DMS-Administration, IT und Forderungsmanagement. Nutze bei Beleglücke, Zustellung, Mängelstatus, Zahlungsklärung oder Schnittstellenmapping. Output... |
| [`46-kostenfestsetzung-antrag`](skills/46-kostenfestsetzung-antrag/SKILL.md) | Kostenfestsetzungsantrag | KFA nach prozessualer Kostengrundentscheidung in Urteil, Beschluss oder Vergleich vorbereiten. Tenor, Quote, Gerichtskosten, tatsächlich entstandene externe Anwaltskosten, Auslagen, Zahlungen, Zinsantrag und gegnerischen KFA nach... |
| [`47-kostenbeschluss-pruefen`](skills/47-kostenbeschluss-pruefen/SKILL.md) | Kostenfestsetzungsbeschluss prüfen | KFB und Kostenfestsetzungsbeschluss prüfen. Abweichung vom KFA, Tenor, Betrag, Zinsen, Quote, Zustellung, Rechtsbehelfsfrist, Erinnerung, sofortige Beschwerde, vollstreckbare Ausfertigung und Zahlung prüfen. |
| [`48-titulierte-forderung-vollstrecken`](skills/48-titulierte-forderung-vollstrecken/SKILL.md) | Titelvollstreckung vorbereiten | Verwenden nach vorhandenem Urteil, Vergleich, Vollstreckungsbescheid oder KFB, wenn eine konkrete Vollstreckungsmaßnahme vorbereitet werden soll. Prüft Titel, Klausel, Zustellung, Restforderung, Zinsen und Kosten und strukturiert... |
| [`49-kontoermittlung-und-drittauskunft`](skills/49-kontoermittlung-und-drittauskunft/SKILL.md) | Kontoermittlung und Drittauskunft | Verwenden nur nach Titel, wenn Bank, Arbeitgeber oder andere pfändbare Spur unbekannt ist und eine konkrete Vollstreckung deshalb stockt. Prüft Voraussetzungen und zulässigen Weg für Drittauskunft nach Paragraf 802l ZPO,... |
| [`50-vollstreckungsakte-monitoring`](skills/50-vollstreckungsakte-monitoring/SKILL.md) | Vollstreckungsmonitoring | Vollstreckungsakte nach Titelgewinn führen und bei neuer Zahlung, Rate, GV-Rücklauf, Pfändung oder Insolvenzmeldung als Delta fortschreiben. Fristen, Tilgung, Kosten und Verjährung überwachen. Output Änderungskarte, Monitoring und... |

<!-- END SKILLS-OVERVIEW (auto-generated) -->
