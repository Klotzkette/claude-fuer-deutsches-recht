# Changelog

Alle wesentlichen Änderungen an diesem Repository werden hier dokumentiert.

## Unreleased

## v5.27.1 - 2026-09-30

- Abschließenden Review-Befund behoben: Nachträge und Vertragsanlagen der Testakten Becker, Meier und Kowalska sind nun vollständig in die dezimale Gliederung eingeordnet. Beträge und Termine bleiben unverändert. Beckers Fenstertausch von 2017 ist im Nachtrag von 2018 statt im Ursprungsvertrag von 2014 dokumentiert; die damalige Übergabe ist als bevorstehend formuliert.
- Dokumentqualitätsprüfung sperrt unnummerierte Zwischenüberschriften, falsche Gliederungstiefen und fehlende Leerzeilen in Mietverträgen. Drei zusätzliche Regressionstests sichern die Prüfung einschließlich eines absichtlich beschädigten Nachtrags.
- Word-Tabellen halten ihre Kopfzeile mit der ersten Datenzeile zusammen und wiederholen sie bei Seitenumbrüchen. So wird der Unterschriftenblock nicht mehr zwischen Kopf- und Namenszeile getrennt. Ein zusätzlicher Regressionstest sichert die Formatierung.
- Betroffene Gesamt-PDFs, Arbeits-ZIPs und Einzel-PDF-ZIPs neu gebaut; Plugin-, Prompt-, Navigations- und Releaseprüfungen erneut durchgeführt.

## v5.27.0 - 2026-09-04

- Forderungsmanagement, beA-Einstieg und beide autarken Prompts führen schneller zum konkreten Arbeitsergebnis: Restrechnung, Beleganforderung, Antwort oder Prozessentwurf. Bereits beantwortete Fragen und geprüfte Inhalte werden übernommen; Detailregister bleiben im Arbeitsstand. Einzelne Stoppbefunde sperren die betroffene Außenmaßnahme, nicht unabhängige Aktenarbeit und Fristsicherung.
- Belegeinsicht rechtlich korrigiert: § 556 Abs. 4 Satz 2 BGB erlaubt die elektronische Bereitstellung bei Wohnraum. Das ältere Urteil VIII ZR 66/20 begründet keinen allgemeinen Papierzwang. Fachskills, Promptfassungen und mitgelieferte Quellenreferenzen sind synchron; Normabgleich am 04.09.2026 dokumentiert.
- Fünf nachträgliche Review-Hinweise aus Version 5.26.0 umgesetzt: Heizkostenanteile neu berechnet, zeitlich unmöglichen Urteilsbezug entfernt, interne Aktennotizen richtig klassifiziert sowie Rechnungs- und Vertragsgliederung verbessert. Braun weist nun 1.961,54 EUR Heizkosten und rechnerisch 684,28 EUR Nachforderung aus; offene Einwendungen und Beleglücken bleiben davon getrennt. Raumheizung und dezentrale Warmwasserbereitung sind eindeutig abgegrenzt.
- Testakten um drei ausformulierte Praxisdokumente erweitert: Treasury klärt eine Belegdublette, Hausservice benennt konkrete Nachweislücken und Riedel erläutert die Finanzierung eines noch nicht angenommenen Ratenvorschlags. Falsche Ratentermine, doppelte Rückfragen und die Vermischung von Drittzahlung und Vertretungsvollmacht bereinigt. Bestand: 174 Aktenstücke in zehn Akten, jeweils Gesamt-PDF, flaches Arbeits-ZIP und Einzel-PDF-ZIP.
- Heizkostenprüfung rechnet die ausgewiesenen Verteilungsquoten und Gerätewerte nach. Dokumentprüfung erfasst auch Texte, die sonst durch den Exportfilter verschwänden. PDF-Bau meldet Fehler und unbekannte Akten als fehlgeschlagen; Überschriften bleiben beim folgenden Text. Acht Regressionstests sichern diese Fehlerbilder und die aktuelle Belegeinsichtsregel in der Release-Pipeline.
- Schnellstart-Skill einschließlich Frontmatter unter 7.500 Zeichen gehalten; Werkstatt-Skill unter 30.000 Zeichen. README-Einstieg, Aktenregister und Beispielaufträge gestrafft, alle Vertrags-PDFs und Downloadpakete neu gebaut.

## v5.26.0 - 2026-08-25

- Alle neun Fach-Testakten von Fallgerüsten zu belastbaren Arbeitsakten ausgebaut. Die Wohnraummietverträge enthalten nun konkrete Mietobjekte, Zahlungswege, Betriebskosten, Belegeinsicht, Mietsicherheit, Gebrauch, Mängelanzeige, Hausordnung, Übergabe, Schlüssel, Kommunikation und Anlagen statt bloßer Eckdatentabellen.
- Acht neue Praxisunterlagen ergänzen entscheidende Beweis- und Konfliktlagen: Wohnflächen-Aufmaß, Sanierungsangebot mit Zutrittsterminen, Handwerkerrechnung, neuer Kontoauszug, Bankbestätigung eines nicht ausgeführten Auftrags, wohnungsbezogener Wasser-Verteilungsbogen, Objektbesuchsprotokoll, Zwischenbescheid zum Ratenwunsch sowie ein gesonderter Beendigungs- und Kautionsvermerk. Leere DMS-Beifänge und eine inhaltsarme Objektkurznotiz wurden entfernt beziehungsweise ersetzt.
- Betriebskostenakte Braun rechnerisch und inhaltlich neu aufgebaut. Kalte Betriebskosten, Heizkosten, Wasserverbrauch, Flächenanteile, Vorauszahlungen und Nachforderung stimmen nun durchgängig zwischen Mietvertrag, Abrechnung, Verteilungsblättern, Rechnungen, Zahlungsbelegen und DMS-Register; der Finanzvalidator prüft diese Rechenwege einzeln.
- Gesamt-PDFs folgen der fachlichen Reihenfolge des jeweiligen Aktenregisters. Jedes Aktenstück besitzt einen stabilen Dokumentkopf, eine lesbare Pfadangabe und eine passende Dokumentart; E-Mail-Metadaten werden als echter Nachrichtenkopf gesetzt. Lange Namen laufen nicht mehr aus dem Satzspiegel, mehrseitige DOCX-Ausgaben behalten Briefkopf und Registerfuß.
- Neuer Dokumentqualitäts-Validator sperrt künftig zu kurze Gerippe, leere oder didaktische Beifänge, unvollständige Mietverträge, sachfremde Tabellengerüste und interne Bewertungen in externer Korrespondenz. Release-CI, lokale Pflichtprüfung und Testakten-Dokumentation führen dieses Gate verbindlich.
- Sämtliche Gesamt-PDFs, Arbeits-ZIPs und Einzel-PDF-ZIPs neu erzeugt und visuell stichprobenartig geprüft. Der veröffentlichte Bestand umfasst 171 fachliche Aktenstücke; Arbeits-ZIPs bleiben flach, ohne Markdown und ohne Unterordner und enthalten ausschließlich DOCX, XLSX und PDF.

## v5.25.0 - 2026-08-09

- Autarken Forderungsmanagement-Werkstattprompt um gut ein Drittel vertieft. Vier sofort verständliche Startaufträge routen neue Akte, Neuzugang, Tagesfristen und gerichtsfertigen Schriftsatz ohne Skillwahl; auch KI-Umgebungen mit Einzeldatei- oder Kontextgrenzen erhalten eine belastbare Stapel- und Übergabelogik.
- Durchgängige Phasensteuerung ergänzt: Eingang, Frist, Rekonstruktion, Rechtsroute, Entscheidung, Produktion, Rückwärtskontrolle, menschliche Freigabe und Einreichungsnachlauf besitzen jeweils ein Muss-Ergebnis und ein Übergabegate. Neuzugänge springen kontrolliert in den Delta-Lauf zurück, statt einen bereits erzeugten Entwurf unbemerkt veralten zu lassen.
- Rohdaten- und Beweisführung geschärft. Dokument-, Ereignis-, Eingangs-, Import- und Zugangstag werden getrennt, Dubletten nicht gelöscht, OCR gegen das Originalbild gehalten und widersprüchliche SAP-/DMS-/Belegwerte als Konfliktdatensatz mit Freigabefolge geführt.
- Rechtsprechungslauf konkretisiert: amtliche Normen und höchstrichterliche Volltexte, Instanzrechtsprechung, bloße Suchhinweise und unverifizierte Treffer erhalten getrennte Quellenstatus. Arbeitskarten für die 2026-Linien zu Mietpreisbremse, gesundheitlicher Härte, Kündigungshaftung, Betriebskosten, Bonitätskosten und Gewerberaum-Indexklauseln übersetzen jedes Aktenzeichen in eine konkrete Fallprüfung.
- Gesetzgebungsstatus sprachlich korrigiert: BT-Drs. 21/6807 wird in Werkstatt- und Schnellstartprompt als Regierungsentwurf bezeichnet, der an die Ausschüsse überwiesen wurde, nicht als vermeintlicher Ausschussentwurf. Die vorgeschlagenen BGB-E-Regeln bleiben bis zu Verkündung und einschlägigem Inkrafttreten gesperrt.
- Standalone-Grenze des vertieften Werkstatt-Skills kontrolliert auf 30.000 Zeichen angehoben; die gebaute Fassung umfasst 26.763 Zeichen. Der Schnellstart bleibt mit 7.477 Zeichen weiterhin unter der unveränderten 7.500-Zeichen-Grenze.

## v5.24.0 - 2026-08-09

- Rechtsstand 2026 anhand amtlicher Quellen erweitert: Das seit 15.04.2026 am Amtsgericht Schöneberg für dessen eigenen Bezirk erprobte Online-Verfahren, die seit 01.07.2026 geltenden Pfändungsfreigrenzen und das gestufte Inkrafttreten der digitalen Zwangsvollstreckung ab 01.10.2026, 01.01.2027 und 01.06.2027 stehen in einer neuen mitgelieferten Stichtagsreferenz.
- Zahlungsklage, Zuständigkeit, Gerichtskosten und Dokumentenproduktion unterscheiden nun reguläre elektronische Einreichung und wirksam eröffnetes Online-Verfahren. Reine Geldforderung, 10.000-EUR-Grenze, tatsächlich zuständiges Pilotgericht, Landesregel, amtlicher Eingabedienst und unterstützte reale Vertretungsrolle sind eigene Gates; die derzeit nicht automatisch abgebildete Eigenvertretung einer privaten GmbH durch Beschäftigte wird nicht in den Sonderweg gedrängt.
- Gerichtskosten für den Online-Weg präzisiert: KV Nr. 1216 GKG mit 2.0 Gebühren und die begrenzte Ermäßigung nach KV Nr. 1217 werden nur nach bestandenem Verfahrensgate verwendet. Eine bloße PDF- oder eBO-Einreichung bleibt kostenrechtlich ein reguläres Verfahren.
- Vollstreckung auf den Normstichtag gehärtet: Lohnpfändungen verwenden die amtliche Tabelle ab 01.07.2026; Paragrafen 754a und 829a ZPO werden vor dem 01.10.2026 gesperrt. Die besonderen Versicherungen nach Paragrafen 752a und 753a werden nicht fälschlich auf Beschäftigte nach Paragraf 79 Abs. 2 S. 2 Nr. 1 ZPO übertragen; PDF/XML für PfÜB-Formulare bleibt bis 01.01.2027 Zukunftsrecht.
- Mietrechtsnovelle BT-Drs. 21/6807 als Entwurfsgate aufgenommen: Die am 09.07.2026 erst an die Ausschüsse überwiesenen Vorschläge zu Kurzzeitmiete, Möblierungszuschlag, Indexmiete, Modernisierung, ordentlicher Kündigung und Geschäftsraum-Belegeinsicht bleiben aus Berechnungen, Kündigungen und Schriftsätzen heraus, bis ein endgültiges Gesetz verkündet und zeitlich anwendbar ist.
- Werkstatt- und Schnellstartprompt führen die 2026er Klage- und Vollstreckungsgates autark aus und bleiben als einzelne Cowork-Skills innerhalb ihrer Zeichenlimits. README-Menüs, Plugin-Spiegel, Offline-Dokumentation und Release-Validatoren verlangen und verpacken die neue Referenz.

## v5.23.0 - 2026-08-09

- Einstieg auf zwei sichtbare Entscheidungen reduziert: Das Root-README führt vor dem großen Downloadkatalog entweder in die fachliche Fallbearbeitung oder in die rein technische beA-Endfertigung. Für beide Wege stehen Plugin, ein einziger Startsatz und das erwartete erste Ergebnis unmittelbar nebeneinander.
- Einheitlichen Ein-Satz-Start im Fachplugin verankert. README, Bedienstandard und Default-Intake verstehen denselben Auftrag, verlangen keine Skillnummer und liefern zuerst dieselbe Sofortkarte mit Akten-ID, Stichtag, Fristquelle, Ampel, Fortschritt, höchstens drei Kernlücken und Feld `Jetzt`.
- Default-Intake und Pflicht-Router trennschärfer aktiviert: Gemischte Ordner beginnen verbindlich mit Fristscan und Dokumentenmix; Fachskills folgen erst nach Startkarte und interner Triage. Nicht blockierende Unsicherheiten bleiben gelb, nur unmittelbar entscheidende Fragen zu Frist, Rolle oder Maßnahme unterbrechen.
- Werkstatt- und Schnellstartprompt auf denselben Ablauf gebracht, ohne externe Skills oder Repo-Dateien vorauszusetzen. Die erzeugten Standalone-Skills bleiben mit 19.891 beziehungsweise 7.323 Zeichen innerhalb ihrer Cowork-Grenzen und besitzen triggerstärkere Frontmatter-Beschreibungen.
- beA-Schriftsatzwerkstatt vereinfacht: Der Nutzer kann nur den Ordner und den Auftrag zur unveränderten technischen Endfertigung übergeben. Die Werkstatt übernimmt sicher erkennbare Angaben, zeigt zuerst eine Paketkarte und fragt ausschließlich offene Pflichtdaten gebündelt nach.
- Navigationsvalidator zum Quickstart-Vertragsprüfer erweitert. Er stoppt Releases, wenn Ein-Satz-Aufträge, Sofortkartenfelder oder die Platzierung des Direktstarts zwischen Root-README, Plugin-README, Bedienstandard, Default-Skills und Standalone-Prompts auseinanderlaufen.

## v5.22.0 - 2026-08-09

- Amtlichen BGH-Feed und neue Volltexte bis 05.08.2026 ausgewertet. VIII ZR 277/25 schärft den Sozialklausel- und Räumungsworkflow um Sachverständigenbeweis, Paragraf 144 ZPO und den richtigen Umgang mit Widersprüchen im Parteivortrag; VIII ZR 125/23 und VIII ZR 211/23 trennen bei der Mietpreisbremse objektive Vormiete, Informationen an Vor- und Nachmieter, Auskunft, Nachholung und Rechtsverfolgungskosten.
- Mietpreisbremsen-Streitwert stichtagsfest korrigiert: Seit 01.06.2025 gilt für die Feststellung der Überschreitung der Jahresbetrag nach Paragraf 41 Abs. 5 GKG. Der 42-fache Überschreitungsbetrag aus VIII ZR 211/23 bleibt ausdrücklich auf Altfälle beschränkt, in denen diese Gesetzesfassung noch nicht anwendbar ist.
- Die neuen Regeln stehen nicht nur in Referenzen: Skills für Sozialwiderspruch, Streitwert, Räumungsklage, Kappungsgrenze/Mietpreisbremse und Mieterklageverteidigung sowie Werkstatt- und Schnellstartprompt führen dieselben Tatbestands-, Beweis- und Stichtagskontrollen. Der Schnellstart bleibt unter 7.500 Zeichen, der große Standalone-Skill unter 20.000 Zeichen.
- beA-Schriftsatzwerkstatt auf den aktuellen amtlichen Technikstand nachgezogen: ERVB 2025, beA 4.5 und XJustiz 3.6.2 sind mit Quellenstatus dokumentiert. Ordnerannahme, Paketfreigabe, Prüfprotokoll und Versandauftrag erfassen nun den tatsächlich aktiven Clientstand, das XJustiz-Profil und wörtliche Clientwarnungen, statt eine bloß dokumentierte Version als lokal aktiv zu unterstellen.
- Fiesen Navigationsfehler geschlossen: Der Markdown-Validator prüft nun auch Sprungmarken, doppelte Überschriften, explizite HTML-Anker und Pfade außerhalb des Repos. Ein eigener Positiv-/Negativ-Selbsttest sichert fehlende Dateien, fehlende Fragmente und Pfadfluchten; CI und Pflichtprüflisten führen ihn vor jedem Release aus.
- Release-Strecke gegen Hänger gehärtet: Der GitHub-Job besitzt ein festes Zeitlimit und übernimmt die versionsbezogene Changelog-Zusammenfassung in die GitHub-Release-Notizen. Skill-Indizes, README-Navigation, Plugin-Spiegel, Rechtsanker und alle Cowork-/Marketplace-Metadaten wurden für Version 5.22.0 synchronisiert.
- Reproduzierbare Release-Umgebung ergänzt: `requirements-release.txt` bindet Dokument-, Tabellen-, PDF-, YAML- und Prüfwerkzeuge auf denselben Stand wie GitHub Actions. Die lokale Testaktenprüfung läuft damit nicht mehr erst spät auf fehlende Konvertierungsbibliotheken; zwei Paketwerkzeuge verzichten zudem auf die neuere `zip(strict=...)`-Schnittstelle und prüfen erforderliche Längengleichheit ausdrücklich.

## v5.21.0 - 2026-07-29

- DMS-Zeitachsen aller neun Fach-Testakten nachgezogen. Drei unmögliche Exporte mit erst später entstandenen Dokumenten wurden korrigiert, achtzehn neue Aktenstücke aus dem vorherigen Ausbau sind nun entweder im passenden DMS-Bestand oder als ausdrücklich nachgelagerter Aktennachlauf erfasst und sämtliche Trefferzahlen stimmen wieder mit den Tabellen überein. Gesamt- und Einzel-PDFs stellen DMS-Register als zusammengehaltene Datensatzkarten dar, sodass IDs, Indexnamen und Statushinweise nicht mehr in zu schmalen Spalten zerfallen.
- Gewollte Aktenwidersprüche sind jetzt in der jeweiligen Fallübersicht handlungsorientiert benannt: abweichende Zustellvermerke, Badfenster gegen Lüftungsöffnung, technischer Befund gegen Austauschforderung, Bankerklärung ohne Zahlung, Objektkosten ohne Wohnungsanteil, Jobcenter-Zahlung ohne Besitzaufgabe, neues Ratenangebot ohne Annahme und anonymer Arbeitgeberhinweis ohne belastbare Drittauskunft.
- Der Stammdatenvalidator prüft zusätzlich jede DMS-Exportliste auf vorhandenes Exportdatum, korrekte Trefferzahl und Dokumentdaten vor oder am Exporttag. Drei Negativ- und Positivtests sichern die neue Chronologieprüfung dauerhaft.
- Mieterhöhungs- und Vollstreckungsskills sind anhand ihres tatsächlichen Startzeitpunkts und ihrer Negativtrigger trennschärfer beschrieben. Vorbereitung, Verlangen, Zustimmungsklage, konkrete Vollstreckung und nachgelagerte Drittauskunft werden dadurch zuverlässiger geroutet.
- Fachplugin, Werkstattprompt und Bedienstandard unterscheiden nun strikt zwischen interner Arbeitsskizze mit Lückenmarken und außenfähigem Entwurf. Offene Platzhalter sperren Freigabe, Versand und beA-Übergabe. Der Build begrenzt nun auch die vollständige große Standalone-`SKILL.md` einschließlich Frontmatter auf 20.000 Zeichen; großer und kleiner Prompt werden mit 19.854 beziehungsweise 7.394 Zeichen ausgeliefert.
- Die beA-Werkstatt führt Quellenpfad und Hash von Anlagenplanung über Manifest und Signatur bis zur Eingangsakte fort. Ihr README enthält erstmals den vollständigen klickbaren Neun-Skill-Katalog mit sprechenden Arbeitsnamen.
- Der allgemeine Schriftsatzstandard begrenzt seine verfahrensrechtlichen BGH-Anker ausdrücklich auf die jeweils geprüfte abstrakte Aussage; Sachverhalt und materiell-rechtliche Wertung des Ausgangsfalls werden nicht ungeprüft auf Mietfälle übertragen.

## v5.20.0 - 2026-07-29

- Alle neun Fach-Testakten um insgesamt 18 fallbezogene Praxisunterlagen erweitert. Buchungsklärung, Einwurfprotokoll, Jobcenter-Nachlauf, Rücklastschrift, Kulanztelefonat, Fensterprüfung, Objektbegehung, Originalrechnungen, Ratenwunsch, Gerichtsvollzieher-E-Mail, Arbeitgeberhinweis und Objektarchiv-Recherche erhöhen den Bestand auf 163 fachliche Aktenstücke.
- Die neuen Unterlagen bilden gerade die unbequemen Beweis- und Klärungslagen ab: unbestimmter Verwendungszweck einer Teilzahlung, fehlende Banknachricht, nur angekündigte Fotos, nicht abgeschlossene technische Prüfung, widersprüchliche Wohnflächenangabe, ungesicherter Arbeitgeberhinweis und nicht wohnungsbezogener Altbefund. Alle Aktenregister und drei Downloadformen wurden entsprechend fortgeschrieben.
- Neuer mitgelieferter Schriftsatz- und Argumentationsstandard für Tatsachenkarte, Substantiierung, Bestreiten, sekundäre Darlegungslast, Beweisangebot, Subsumtion, Hilfsvortrag und Schlusskontrolle. Die allgemeinen Verfahrensanker BGH III ZR 81/24, IX ZR 129/22, IX ZR 209/23 und VII ZR 191/23 sind mit amtlichen Volltexten und klar begrenzter Arbeitsfolge dokumentiert.
- Zwanzig besonders schreibintensive Fachskills von Mahnung und Kündigung über Zahlungsklage, Räumung, Mieterhöhung, Replik und Verteidigung bis Kostenfestsetzung und Vollstreckung erhalten fallbezogene Argumentationsketten. Systemsaldo, Tatsachenvortrag und Rechtswertung bleiben getrennt; kein Anlagenverweis ersetzt den Tatsachensatz und kein Zeugenname das Wahrnehmungsthema.
- Werkstatt- und Schnellstartprompt führen die Schriftsatzlogik autark aus, ohne auf einen externen Skill zu verweisen. Beide bleiben innerhalb ihrer Cowork-Grenzen und verbinden Antrag, Tatbestandsmerkmal, konkrete Tatsache, Prozessstatus, Beweislast, Beweis, Subsumtion, Gegeneinwand und Rechtsfolge.
- Die fachlich neutrale beA-Werkstatt erhält einen eigenen Inhaltstreue- und Renderabgleich. Quellhash, Konvertierungsprofil, Ausgabehash, Seitenzahl und visuelle Kontrolle bilden eine geschlossene Kette; Abweichungen bei Antrag, Betrag, Namen, Termin, Seite oder juristischem Inhalt sperren das Paket.
- Release-Validatoren verlangen und verpacken beide neuen Referenzen. Zusätzliche Smoke-Tests sichern belastbaren Tatsachenvortrag und den Abbruch bei einer während der PDF-Konvertierung veränderten Zahl.

## v5.19.0 - 2026-07-26

- Den vorhandenen 100-Punkte-Bediencheck und 100-Punkte-beA-Fehlerkatalog erneut als konkrete Repo-Abnahme durchlaufen. Die dabei reproduzierten Fehler wurden nicht nur in den Ausgaben, sondern in Erzeugern, Validatoren und Smoke-Tests gesperrt.
- Neuer pluginübergreifender Skill-Katalog mit 59 Skills, kurzen Detailseiten, authentifizierungsfähigen Einzeldatei-Links und ausschließlich real veröffentlichten Assets. Ein Prüfmodus verhindert künftig veraltete Beschreibungen, fehlende Skills und verwaiste Indexseiten.
- `alle-skills-markdown.zip` ist jetzt direkt entpackbar. Statt zweier ineinander verschachtelter ZIPs enthält es die beiden Plugin-Ordner mit README-Indizes und allen `SKILL.md`; Quellenleitplanken bleiben im vollständigen Plugin-ZIP.
- Einzel-PDFs der Testakten beginnen unmittelbar mit dem natürlichen Aktenstück. Künstliche Zweitüberschriften, Markdown-Quellpfade und technische `Arbeitsakte: Einzel-PDF`-Footer wurden entfernt; Klageschrift, Mietvertrag und Aktennotiz wurden nach Neu-Build als PNG visuell geprüft.
- Testaktenexport gehärtet: Dateinamen werden konsistent in sichere ASCII-Namen transliteriert, Groß-/Kleinschreibungskollisionen erkannt und Symlinks sowie übergroße Quellen kontrolliert abgebrochen. Das Sammel-Arbeits-ZIP wird in README und Asset-Index nun korrekt als flaches Paket statt als Sammlung verschachtelter Akten-ZIPs beschrieben.
- Zwei kleine, aber folgenreiche Dokumentfehler behoben: Die Kowalski-Aktennotiz mit Jobcenter-Bezug bleibt bearbeitbares DOCX statt fälschlich PDF zu werden; das Dokumentdatum erzeugter DOCX/XLSX priorisiert Stand-, Datums- und Unterschriftsangaben und übernimmt nicht länger das zuerst genannte Geburtsdatum.
- Einen veralteten Skillverweis in der Schimmel-Verteidigungsakte auf den tatsächlichen Skill `45-hausverwaltung-schnittstelle` korrigiert. Der Navigationsvalidator prüft fortan vollständige Skill-IDs in allen Testakten-READMEs.
- Release-Prüfungen gegen Hänger und unbemerkte Paketabweichungen abgesichert: GitHub- und Git-Unterprozesse haben feste Zeitlimits, Hashes werden gestreamt, Asset-Paginierung ist begrenzt, Archivpfade werden auch dateisystemübergreifend auf Kollisionen geprüft und die neuen Skill-Indizes sind Pflichtbestandteil der Offline-Dokumentation.

## v5.18.0 - 2026-07-26

- Neunte Fach-Testakte `mieterklage-schimmel-schulz-verteidigung` ergänzt: 22 zusammenhängende Aktenstücke bilden eine zugestellte Mieterklage auf Mangelbeseitigung und Rückzahlung mit tatsächlichem Schimmel, Fenstererneuerung, abgesagtem Ersttermin, widerspruchsoffener Ursachenlage, Foto-Originalitätslücke, 61-stündiger Loggerlücke, Beweismatrix, Klageerwiderungsentwurf und roter Freigabekarte ab.
- Der Schimmelfall steht wie jede Akte als Gesamt-PDF, flaches Arbeits-ZIP aus DOCX/XLSX/PDF und flaches Einzel-PDF-ZIP bereit. Root-, Plugin- und Testakten-Menüs, Schnellwahl, Downloadmatrix, Schulungspfad und Smoke-Test führen direkt in die neue Verteidigungsakte.
- Schimmelverteidigung juristisch präzisiert: BGH VIII ZR 155/11 sperrt überspannte Anforderungen an technische Ursache und Minderungsquote; VIII ZR 67/18 und VIII ZR 271/17 werden korrekt auf bauzeitübliche Wärmebrücken, bloße Schimmelgefahr und die konkrete Zumutbarkeit des Heiz- und Lüftungsverhaltens begrenzt. Tatsächlicher Befall, Ursache, Zeitraum, Gebrauchsbeeinträchtigung und Quote bleiben getrennte Prüf- und Beweisfragen.
- Die fachliche Rechenprüfung wurde von einer einzelnen Betriebskostenakte auf alle neun finanziellen Fachakten erweitert. Sie stimmt Vertrag, aktuelle Miete, Mietkonto, Teilzahlung, Jobcenter-Aufteilung, Mieterhöhung, Betriebskosten, Ratenplan, Titel, KFB, Schimmel-Rückforderung und die angegebene Loggerlücke fallbezogen gegeneinander ab.
- Zwei bestehende Aktenfehler korrigiert: In der Meier-Akte bleibt die ursprüngliche Mietsicherheit nach der späteren Mieterhöhung unverändert; in der Kowalski-Akte sind Mietrückstand, Nebenkosten des Verfahrens und Jobcenter-Zahlung nun begrifflich und rechnerisch sauber getrennt.
- Echtformat-Erzeugung verbessert: Raumklima- und Beweismatrizen werden als Excel-Dateien ausgegeben; falltypische Mieter-, Gerichts-, Technik-, Foto- und Grundrissunterlagen erhalten passende PDF-Formate. Excel-Filter, Drucktitel und Fixierung orientieren sich jetzt an der größten echten Datentabelle statt pauschal am gesamten Blatt; fünfspaltige Beweismatrizen nutzen eine lesbare A4-Querformatansicht mit definiertem Druckbereich.
- Zwei unauffällige Infrastrukturfehler behoben: Der Rechtsanker-Validator erkennt dreistellige amtsgerichtliche Abteilungsnummern vollständig, und Gesamt-PDF-Deckblätter kürzen lange Fallbeschreibungen nur noch an Satz- oder Wortgrenzen statt mitten im Wort.
- Eine explizite Ruff-Konfiguration stabilisiert den beabsichtigten Prüfregelsatz über Werkzeugversionen hinweg. Marketplace-, Cowork-, Frontmatter-, Link-, Stammdaten-, PDF- und Release-Gates bleiben unverändert verbindlich.

## v5.17.0 - 2026-07-15

- Die acht fachlichen Testakten wurden um 52 fallspezifische Unterlagen ausgebaut. DMS-Exportlisten, Zahlungsavise, Konto- und Ratenmonitoring, Zustellnachweise, Objekt- und Hausverwaltungsvermerke, Jobcenter-Unterlagen, Betriebskostenbelege sowie Vollstreckungsnachlauf bilden nun insgesamt 123 bewusst heterogene Aktenstücke mit realistischen Dubletten, Versionskonflikten, Lücken und Nebeninformationen.
- Testakten-Downloads folgen einem streng geprüften Drei-Formate-Vertrag: direktes Gesamt-PDF, flaches Arbeits-ZIP mit ausschließlich DOCX, XLSX und PDF sowie flaches Einzel-PDF-ZIP. ZIPs enthalten weder Markdown noch Unterordner; Ordnerherkunft und Aktenzuordnung bleiben über sprechende, kollisionsfreie Dateinamen erhalten, das Gesamt-PDF wird im Arbeits-ZIP nicht gedoppelt.
- Gesamt-PDFs erhalten ein aktenbezogenes Deckblatt mit Sachverhaltskern und Dokumentenzahl. Breite Register werden als lesbare Datensatzkarten statt als zerhackte A4-Mikrospalten gesetzt; Word-Briefköpfe, Excel-Druckansichten und PDF-Einzeldokumente wurden gemeinsam visuell abgenommen.
- Große Akten laufen jetzt unter festen Ressourcenleitplanken: höchstens 20 Dateien oder 30 PDF-Seiten je Stapel, Fortsetzungsmarke nach jedem Stapel und Wiederaufnahme ohne erneutes Lesen oder Ausgeben unveränderter Inhalte. Sichtbare Register wurden auf höchstens sieben Spalten geteilt; gerichtliche Klageerwiderungen und außergerichtliche Mieterverein-/Anwaltsschreiben werden trennscharf zu Skill 37 beziehungsweise 43 geroutet.
- Gesamt-PDFs teilen lange vorformatierte Schreiben nun zeilenweise über Folgeseiten. Dadurch entfallen die großen Leerflächen der früheren starren 38-Zeilen-Blöcke, während Einrückung und Originalcharakter erhalten bleiben.
- Die beA-Schriftsatzwerkstatt verarbeitet große Ordner und Lang-PDFs nun gestreamt und wiederaufnehmbar: begrenzte Annahme-, Konvertierungs- und Sichtprüfstapel, atomare Arbeitskopien, Zeitlimits für externe Konverter sowie Fortsetzungsmarken verhindern übermäßige Speicherlast und Neustarts. Der Paketvalidator bricht riesige Verzeichnisauflistungen kontrolliert ab, bevor sie vollständig in den Speicher gelangen.
- Ein neuer exakt nummerierter 100-Punkte-Bediencheck macht die Verbesserungsmöglichkeiten für Autostart, Fristen, Wiederaufnahme, Lesbarkeit, Rechtsquellen, Gerichtspakete, DMS-Anschluss, Prompts, Testakten und Downloads dauerhaft abnehmbar. Der Strukturvalidator prüft Vollständigkeit und Mitlieferung im Plugin-ZIP. Die Bedienprosa aller Fachskills folgt jetzt einheitlich Arbeitskarten und einer Klartextaktion statt generischer Menüs.
- Falleinstieg beschleunigt und vereinfacht: Der Default-Intake scannt zuerst den gesamten sichtbaren Bestand auf Gerichtspost, Zustellung, Fristen, Zahlungen, Kündigungen und defekte Dateien. Eine kompakte Sofortkarte erscheint vor der Tiefenauswertung; danach arbeitet das Plugin automatisch in risikoorientierten Stapeln weiter und zeigt Nutzern Arbeitsaktionen statt interner Skillnummern.
- Skillaktivierung geschärft: Belegmatrix, Strategieentscheidung und Schonfristzahlung sind trennscharf abgegrenzt; der Vorzustellungs-Kostenpfad führt erst nach fachlicher Klärung in die technische Einreichungswerkstatt. Der README-Validator vergleicht den sichtbaren Skill-Katalog nun mit den aktuellen Frontmattern und stoppt bei veralteten Beschreibungen.
- Gerichtspaket-Workflow rechtlich korrigiert: Skill 23, beide autarken Prompts, READMEs, Bedienreferenz und Smoke-Tests unterscheiden jetzt zwingend zwischen Kanzlei/beA und Eigenvertretung der privaten Konzerngesellschaft. Für die Eigenvertretung werden Paragraf 79 ZPO, eBO nach Paragraf 130a Abs. 4 S. 1 Nr. 3 ZPO und Paragraf 10 ERVV oder ein zulässiger schriftlicher Weg geprüft; Paragraf 130d ZPO wird nicht mehr pauschal auf eine private GmbH übertragen.
- Aktuelle Hochrisikoanker erneut in den amtlichen Volltexten kontrolliert: VII ZR 93/25, VIII ZR 4/23, XII ZR 51/25, XII ZR 71/24, VIII ZR 6/24, VIII ZR 46/25, VIII ZR 47/25 und VIII ZB 17/25 sind erreichbar und den zutreffenden Arbeitsfolgen zugeordnet.
- Streitwert- und Betriebskostenlogik präzisiert: XII ZR 71/24 lässt für künftige Nutzungsentschädigung bis zur Rückgabe die Abgrenzung zwischen Paragraf 3 und Paragraf 9 ZPO ausdrücklich offen; VIII ZR 46/25 und VIII ZR 47/25 betreffen die Umstellung von Einzelöfen auf gewerbliche Wärmelieferung, bei der Paragraf 556c BGB weder unmittelbar noch entsprechend gilt. Validatoren sperren verkürzte Aussagen und den zuvor still überschriebenen Doppelprüfeintrag.
- Die beA-Werkstatt akzeptiert jetzt ordnungsgemäß zugeordnete, abgesetzte CAdES-Signaturdateien in den amtlich vorgesehenen Endungen. Ein eigenes Signaturmanifest bindet jede Signatur über Ziel-PDF, Hash, Dateigröße, Signaturniveau, Unterzeichner und grünes Prüfprotokoll; Signaturen fließen in Mengen- und Größenlimits ein und werden in 205 validen und adversarialen Selbsttestfällen geprüft.
- Release-Blocker behoben: Builder, Testaktenprüfung und Gesamt-Releaseprüfung verwenden nun denselben zentralen Vertrag für das Testakten-Indexschema. Der zuvor auf Version 1 stehen gebliebene Gesamtvalidator kann den aktuellen Version-2-Index nicht mehr fälschlich zurückweisen.

## v5.16.0 - 2026-07-15

- Neues eigenständiges Plugin `schriftsatzwerkstatt-bea` mit neun fachlich neutralen Skills: Ordnerannahme, Versionssperre, Anlagenfolge, PDF-Konvertierung, visuelle PDF-Prüfung, ASCII-Dateinamen und Manifest, Signatur-/Versandweg, Paketfreigabe sowie Eingangssicherung. Der Autostart führt ohne manuelle Skillauswahl durch die technische Werkstatt und stoppt bei fachlichem Änderungsbedarf.
- ERV-Regeln mit amtlichem Stand 14.07.2026 geprüft: ERVV in der zuletzt am 22.06.2026 geänderten Fassung, ERVB 2025 mit 90 Zeichen, 1.000 Dateien und 200 Megabyte. Die Werkstatt verwendet bewusst höchstens 80 ASCII-Zeichen, rechnet 200 MB vorsorglich dezimal und verhindert gemeinsame qeS für mehrere elektronische Dokumente.
- Release- und Navigationsstrecke auf zwei Plugins erweitert: generischer Plugin-ZIP-Bau, getrennte Markdown-Pakete, vollständige README-Menüs, pluginbezogene Referenzprüfung und zusätzliche Defektmutation für das beA-Werkstatt-ZIP.
- Paketvalidator und Werkstattlauf gehärtet und beschleunigt: blockweises Hashen und Gefahrenscannen statt vollständiger Mehrfachlesung, begrenzt parallele PDF-Prüfung, exakter CSV-Kopf, sichere relative Quellpfade, Schutz vor Tabellenformeln und Symlinks, genau ein Hauptschriftsatz, strikter K-/B-Abgleich sowie mehr als 170 eingebaute valide und adversariale Selbsttestfälle.
- Neuer 100-Punkte-Fehlerkatalog und konkreter Delta-Workflow. Unveränderte Arbeitskopien werden nur bei identischem Quellhash, Konvertierungsprofil, Werkzeugstand, Ausgabehash und grünem Sichtstatus wiederverwendet; Konvertierungsprotokoll, Prüfprotokoll, Versandauftrag und Eingangsvermerk bilden die Kontrollspur vollständig ab.
- Miet-, Prozess-, Kosten- und Vollstreckungsanker in 50 Fachskills erneut gegen amtliche Quellen abgeglichen, Fehlzuordnungen gesperrt und Quellenstatus, Tatbestandsvoraussetzungen sowie Entscheidungsfolgen in den zuständigen Workflows präzisiert.
- Fallstart und Renofa-Triage sprechend neu geordnet: Der neue Skill `06-fallziel-renofa-triage` übernimmt neue Akten ohne manuelle Skillauswahl, grenzt das Arbeitsziel ab und routet mit klaren Stop- und Freigabepunkten in die passende Bearbeitung.
- Werkstatt- und Schnellstartprompt stärker auf konkrete Aktenarbeit, Normprüfung, Beweislast, Anlagen und versandfertige Outputs verdichtet; die korrigierten Mieterhöhungs- und Betriebskostenakten wurden anschließend neu als Gesamt-PDF erzeugt.

## v5.15.0 - 2026-07-11

- Root-, Plugin- und Testakten-READMEs als durchgängiges Download-Menü nachgeschärft: Governance- und Lizenzdateien sind klickbar, Prompt-Assets direkt erreichbar und jede Testakte führt in einer zentralen Matrix sowie im eigenen README zu Gesamt-PDF, Arbeits-ZIP und Einzel-PDF-ZIP.
- Die bisher nur im Repo und Arbeits-ZIP vorhandenen neun Gesamt-PDFs werden nun zusätzlich als eigenständige Release-Assets `testakte-<slug>-gesamt.pdf` veröffentlicht. Asset-Index, Katalog, Prüfsummen, GitHub-Upload und Remote-Prüfung bilden diese dritte Downloadform vollständig ab.
- Fiesen Release- und Navigationsfehler dauerhaft gesperrt: Der Remote-Validator erkennt die neuen PDFs als Pflichtassets; eine Defektmutation beweist den Abbruch bei fehlendem Gesamt-PDF. Der README-Validator verlangt außerdem jedes redaktionelle Aktenstück im Register `## Akte` und deckte dadurch sieben bislang nicht verlinkte Aktennotizen auf.

## v5.14.1 - 2026-07-11

- Verbliebenes automatisches Review-Finding aus PR 55 umgesetzt: Der Stammdaten-Validator erkennt Geburtsdaten jetzt auch in Markdown-Tabellen wie `| Geburtsdatum | 14.03.1972 |`. Ein abweichendes Datum aus Vertrag, SAP oder README kann dadurch nicht mehr unbemerkt den Release passieren.
- Rein namenlose Geburtsdatenquellen werden ebenfalls gegeneinander geprüft. Zwei unterschiedliche Werte ohne benannte Referenzperson brechen die Validierung ab, statt wegen einer leeren Vergleichsmenge still akzeptiert zu werden.
- Zwei neue Negativ-Fixtures sichern Tabellenfelder und rein namenlose Konflikte. Die übrigen offenen Codex-Threads der jüngsten PR-Historie wurden gegen `main` geprüft; ihre Korrekturen an Umlauten, Gericht, Dezimalgliederung sowie Vertragsbeginn- und Namensparsern sind bereits vollständig enthalten.

## v5.14.0 - 2026-07-11

- Rechtsstands-Audit anhand amtlicher Bundes-, BGH-, BVerfG-, EuGH- und Berliner Quellen abgeschlossen: allgemeine Amtsgerichtsgrenze von 10.000 EUR, Wohnraummietzuständigkeit, Konzern-/Eigenangelegenheit nach Paragraf 2 RDG, Prozessvertretung nach Paragraf 79 ZPO, KFB-Rechtsbehelf, Drittauskunft und Vollstreckungsverjährung sind in den zuständigen Skills präzisiert.
- Quellenkanon bereinigt: den nicht amtlich verifizierbaren Zukunftsanker OLG Karlsruhe `7 U 173/25` und den falsch zugeordneten EuGH-Anker `C-732/22` entfernt; drei Hinweise nach Paragraf 552a ZPO korrekt als Hinweisbeschlüsse bezeichnet und das Datum von EuGH `C-741/21` auf 11.04.2024 korrigiert.
- Berliner Mieterhöhungsfall auf den seit 28.05.2026 geltenden Mietspiegel 2026 umgestellt. Wohnlage, Tabelle 9.2/Zeile 85, Spannenwerte, Merkmalgruppen und Freigabeampel sind jetzt rechnerisch und prozessual konsistent; die alte Mietspiegeldatei wurde ersetzt und sämtliche betroffenen Gesamt-PDFs neu gebaut.
- Sieben Fachakten zu Rückstand, Kündigung, Räumung, Betriebskosten, Mieterhöhung und Vollstreckung fachlich nachgeschärft: Fälligkeit, Tilgung, Zugang, Schonfrist, Räumungsstreitwert, Belegeinsicht, KFB-Schwelle, Gerichtsbezeichnungen und Einreichungsreife stimmen nun mit Konto, SAP, Vertrag und Korrespondenz überein.
- Neuer Pflichtvalidator `validate-legal-anchors.py` sperrt bekannte Scheinzitate, falsche Entscheidungsdaten, veraltete Norm- und Landesrechtsstände, unzugeordnete operative Aktenzeichen und auseinanderlaufende Referenzkopien. Er läuft lokal, in den Agentenregeln und im Release-CI.
- Cowork-Preflight repariert: Werkstattprompt und Schnellstartprompt bleiben rechtsgebietsspezifisch, bauen aber wieder innerhalb der 20.000-Zeichen-Quellgrenze beziehungsweise als vollständiger Standalone-Skill mit 7.486 Zeichen. Markdown-Weblinks werden in Testakten-Gesamt-PDFs lesbar und anklickbar ausgegeben.

## v5.13.1 - 2026-07-10

- Release-Integrität gehärtet: Plugin-, Marketplace-, Dokumentations- und Skill-ZIPs werden nun auf sichere Pfade, eindeutige Einträge, CRC, vollständigen Dateisatz und bytegenaue Übereinstimmung mit dem getrackten Quellstand geprüft. Manifest-, Marketplace- und Release-Tag-Version müssen identisch sein.
- Testakten-Pakete werden nicht mehr nur anhand weniger Anfangsbytes akzeptiert. DOCX/XLSX müssen gültige OOXML-Kernbestandteile enthalten, PDFs vollständig lesbar und unverschlüsselt sein, EML-Dateien Pflichtheader und Nachrichtentext besitzen; Gesamt-PDFs und jeder Indexpfad sind zwingend.
- Dokumenterzeugung korrigiert: Überschriftenabstand wird tatsächlich gesetzt, E-Mail-Zeitstempel verwenden Sommer- und Winterzeit für Europa/Berlin, DOCX-/XLSX-Metadaten folgen dem Dokumentdatum und der PDF-Renderer bricht bei fehlendem Modul kontrolliert ab.
- Betragsparser gegen Punktdezimalwerte aus SAP-/CSV-Exporten abgesichert und mit fünf deutschen/internationalen Zahlenformaten selbstgetestet.
- Release-CI kompiliert und prüft jetzt sämtliche Python-Werkzeuge mit Ruff. Sechs Defektmutationen sichern die neuen Release-Gates dauerhaft ab; 27 bestehende statische Codebefunde wurden bereinigt und die Release-Beschreibung nennt das Schnellstartlimit korrekt als 7.500 Zeichen statt als Dateigröße.
- Repo-Audit über 282 Skill-/Referenzverweise und 85 externe Links abgeschlossen: keine verwaisten internen Verweise, öffentliche Primärquellen erreichbar; private Release-Links bleiben erwartungsgemäß an die GitHub-Anmeldung gebunden.

## v5.13.0 - 2026-07-10

- Skill `23-klage-egvp-bea-einreichen` zur vollständigen Gerichtsprozess-Dokumentenproduktion ausgebaut: Gestaltungsabfrage, Versionssperre, Einzel-PDFs, sichtbare K-/B-Anlagenkennzeichnung, ASCII-Dateinamen, Hashmanifest, ERVV-/Signaturgate, Versandauftrag und Eingangsnachlauf.
- Skill `39-beweisangebot-anlagenplan` erzeugt jetzt ein fortlaufendes, revisionsfähiges Anlagenmanifest mit Beweislast, Originalquelle, bereits eingereichten Nummern, Version/Hash, Seiten, Zielname und Beschaffungsstatus.
- Neue mitgelieferte Referenz `erv-dokumentenproduktion.md` bündelt Paragrafen 130, 130a, 130d und 253 ZPO, Paragraf 2 ERVV, ERVB 2025, NRW-Namenskonventionen sowie BGH-/BVerfG-Anker zum elektronischen Rechtsverkehr.
- Neues Rechtsprechungsradar 2021 bis 2026 trennt BGH/BVerfG/EuGH-Primäranker von KG-, OLG- und LG-Fallradar sowie Dejure/OpenJur- und Gansel-Recherchehinweisen; Sekundärquellen werden nicht als Autorität verwendet.
- Datenschutz-Skill fachlich korrigiert: Aufbewahrung nach Dokumenttyp gemäß Paragraf 147 AO, Auskunftei-Prüfung mit zwei Mahnungen und EuGH-Matrix für Verstoß, Schaden und Kausalität.
- Werkstatt- und Schnellstartprompt bilden den Gerichtspaket-Workflow autark ab. README-Menüs, Skill-Arbeitsnamen, Router, Smoke-Tests und Release-Validatoren sichern dieselbe Funktion im Plugin und in den Standalone-Skills.

## v5.12.10 - 2026-07-10

- Root-, Plugin- und Testakten-READMEs zu einer durchgängigen Navigation verbunden: zentrale Downloadkarte, klickbarer Index aller 50 `SKILL.md`, Testakten-Breadcrumbs und vollständige Referenzübersicht.
- Neues Offline-Paket `immobilien-forderungsmanagement-dokumentation.zip` bündelt den vollständigen getrackten Repo-Inhalt ohne Git-Metadaten und Build-Abfall; relative Links funktionieren nach dem Entpacken.
- `release-katalog.md` listet jedes veröffentlichte Asset mit Direktlink, Größe und Zweck; `checksums-sha256.txt` sichert alle übrigen Assets ab.
- Neuer README-Navigationsvalidator und erweiterte Release-Prüfung verhindern fehlende Skill-Links, unvollständige Testakten-Menüs, nicht katalogisierte Downloads und Prüfsummenabweichungen.
- Veralteten Quellenstand und fragile feste Asset-Anzahl im Plugin-README entfernt; generierte Skill-Beschreibungen enden jetzt an Wortgrenzen.

## v5.12.9 - 2026-07-09

- Wohnraummietzahlung rechtsprechungsfest präzisiert: BGH VIII ZR 222/15 trennt rechtzeitigen, gedeckten Überweisungsauftrag vom späteren Kontoeingang; VIII ZR 129/09 und VIII ZR 291/09 klären den Sonnabend bei der Zahlungsfrist.
- Außenwirksame Workflows erhalten eine getrennte Freigabekarte. Standard bleibt `ENTWURF - NICHT VERSENDEN/EINREICHEN`; nur eine reale Freigabeperson setzt `FREIGEGEBEN`, und relevante Änderungen heben die Freigabe auf.
- Strukturvalidator, Werkstatt-/Schnellstartprompt, 21 risikoreiche Skills, Quellenreferenzen, READMEs und Smoke-Tests erzwingen dieselbe Rechts- und Freigabelogik.

## v5.12.8 - 2026-07-09

- Laufende Akten werden jetzt als Delta fortgeschrieben: Akten-ID und Stichtag bleiben erhalten, neue Zahlungen, Gerichtspost oder DMS-Unterlagen aktualisieren nur betroffene Salden, Fristen, Beweise und Prozessstände.
- Neue Änderungskarte verhindert stillen Zustandsverlust: unveränderter Kernstand, Neuzugang, überholte Annahmen oder Entwürfe, Sofortfrist und genau ein Folgeskill werden ausdrücklich ausgewiesen.
- Skills `01`, `03`, `05`, `06`, `33`, `37` und `50`, beide autarken Prompts, Bedienreferenzen, READMEs und Smoke-Tests sprechen dieselbe Fortschreibungslogik.

## v5.12.7 - 2026-07-09

- Kaltstart weiter vereinfacht: Root-README enthält jetzt einen "Start in 30 Sekunden"-Abschnitt mit Alltagssätzen und erwarteter erster Ausgabe.
- Große Upload-Bundles werden explizit zweiphasig geführt: zuerst sichtbare Startkarte und Dokumenteninventar, danach tiefe Auswertung in Stapeln.
- Skill `33-dokumentenmix-ocr-sichten`, Plugin-README, Bedienführungsreferenz und Smoke-Tests sind auf diesen schnellen Autostart synchronisiert.

## v5.12.6 - 2026-07-09

- Plugin-README um direkt kopierbare Startaufträge ergänzt: neuer Fall, SAP-Statusauszug, fertige Fallkarte, Gerichtspost und Kosten/Vollstreckung führen jetzt jeweils zum erwarteten Startskill oder Zielpfad.
- Deployment-Readiness-Smoke-Test erweitert: Pilotgruppen dürfen kein Repo-Insiderwissen brauchen, um den richtigen Startauftrag zu formulieren.
- Qualitäts-Sweep ohne Slug-Änderungen: Skill-Ordner, interne Links, Prompt-Größen und Release-Struktur bleiben stabil.

## v5.12.5 - 2026-07-09

- Großen Werkstattprompt an einer generischen Reststelle geschärft: Ohne Akte wird nicht mehr mit "Beispielstruktur" gearbeitet, sondern mit Startkarte, Register, Ampel, Lückenliste und nächstem Schritt.
- Smoke-Tests ergänzt: Autostart ohne Skill-Nennung wird jetzt ausdrücklich geprüft, inklusive Nutzersatz "Hier ist ein neuer Fall, mach die Akte fertig".
- Deployment-Readiness-Test erweitert: Autostart über Skill `33` und die neue Übersicht mit stabilen Skill-IDs plus Arbeitsnamen sind nun Release-Abnahmepunkte.
- Strukturvalidator fokussiert: Der langsame doppelte Markdown-Linkscan wurde entfernt; Linkprüfung läuft weiterhin separat über `scripts/validate-markdown-links.py`.

## v5.12.4 - 2026-07-08

- Skill-Zuordnung verbessert, ohne Skill-Slugs oder Links zu ändern: Die Plugin-README zeigt nun stabile technische Skill-IDs plus kuratierte Arbeitsnamen für alle 50 Skills.
- Autostart geschärft: Neue Fälle, Projektordner, Aktenordner und gemischte Upload-Bundles landen ausdrücklich bei `33-dokumentenmix-ocr-sichten`, der Startkarte, Inventar, Fristen, Beweiswert, Lückenliste und nächsten Skill liefert.
- Startskill-Beschreibungen für `01`, `06`, `33` und `34` synchronisiert; SAP-Input, Triage und technische Normalisierung sind jetzt klar vom Default-Autostart abgegrenzt.
- Root-README, Plugin-README sowie Werkstatt- und Schnellstartprompt auf den Einstieg "neuer Fall / mach die Akte fertig" ausgerichtet.

## v5.12.3 - 2026-07-08

- Werkstattprompt und Schnellstartprompt weiter auf fallbezogene Normenarbeit geschärft: Fallkarte, Tatbestandskarte, Beweislast, BGH-/BVerfG-Anker, Quellenstatus und Rechtsfolge stehen jetzt direkt im Startablauf.
- Schnellstartprompt trotz Größenlimit konkreter gemacht: Rückstand, Mieterhöhung, Betriebskosten, Kosten und Vollstreckung werden mit eigenen Normenankern geführt.
- Standalone-Skill-Generator und Plugin-/Marketplace-Descriptions auf Fallkarte, Normenanker, Beweislast und Rechtsprechungsanker synchronisiert.

## v5.12.2 - 2026-07-08

- Werkstattprompt und Schnellstartprompt nochmals auf die Kernlogik verdichtet: Rechtsprechungs-Fallkarte, Normenanker, Tatbestandswichtigkeiten, Beweislastmerker, Rechtsprechungsanker, Quellenstatus und Rechtsfolgen stehen nun direkt in Startkarte, Rohdatenablauf und Ausgabeordnung.
- Outputvarianten ausdrücklich gemacht: Prüfung, Matrix, Entwurf, KFA, Vollstreckung und RA-Übergabe werden als konkrete Arbeitsprodukte geführt, nicht nur als allgemeiner Dokumentauftrag.
- Standalone-Skill-Generator und Plugin-/Marketplace-Descriptions auf Rechtsprechungs-Fallkarte, Normenkarte, Outputvarianten und BGH-Anker synchronisiert.

## v5.12.1 - 2026-07-08

- Werkstattprompt und Schnellstartprompt weiter entgeneralisiert: Rechtsprechungs-Fallkarte, Outputwunsch, Normenanker, Tatbestandsmerkmale, Beweislastmerker, Quellenstatus und Rechtsfolgen stehen noch früher im Arbeitsablauf.
- Standalone-Skill-Metadaten für Cloud-Co-Work erneut geschärft, damit Mini- und Werkstatt-Skill als spezifische Immobilien-Forderungsmanagement-Skills mit Rechtsprechungs-Fallkarte, Normenkarte, BGH-Ankern, Klage, Räumung, Mieterhöhung und Kostenpfad erkannt werden.
- Plugin- und Marketplace-Description auf die neue Schwerpunktlogik synchronisiert; Release-Metadaten auf v5.12.1 angehoben.

## v5.12.0 - 2026-07-08

- Werkstattprompt und Schnellstartprompt rechtsgebietsspezifisch geschärft: beide arbeiten jetzt ausdrücklich mit Fallkarte, Aktenregister, Normenkarte, Tatbestand, Beweislast, BGH-/BVerfG-Anker, Quellenstatus und Rechtsfolge statt allgemeiner Ablaufprosa.
- Rechtsprechungsanker im Werkstattprompt datiert und präzisiert: Schonfristzahlung, Mieterhöhung, Mietpreisbremse, Betriebskosten/Wärmelieferung, Räumung/Nachlauf und Kostenpfad führen Gericht, Datum, Aktenzeichen und konkrete Arbeitsregel.
- Standalone-Skill-Metadaten für Cloud-Co-Work präzisiert, damit Mini- und Werkstatt-Skill schon in der Skill-Erkennung auf Normenkarte, BGH-Anker, Aktenintake, Klage, Räumung, Mieterhöhung, Kostenpfad und Vollstreckung ausgerichtet sind.
- Release-Metadaten auf v5.12.0 angehoben; Plugin- und Marketplace-Description nennen Normenkarte und BGH-Anker als zentrale Arbeitslogik.

## v5.11.2 - 2026-07-07

- README-Ansichten final sortiert und besser verlinkt: Root-README, Plugin-README, Testakten-Index und alle Einzel-Testakten führen jetzt schneller zu Installation, Skills, Prompts, Testakten, Quellen und Abnahmetests.
- Jede Testakte hat eine knappe Auf-einen-Blick-Tabelle mit Trainingspfad, Startskills, Kernentscheidung und Besonderheit; rechtliche Kurzformeln zu Kostenweg, Belegeinsicht, Vollstreckung und Mietspiegel wurden präzisiert.
- Neuer schneller Validator `scripts/validate-markdown-links.py` prüft lokale Markdown-Links ohne Netzwerkzugriff. Der Release-Workflow und die Agenten-/Smoke-Test-Dokumentation führen ihn jetzt als Pflichtcheck.
- Release-Metadaten auf v5.11.2 angehoben; neue Release-Artefakte werden aus dem validierten Stand gebaut.

## v5.11.1 - 2026-07-06

- Einzelne Testakten-READMEs mit den in v5.11.0 ergänzten realistischen Aktenstücken synchronisiert: E-Mail-Nachträge, Rückrufnotizen, DMS-/DocuWeb-Hinweise, unklare Verwendungszwecke und Vollstreckungsrückläufe sind jetzt pro Fall direkt auffindbar.
- Root-README, Plugin-README und Smoke-Tests präzisieren die Abnahme der bewusst unaufgeräumten Trainingsakten: zuerst Dokumenteninventar, Beifang-Liste, Belegstatus, Rückfragen und Ampel, dann erst Forderung, Kündigung, Klage oder Vollstreckung.
- Release-Metadaten auf v5.11.1 angehoben; Download-Blöcke der Testakten bleiben im nächsten Build mit den vorhandenen Gesamt-PDFs synchron.

## v5.11.0 - 2026-07-06

- Testakten realistischer und weniger glatt gemacht: acht Fachfälle enthalten zusätzliche E-Mail-Nachträge, Rückrufnotizen, DMS-Beifänge, Dubletten- und Scanqualitätsvermerke, unklare Verwendungszwecke oder angekündigte fehlende Anlagen.
- Gesamt-PDFs der Testakten neu gebaut, damit die zusätzlichen Aktenstücke in Arbeits-ZIPs, Gesamt-PDFs und Einzel-PDF-ZIPs aus derselben Markdown-Quelle mitlaufen.
- Testakten-README ergänzt: Die neuen Unschärfen sind absichtlicher Schulungsstoff für Aktenintake, Belegmatrix, Rückfragen und Ampelsteuerung, ohne Kernbeträge oder Stammdaten zu verfälschen.

## v5.10.4 - 2026-07-04

- Plugin-README um eine klare Rollout-Abnahme ergänzt: Release-Workflow grün, 29 Assets vorhanden, Remote-Asset-Prüfung erfolgreich.
- AGENTS.md und Smoke-Tests auf dieselbe Release-Abnahmelogik synchronisiert, damit Agenten, Training und Produktivrollout dieselbe Prüfkette verwenden.
- Manuelle Nachkontrolle nach Workflow-Ende konkretisiert: veröffentlichte Assets herunterladen und die ZIP-Validatoren gegen das Download-Verzeichnis laufen lassen.

## v5.10.3 - 2026-07-04

- Release-Workflow gehärtet: Nach Upload oder Clobber prüft GitHub die tatsächlich veröffentlichten Assets remote auf Name, Status, Größe und SHA-256-Digest.
- README und Agentenhinweise um die Release-Asset-Prüfung ergänzt, damit Produktivrollouts nicht nur lokale ZIPs, sondern die veröffentlichten Downloads abnehmen.
- `scripts/validate-release-assets.py` präzisiert: Bytevergleich ist für denselben Build-Job gedacht; nach einem fremden Workflow-Rebuild sind die heruntergeladenen Release-Assets inhaltlich zu validieren.

## v5.10.2 - 2026-07-04

- Release-Kommunikation auf den tatsächlichen Stand synchronisiert: acht Berliner Fachfälle plus Mietspiegel-Referenz, 50 Skills und ein README-Index im Skill-Markdown-Bundle.
- Pflichtvalidatoren in README und Agentenhinweisen vereinheitlicht; der Stammdatencheck ist jetzt auch dort ausdrücklich Teil des Vor-Push-Checks.
- Skill-Markdown-Build-Log präzisiert, damit Release-Abnahme zwischen 50 `SKILL.md`-Dateien und 51 Markdown-Dateien im Bundle unterscheiden kann.
- Schema-Helfer `scripts/validate.py` robuster gemacht: ein Direktaufruf zeigt jetzt die Usage, auch wenn die optionale `jsonschema`-Abhängigkeit lokal fehlt.

## v5.10.1 - 2026-07-03

- Die sieben Alt-Mietverträge der Testakten auf die verbindliche Dezimalgliederung umgestellt (Überschriften 1 bis 7 statt Paragraf-Schema, Absätze als 1.1, 1.2 statt Klammerziffern); Gesetzeszitate wie Paragraf 573 BGB bleiben unverändert. Der bewusste Sprung auf Abschnitt 14 Schriftform im Meier-Vertrag (Auszugscharakter) bleibt erhalten. Betroffene Gesamt-PDFs neu gebaut.
- Kontrollbefund dokumentiert: Die scheinbare Differenz zwischen Meier-Vertrag (Summe 1080 EUR bei Vertragsschluss 2019) und Akte (1180 EUR) ist gewollte Lebensnähe durch die dokumentierte Mieterhöhung 2021 im SAP-Auszug; keine Korrektur erforderlich.


## v5.10.0 - 2026-07-03

- Testakten-Arbeits-ZIPs enthalten kein Markdown mehr, sondern den lebensechten Formate-Mix: SAP- und FBL5N-Auszüge als XLSX, eigene Schreiben, Verträge, Schriftsätze und Vermerke als DOCX mit Briefkopf, Mieter-E-Mails als EML mit echten Headern, Urteile, Beschlüsse, Bescheide, Betriebskostenabrechnung und Mietspiegel als PDF. Die Markdown-Dateien bleiben redaktionelle Quelle; Arbeits-ZIP, Gesamt-PDF und Einzel-PDFs sind dadurch garantiert inhaltsgleich.
- Neues Konverter-Modul `scripts/testakte_realformate.py` mit deterministischer Format-Zuordnung über Dateinamens-Schlüsselwörter; zeilentreue Umsetzung von Adressblöcken und Briefköpfen.
- Release-Validator erzwingt die neue Regel: Markdown im Arbeits-ZIP bricht den Build; DOCX/XLSX/EML/PDF werden per Magic-Bytes geprüft.
- Verbindliche Regel für alle künftigen Testakten und alle Werkzeuge dokumentiert in CLAUDE.md, AGENTS.md und testakten/README.md; Download-Beschreibungen und Smoke-Test 11 aktualisiert.


## v5.9.1 - 2026-07-02

- Stammdaten-Validator gehärtet (Codex-Review-Findings zu PR 54): erfasst jetzt auch Mietbeginn und Doppelpunkt- oder Bullet-Formate, Fließtext-Formulierungen, invertierte Namen wie Becker Komma Wolfgang, Geburtsnamen (geb. Schubert) und namenlose Geburtsdaten aus SAP-Auszügen, die gegen die benannten Personen der Akte geprüft werden. Jahresangaben bei Kindern lösen keine Fehlalarme aus.
- Eingebauter Selbsttest mit Positiv- und Negativ-Fixtures für alle erfassten Formate; läuft im CI-Workflow vor dem eigentlichen Validatorlauf.


## v5.9.0 - 2026-07-01

- Stammdaten-Konsistenz in vier Testakten repariert: Riedel (Vorname, Geburtsdatum, Vertragsnummer und Vertragsbeginn wichen zwischen README, SAP, Mietvertrag und Korrespondenz ab), Lange (Vertragsnummer, Vertragsbeginn, Geburtsdatum), Demir und Braun (Vertragsbeginn und Geburtsdatum im README). Kanonische Quelle ist jeweils der Mietvertrag; betroffene Gesamt-PDFs neu gebaut.
- Neuer Pflichtvalidator `scripts/validate-testakten-stammdaten.py`: prüft je Testakte Vertragsnummer, Vertragsbeginn und Geburtsdatum je Person auf Widerspruchsfreiheit; gewollte Übungskonflikte sind nur über eine dokumentierte Ausnahmeliste zulässig. In CI-Workflow, Smoke-Test-Validatorenliste und Testakten-README verankert.


## v5.8.1 - 2026-07-01

- Gerichtsstand der Vollstreckungs-Testakte Krüger korrigiert: Für das Wedding-Objekt Seestraße 87 ist das Amtsgericht Wedding zuständig, nicht das Amtsgericht Mitte. Versäumnisurteil, Kostenfestsetzungsantrag, Kostenfestsetzungsbeschluss, Zahlungsaufforderung, SAP-Statusauszug, Aktennotiz und README konsistent umgestellt (Codex-Review-Finding zu PR 52).
- Mietvertrag der Testakte Krüger auf die verbindliche Dezimalgliederung umgestellt (Codex-Review-Finding zu PR 52).
- Kohärenz-Sweep: alle Pflichtvalidatoren, Testakten-Release-ZIP-Build und ein repo-weiter Link-Check über 147 Markdown-Dateien ohne Befund; Skill-Discovery-Descriptions und Prompt-Größen im Limit.

## v5.8.0 - 2026-07-01

- Neue Testakte `vollstreckung-krueger-titel-teilzahlung` für die Nach-Titel-Phase ergänzt: rechtskräftiges Versäumnisurteil, Kostenfestsetzungsantrag mit zurückgewiesener interner Pauschale, Kostenfestsetzungsbeschluss, Teilzahlung ohne Tilgungsbestimmung und Vollstreckungsstrategie. Damit haben die Skills 46 bis 50 erstmals eine echte Trainingsakte; Smoke-Test 5 arbeitet nicht mehr mit simulierten Eingaben.
- Smoke-Tests 5 und 13 sowie Schulungsablauf, Repo-README, Plugin-README und Testakten-Übersicht auf die neue achte Fach-Testakte aktualisiert.
- Veraltete Gesamt-PDF-Größenangaben und ein fehlerhafter Umlaut-Linktext in den Download-Abschnitten der Testakten-READMEs korrigiert.

## v5.7.0 - 2026-07-01

- Skill-Übersicht im Plugin-README mit den aktuellen Discovery-Descriptions synchronisiert.
- Workflow-Referenz um Korrekturregeln ergänzt, wenn ein Modell bei direkter Skill-Nutzung den falschen Fachskill lädt.
- Smoke-Test für Kaltstart, Skill-Auswahl und Router-Negativtrigger ergänzt.
- Release-Notizen als dauerhaftes Changelog eingeführt.

## v5.6.0 - 2026-07-01

- Harte Skill-Startlogik für gemischte DMS-Uploads, SAP-/Mietkonto-Input und Triage ergänzt.
- Zahlungsklage, Räumungsklage, Schonfristzahlung, Betriebskosten, Kostenfestsetzung und Vollstreckung stärker voneinander abgegrenzt.
- Release-Assets für Plugin, Standalone-Skills und Testakten validiert.
