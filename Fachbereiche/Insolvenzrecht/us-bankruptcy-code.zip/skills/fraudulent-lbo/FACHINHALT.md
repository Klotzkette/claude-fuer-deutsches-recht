---
name: fraudulent-lbo
description: "Für Fraudulent Conveyance LBO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Fraudulent Conveyance LBO

## Normenanker

Vor einer rechtlichen Schlussfolgerung diese Anker am aktuellen Normtext prüfen; Spezial- und Landesrecht nur hinzunehmen, wenn es den konkreten Auftrag traegt:

- `§ 1 Abs. 1 KWG` — Bankgeschaefte.
- `§ 32 Abs. 1 KWG` — Erlaubnispflicht.
- `§ 25a Abs. 1 KWG` — ordnungsgemaesse Geschäftsorganisation.
- `§ 44 Abs. 1 KWG` — Auskunfts- und Prüfungsrechte.
- `§ 1 Abs. 1 ZAG` — Zahlungsdienste.
- `§ 10 Abs. 1 ZAG` — Erlaubnis Zahlungsinstitut.
- `Art. 16 DORA` — vereinfachter IKT-Risikomanagementrahmen.
- `Art. 28 DORA` — IKT-Drittparteienrisiko.
- `§ 675f BGB` — Zahlungsdiensterahmenvertrag.
- `§ 765 BGB` — Bürgschaft.

Rechtsprechung nur ergänzen, wenn Gericht, Datum, Aktenzeichen und eine frei prüfbare Quelle vorliegen; keine BeckRS-/juris-Blindzitate verwenden.

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: die im Plugin-Kontext einschlägigen Normen über gesetze-im-internet.de, dejure.org, eur-lex.europa.eu und die amtlichen Bundes-/Landesportale live prüfen — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachkern: Fraudulent Conveyance LBO
- **Normen-/Quellenanker:** Title 11 U.S. Code, Federal Rules of Bankruptcy Procedure, Chapter 7/11/13/15, automatic stay, DIP financing, claims, plan, avoidance, discharge und U.S.-Court-Docket.
- **Entscheidende Weiche:** Bestimme Chapter, Estate Property, Stay-Wirkung, Creditor-Klasse, Court-Order-Bedarf, Timeline und Schnittstelle zu deutschen Assets.

## Code- und Quellenanker

- 11 U.S.C. §§ 544, 548, 550
- State fraudulent transfer law
- Deal and solvency files

Aktuelle Fassungen, Forms, Fees, Local Rules und Court-Practice immer live über offizielle Quellen prüfen. Keine Modellzitate zu US-Rechtsprechung verwenden, wenn Gericht, Datum, Aktenzeichen/Docket und freie Quelle nicht geprüft sind.

## Intake-Fragen

- Transaction structure?
- Solvency at closing?
- Who received value?

## Workflow

1. Funds flow map.
2. Solvency and value evidence.
3. Targets and defenses.

## Tiefencheck für die Akte

Arbeite hier nicht nur abstrakt, sondern als strukturierter US-Counsel-Briefing-Filter:

- Welche Zahlung, Übertragung oder Sicherheit liegt in welchem lookback period und zugunsten welcher Partei?
- War die Leistung antecedent debt, new value, ordinary course, contemporaneous exchange oder insider-bezogen?
- Welche State-law- oder bankruptcy-law avoidance route ist realistisch und wer trägt praktisch die Beweislast?
- Welche Verteidigungsakten fehlen noch: invoices, payment history, shipment logs, solvency material, board papers?

**Mindest-Output:** Avoidance-Analyse mit Transferliste, Zeitachse, Defenses, Vergleichswert und Litigation-Risiko.

## Qualitäts- und Risikofilter

- US-Bankruptcy ist Bundesrecht, aber Local Rules, Judges, District Practice und State-Law-Rechte bleiben entscheidend.
- Keine Einreichung, Fristberechnung oder strategische US-Prozessentscheidung ohne zugelassenen US-Bankruptcy-Counsel finalisieren.

- Unklare US-Rechtsfragen werden nicht als sicher verkauft, sondern als Issue List für US-Counsel markiert.
- Zahlen, Fristen, Fees, Formulare und Schwellenwerte werden vor konkreter Verwendung anhand offizieller aktueller Quellen geprüft.
