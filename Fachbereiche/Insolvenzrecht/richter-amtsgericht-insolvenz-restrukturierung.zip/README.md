# Insolvenz- und Restrukturierungsgericht am Amtsgericht

<!-- BEGIN direkt-loslegen (autogen) -->
## Was ist das hier?

Insolvenz- und Restrukturierungsgericht: Eröffnungsverfahren Sicherungsmaßnahmen Verwalterauswahl Gläubigerversammlung Prüfungstermin Schlusstermin Restschuldbefreiung Restrukturierungssache nach StaRUG mit Stabilisierungsanordnung und Planbestätigung

Zur Installation laden Sie das Einzel-ZIP herunter. Ohne Installation genügt zum Einstieg einer der beiden eigenständigen Markdown-Prompts: Schnellstart für den Kernvorgang, Werkstatt für die ausführliche Bearbeitung. Die Prompts ersetzen nicht sämtliche Spezialskills und Hilfsdateien des Plugins.

## Welche Datei wofür? / Which file should I use?

| Bestandteil | Deutsch | English | Wo? / Where? |
| --- | --- | --- | --- |
| Plugin-ZIP | Installiert das vollständige Plugin mit Skills, Referenzen und Hilfsdateien. | Installs the complete plugin with its skills, references and supporting files. | [`richter-amtsgericht-insolvenz-restrukturierung.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/paketpflege-20261122-v445.36.9/richter-amtsgericht-insolvenz-restrukturierung.zip) |
| Skills | Arbeitsabläufe für einzelne Aufgaben. Wähle bei einem klaren Auftrag den passenden Skill ausdrücklich; die automatische Auswahl ist nicht garantiert. Einzeldownloads enthalten nur die jeweilige Markdown-Datei. | Focused task workflows. Select a known skill explicitly; automatic selection is not guaranteed. An individual download contains only that Markdown file. | [Skill-Liste öffnen / Open skill list](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/skills-index/richter-amtsgericht-insolvenz-restrukturierung.md) |
| Werkstatt-Prompt | Ausführliche eigenständige Markdown-Datei für komplexe oder mehrstufige Vorgänge. Sie ist kein Skill und nicht im Plugin-ZIP enthalten. | Detailed standalone Markdown file for complex or multi-step matters. It is not a skill and is not included in the plugin ZIP. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/richter-amtsgericht-insolvenz-restrukturierung-werkstatt.md) |
| Schnellstart / Mini-Prompt | Kompakte eigenständige Markdown-Datei für einen schnellen ersten Arbeitsstand. Sie ist kein Skill und nicht im Plugin-ZIP enthalten. | Compact standalone Markdown file for a fast first work product. It is not a skill and is not included in the plugin ZIP. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/richter-amtsgericht-insolvenz-restrukturierung-schnellstart.md) |
| Testakten | Separate Übungsunterlagen in PDF- und Originalformaten; sie werden nicht mit dem Plugin installiert. | Separate practice files in PDF and original formats; they are not installed with the plugin. | [Testakten-Übersicht / Test-file index](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/README.md) |

Links mit „MD herunterladen / Download MD“ starten einen Dateidownload. Navigationslinks zu README- und Übersichtsseiten bleiben dagegen als GitHub-Seiten geöffnet.

Links labelled “MD herunterladen / Download MD” start a file download. Navigation links to README and index pages remain normal GitHub pages.

Die Skill-Liste bildet den Quellbestand ab. Im installierten Paket werden umfangreiche Spezialserien teilweise über einen Fachrouter bei Bedarf geladen und erscheinen dann nicht als eigene auswählbare Skills. Beim manuellen Einsatz eines einzelnen Skills müssen zusätzlich benötigte Referenzen oder Werkzeuge verfügbar sein.

The skill index lists the source collection. In the installed package, some specialist series are accessed through a topic router rather than separate menu entries. A standalone skill may need additional reference files or tools. Choose one entry point, then add only what the matter requires.

Direktnavigation: [30-Sekunden-Start](#in-30-sekunden-starten) · [Startseite](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/README.md) · [Plugin-Katalog](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/README.md#was-ist-drin) · [Skill-Gesamtübersicht](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/SKILLS.md) · [Skills dieses Plugins](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/skills-index/richter-amtsgericht-insolvenz-restrukturierung.md) · [Plugin-Dateien](.) · [Download-Index](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/ASSET_INDEX.md) · [Installation](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/INSTALLATION_EINFACH.md) · [Testakten](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/README.md)

## In 30 Sekunden starten

| Ausgangslage | Schnellster Weg |
| --- | --- |
| Plugin installiert | Passenden Fachskill in der [alphabetisch sortierten Skill-Liste](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/skills-index/richter-amtsgericht-insolvenz-restrukturierung.md) wählen und den untenstehenden Startsatz mit dem Arbeitsordner absenden. |
| Noch keine Installation | Den Schnellstart unten als Markdown herunterladen und mit den Unterlagen in einer freigegebenen Arbeitsoberfläche bereitstellen. |
| Umfangreicher oder mehrstufiger Vorgang | Die Werkstatt laden; sie führt tiefer durch Fachrouten, Gegenposition und Endprodukt. |

Startsatz für Insolvenz- und Restrukturierungsgericht am Amtsgericht:

> Sichte den ausgewählten Ordner intern, ohne seine Inhalte ungefragt aufzulisten. Lies die für den Auftrag tragenden Unterlagen; ergänze die Lektüre gezielt bei offenen Belegfragen. Beginne mit folgendem Arbeitsschritt: einen fachbezogenen Erststand mit Ergebnisrichtung, Kernbeleg und nächstem Dokument. Wenn bereits ein konkretes Dokument verlangt ist, beginne unmittelbar damit. Frage gezielt nach entscheidenden offenen Punkten und arbeite an den unabhängigen Teilen weiter. Verarbeite die Antwort im bestehenden Entwurf; weitere Rückfragen nur bei neuen entscheidenden Lücken.

Bei einem Folgewunsch den bisherigen Aktenstand fortführen. Bereits festgestellte Tatsachen, Berechnungen und Quellen nicht erneut abfragen oder ohne Anlass neu aufbauen.

## Downloads

> Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.
>
> This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

| Was | Format | Direkt-Download |
| --- | --- | --- |
| Plugin als Komplett-ZIP (Hauptweg) | ZIP | [`richter-amtsgericht-insolvenz-restrukturierung.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/paketpflege-20261122-v445.36.9/richter-amtsgericht-insolvenz-restrukturierung.zip) |
| Kompakter Prompt (Schnellstart) | Markdown | [`richter-amtsgericht-insolvenz-restrukturierung-schnellstart.md`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/richter-amtsgericht-insolvenz-restrukturierung-schnellstart.md) |
| Großer Prompt (Werkstatt) | Markdown | [`richter-amtsgericht-insolvenz-restrukturierung-werkstatt.md`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/richter-amtsgericht-insolvenz-restrukturierung-werkstatt.md) |
| Zugeordnete Testakten | PDF / ZIP | [`alle-testakten.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/latest/download/alle-testakten.zip) und [`alle-testakten-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/latest/download/alle-testakten-einzelpdfs.zip) (zentrale Sammlung) |

> Das Sammelpaket [`alle-plugins-megazip.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/latest/download/alle-plugins-megazip.zip) enthält die Plugins der ausgewiesenen Ausgabe. Die Einzelpakete finden Sie im [Download-Index](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/ASSET_INDEX.md). Werkstatt und Schnellstart stehen als Markdown bereit.
<!-- END direkt-loslegen (autogen) -->

## Die lokale Übungsakte

[Grundakten für Insolvenzrecht mit Eingangspost, Rückfragen und Belegen](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/docs/grundakten-lebenswelt/Fachakten.md#insolvenzrecht)

Für den ersten Durchgang öffnen Sie im Arbeits-ZIP `Grundakte/00_Posteingang`. Die vollständige Akte enthält auch die späteren Verfahrensstücke. [Fallordner im Druckpaket nachschlagen](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/docs/grundakten-lebenswelt/README.md#weitere-arbeitsakten-und-eigenständige-pluginfassungen).

> Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.
>
> This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

| Fall | Originalunterlagen und Eingangspost | Lesefassungen |
| --- | --- | --- |
| Testakte AG Musterstadt 7 IN 88/26 — Gläubigerantrag über das Vermögen der Edelholz Berlin GmbH bei streitigem Eröffnungsgrund | [Arbeits-ZIP mit Eingangspost](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-fachakten-v1.1.0/lebensakte-gericht-richter-amtsgericht-insolvenz-restrukturierung.zip) | [Druckfassungen dieses Falls](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-fachakten-v1.1.0/druckakte-gericht-richter-amtsgericht-insolvenz-restrukturierung.zip) |

Wenn du das hier öffnest, willst du Eröffnungsgrund und Fortbestehensprognose belastbar bestimmen und den nächsten Verfahrensschritt wählen.
> **Experimentelles Plugin im Ordner `gerichtsplugins/`** — siehe Vorspruch unten.

> **Hochrisiko-Prüfung vor Justizeinsatz:** Artikel 6 Absatz 2 mit Anhang III Nummer 8 Buchstabe a anhand der konkreten Zweckbestimmung prüfen; nicht jede Verwaltungs- oder Recherchefunktion einer Justizbehörde ist automatisch erfasst. Artikel 6 Absatz 3 gilt nur im Anhang-III-Pfad: kein erhebliches Risiko für Gesundheit, Sicherheit oder Grundrechte, einschließlich keiner wesentlichen Beeinflussung des Entscheidungsergebnisses, und mindestens eine Fallgruppe nach Buchstaben a bis d belegen. Profiling natürlicher Personen schließt die Ausnahme aus. Anbieter dokumentieren nach Absatz 4 und registrieren nach Artikel 49 Absatz 2; menschliche Schlusskontrolle oder die Bezeichnung „vorbereitend“ allein genügen nicht. Artikel 113 Buchstabe c erfasst Kapitel III Abschnitte 1 bis 3 außer Artikel 6 Absatz 5: bei Anhang III ab 02.12.2027, bei Anhang I ab 02.08.2028. Artikel 111 und die Zeitverschränkung mit anderen Abschnitten gesondert prüfen; keine pauschale Verschiebung sämtlicher Pflichten. Datenschutzrechtliche Grenzen automatisierter Entscheidungen sind gesondert nach dem anwendbaren Regime zu prüfen. Die richterliche Entscheidung bleibt dem zuständigen Menschen vorbehalten. [amtlicher Text, Prüfstand 09.10.2026](https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:02024R1689-20260727)

## Rolle

Insolvenzrichter oder Restrukturierungsrichter am Amtsgericht (Paragraf 2 InsO, Paragrafen 34 ff. StaRUG)

## Rechtsrahmen

InsO, StaRUG, EuInsVO 2015/848, ZPO, GVG, RPflG, GKG, InsVV

## Inhalt

- Skills mit ihren Referenzen: siehe vollständige Liste unten. Werkstatt und Schnellstart sind separate Markdown-Dateien, keine zusätzlichen Skills.
- **Werkstatt-Prompt** (`richter-amtsgericht-insolvenz-restrukturierung-werkstatt.md`)
- **Schnellstart-Prompt** (`richter-amtsgericht-insolvenz-restrukturierung-schnellstart.md`)
- **Testakte** ([Aktenverzeichnis](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/testakte/README.md)) — aus Richtersicht

## Skill-Liste

Die [vollständige alphabetische Skill-Liste](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/skills-index/richter-amtsgericht-insolvenz-restrukturierung.md) enthält die aktuellen Namen, Beschreibungen und Markdown-Downloads. Die thematische Navigation und die automatisch gepflegte Übersicht weiter unten helfen bei der Auswahl nach Arbeitsschritt.

## Quellenhygiene

- Keine erfundenen Aktenzeichen.
- Rechtsprechung nur mit Aktenzeichen + Datum + Verfahrensbezeichnung.
- Bei Unsicherheit lieber Lückenliste als Erfindung.
- Vor Verwendung Aktenzeichen in offiziellen Datenbanken (Bundesgerichte, juris frei, Bundesverfassungsgericht.de) live verifizieren.

## Lizenz

Dual-lizenziert MIT und Apache-2.0.


<!-- BEGIN SKILLS-LOGIC (auto-generated) -->

## Orientierung nach Arbeitslogik

Diese Navigation ordnet die Skills nach typischen Arbeitsschritten. Ein Klick auf einen Skill lädt seine Markdown-Datei; die alphabetische Komplettliste bleibt darunter erhalten.

English: Skills are grouped by typical work phase. Clicking a skill downloads its Markdown file; the complete alphabetical list remains below.

| Arbeitsphase | Typische Skills |
| --- | --- |
| 3. Prüfung, Anspruch und Subsumtion | [`04-glaeubigerversammlung-und-pruefungstermin`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/04-glaeubigerversammlung-und-pruefungstermin/SKILL.md), [`juristischer-argumentationskern`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/juristischer-argumentationskern/SKILL.md) |
| 4. Gestaltung, Strategie und Verhandlung | [`07-insolvenzplan-bestaetigen`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/07-insolvenzplan-bestaetigen/SKILL.md), [`08-starug-restrukturierungssache-anzeigen`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/08-starug-restrukturierungssache-anzeigen/SKILL.md), [`10-starug-planbestaetigung-und-folgen`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/10-starug-planbestaetigung-und-folgen/SKILL.md) |
| 5. Verfahren, Behörde und Gericht | [`01-eroeffnungsantrag-pruefen-insolvenz`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/01-eroeffnungsantrag-pruefen-insolvenz/SKILL.md), [`03-eroeffnungsbeschluss-und-verwalterbestellung`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/03-eroeffnungsbeschluss-und-verwalterbestellung/SKILL.md) |
| 8. Spezialmodule und Schnittstellen | [`02-sicherungsmassnahmen-vor-eroeffnung`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/02-sicherungsmassnahmen-vor-eroeffnung/SKILL.md), [`05-restschuldbefreiung-und-schlusstermin`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/05-restschuldbefreiung-und-schlusstermin/SKILL.md), [`06-eigenverwaltung-und-schutzschirm`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/06-eigenverwaltung-und-schutzschirm/SKILL.md), [`09-starug-stabilisierungsanordnung`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/09-starug-stabilisierungsanordnung/SKILL.md), [`99-finale-entscheidung-volltext`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/99-finale-entscheidung-volltext/SKILL.md), [`prozessuale-kniffe-und-rechtsprechungsanker`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/prozessuale-kniffe-und-rechtsprechungsanker/SKILL.md) |

<!-- END SKILLS-LOGIC (auto-generated) -->

<!-- BEGIN SKILLS-OVERVIEW (auto-generated) -->

## Alle Skills im Überblick

Automatisch generierte Komplett-Liste aller 13 Skills in diesem Plugin. Jeder Skillname und der Downloadlink laden den unveränderten Inhalt der zugehörigen `SKILL.md` als Markdown-Datei. Der eindeutige Dateiname enthält Plugin und Skill; Beschreibungen stammen aus dem jeweiligen `description`-Feld.

English: Complete list of all 13 skills in this plugin. Both links in each row download the unchanged `SKILL.md` content as a Markdown file with a unique plugin-and-skill filename.

| Skill | Beschreibung | Markdown-Download |
| --- | --- | --- |
| [`01-eroeffnungsantrag-pruefen-insolvenz`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/01-eroeffnungsantrag-pruefen-insolvenz/SKILL.md) | Für 01 Eröffnungsantrag Prüfen Insolvenz: erstellt Entwurf mit Antrag, Beweis und Anlagen; Ergebnis: Schriftsatz mit Begründungs- und Anlagenlogik. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/01-eroeffnungsantrag-pruefen-insolvenz/SKILL.md) |
| [`02-sicherungsmassnahmen-vor-eroeffnung`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/02-sicherungsmassnahmen-vor-eroeffnung/SKILL.md) | Für 02 Sicherungsmaßnahmen vor Eröffnung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/02-sicherungsmassnahmen-vor-eroeffnung/SKILL.md) |
| [`03-eroeffnungsbeschluss-und-verwalterbestellung`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/03-eroeffnungsbeschluss-und-verwalterbestellung/SKILL.md) | Für 03 Eröffnungsbeschluss und Verwalterbestellung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/03-eroeffnungsbeschluss-und-verwalterbestellung/SKILL.md) |
| [`04-glaeubigerversammlung-und-pruefungstermin`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/04-glaeubigerversammlung-und-pruefungstermin/SKILL.md) | Für 04 Gläubigerversammlung und Prüfungstermin: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Schnittstellenkarte mit Zuständigkeits- und Nachweisfragen. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/04-glaeubigerversammlung-und-pruefungstermin/SKILL.md) |
| [`05-restschuldbefreiung-und-schlusstermin`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/05-restschuldbefreiung-und-schlusstermin/SKILL.md) | Für 05 Restschuldbefreiung und Schlusstermin: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/05-restschuldbefreiung-und-schlusstermin/SKILL.md) |
| [`06-eigenverwaltung-und-schutzschirm`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/06-eigenverwaltung-und-schutzschirm/SKILL.md) | Für 06 Eigenverwaltung und Schutzschirm: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/06-eigenverwaltung-und-schutzschirm/SKILL.md) |
| [`07-insolvenzplan-bestaetigen`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/07-insolvenzplan-bestaetigen/SKILL.md) | Für 07 Insolvenzplan Bestätigen: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/07-insolvenzplan-bestaetigen/SKILL.md) |
| [`08-starug-restrukturierungssache-anzeigen`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/08-starug-restrukturierungssache-anzeigen/SKILL.md) | Für 08 StaRUG Restrukturierungssache Anzeigen: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/08-starug-restrukturierungssache-anzeigen/SKILL.md) |
| [`09-starug-stabilisierungsanordnung`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/09-starug-stabilisierungsanordnung/SKILL.md) | Für 09 StaRUG Stabilisierungsanordnung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/09-starug-stabilisierungsanordnung/SKILL.md) |
| [`10-starug-planbestaetigung-und-folgen`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/10-starug-planbestaetigung-und-folgen/SKILL.md) | Für 10 StaRUG Planbestätigung und Folgen: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/10-starug-planbestaetigung-und-folgen/SKILL.md) |
| [`99-finale-entscheidung-volltext`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/99-finale-entscheidung-volltext/SKILL.md) | Für Finale Entscheidung als Volltext (Beschluss Insolvenz oder Restrukturierung): ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/99-finale-entscheidung-volltext/SKILL.md) |
| [`juristischer-argumentationskern`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/juristischer-argumentationskern/SKILL.md) | Insolvenz- und Restrukturierungssache entscheidungsreif bearbeiten. Wertet vorhandene Unterlagen aus, entscheidet die fachlichen Weichen und liefert begründeten gerichtlichen Beschluss mit bestimmten Rechtsfolgen, Beweiswürdigung und fal... | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/juristischer-argumentationskern/SKILL.md) |
| [`prozessuale-kniffe-und-rechtsprechungsanker`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/prozessuale-kniffe-und-rechtsprechungsanker/SKILL.md) | Für Prozessuale Kniffe und Rechtsprechungsanker: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: Insolvenz- und Restrukturierungsgericht am Amtsgericht. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=gerichtsplugins/richter-amtsgericht-insolvenz-restrukturierung/skills/prozessuale-kniffe-und-rechtsprechungsanker/SKILL.md) |

<!-- END SKILLS-OVERVIEW (auto-generated) -->

<a id="fachliche-ki-prüfung"></a>

## 1. Fachliche KI-Prüfung

[Normen, technische Nachweise, Rechtsprechungsgrenzen und Übungsakte](references/ki-normen-und-fallpruefung.md): Unterscheiden Sie bei der Anwendung für Insolvenz- und Restrukturierungsentscheidung technische Aktenorganisation von der Würdigung von Tatsachen und Recht. Prüfen Sie den konkreten Justiz- oder Strafverfolgungsbezug in Anhang III und den tatsächlichen Einfluss auf die Entscheidung; eine formale Schlusszeichnung allein genügt nicht als Gegenbeleg.

Die KI-Fachvertiefung steht als [Komponentenausgabe 445.35.2](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/tag/ki-verordnung-v445.35.2) zur Verfügung.
