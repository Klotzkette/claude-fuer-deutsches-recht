# Insolvenzverwaltung - IV-Cockpit

<!-- BEGIN direkt-loslegen (autogen) -->
## Was ist das hier?

Freistehendes Insolvenzverwaltungs-Plugin aus Sicht von Insolvenzverwalter, Sachwalter und vorläufiger Verwaltung: Regelverfahren, Eigenverwaltung, Schutzschirm, Anfechtung, Paragraf 15b InsO, Masse, Forderungsprüfung, Insolvenzplan, StaRUG-Planwerkstatt, Gutachten, Berichte und Schlussrechnung.

Zur Installation laden Sie das Einzel-ZIP herunter. Ohne Installation genügt zum Einstieg einer der beiden eigenständigen Markdown-Prompts: Schnellstart für den Kernvorgang, Werkstatt für die ausführliche Bearbeitung. Die Prompts ersetzen nicht sämtliche Spezialskills und Hilfsdateien des Plugins.

## Welche Datei wofür? / Which file should I use?

| Bestandteil | Deutsch | English | Wo? / Where? |
| --- | --- | --- | --- |
| Plugin-ZIP | Installiert das vollständige Plugin mit Skills, Referenzen und Hilfsdateien. | Installs the complete plugin with its skills, references and supporting files. | [`insolvenzverwaltung.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/paketpflege-20261122-v445.36.9/insolvenzverwaltung.zip) |
| Skills | Arbeitsabläufe für einzelne Aufgaben. Wähle bei einem klaren Auftrag den passenden Skill ausdrücklich; die automatische Auswahl ist nicht garantiert. Einzeldownloads enthalten nur die jeweilige Markdown-Datei. | Focused task workflows. Select a known skill explicitly; automatic selection is not guaranteed. An individual download contains only that Markdown file. | [Skill-Liste öffnen / Open skill list](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/skills-index/insolvenzverwaltung.md) |
| Werkstatt-Prompt | Ausführliche eigenständige Markdown-Datei für komplexe oder mehrstufige Vorgänge. Sie ist kein Skill und nicht im Plugin-ZIP enthalten. | Detailed standalone Markdown file for complex or multi-step matters. It is not a skill and is not included in the plugin ZIP. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/insolvenzverwaltung-werkstatt.md) |
| Schnellstart / Mini-Prompt | Kompakte eigenständige Markdown-Datei für einen schnellen ersten Arbeitsstand. Sie ist kein Skill und nicht im Plugin-ZIP enthalten. | Compact standalone Markdown file for a fast first work product. It is not a skill and is not included in the plugin ZIP. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/insolvenzverwaltung-schnellstart.md) |
| Testakten | Separate Übungsunterlagen in PDF- und Originalformaten; sie werden nicht mit dem Plugin installiert. | Separate practice files in PDF and original formats; they are not installed with the plugin. | [Testakten-Übersicht / Test-file index](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/README.md) |

Links mit „MD herunterladen / Download MD“ starten einen Dateidownload. Navigationslinks zu README- und Übersichtsseiten bleiben dagegen als GitHub-Seiten geöffnet.

Links labelled “MD herunterladen / Download MD” start a file download. Navigation links to README and index pages remain normal GitHub pages.

Die Skill-Liste bildet den Quellbestand ab. Im installierten Paket werden umfangreiche Spezialserien teilweise über einen Fachrouter bei Bedarf geladen und erscheinen dann nicht als eigene auswählbare Skills. Beim manuellen Einsatz eines einzelnen Skills müssen zusätzlich benötigte Referenzen oder Werkzeuge verfügbar sein.

The skill index lists the source collection. In the installed package, some specialist series are accessed through a topic router rather than separate menu entries. A standalone skill may need additional reference files or tools. Choose one entry point, then add only what the matter requires.

Direktnavigation: [30-Sekunden-Start](#in-30-sekunden-starten) · [Startseite](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/README.md) · [Plugin-Katalog](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/README.md#was-ist-drin) · [Skill-Gesamtübersicht](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/SKILLS.md) · [Skills dieses Plugins](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/skills-index/insolvenzverwaltung.md) · [Plugin-Dateien](.) · [Download-Index](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/ASSET_INDEX.md) · [Installation](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/INSTALLATION_EINFACH.md) · [Testakten](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/README.md)

## In 30 Sekunden starten

| Ausgangslage | Schnellster Weg |
| --- | --- |
| Plugin installiert | Passenden Fachskill in der [alphabetisch sortierten Skill-Liste](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/skills-index/insolvenzverwaltung.md) wählen und den untenstehenden Startsatz mit dem Arbeitsordner absenden. |
| Noch keine Installation | Den Schnellstart unten als Markdown herunterladen und mit den Unterlagen in einer freigegebenen Arbeitsoberfläche bereitstellen. |
| Umfangreicher oder mehrstufiger Vorgang | Die Werkstatt laden; sie führt tiefer durch Fachrouten, Gegenposition und Endprodukt. |

Startsatz für Insolvenzverwaltung - IV-Cockpit:

> Sichte den ausgewählten Ordner intern, ohne seine Inhalte ungefragt aufzulisten. Lies die für den Auftrag tragenden Unterlagen; ergänze die Lektüre gezielt bei offenen Belegfragen. Beginne mit folgendem Arbeitsschritt: einen fachbezogenen Erststand mit Ergebnisrichtung, Kernbeleg und nächstem Dokument. Wenn bereits ein konkretes Dokument verlangt ist, beginne unmittelbar damit. Frage gezielt nach entscheidenden offenen Punkten und arbeite an den unabhängigen Teilen weiter. Verarbeite die Antwort im bestehenden Entwurf; weitere Rückfragen nur bei neuen entscheidenden Lücken.

Bei einem Folgewunsch den bisherigen Aktenstand fortführen. Bereits festgestellte Tatsachen, Berechnungen und Quellen nicht erneut abfragen oder ohne Anlass neu aufbauen.

## Downloads

| Was | Format | Direkt-Download |
| --- | --- | --- |
| Plugin als Komplett-ZIP (Hauptweg) | ZIP | [`insolvenzverwaltung.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/paketpflege-20261122-v445.36.9/insolvenzverwaltung.zip) |
| Kompakter Prompt (Schnellstart) | Markdown | [`insolvenzverwaltung-schnellstart.md`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/insolvenzverwaltung-schnellstart.md) |
| Großer Prompt (Werkstatt) | Markdown | [`insolvenzverwaltung-werkstatt.md`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/insolvenzverwaltung-werkstatt.md) |
| Zugeordnete Testakten | PDF / ZIP | [25 zugeordnete Akten](#zugeordnete-testakten) mit Gesamt-PDF, Originaldateien und Einzel-PDFs |

> Das Sammelpaket [`alle-plugins-megazip.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/latest/download/alle-plugins-megazip.zip) enthält die Plugins der ausgewiesenen Ausgabe. Die Einzelpakete finden Sie im [Download-Index](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/ASSET_INDEX.md). Werkstatt und Schnellstart stehen als Markdown bereit.

## Zugeordnete Testakten

[Grundakten für Insolvenzrecht mit Eingangspost, Rückfragen und Belegen](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/docs/grundakten-lebenswelt/Fachakten.md#insolvenzrecht)

Jede Akte ist getrennt als lesbares Gesamt-PDF, ZIP mit Originaldateien und ZIP mit einzelnen PDFs erreichbar.

> Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.
>
> This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

| Akte | Gesamt-PDF | Originaldateien | Einzel-PDFs |
| --- | --- | --- | --- |
| [Geschäftsführerhaftung nach Paragraf 15b InsO — Zahlungen nach Insolvenzreife (Hannover)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover/gesamt-pdf/geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover_gesamt.pdf) | [`testakte-geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover.zip) | [`testakte-geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover-einzelpdfs.zip) |
| [Insolvenz-Asset-Deal — ChainCortex AI GmbH (Berlin) → Voracis Ventures GmbH](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenz-asset-deal-chaincortex-ai-berlin/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenz-asset-deal-chaincortex-ai-berlin/gesamt-pdf/insolvenz-asset-deal-chaincortex-ai-berlin_gesamt.pdf) | [`testakte-insolvenz-asset-deal-chaincortex-ai-berlin.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenz-asset-deal-chaincortex-ai-berlin.zip) | [`testakte-insolvenz-asset-deal-chaincortex-ai-berlin-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenz-asset-deal-chaincortex-ai-berlin-einzelpdfs.zip) |
| [Insolvenzanfechtung Vellnitz Kunststofftechnik — Bargeschäft und Vorkasse beim Rohstofflieferanten (Chemnitz)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz/gesamt-pdf/insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz_gesamt.pdf) | [`testakte-insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz.zip) | [`testakte-insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz-einzelpdfs.zip) |
| [Insolvenzanfechtung — Gesellschafterdarlehen im Konzern-Cash-Pool (Regensburg)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg/gesamt-pdf/insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg_gesamt.pdf) | [`testakte-insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg.zip) | [`testakte-insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg-einzelpdfs.zip) |
| [Insolvenzanfechtung Vondering Metallform — Grundstücksverkauf und „Vermittlungsprovision" (Mönchengladbach)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach/gesamt-pdf/insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach_gesamt.pdf) | [`testakte-insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach.zip) | [`testakte-insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach-einzelpdfs.zip) |
| [Insolvenzanfechtung — Warenlager an Erfüllungs statt an den Hauptlieferanten (Kassel)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel/gesamt-pdf/insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel_gesamt.pdf) | [`testakte-insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel.zip) | [`testakte-insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel-einzelpdfs.zip) |
| [Insolvenzanfechtung — Inkongrünte Deckung durch Zwangsvollstreckung (Fürth)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth/gesamt-pdf/insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth_gesamt.pdf) | [`testakte-insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth.zip) | [`testakte-insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth-einzelpdfs.zip) |
| [Insolvenzanfechtung Kiezflitzer — Gesellschafterdarlehen, Beraterhonorar und Vorschuss (Berlin)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin/gesamt-pdf/insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin_gesamt.pdf) | [`testakte-insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin.zip) | [`testakte-insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin-einzelpdfs.zip) |
| [Insolvenzanfechtung Trave Clean — Beitragszahlung an die Krankenkasse nach Fremdantrag (Lübeck)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck/gesamt-pdf/insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck_gesamt.pdf) | [`testakte-insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck.zip) | [`testakte-insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck-einzelpdfs.zip) |
| [Insolvenzanfechtung Teutoburger Möbelwerk — kongrünte Deckung, Mahnlauf und Kenntnisfrage (Bielefeld)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld/gesamt-pdf/insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld_gesamt.pdf) | [`testakte-insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld.zip) | [`testakte-insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld-einzelpdfs.zip) |
| [Insolvenzanfechtung Domblick Weinkellerei — Kontokorrent-Rückführung nach Linienherabsetzung (Mainz)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz/gesamt-pdf/insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz_gesamt.pdf) | [`testakte-insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz.zip) | [`testakte-insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz-einzelpdfs.zip) |
| [Insolvenzanfechtung Ruhrland Getränkegroßhandel — Kontokorrent-Verrechnungen bei geduldeter Überziehung (Dortmund)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund/gesamt-pdf/insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund_gesamt.pdf) | [`testakte-insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund.zip) | [`testakte-insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund-einzelpdfs.zip) |
| [Insolvenzanfechtung Schenkung Familie — Hollmann Bau- und Sanierungs GmbH (Oldenburg)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-schenkung-familie-oldenburg/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-schenkung-familie-oldenburg/gesamt-pdf/insolvenzanfechtung-schenkung-familie-oldenburg_gesamt.pdf) | [`testakte-insolvenzanfechtung-schenkung-familie-oldenburg.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-schenkung-familie-oldenburg.zip) | [`testakte-insolvenzanfechtung-schenkung-familie-oldenburg-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-schenkung-familie-oldenburg-einzelpdfs.zip) |
| [Insolvenzanfechtung aufsteigende Konzernsicherheit — Feinwerk Präzisionswerkzeuge GmbH (Stuttgart)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart/gesamt-pdf/insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart_gesamt.pdf) | [`testakte-insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart.zip) | [`testakte-insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart-einzelpdfs.zip) |
| [Vorsatzanfechtung gegen das Finanzamt — 30 Raten im Vierjahreszeitraum (Augsburg)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg/gesamt-pdf/insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg_gesamt.pdf) | [`testakte-insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg.zip) | [`testakte-insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg-einzelpdfs.zip) |
| [Insolvenzforderungen Rheinsteg Handwerk Köln](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzforderungen-handwerk-koeln/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzforderungen-handwerk-koeln/gesamt-pdf/insolvenzforderungen-handwerk-koeln_gesamt.pdf) | [`testakte-insolvenzforderungen-handwerk-koeln.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzforderungen-handwerk-koeln.zip) | [`testakte-insolvenzforderungen-handwerk-koeln-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzforderungen-handwerk-koeln-einzelpdfs.zip) |
| [MedTech Jena: Eigenverwaltung, Schutzschirm und Liquiditätsstatus](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena/gesamt-pdf/insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena_gesamt.pdf) | [`testakte-insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena.zip) | [`testakte-insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena-einzelpdfs.zip) |
| [Forderungsprüfung Berlin: Mietkaution, Aufrechnung und Absonderungsrechte](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzrecht-forderungspruefung-mietkaution-berlin/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzrecht-forderungspruefung-mietkaution-berlin/gesamt-pdf/insolvenzrecht-forderungspruefung-mietkaution-berlin_gesamt.pdf) | [`testakte-insolvenzrecht-forderungspruefung-mietkaution-berlin.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenzrecht-forderungspruefung-mietkaution-berlin.zip) | [`testakte-insolvenzrecht-forderungspruefung-mietkaution-berlin-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-insolvenzrecht-forderungspruefung-mietkaution-berlin-einzelpdfs.zip) |
| [Testakte Klangbogen Buehnen- und Probenraumtechnik GmbH](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-klangbogen-buehnentechnik-bamberg/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-klangbogen-buehnentechnik-bamberg/gesamt-pdf/insolvenzverwaltung-klangbogen-buehnentechnik-bamberg_gesamt.pdf) | [`testakte-insolvenzverwaltung-klangbogen-buehnentechnik-bamberg.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-sammlung-v1.0.0/testakte-insolvenzverwaltung-klangbogen-buehnentechnik-bamberg.zip) | [`testakte-insolvenzverwaltung-klangbogen-buehnentechnik-bamberg-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenzverwaltung-berichtsersteller-v1.1.0/testakte-insolvenzverwaltung-klangbogen-buehnentechnik-bamberg-einzelpdfs.zip) |
| [Mainbogen Laborsoftware GmbH](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-mainbogen-laborsoftware-wuerzburg/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-mainbogen-laborsoftware-wuerzburg/gesamt-pdf/insolvenzverwaltung-mainbogen-laborsoftware-wuerzburg_gesamt.pdf) | [`testakte-insolvenzverwaltung-mainbogen-laborsoftware-wuerzburg.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-sammlung-v1.0.0/testakte-insolvenzverwaltung-mainbogen-laborsoftware-wuerzburg.zip) | [`testakte-insolvenzverwaltung-mainbogen-laborsoftware-wuerzburg-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenzverwaltung-berichtsersteller-v1.0.0/testakte-insolvenzverwaltung-mainbogen-laborsoftware-wuerzburg-einzelpdfs.zip) |
| [Akte Insolvenzverwaltung – Möbelwerk Havelberg GmbH](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-moebelwerk-havelberg-regelverfahren/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-moebelwerk-havelberg-regelverfahren/gesamt-pdf/insolvenzverwaltung-moebelwerk-havelberg-regelverfahren_gesamt.pdf) | [`testakte-insolvenzverwaltung-moebelwerk-havelberg-regelverfahren.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-sammlung-v1.0.0/testakte-insolvenzverwaltung-moebelwerk-havelberg-regelverfahren.zip) | [`testakte-insolvenzverwaltung-moebelwerk-havelberg-regelverfahren-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenzverwaltung-berichtsersteller-v1.0.0/testakte-insolvenzverwaltung-moebelwerk-havelberg-regelverfahren-einzelpdfs.zip) |
| [Insolvenzverwaltung Nordlicht Handels GmbH](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-nordlicht-handels-kiel/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenzverwaltung-nordlicht-handels-kiel/gesamt-pdf/insolvenzverwaltung-nordlicht-handels-kiel_gesamt.pdf) | [`testakte-insolvenzverwaltung-nordlicht-handels-kiel.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-sammlung-v1.0.0/testakte-insolvenzverwaltung-nordlicht-handels-kiel.zip) | [`testakte-insolvenzverwaltung-nordlicht-handels-kiel-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenzverwaltung-berichtsersteller-v1.0.0/testakte-insolvenzverwaltung-nordlicht-handels-kiel-einzelpdfs.zip) |
| [Akte Rotorwerk: Maschinenleasing, Restwert und Insolvenzgerücht](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/leasingrecht-maschinenfleet-restwert-insolvenz/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/leasingrecht-maschinenfleet-restwert-insolvenz/gesamt-pdf/leasingrecht-maschinenfleet-restwert-insolvenz_gesamt.pdf) | [`testakte-leasingrecht-maschinenfleet-restwert-insolvenz.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-sammlung-v1.0.0/testakte-leasingrecht-maschinenfleet-restwert-insolvenz.zip) | [`testakte-leasingrecht-maschinenfleet-restwert-insolvenz-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-leasingrecht-maschinenfleet-restwert-insolvenz-einzelpdfs.zip) |
| [LUMEN Studios GmbH — Insolvenz- und Wirtschaftsstrafverfahren](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/lumen-studios-insolvenz-strafverfahren/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/lumen-studios-insolvenz-strafverfahren/gesamt-pdf/lumen-studios-insolvenz-strafverfahren_gesamt.pdf) | [`testakte-lumen-studios-insolvenz-strafverfahren.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/grundakten-sammlung-v1.0.0/testakte-lumen-studios-insolvenz-strafverfahren.zip) | [`testakte-lumen-studios-insolvenz-strafverfahren-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-lumen-studios-insolvenz-strafverfahren-einzelpdfs.zip) |
| [StaRUG-Aufhebung der Restrukturierungssache — Holding Düsseldorf (BGH IX ZB 18/25)](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/starug-aufhebung-holding-duesseldorf-ix-zb-18-25/README.md) | [Gesamt-PDF](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/starug-aufhebung-holding-duesseldorf-ix-zb-18-25/gesamt-pdf/starug-aufhebung-holding-duesseldorf-ix-zb-18-25_gesamt.pdf) | [`testakte-starug-aufhebung-holding-duesseldorf-ix-zb-18-25.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-starug-aufhebung-holding-duesseldorf-ix-zb-18-25.zip) | [`testakte-starug-aufhebung-holding-duesseldorf-ix-zb-18-25-einzelpdfs.zip`](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/akten-v445.35.3/testakte-starug-aufhebung-holding-duesseldorf-ix-zb-18-25-einzelpdfs.zip) |

[Alle Testakten und Fachzuordnungen](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/README.md)
<!-- END direkt-loslegen (autogen) -->

[Oberordner Insolvenzrecht – alle eigenständigen Plugins nach Aufgabe](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/insolvenzrecht-plugins/README.md)
Wenn du das hier öffnest, willst du Eröffnungsgrund und Fortbestehensprognose belastbar bestimmen und den nächsten Verfahrensschritt wählen.
Technischer Plugin-Name: `insolvenzverwaltung`.

Großes freistehendes Plugin für die Insolvenzverwaltung aus Sicht des Insolvenzverwalters, vorläufigen Insolvenzverwalters und Sachwalters. Abgebildet sind Regelverfahren, Eröffnungsverfahren, Schutzschirm, Eigenverwaltung, Masseeinsammlung, Massemehrung, Insolvenzanfechtung, Zahlungsklagen nach § 15b InsO, Forderungsanmeldungsprüfung, Tabelle, Anzeige der Masseunzulänglichkeit, Betriebsfortführung, Insolvenzplan, StaRUG-Restrukturierungsplan, Vergleichsrechnung, Berichte, Schlussrechnung und Verteilung.

**Freistehend:** Dieses Plugin enthält eigene Skills, Vorlagen, Quellenhinweise, Vorschau und Testakte. Es verweist nicht auf andere Plugins als Voraussetzung.

## Vorlage Asset-Purchase-Agreement (Insolvenz-Asset-Deal)

Der ausgefüllte Mustervertrag ChainCortex AI GmbH (i. Ins.) -> Voracis Ventures GmbH steht als sofort einsetzbares Template zum Direkt-Download bereit:

> Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.
>
> This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

| Format | Direkt-Download |
| --- | --- |
| **Word (DOCX, Times New Roman, 12 pt)** | [asset-purchase-agreement-chaincortex-voracis.docx](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenz-asset-deal-chaincortex-ai-berlin/docx/asset-purchase-agreement-chaincortex-voracis.docx) |
| **PDF (Times Roman, A4)** | [asset-purchase-agreement-chaincortex-voracis.pdf](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenz-asset-deal-chaincortex-ai-berlin/pdfs/asset-purchase-agreement-chaincortex-voracis.pdf) |
| Markdown-Volltext (zum Lesen auf GitHub) | [09_asset-purchase-agreement-text.docx](https://github.com/Klotzkette/claude-fuer-deutsches-recht/blob/insolvenz-fachbereich-v445.36.10/testakten/insolvenz-asset-deal-chaincortex-ai-berlin/09_asset-purchase-agreement-text.docx) |
| Gesamte Testakte als ZIP | [testakte-insolvenz-asset-deal-chaincortex-ai-berlin.zip](https://github.com/Klotzkette/claude-fuer-deutsches-recht/releases/download/insolvenz-arbeitsvorlagen-v1.0.0/testakte-insolvenz-asset-deal-chaincortex-ai-berlin.zip) |

Das Template umfasst 11 Paragraphen: Präambel, Vertragsgegenstand mit Datenschutz- und Betriebsübergangsbausteinen, Kaufpreis, Vollzugsvoraussetzungen, Signaturklausel, Haftungsregeln, Compliance-Klausel und Schlussbestimmungen plus Anlagen. Vor Verwendung im Mandat: Anpassung an konkrete Parteien, IP-Liste, Arbeitnehmerübergang, Kundendaten und Kaufpreis erforderlich.

## Installation

1. ZIP aus dem Release herunterladen.
2. Plugin-Umgebung öffnen.
3. **Customize → Plugins** bzw. **Personal plugins** öffnen.
4. **Upload plugin** wählen und `insolvenzverwaltung.zip` hochladen.
5. Mit einem konkreten Auftrag starten, zum Beispiel: `Starte das Insolvenzverwaltungs-Kommandocenter für diese neue IV-Akte.`

Nicht das komplette Repository-ZIP hochladen. Das Plugin-ZIP muss im Root direkt `.claude-plugin/plugin.json`, `skills/`, `assets/` und `references/` enthalten.

## Kernmodule

| Modul | Funktion |
| --- | --- |
| Verfahrenscockpit | Aktenanlage, Rollen, Fristen, Beschlussauswertung, Workstreams und Gerichtskommunikation. |
| Gutachten und Eröffnung | Eröffnungsgründe, Massekostendeckung, Sicherungsmaßnahmen und Empfehlung. |
| Masse und Verwertung | Masseeinsammlung, Massemehrung, Verwertung, Fortführung, Drittschuldner und Vergleich. |
| Ansprüche | Insolvenzanfechtung, § 15b InsO, D&O, Zahlungsanalyse, Klage- und Vergleichspfad. |
| Tabelle | Forderungsanmeldung, Belegprüfung, Rang, Widerspruch, Prüfungstermin und Feststellung. |
| Bericht und Abschluss | Zwischenbericht, Ausschussbericht, Anzeige § 208 InsO, Schlussbericht, Schlussrechnung und Verteilung. |
| Insolvenzplan und StaRUG | IV-integrierte Planwerkstatt mit Sanierungskonzept, Vergleichsrechnung, Gruppen/Klassen, darstellendem und gestaltendem Teil, Anlagen, Abstimmung, Cram-down, Minderheitenschutz und Planvollzug. |

## Skill-Landkarte

| Skill | Zweck |
| --- | --- |
| `iv-kommandocenter` | Erkennt Verfahrensart, Rolle, rote Schwellen und nächste sichere Aktion. |
| `iv-aktenanlage-verfahrenscockpit` | Legt eine vollständige Verfahrensakte mit Tabellen, Konten und Workstreams an. |
| `iv-eroeffnungsgutachten` | Strukturiert Eröffnungsgrund, Massekostendeckung, Sicherung und Fortführung. |
| `iv-vorlaeufige-verwaltung` | Steuert Zustimmungsvorbehalt, Kasse, Post, Banken und Sofortmaßnahmen. |
| `iv-sicherung-betriebsfortfuehrung` | Baut Wochenplan, Cash-Bridge, Lieferantenampel und Insolvenzgeldpfad. |
| `iv-regelverfahren-eroeffnung` | Ordnet eröffnetes Regelverfahren, Masse, Tabelle, Berichte und Verwertung. |
| `iv-eigenverwaltung-sachwaltung` | Trennt Schuldnerverwaltung, Sachwalterkontrolle, Haftung und Anfechtung. |
| `iv-schutzschirm-270d` | Prüft Bescheinigung, Frist, Planreife und Anzeige der Zahlungsunfähigkeit. |
| `iv-masseeinsammlung` | Sammelt Forderungen, Konten, Herausgabeansprüche, Rückstände und Drittrechte. |
| `iv-massemehrung-asset-realisation` | Entwickelt Verwertungs-, Vergleichs-, Prozess- und Fortführungsoptionen. |
| `iv-anfechtung-129ff` | Prüft Deckung, Vorsatz, Gesellschafterdarlehen, Bargeschäft und Klagepfad. |
| `iv-zahlungsklagen-15b` | Rekonstruiert Insolvenzreife, Zahlungen, Ausnahmen, Schaden und Klage. |
| `iv-forderungsanmeldung-pruefung` | Prüft Forderungsanmeldungen auf Grund, Betrag, Rang, Belege und vbuH. |
| `iv-tabelle-pruefungstermin` | Bereitet Prüfungstermin, Widersprüche, Auszüge und Feststellungsklagen vor. |
| `iv-masseunzulaenglichkeit-208` | Prüft Anzeige, Rang, Zahlungsstopp, Kommunikation und Fortverwaltung. |
| `iv-arbeitsrecht-insolvenzgeld` | Ordnet Löhne, Insolvenzgeld, Kündigungen, Betriebsrat und Personalmaßnahmen. |
| `iv-steuern-sozialversicherung` | Prüft Steuerforderungen, Masseverbindlichkeiten, § 15b-Ausnahmen und SV. |
| `iv-berichte-gericht-glaeubiger` | Erstellt Zwischenberichte, Ausschussberichte, Sachstandsberichte und Beschlussvorlagen. |
| `iv-verteilung-schlussrechnung` | Bereitet Schlussbericht, Schlussrechnung, Verteilung und Nachtragsverteilung vor. |
| `iv-qualitaets-und-plausibilitaetsgate` | Findet Lücken, Widersprüche, Fristen, Rechenfehler und Rollenverwechslungen. |

## IV-integrierte Planwerkstatt

Die Planwerkstatt aus dem freien Plugin ist inhaltlich vollständig auch in diesem Insolvenzverwaltungs-Plugin enthalten. Die Skills tragen hier bewusst den Präfix `iv-plan-`, damit bei paralleler Installation keine Namenskollision mit dem freistehenden Plugin entsteht. Inhaltlich bleibt der Workflow gleich: Intake, Sanierungskonzept, integrierte Planung, Vergleichsrechnung, Insolvenzplan, StaRUG-Plan, Gruppen/Klassen, Anlagen, Abstimmung, Cram-down, Minderheitenschutz, Gericht und Vollzug.

| Skill | Zweck |
| --- | --- |
| `iv-plan-abstimmung-mehrheiten` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-anlagenpaket` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-cramdown-obstruktion` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-darstellender-teil` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-datenraum-register` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-gerichtliche-schritte` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-gestaltender-teil` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-gruppen-klassenbildung` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-insolvenzplan-architektur` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-integrierte-planung` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-kaltstart-interview` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-kommandocenter` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-minderheitenschutz` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-planbetroffene-auswahl` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-planvollzug-monitoring` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-redteam-qualitygate` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-sanierungskonzept` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-sicherheiten-drittsicherheiten` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-stabilisierung-starug` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-stakeholder-kommunikation` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-starug-plan-architektur` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-steuern-bilanz-folgen` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-verfahrenswahl` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |
| `iv-plan-vergleichsrechnung` | Integrierte Planwerkstatt-Funktion für Insolvenzplan und StaRUG aus IV-/Sachwalter-Sicht. |

## Typische Workflows

- Eröffnungsauftrag -> Aktenanlage -> Kassensturz -> Eröffnungsgutachten -> Sicherungsmaßnahmen.
- Eröffnung -> Masseverzeichnis -> Forderungsanmeldungen -> Prüfungstermin -> Berichtstermin.
- Zahlungsjournal -> Insolvenzreife -> § 15b-Matrix -> D&O/Organe -> Klage oder Vergleich.
- OPOS/Konto -> Anfechtungsmatrix -> Anspruchsschreiben -> Klagepfad -> Vergleichsfreigabe.
- Masseprognose -> § 208-Prüfung -> Anzeige -> Rangsteuerung -> Fortverwaltung.
- Planoption -> Sanierungskonzept -> Vergleichsrechnung -> Gruppen/Klassen -> Planentwurf -> Abstimmung -> Planvollzug.
- Verwertung abgeschlossen -> Schlussbericht -> Schlussrechnung -> Verteilungsverzeichnis.

## Enthaltene Vorlagen

- `assets/templates/iv-mandatskarte.md` - Verfahrenskarte mit Gericht, Rolle, Beschluss, Workstreams und roten Schwellen
- `assets/templates/eroeffnungsgutachten-gliederung.md` - Gliederung Eröffnungsgutachten mit Zahlen- und Belegblöcken
- `assets/templates/vorlaeufige-verwaltung-checkliste.md` - Sofortcheck vorläufige Verwaltung und Zustimmungsvorbehalt
- `assets/templates/betriebsfortfuehrung-wochenplan.md` - Betriebsfortführungsplan mit Cash-Bridge und kritischen Lieferanten
- `assets/templates/liquiditaetsstatus-kurzcheck.md` - Kurzer Liquiditäts- und Insolvenzreifecheck für Gutachten und § 15b
- `assets/templates/regelverfahren-eroeffnung.md` - Checkliste nach Eröffnung des Regelverfahrens
- `assets/templates/masseverzeichnis.md` - Masseverzeichnis mit Sicherungsrechten und Realisierungspfad
- `assets/templates/massenachverfolgung.csv` - CSV für Masseeingänge und Forderungsrealisierung
- `assets/templates/verwertung-und-massemehrung.md` - Kosten-Nutzen-Matrix für Verwertung, Prozesse und Vergleiche
- `assets/templates/anfechtungsmatrix-129ff.md` - Anfechtungsmatrix nach §§ 129 ff. InsO
- `assets/templates/anfechtungsschreiben.md` - Anfechtungsschreiben mit Anspruch, Belegen und Vergleichsanker
- `assets/templates/zahlungsklage-15b.md` - Klage- und Prüfmatrix § 15b InsO
- `assets/templates/forderungen-und-tabelle.md` - Forderungsprüfung und Tabellenvermerk
- `assets/templates/tabellenpruefung.csv` - CSV-Struktur für Tabellenprüfung
- `assets/templates/masseunzulaenglichkeit-208.md` - Anzeige der Masseunzulänglichkeit nach § 208 InsO
- `assets/templates/eigenverwaltung-sachwalterbericht.md` - Sachwalterbericht für Eigenverwaltung
- `assets/templates/schutzschirm-270d.md` - Schutzschirmcheck § 270d InsO
- `assets/templates/personal-insolvenzgeld.md` - Personal- und Insolvenzgeldmatrix
- `assets/templates/steuern-sozialversicherung.md` - Steuer- und Sozialversicherungsstatus
- `assets/templates/zwischenbericht.md` - Zwischenbericht an Gericht oder Gläubigerausschuss
- `assets/templates/glaeubigerausschuss-bericht.md` - Gläubigerausschussbericht mit Entscheidungsbedarf
- `assets/templates/schlussbericht-schlussrechnung.md` - Schlussbericht und Schlussrechnung
- `assets/templates/verteilungsverzeichnis.md` - Verteilungsverzeichnis und Quotenberechnung
- `assets/templates/zahlungslauf-freigabe.md` - Freigabeprotokoll für Zahlungsläufe
- `assets/templates/quality-gate.md` - Vor-Versand- und Vor-Entscheidungsprüfung
- `assets/templates/planwerkstatt/` - vollständige Planwerkstatt-Vorlagen für Insolvenzplan, StaRUG, Vergleichsrechnung, Gruppen/Klassen, Anlagen, Cram-down und Planvollzug

## Sicherheitsleitplanken

- Keine gerichtliche, wirtschaftliche oder steuerliche Entscheidung ohne menschliche Letztprüfung.
- Keine echten Mandatsgeheimnisse, Bankzugänge, Gerichtslogins, beA-Zertifikate, Registerzugänge oder personenbezogene Daten in nicht freigegebene Systeme.
- Alle Fristen, Forderungen, Zahlungsflüsse, Tabellenvermerke, Anfechtungsansprüche und Verteilungsrechnungen müssen belegbar sein.
- Wo amtliche Onlinequellen abgefragt werden, werden Abrufdatum, URL, Treffer und Grenzen der Recherche dokumentiert.
- Simulationen sind deutlich als Simulation zu kennzeichnen.

<!-- BEGIN FACHMODULE-NAVIGATION -->

Das Plugin bietet **9 auswählbare Skills**. Die **53 vollständigen Fachmodule** und ihre Hilfsdateien stehen in der [Fachbibliothek](FACHMODULE.md). Wählen Sie den Arbeitsweg nach dem gewünschten Ergebnis; er führt zu den passenden Vertiefungen.

<!-- END FACHMODULE-NAVIGATION -->

<!-- BEGIN SKILLS-LOGIC (auto-generated) -->

## Orientierung nach Arbeitslogik

Diese Navigation ordnet die Skills nach typischen Arbeitsschritten. Ein Klick auf einen Skill lädt seine Markdown-Datei; die alphabetische Komplettliste bleibt darunter erhalten.

English: Skills are grouped by typical work phase. Clicking a skill downloads its Markdown file; the complete alphabetical list remains below.

| Arbeitsphase | Typische Skills |
| --- | --- |
| 1. Auftrag und bewährte Fachwerkzeuge | [`juristischer-argumentationskern`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/juristischer-argumentationskern/SKILL.md), [`kommandocenter`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/kommandocenter/SKILL.md) |
| 2. Eröffnung und vorläufige Verwaltung | [`eroeffnung-vorlaeufige-verwaltung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/eroeffnung-vorlaeufige-verwaltung-bearbeiten/SKILL.md) |
| 3. Masseverwertung und laufende Abwicklung | [`masse-verwertung-abwicklung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/masse-verwertung-abwicklung-bearbeiten/SKILL.md) |
| 4. Anfechtung und Zahlungsklagen | [`anfechtung-zahlungsklagen-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/anfechtung-zahlungsklagen-bearbeiten/SKILL.md) |
| 5. Tabelle und Verteilung | [`tabelle-verteilung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/tabelle-verteilung-bearbeiten/SKILL.md) |
| 6. Eigenverwaltung und Schutzschirm | [`eigenverwaltung-schutzschirm-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/eigenverwaltung-schutzschirm-bearbeiten/SKILL.md) |
| 7. Plan, Sanierung und Umsetzung | [`plan-sanierung-umsetzung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/plan-sanierung-umsetzung-bearbeiten/SKILL.md) |
| 8. Verwaltungsakte und Kommunikation | [`verwaltung-akte-kommunikation-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/verwaltung-akte-kommunikation-bearbeiten/SKILL.md) |

<!-- END SKILLS-LOGIC (auto-generated) -->

<!-- BEGIN SKILLS-OVERVIEW (auto-generated) -->

## Alle Skills im Überblick

Automatisch generierte Komplett-Liste aller 9 Skills in diesem Plugin. Jeder Skillname und der Downloadlink laden den unveränderten Inhalt der zugehörigen `SKILL.md` als Markdown-Datei. Der eindeutige Dateiname enthält Plugin und Skill; Beschreibungen stammen aus dem jeweiligen `description`-Feld.

English: Complete list of all 9 skills in this plugin. Both links in each row download the unchanged `SKILL.md` content as a Markdown file with a unique plugin-and-skill filename.

| Skill | Beschreibung | Markdown-Download |
| --- | --- | --- |
| [`anfechtung-zahlungsklagen-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/anfechtung-zahlungsklagen-bearbeiten/SKILL.md) | Rückgewähr- und Zahlungsansprüche aus der Insolvenzmasse belegen und gerichtlich durchsetzen. Die vollständigen Fachanweisungen werden passend zum konkreten Vorgang gelesen und gemeinsam umgesetzt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/anfechtung-zahlungsklagen-bearbeiten/SKILL.md) |
| [`eigenverwaltung-schutzschirm-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/eigenverwaltung-schutzschirm-bearbeiten/SKILL.md) | Voraussetzungen, Rollen und Qualitätskontrolle in Eigenverwaltung und Schutzschirm trennen. Die vollständigen Fachanweisungen werden passend zum konkreten Vorgang gelesen und gemeinsam umgesetzt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/eigenverwaltung-schutzschirm-bearbeiten/SKILL.md) |
| [`eroeffnung-vorlaeufige-verwaltung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/eroeffnung-vorlaeufige-verwaltung-bearbeiten/SKILL.md) | Eröffnungsgutachten, Sicherungsmaßnahmen und Übergang in das Regelverfahren organisieren. Die vollständigen Fachanweisungen werden passend zum konkreten Vorgang gelesen und gemeinsam umgesetzt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/eroeffnung-vorlaeufige-verwaltung-bearbeiten/SKILL.md) |
| [`juristischer-argumentationskern`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/juristischer-argumentationskern/SKILL.md) | Schaltet sich ein, wenn in Insolvenzverwaltung ein juristisches Arbeitsprodukt tragfähig begründet werden muss; verbindet konkrete Aktenfundstellen mit Tatbestandsmerkmal, Beweislast, stärkster Gegenposition und Rechtsfolge. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/juristischer-argumentationskern/SKILL.md) |
| [`kommandocenter`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/kommandocenter/SKILL.md) | Insolvenzverwaltung bis zur begründeten Maßnahme steuern. Wertet vorhandene Unterlagen aus, entscheidet die fachlichen Weichen und liefert eine vollständig begründete Maßnahme, einen gerichtlichen Bericht oder einen Antrag mit Befugnis,... | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/kommandocenter/SKILL.md) |
| [`masse-verwertung-abwicklung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/masse-verwertung-abwicklung-bearbeiten/SKILL.md) | Vermögen einziehen, verwerten, Personal und Steuern bearbeiten und Masseunzulänglichkeit prüfen. Die vollständigen Fachanweisungen werden passend zum konkreten Vorgang gelesen und gemeinsam umgesetzt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/masse-verwertung-abwicklung-bearbeiten/SKILL.md) |
| [`plan-sanierung-umsetzung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/plan-sanierung-umsetzung-bearbeiten/SKILL.md) | Insolvenzplan, Gruppen, Vergleichsrechnung, Abstimmung und Vollzug konsistent gestalten. Die vollständigen Fachanweisungen werden passend zum konkreten Vorgang gelesen und gemeinsam umgesetzt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/plan-sanierung-umsetzung-bearbeiten/SKILL.md) |
| [`tabelle-verteilung-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/tabelle-verteilung-bearbeiten/SKILL.md) | Forderungsanmeldungen, Prüfungstermin, Tabellenführung und Verteilung zusammenführen. Die vollständigen Fachanweisungen werden passend zum konkreten Vorgang gelesen und gemeinsam umgesetzt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/tabelle-verteilung-bearbeiten/SKILL.md) |
| [`verwaltung-akte-kommunikation-bearbeiten`](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/verwaltung-akte-kommunikation-bearbeiten/SKILL.md) | Aktenführung, Fristen, Berichte, Belegkontrolle und Kommunikation der Insolvenzverwaltung sichern. Die vollständigen Fachanweisungen werden passend zum konkreten Vorgang gelesen und gemeinsam umgesetzt. | [MD herunterladen / Download MD](https://klotzkette.github.io/claude-fuer-deutsches-recht/download.html?path=insolvenzverwaltung/skills/verwaltung-akte-kommunikation-bearbeiten/SKILL.md) |

<!-- END SKILLS-OVERVIEW (auto-generated) -->
