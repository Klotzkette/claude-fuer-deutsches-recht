---
name: insolvenzverwaltungs-erstpruefung-und-mandatsziel
description: "Für Insolvenzverwaltungs: Erstprüfung, Rollenklärung und Mandatsziel: routet Rolle, Frist, Unterlagen und Fachschritt; Ergebnis: Tatbestands- oder Anspruchsmatrix."
---

# Insolvenzverwaltungs: Erstprüfung, Rollenklärung und Mandatsziel

## Direktstart: lesen, entscheiden, liefern

Beginne nicht mit einem Fragenkatalog. Wenn Material vorliegt, lies es zuerst und starte mit einer verwertbaren Arbeitshypothese:

- Frist oder Sofortrisiko.
- erkannte Rolle, Zielrichtung und Verfahrensstand.
- tragende Tatsachen aus dem Material.
- bester nächster Arbeitsschritt mit direkt nutzbarem Output.

Frage höchstens zwei Punkte nach, und nur wenn ohne diese Antwort der nächste Schritt falsch oder riskant würde. Fehlt Material vollständig, verlange nicht allgemein alle Unterlagen, sondern nenne die drei wichtigsten Dokumente und arbeite mit sichtbaren Annahmen weiter.

Starte mit einem Arbeitsprodukt, nicht mit einer Inventarliste: Kurzvermerk, Fristenblatt, Prüfmatrix, Entwurf, Fragenliste oder Entscheidungsvorschlag. Routing ist nur Mittel zum Zweck. Wenn ein Fachskill eindeutig passt, arbeite unmittelbar in dessen Richtung weiter.

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: die im Plugin-Kontext einschlägigen Normen über gesetze-im-internet.de, dejure.org, eur-lex.europa.eu und die amtlichen Bundes-/Landesportale live prüfen — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Insolvenzverwaltungs: Erstprüfung, Rollenklärung und Mandatsziel` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Spezialwissen: Insolvenzverwaltungs: Erstprüfung, Rollenklärung und Mandatsziel
- **Normen-/Quellenanker:** InsO, StaRUG.

## Fallweichen
Wenn Unterlagen vorhanden sind, arbeite zuerst aus den Unterlagen. Stelle nur Rückfragen, die die nächste Weiche verändern:

1. Welche Rolle hat die fragende Person und wer ist Gegenüber?
2. Welches konkrete Ziel soll erreicht oder verhindert werden?
3. Welche Frist, Zustellung, Schwelle, Zahlung, Sanktion oder Verfahrensstufe ist kritisch?
4. Welche Dokumente, Registerauszüge, Bescheide, Verträge, Tabellen, Screenshots oder Nachrichten belegen den Punkt?
5. Welcher Output wird gebraucht: Memo, Checkliste, Tabelle, Entwurf, Schriftsatzbaustein, Mandantenbrief oder Entscheidungsvorlage?

## Arbeitsworkflow
1. **Fallbild bilden:** Sachverhalt, Rollen, Zeitachse und Dokumente in eine kurze Matrix bringen.
2. **Rechtsrahmen setzen:** Normen, Zuständigkeiten, Fristen, Formfragen und Verfahrensstand zum Themenfeld **Insolvenzverwaltungs** prüfen.
3. **Prüfpunkte abarbeiten:** Tatbestandsmerkmale, Beweisfragen, typische Fehler, Gegenargumente und Ermessens- oder Wertungsfragen trennen.
4. **Risiko bewerten:** Grün/Gelb/Rot mit Begründung, Annahmen, fehlenden Belegen und möglichen Alternativwegen ausgeben.
5. **Anschluss bauen:** Passende weitere Skills desselben Plugins vorschlagen, wenn eine Vertiefung, ein Schreiben, eine Tabelle, ein Fristenblatt oder eine Verhandlungsstrategie sinnvoll ist.

## Erstprüfung Insolvenzverwalter — Pflichtfragen
- **Rollenklärung:**
 - Regelverwalter § 80 InsO (volle Verwaltungs- und Verfügungsbefugnis) oder Sachwalter § 274 InsO (Eigenverwaltung — Schuldner bleibt verfügungsbefugt, Sachwalter überwacht)?
 - Vorl. Verwalter § 21, § 22 InsO: stark (Verwaltungs- und Verfügungsbefugnis) oder schwach (Zustimmungsvorbehalt § 21 Abs. 2 Nr. 2 Alt. 2 InsO)?
 - Restrukturierungsbeauftragter § 73 ff. StaRUG (StaRUG-Verfahren)?
- **Mandatsziel:**
 - Massesicherung in den ersten 14 Tagen (§ 22 InsO Sicherungsmaßnahmen).
 - Berichtstermin § 156 InsO mit Empfehlung Fortführung oder Stilllegung.
 - Planinsolvenz §§ 217 ff. InsO als Verwertungsstrategie.
 - Übertragende Sanierung (Asset Deal / Share Deal).
- **Erstmaßnahmen:**
 - Inbesitznahme der Geschäftsräume, IT-Systeme, Buchhaltung, Mailpostfach (§ 148 InsO).
 - Sofortige Kontensperrung bei Banken, Neueröffnung Insolvenzkonto.
 - Anmeldung bei Insolvenzgericht: Verfahrenseröffnungsantrag bestätigt, Insolvenzbekanntmachung veranlasst.
 - Information Mitarbeiter, Betriebsrat — Insolvenzgeld § 165 SGB III prüfen, Vorfinanzierung anstoßen.
 - Eilige Verträge: Mietvertrag § 109 InsO (3 Monate Sonderkündigungsrecht), Arbeitsverträge § 113 InsO (3 Monate Kündigungsfrist), Dauerlieferverträge § 103 InsO Erfüllungswahlrecht.
- **Vergütung:** § 63 InsO i.V.m. InsVV — Regelsatz nach Massewert mit Zu-/Abschlägen.

## Haftungsrelevante Erstmaßnahmen
- § 60 InsO Verwalterhaftung — fehlerhafte Erstmaßnahmen sind tragender Haftungsanknüpfungspunkt.
- Dokumentation jeder Erstentscheidung (Datum, Begründung, Beleg).
