---
name: massemehrung-asset-realisation
description: "Für Massemehrung und Verwertung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Massemehrung und Verwertung

## Arbeitsbereich

Verwertungsstrategie und Massemehrung entwickeln wenn Masse niedrig oder Quote ungewiss ist. §§ 159 160 InsO Verwertung § 133 InsO Vorsatzanfechtung § 15b InsO Haftungsansprüche. Prüfraster: Werthebel Assets Prozesse Anfechtung D und O Vergleichspotenzial Kosten-Nutzen. Output: Verwertungskonzept Strategiematrix Beschlussvorlage. Abgrenzung: nicht für reine Masseeinsammlung (iv-masseeinsammlung) oder Betriebsfortführung. Arbeite entlang dieser konkreten Prüfungslinie und trenne Rolle, Frist, Zuständigkeit, Beweislast und gewünschten Output.

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: die im Plugin-Kontext einschlägigen Normen über gesetze-im-internet.de, dejure.org, eur-lex.europa.eu und die amtlichen Bundes-/Landesportale live prüfen — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Massemehrung und Verwertung` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Startet bei

- Masse niedrig oder Quote unklar ist
- Vermögensgegenstände, Prozesse oder Ansprüche bewertet werden müssen
- Gläubigerausschuss oder Gericht eine Verwertungsstrategie braucht

## Eingaben

- Assetliste, Bewertung, Sicherheiten
- Anfechtungs- und Haftungsmatrix
- Kosten, Prozessrisiken, Kaufinteressenten

## Workflow

1. **Werthebel sammeln** - Assets, Forderungen, Anfechtung, § 15b, D&O, Versicherungen und Vergleiche kartieren.
2. **Wirtschaftlichkeit** - Bruttoerlös, Kosten, Zeit, Sicherungsrechte, Prozessrisiko und Quote schätzen.
3. **Strategie** - Verkauf, Auktion, Vergleich, Klage oder Nichtverfolgung begründen.
4. **Freigabe** - Ausschuss-, Gericht- oder Gläubigerkommunikation vorbereiten.

## Ausgabe

- Massemehrungs-Matrix
- Verwertungsvorschlag
- Kosten-Nutzen-Vermerk

## Qualitätsgates

- Sicherungsrechte abgezogen
- Kosten und Dauer ausgewiesen
- Nichtverfolgung begründet

## Rote Schwellen

- Prozesskosten ohne Deckung
- Interessenkonflikt beim Verkauf
- Vergleich ohne Massevorteil
- Ausländischer office holder will deutsches Asset verwerten, ohne Verfahrenseröffnung, Amt und konkrete Befugnis in deutscher Vollzugsform nachzuweisen
- Verwechslung von Konzernkontrolle mit Eigentum: Insolvenz der ausländischen Mutter bedeutet nicht automatisch Verfügungsbefugnis über Vermögen der deutschen Tochter

## Cross-Border-Asset-Hinweis

Bei US debtor in possession, US trustee, kanadischem trustee/monitor/receiver oder sonstigem ausländischem office holder immer `iv-cross-border-assets-trustee-registervollzug` hinzuziehen. Der Skill klärt Anerkennung, Inzidentprüfung, GmbH-Anteile, Grundbuch, Register, Nachweispaket und Masseinteresse.

## Interne Vorlagen

- assets/templates/masseverzeichnis.md
- assets/templates/verwertung-und-massemehrung.md

## Amtliche Erstquellen

- §§ 159 ff. InsO
- §§ 129 ff. InsO

## Paragrafenkette Insolvenzverwaltung

§ 56 InsO (Bestellung IV) → § 60 InsO (Haftung) → § 61 InsO (persönliche Haftung Masseglaeubigeransprueche) → § 66 InsO (Rechnungslegung) → § 69 InsO (Ausschuss-Informationspflicht) → § 160 InsO (Zustimmung bei bedeutenden Maßnahmen) → § 208 InsO (Masseunzulaenglichkeit) → §§ 187-216 InsO (Verteilung)

## Triage — Verfahrensstand

Bevor losgelegt wird, klaere:
1. **Verfahrensstatus?** Vorlaeufige Verwaltung (§ 22 InsO) oder Eroeffnung (§ 27 InsO)?
2. **Massedeckung?** § 54/55 InsO: Verfahrenskosten gedeckt? Masseunzulaenglichkeit § 208 droht?
3. **Zustimmungserfordernis § 160 InsO?** Handlung besonders bedeutsam → Gläubigerausschuss oder -versammlung einbeziehen.
4. **Dokumentation vollstaendig?** Schlussrechnung § 66 InsO vorbereitet?

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
