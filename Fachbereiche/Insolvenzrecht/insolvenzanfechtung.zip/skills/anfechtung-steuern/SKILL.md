---
name: anfechtung-steuern
description: "Insolvenzanfechtung handlungs- und beweisbezogen ausarbeiten. Wertet vorhandene Unterlagen aus, entscheidet die fachlichen Weichen und liefert bezifferte Anfechtungsforderung, Klage oder Abwehr mit je Handlung vollständiger Tatbestands- und Beweisführung."
---

# Insolvenzanfechtung handlungs- und beweisbezogen ausarbeiten

## 1. Zweck und Anwendungsfall

Führen Sie den Auftrag vom vorhandenen Aktenbestand bis zum verlangten Arbeitsprodukt durch. Beginnen Sie mit der konkreten Zahlung, Sicherheit oder Vertragsgestaltung und der Rolle der Mandantschaft. Das Plugin behandelt Insolvenzanfechtung; es nimmt keine vollständige Unternehmenssanierung, Organhaftungsprüfung oder Strafbewertung ohne gesonderten Auftrag vor.

Der Ablauf ist flexibel: Ein klar belegter einzelner Vorgang kann unmittelbar geprüft und beantwortet werden. Eine unübersichtliche Plattformakte braucht zuerst eine Zahlungskette. Ein zugestellter Prozessauftrag erfordert vorrangig Frist- und Rubrumkontrolle. Sie dürfen nicht alle zehn Fachskills als starres Ritual abarbeiten, wenn nur ein enger Teilauftrag besteht. Ebenso dürfen Sie eine entscheidende Schnittstelle nicht aus Zeitgründen überspringen.

Für eine vertiefte Bearbeitung laden Sie nur die einschlägige vollständige Einzelwerkstatt: [§ 130 InsO](../../werkstattprompts/130-kongruente-deckung.md), [§ 131 InsO](../../werkstattprompts/131-inkongruente-deckung.md), [§ 132 InsO](../../werkstattprompts/132-unmittelbare-benachteiligung.md), [§ 133 InsO](../../werkstattprompts/133-vorsatzanfechtung.md), [§ 134 InsO](../../werkstattprompts/134-unentgeltliche-leistung.md), [§ 135 InsO](../../werkstattprompts/135-gesellschafterdarlehen.md), [§ 136 InsO](../../werkstattprompts/136-stille-gesellschaft.md), [§ 137 InsO](../../werkstattprompts/137-wechsel-und-scheckzahlungen.md), [§ 138 InsO](../../werkstattprompts/138-nahestehende-personen.md), [§ 139 InsO](../../werkstattprompts/139-fristen-und-antragsauswahl.md). Jede Werkstatt enthält eigenen Auftrag, Merkmalsprüfung, Belegkennzeichnung, Gegenprüfung und ausformulierte Fallvarianten. §§ 138 und 139 sind Zuordnungs- und Fristenregeln; § 137 ist eine Sonderregel, kein allgemeiner zusätzlicher Rückgewährtatbestand.

## 2. Eingaben

Lesen Sie die vom Nutzer benannten Unterlagen und übernehmen Sie Rolle, Verfahren, Vorgänge und gewünschtes Dokument. Fragen Sie nur nach entscheidenden Lücken: Wer soll vertreten werden, welche Handlungen sind betroffen, welche gerichtliche oder materielle Frist läuft und welches Ergebnis wird jetzt benötigt? Bereits bekannte Daten werden nicht erneut abgefragt.

Nehmen Sie einen laufenden Bearbeitungsstand auf, sofern vorhanden. Er enthält führende Dateifassung, Vorgangskennungen, Belegstatus, Normfassung, offene Tatsachen, Fristobjekt, Betragsrechnung und nächsten Schritt. Ein vorheriges KI-Ergebnis ist eine Arbeitshypothese und keine verifizierte Quelle. Kontrollieren Sie seine tragenden Belege, ohne sämtliche unstreitigen Angaben bei jedem Folgeschritt neu zu erheben.

## 3. Ablauf und Checkliste

**Aktenstart.** Lies Zahlungsbelege, Verträge, Mahnungen, Sicherheiten und Eröffnungsdaten; erfasse jede Rechtshandlung mit Empfänger, Betrag und maßgeblichem Zeitpunkt. Leite Auftrag und Empfänger aus dem Material ab; wiederhole keine bereits beantwortete Eingangsfrage.

**Entscheidende Weiche.** Prüfe Gläubigerbenachteiligung, richtigen Anfechtungstatbestand und zeitliche Anwendbarkeit vor Kenntnis und Vorsatz. Trenne Verpflichtungsgeschäft, Zahlung und Besicherung; unterschiedliche Handlungen dürfen nicht zu einer pauschalen Krisenzahlung verschmelzen.

**Gezielte Vertiefung.** Bei kongruenter Deckung genügt erkannte Zahlungsunfähigkeit nicht automatisch für Benachteiligungsvorsatz. Bei Sale-and-lease-back oder Liquiditätstausch tatsächlichen Vermögenseffekt berechnen; außenstehende Gegner erhalten keine pauschale interne Buchhaltungslast. Öffne nur den dadurch erforderlichen vorhandenen Fachskill oder Fachtext. Übernimm Befund, Beleg und Rechtsfolge unmittelbar in dasselbe Arbeitsprodukt; die Übergabe beendet den Auftrag nicht.

**Lücke und Gegenposition.** Frage nur nach einer Information, die Antrag, Rechtsfolge, Frist, Betrag oder entscheidenden Nachweis verändert. Benenne ihre Auswirkung und arbeite an den übrigen Teilen weiter. Stelle dem vorläufigen Ergebnis den stärksten belegbaren Gegenbefund gegenüber; Unsicherheit wird als solche begründet, nicht durch erfundene Tatsachen geschlossen.

**Fertigstellen und fortschreiben.** Liefere bezifferte Anfechtungsforderung, Klage oder Abwehr mit je Handlung vollständiger Tatbestands- und Beweisführung. Eine spätere Antwort oder Unterlage wird an der betroffenen Stelle eingearbeitet; ändere daraus folgende Rechnung, Antrag und Begründung gemeinsam. Ein Menü, eine reine Fragenliste oder der Verweis auf einen Folgeskill ist kein Endprodukt.

**Fachliche Durchführung und bestehende Verzweigungen:**


### 3.1 Ersten Arbeitsstand liefern

Benennen Sie in wenigen Sätzen Ergebnisrichtung, stärksten vorhandenen Beleg und entscheidende offene Frage. Beginnen Sie bei einem Dokumentenauftrag bereits mit den bearbeitbaren Teilen des Entwurfs. Eine Rückfrage soll einen konkreten Unterschied im Ergebnis auflösen; sie darf nicht zur pauschalen Warteschleife werden. Bei einem Eilrisiko priorisieren Sie die betroffene Frist und kennzeichnen Sie, welche unabhängigen Sacharbeiten parallel möglich sind.

### 3.2 Grundlagenroute auswählen

Bei unklaren Zahlungen starten Sie mit Zahlungskette und Belegen. Für jeden angegriffenen Vorgang folgen Rechtshandlung, Zeitpunkt und Gläubigerbenachteiligung. Stellen Sie sicher, dass Antrag, Eröffnung und Wirksamkeit nicht vermischt werden. Ein neues Dokument kann die Zuordnung ändern; führen Sie die gleiche Vorgangskennung weiter und begründen Sie die Änderung. Prüfen Sie bei Auslandsbezug zuerst, ob die deutsche Anfechtungsroutine überhaupt passt.

### 3.3 Tatbestandsrouten gezielt verbinden

Für bestehende Forderungen prüfen Sie Deckung, für besonderen Wissensstoff Vorsatz, für fremde Schuld oder Schenkung Unentgeltlichkeit, für Gesellschafterfinanzierung die Spezialroute und für Sicherheiten oder Verrechnung die zugehörige Analyse. Unmittelbar nachteilige Verträge werden in der Grundlagenroute gesondert eingeordnet. Bei unmittelbarer Gegenleistung folgt die Bargeschäftsprüfung. Eine nicht erfolgreiche Route führt nicht automatisch zum gesamten Anspruchsausschluss; weitere Routen brauchen aber eigene tragende Tatsachen.

### 3.4 Gemeinsamen Mandatsstand führen

Speichern Sie für jeden Vorgang Ergebnis, Beleg, Gegenposition und offene Frage. Eine Gesamttabelle verwendet höchstens vier Spalten; Einzelheiten stehen in verlinkten Vorgangsblättern. Pflegen Sie Rechenstand und Quellenstatus mit, statt am Ende verschiedene Teilergebnisse unkontrolliert zusammenzukopieren. Ein Tatbestand gilt nicht als bestätigt, solange ein entscheidendes Merkmal lediglich vermutet wird. Änderungen an einer Zahlung prüfen Sie auf Folgen für Gesamtsumme, Anträge und Vergleichskorridor.

### 3.5 Rechtsfolgen und bestelltes Produkt ausarbeiten

Prüfen Sie Rückgewähr, Gegenleistung, Nebenforderungen und Verjährung als eigenständige Stufe. Führen Sie danach das bestellte Memo, Schreiben, die Klage, Erwiderung oder den Vergleich zu Ende. Bei offenem Sachverhalt liefern Sie eine verwendbare Teilfassung und eine kurze gezielte Nachforderung. Ein Risikoampelbericht ersetzt weder eine bestellte Klageerwiderung noch eine ausformulierte Vergleichsvereinbarung.

### 3.6 Freigabe und Fortsetzung bestimmen

Kontrollieren Sie Quellen, Aktenbezug, Rechnung und Vollständigkeit. Interne Sichtung, Berechnung und Entwurfsarbeit erfolgen innerhalb des Auftrags selbständig. Außenwirkung braucht eine konkrete menschliche Freigabe mit Person, Fassung und Handlung; aus einer Freigabe zur Recherche folgt keine Versandvollmacht. Nach Rückmeldung führen Sie denselben Stand fort. Schließen Sie mit dem erreichten Produkt, offenen Punkten und dem sachlich nächsten Schritt, ohne einen abgeschlossenen engen Auftrag künstlich zu verlängern.

### 3.7 Selbstkontrolle und Übergabe

Prüfen Sie zum Abschluss, ob die Bearbeitung dem tatsächlichen Auftrag entspricht. Eine neutrale Aktenanalyse darf nicht unbemerkt zur parteilichen Zahlungsforderung werden. Ein Verteidigungsauftrag rechtfertigt kein Weglassen belastender Belege. Ein späterer Rollenwechsel ist ausdrücklich festzuhalten und auf mögliche Interessenkonflikte zu prüfen. Das Plugin hält den fachlichen Arbeitsstand nachvollziehbar, ersetzt aber weder die Befugnis zur Berufsausübung noch die verantwortliche Entscheidung der beauftragten Person. Diese Grenze wird durch konkrete Freigaben und Quellenkontrolle umgesetzt, nicht durch eine folgenlose allgemeine Warnung.

Die Übergabe enthält Vorgangskennung, konkreten Beleg, festgestellte Tatsachen, bestrittene Punkte und das benötigte nächste Produkt. Nutzen Sie nur die sachlich erforderlichen Nachbarschritte: [Zahlungsketten und Krisenbelege rekonstruieren](../zahlungskette-und-belege/SKILL.md), [Rechtshandlung, Zeitpunkt und Gläubigerbenachteiligung prüfen](../rechtshandlung-zeit-benachteiligung/SKILL.md), [Anfechtungsansprüche durchsetzen, abwehren und vergleichen](../prozess-und-vergleich/SKILL.md). Nach einer Antwort ergänzen Sie den laufenden Stand und kontrollieren die betroffenen Folgeprodukte.

## 4. Quellenpflicht

### 4.1 Fachlicher Entscheidungsanker

BGH, Urteil vom 21. Mai 2026 – IX ZR 168/24, ECLI:DE:BGH:2026:210526UIXZR168.24.0, insbesondere Rn. 24 bis 35, 40 bis 45 und 55 bis 62. Gelesen: Rn. 14 bis 62.

[Amtlicher Volltext](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/IX_ZS/2024/IX_ZR_168-24.pdf?__blob=publicationFile&v=1).

Trägt: Verpflichtungsgeschäft und einzelne Erfüllungshandlungen getrennt prüfen. Das Sale-and-lease-back-Verpflichtungsgeschäft ist nicht allein wegen angemessenen Kaufpreises eine Deckung. Interne Krisenmails an Organ/Gesellschafter sind nicht automatisch nach außen hervorgetretene Zahlungseinstellung, können aber Krisenwissen belegen. Aufrechnung mit einem Altdarlehen schafft keinen für § 142 ausreichenden Aktivzufluss. Ein Sanierungsansatz muss Ursachen adressieren; bloßes kurzfristiges Schließen einer Liquiditätslücke genügt nicht ohne Weiteres.

Trägt nicht: Interne Nachrichten sind generell unbeachtlich; alle Sale-and-lease-back-Geschäfte sind anfechtbar; Gesellschafterstellung allein ersetzt Kenntnis- oder Vorsatzbeweis. Eine Nachricht an einen Gesellschafter kann anders zu würdigen sein, wenn dieser tatsächlich als Gläubiger auftritt.

Bei kongruenter Deckung den damaligen Informationsstand je Zahlung belegen. [BGH, Urteil vom 24.09.2026, IX ZR 65/25](https://www.rechtsprechung-im-internet.de/jportal/docs/bsjrs/jb-KORE313232026.zip), Rn. 13–23: Belegen Sie, ob der Schuldner die Zahlung einer fälligen erheblichen Schuld binnen drei Wochen auch in Raten als unmöglich bezeichnete. Ordnen Sie Empfänger, Erklärungstag und Fortdauer bis zur Zahlung zu. Der BGH hat zur weiteren Tatsachenprüfung zurückverwiesen.

### 4.2 Prüfung vor Verwendung

Prüfen Sie die anwendbare Normfassung und jede tragende gerichtliche Aussage anhand der [Rechtsquellen](../../references/rechtsquellen.md) und der [Zitierweise](../../references/zitierweise.md). Eine Suchtrefferüberschrift, ein früherer KI-Text oder ein Datenbankzitat ohne gelesenen Volltext ist kein Beleg. Gericht, Entscheidungsform, Datum, Aktenzeichen und gelesene Randnummer müssen zur konkreten Aussage passen. Dokumentieren Sie, was der Anker trägt und was er nicht trägt. Übernehmen Sie keine allgemeine Bindung aus einem Präzedenzfall.

Ist der amtliche Text nicht zugänglich, bleibt die Aussage ausdrücklich unverifiziert; verlangen Sie den Originaltext oder formulieren Sie den offenen Prüfpunkt. Erfinden Sie keine Randnummer, Frist oder Fundstelle. Die [Arbeitsweise](../../references/arbeitsweise.md) verlangt eine getrennte Tatsachen-, Rechts- und Rechenkontrolle. Im Schriftsatz stehen tragende Nachweise an der passenden Stelle; technische Abrufprotokolle bleiben in der internen Notiz.

## 5. Ausgabeformat

Die Ausgabe beginnt mit dem verlangten Arbeitsprodukt. Danach folgt ein kurzer Statusblock: Rolle und Ziel; bearbeitete Vorgänge; führende Fassung; Friststand; offene Belege oder Quellen; nächste Handlung; erforderliche Freigabe. Falls keine Dateiumgebung vorhanden ist, wird dieser Stand im Chat ausgegeben. Behaupten Sie keine gespeicherte Excel-Datei, keinen versandten Brief und keine erfolgte gerichtliche Einreichung, wenn nur Text erstellt wurde.

Alle Endprodukte werden vollständig ausformuliert in grammatikalisch vollständigen Sätzen geliefert. Skelette, leere Klauselrümpfe und bloße Stichwortsammlungen sind kein fertiges Dokument. Fehlende Einzelangaben erhalten eindeutige Platzhalter, ohne den umgebenden Sinnsatz wegzulassen. Formatierte Dokumente verwenden soweit technisch möglich Times New Roman, 11 pt und ausschließlich dezimale Gliederung. Bei reiner Textausgabe steht der Formatwunsch in einem getrennten Exporthinweis. Versand, Einreichung, Anerkenntnis, Verzicht und Vergleichsannahme werden nicht ohne konkrete menschliche Freigabe ausgeführt.

## 6. Beispiele

„Prüfen Sie das Forderungsschreiben und entwerfen Sie die Antwort“ führt nach Aktenlektüre zur begründeten Antwort mit getrennter interner Risikonotiz. Der Skill verlangt nicht zuerst einen vollständigen allgemeinen Insolvenzfragebogen.

„Erstellen Sie eine Anfechtungsklage zu den drei belegten Zahlungen“ führt über Zeitpunkt, Tatbestand, Betrag und Beweise zur ausformulierten Klage. Fehlt nur eine entscheidende Vertragszustimmung, wird diese gezielt nachgefragt, während Rubrum, Zahlungssachverhalt und unstreitige Teile bereits ausgearbeitet werden.



### 6.1. Rechtsprechung im konkreten Arbeitsschritt

Nutze nur den zur konkreten Streitfrage passenden Anker. Übernimm Rechtssatz, tragende Tatsache und Übertragungsgrenze in das bestellte Dokument; ein angehängtes Zitat ersetzt keine Subsumtion. Die folgenden Karten verbinden vorhandene dokumentierte Vorprüfungen mit ausdrücklich bezeichneten punktuellen Nachprüfungen vom 18.11.2026. Sie sind keine umfassende Aktualitäts- oder Negativrecherche. Bei rechtserheblicher neuer Gesetzeslage, abweichendem Sachverhalt oder nur vorläufigem Bericht den fehlenden Volltext beziehungsweise Normstand gezielt nachprüfen.

1. [BGH, Urteil vom 6. Mai 2021 – IX ZR 72/20, ECLI:DE:BGH:2021:060521UIXZR72.20.0, insbesondere Rn. 30 bis 37 und 40 bis 42](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/IX_ZS/2020/IX_ZR__72-20.pdf?__blob=publicationFile&v=1). **Anwendung:** Bei kongruenten Deckungen nicht aus bekannter Zahlungsunfähigkeit allein auf Benachteiligungsvorsatz schließen. Erforderlich ist die ex ante belegte Vorstellung, andere Gläubiger auch künftig nicht vollständig befriedigen zu können; die entsprechenden Kenntnistatsachen des Empfängers sind eigenständig zu würdigen. Für Zahlungseinstellung sind ausdrückliche Erklärungen oder gleichgewichtige Indizien erforderlich. Eine bloße Ratenbitte oder wiederholte Verzögerung ist kein automatischer Vollbeweis. **Grenze:** Abschaffung der Vorsatzanfechtung, generelle Unanfechtbarkeit insolventer Zahlungen oder mechanische Übertragung der Anforderungen kongruenter Deckungen auf jede inkongruente Sicherung.

   **Quellenstatus:** Übernommener dokumentierter Nachweis; am 18.11.2026 keine erneute Volltextprüfung. Übernommener Prüf-/Aktenstand: 2026-10-22.

2. [BGH, Urteil vom 18. April 2024 – IX ZR 129/22, ECLI:DE:BGH:2024:180424UIXZR129.22.0, Rn. 20 bis 27](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/IX_ZS/2022/IX_ZR_129-22.pdf?__blob=publicationFile&v=1). **Anwendung:** Ein außenstehender Empfänger muss aus einer nicht durch Einzelbelege erläuterten, nur zusammengefassten Liquiditätstabelle keine nicht vorhandenen internen Kenntnisse gewinnen. Umfang des erforderlichen Bestreitens hängt von Substantiierung des Verwaltervortrags und eigener Kenntnis ab. Forderung, Fälligkeit, liquide Mittel und Belege sind so aufzubereiten, dass konkrete Einwendungen möglich sind. **Grenze:** Pauschales Nichtwissen ist bei eigenen Handlungen immer zulässig; jede Liquiditätsrechnung benötigt ausnahmslos jeden Buchhaltungsbeleg als Anlage; der außenstehende Empfänger ist materiell von Anfechtung befreit.

   **Quellenstatus:** Übernommener dokumentierter Nachweis; am 18.11.2026 keine erneute Volltextprüfung. Übernommener Prüf-/Aktenstand: 2026-10-22.

3. [BGH, Urteil vom 21. Mai 2026 – IX ZR 168/24, ECLI:DE:BGH:2026:210526UIXZR168.24.0, insbesondere Rn. 24 bis 35, 40 bis 45 und 55 bis 62](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/IX_ZS/2024/IX_ZR_168-24.pdf?__blob=publicationFile&v=1). **Anwendung:** Verpflichtungsgeschäft und einzelne Erfüllungshandlungen getrennt prüfen. Das Sale-and-lease-back-Verpflichtungsgeschäft ist nicht allein wegen angemessenen Kaufpreises eine Deckung. Interne Krisenmails an Organ/Gesellschafter sind nicht automatisch nach außen hervorgetretene Zahlungseinstellung, können aber Krisenwissen belegen. Aufrechnung mit einem Altdarlehen schafft keinen für § 142 ausreichenden Aktivzufluss. Ein Sanierungsansatz muss Ursachen adressieren; bloßes kurzfristiges Schließen einer Liquiditätslücke genügt nicht ohne Weiteres. **Grenze:** Interne Nachrichten sind generell unbeachtlich; alle Sale-and-lease-back-Geschäfte sind anfechtbar; Gesellschafterstellung allein ersetzt Kenntnis- oder Vorsatzbeweis. Eine Nachricht an einen Gesellschafter kann anders zu würdigen sein, wenn dieser tatsächlich als Gläubiger auftritt.

   **Quellenstatus:** Übernommener dokumentierter Nachweis; am 18.11.2026 keine erneute Volltextprüfung. Übernommener Prüf-/Aktenstand: 2026-10-22.

4. [BGH, Urteil vom 17.09.2026 – IX ZR 229/23, Rn. 13–16, 24, 28–29, 37–38](https://www.rechtsprechung-im-internet.de/jportal/docs/bsjrs/jb-KORE304032026.zip). **Anwendung:** Tilgung, atypisch vorfinanzierte Warenlieferung und Zinszahlungen getrennt prüfen. Die Anfechtung der Befriedigung einer Gesellschafterdarlehensforderung nach § 135 Abs. 1 Nr. 2 InsO setzt den insolvenzrechtlichen Nachrang durch. **Grenze:** Art. 13 EuInsVO a. F. hindert diese Rangdurchsetzung nicht. Art. 16 der Neufassung und gewöhnliche Fremdfinanzierung gesondert prüfen. Zinszahlungen zur Tatsachenfeststellung zurückverwiesen.

   **Quellenstatus:** Übernommener dokumentierter Nachweis; am 18.11.2026 keine erneute Volltextprüfung. Übernommener Prüf-/Aktenstand: 2026-11-10.

5. [BGH, Urt. v. 24.09.2026 – Az. IX ZR 65/25, Rn. 13–20](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/IX_ZS/2025/IX_ZR__65-25.pdf?__blob=publicationFile&v=1). **Anwendung:** Eine nach außen erklärte Unfähigkeit, eine erhebliche fällige Schuld binnen drei Wochen auch nicht ratenweise zu zahlen, im Gesamtbild würdigen. **Grenze:** Bloße Ratenbitte und spätere Zahlungsversprechen verlangen eigene Würdigung. Die Kenntnis nach § 130 InsO ist gesondert zu prüfen.

   **Quellenstatus:** Übernommener dokumentierter Nachweis; am 18.11.2026 keine erneute Volltextprüfung. Übernommener Prüf-/Aktenstand: 2026-11-13.

#### 6.1.1. Beweis und Abschluss

Unterscheide das Insolvenzverfahren mit § 5 InsO, die Glaubhaftmachung eines Gläubigerantrags nach § 14 InsO und einen streitigen Zivilprozess. Der Anfechtungskläger muss die anspruchsbegründenden Tatsachen darlegen und beweisen; sekundäre Darlegungslast oder Beweisvereitelung verlangen besondere Voraussetzungen. Ein außenstehender Empfänger muss fehlende Schuldnerbuchhaltung nicht generell ersetzen. Bei Organhaftung, Tabellenfeststellung und Planbestätigung gelten jeweils eigene Nachweisregeln. Rechnung, Indizienwürdigung und offene Datenlücke bleiben getrennt.

Die belegten Ergebnisse in der angeforderten fertigen Fassung ausformulieren. Frist, Form, Zuständigkeit, Beträge und Anlagen gegeneinander prüfen. Eine Visualisierung nur mit tatsächlich verfügbaren Werkzeugen verwenden; andernfalls Tabelle oder Textskizze. Keine Übermittlung oder erfolgreiche Einreichung behaupten, die nicht stattgefunden hat.

<!-- BEGIN werkstatt-visualisierung -->
## 7. Verständlich arbeiten und sichtbar prüfen

Bei komplexem Material zuerst verständlich machen, wer beteiligt ist, was geschehen ist und welche Entscheidung ansteht. Vorhandene Unterlagen auswerten und Fachbegriffe beim ersten Gebrauch kurz erklären. Danach das erste nutzbare Arbeitsergebnis liefern. Die Fachansicht und ihre Beispiele an den konkreten Auftrag, Empfänger und Bearbeitungsstand anpassen; daraus entsteht kein Auftrag für ein zusätzliches Verfahren oder andere Unterlagen. Eine passende Visualisierung direkt erstellen, wenn sie Vergleich, Ablauf, Mengen oder Zusammenhänge verständlicher macht; nicht erst allgemein anbieten oder eine Auswahl aus Werkzeugnamen verlangen. Einfache Einzelfragen knapp beantworten. Anfangs eine zentrale Ansicht mit verständlichen Beschriftungen und kurzem Befund zeigen; weitere Details nach Bedarf öffnen.

**Leitfrage für Insolvenzanfechtung aus Verwalter- und Empfängersicht:** Welche belegten Beträge tragen das Ergebnis und welche Annahme verändert es?

**Erste Ansicht:** Zeige Ausgangswerte, Zu- und Abgänge oder Forderungsbestand in einer nachvollziehbaren Tabelle und bei Zeitreihen als Verlauf. Trenne Stichtag, Zeitraum, Fälligkeit und tatsächlichen Geldfluss.

**Sinnvolle Interaktion:** Erlaube bei geeigneter Oberfläche einen Stichtags- oder Szenariowechsel. Nur belegte oder ausdrücklich angenommene Positionen lassen sich ein- oder ausblenden; Rechenergebnis und Begründung zeigen gemeinsam die Differenz zum Ausgangsstand.

**Datengrundlage:** Betrag, Währung, Vorzeichen, Datum, Zuordnungsgrund, Berechnungsregel und Originalfundstelle. Je tragendem Wert die Datei und Seite, Tabellenblatt/Zelle, Zeile oder Belegkennung mitführen.

**Weiter zum Ergebnis:** nachrechenbare Berechnung mit begründetem Befund und dem bestellten Bericht oder Anspruchsschreiben. Die Ansicht ist ein Arbeitsmittel auf diesem Weg.

Nutze eine tatsächlich verfügbare Visualisierung oder Fachanwendung; bei geeigneter interaktiver Oberfläche direkt ein Applet erstellen oder die vorhandene Anwendung verwenden. Ohne diese Fähigkeit eine verständliche Tabelle oder Skizze liefern. Belege und Annahmen trennen, fehlende Werte nicht als null behandeln. Auswahl und neue Angaben im selben Arbeitsprodukt fortschreiben und dieses ausformulieren. Keine Datenübermittlung, Speicherung oder erfolgreiche Funktion behaupten, die nicht stattfand.

Bei interaktiver Arbeit die [lokalen Regeln für Oberfläche, Belege und Fortsetzung](../../references/arbeitsoberflaeche-und-visualisierung.md) lesen.
<!-- END werkstatt-visualisierung -->
