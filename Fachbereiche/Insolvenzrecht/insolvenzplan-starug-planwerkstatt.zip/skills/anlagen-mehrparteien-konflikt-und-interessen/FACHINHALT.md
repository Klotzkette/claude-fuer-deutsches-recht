---
name: anlagen-mehrparteien-konflikt-und-interessen
description: "Für Anlagen: Mehrparteienkonflikt und Interessenmatrix: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Anlagen: Mehrparteienkonflikt und Interessenmatrix

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: StaRUG §§ 1, 29, 31, 39, 49-55, 84, 102, IDW S 6, IDW S 11, InsO § 270; StaRUG — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Anlagen: Mehrparteienkonflikt und Interessenmatrix` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Spezialwissen: Anlagen: Mehrparteienkonflikt und Interessenmatrix
- **Normen-/Quellenanker:** StaRUG.

## Fallweichen
Wenn Unterlagen vorhanden sind, arbeite zuerst aus den Unterlagen. Stelle nur Rückfragen, die die nächste Weiche verändern:

1. Welche Rolle hat die fragende Person und wer ist Gegenüber?
2. Welches konkrete Ziel soll erreicht oder verhindert werden?
3. Welche Frist, Zustellung, Schwelle, Zahlung, Sanktion oder Verfahrensstufe ist kritisch?
4. Welche Dokumente, Registerauszüge, Bescheide, Verträge, Tabellen, Screenshots oder Nachrichten belegen den Punkt?
5. Welcher Output wird gebraucht: Memo, Checkliste, Tabelle, Entwurf, Schriftsatzbaustein, Mandantenbrief oder Entscheidungsvorlage?

## Arbeitsworkflow
1. **Fallbild bilden:** Sachverhalt, Rollen, Zeitachse und Dokumente in eine kurze Matrix bringen.
2. **Rechtsrahmen setzen:** Normen, Zuständigkeiten, Fristen, Formfragen und Verfahrensstand zum Themenfeld **Anlagen** prüfen.
3. **Prüfpunkte abarbeiten:** Tatbestandsmerkmale, Beweisfragen, typische Fehler, Gegenargumente und Ermessens- oder Wertungsfragen trennen.
4. **Risiko bewerten:** Grün/Gelb/Rot mit Begründung, Annahmen, fehlenden Belegen und möglichen Alternativwegen ausgeben.
5. **Anschluss bauen:** Passende weitere Skills desselben Plugins vorschlagen, wenn eine Vertiefung, ein Schreiben, eine Tabelle, ein Fristenblatt oder eine Verhandlungsstrategie sinnvoll ist.

## Plan-Anlagen § 229 InsO und Interessenmatrix
- **§ 229 InsO Pflichtanlagen:** Vermögensübersicht, Ergebnis- und Finanzplan für Planlaufzeit (idR 3–5 Jahre), Vergleichsrechnung Plan vs. Liquidation.
- **§ 230 InsO weitere Anlagen:** Erklärungen der Planbetroffenen (z. B. neue Kreditzusagen, Forderungsverzichte, Patronatserklärungen) — Anlagen wirken als Vertragsverpflichtung; ohne Anlage kein Plan-Vollzug.
- **§ 7 StaRUG entspricht:** Vergleichende Aufstellung, Finanzplan, Sanierungskonzept als Anlagen.
- **Interessenmatrix (Gläubigergruppen):**
 - Banken: Sicherheitenverwertung, Realkreditverteidigung, Kovenanten;
 - Lieferanten: Lieferantenkredit, Eigentumsvorbehalt, Geschäftsbeziehung;
 - Arbeitnehmer: Arbeitsplätze, Lohnzahlung, Insolvenzgeld;
 - Steuerfiskus/SV: Sondergläubiger mit Insolvenzaufrechnungsverbot § 96 InsO;
 - Gesellschafter: Anteilseignerrechte, Debt-Equity-Swap, Squeeze-out.
- **Konflikte typisch:** Gesellschafter wollen Anteile behalten, Banken wollen Sicherheiten realisieren, Lieferanten wollen Geschäft fortsetzen, Arbeitnehmer wollen Beschäftigung sichern.
- **Trade-off:** Plan-Anlagen mit harten Verpflichtungen geben Gläubigern Sicherheit, binden aber Schuldnerin operativ; weiche Bekundungen sind flexibel, aber im Streit wertlos.
- **Praxis:** Anlagen-Reihenfolge: Sanierungskonzept, Plan-Bilanz/-GuV/-Liquidität, Vergleichsrechnung je Gruppe, Zusagen Dritter, Drittsicherheiten — die Vergleichsrechnung ist meist die Streitkernzelle.
