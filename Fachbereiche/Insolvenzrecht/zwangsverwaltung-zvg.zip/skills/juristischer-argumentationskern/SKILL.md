---
name: juristischer-argumentationskern
description: "Schaltet sich ein, wenn in Zwangsverwaltung Zvg ein juristisches Arbeitsprodukt tragfähig begründet werden muss; verbindet konkrete Aktenfundstellen mit Tatbestandsmerkmal, Beweislast, stärkster Gegenposition und Rechtsfolge."
---

# Juristischer Argumentationskern - Zwangsverwaltung Zvg

## 1. Direktstart

Ordne Anordnungsbeschluss, Grundstück, Mietverträge und Zahlungseingänge. Begründe den beauftragten Bericht, die Abrechnung oder den Antrag mit den konkreten Verwaltungsbelegen.

1.1. Lies zuerst die auftragsrelevanten Unterlagen und halte erkennbare Fristen fest. Prüfe Namen, Fassungen und Anlagen, soweit sie für das Ergebnis eine Rolle spielen.
1.2. Beginne bei klarem Auftrag mit dem verlangten Arbeitsprodukt. Frage nur nach Tatsachen, die Anspruch, Einwendung, Antrag, Frist oder Beweisführung ändern. Arbeite an den übrigen Teilen weiter und übernimm die Antwort in denselben Entwurf.
1.3. Trenne Aktenfund, gesicherte Rechtsquelle, vertretbare Schlussfolgerung und offene Prüfung sichtbar. Erfinde weder Tatsache noch Fundstelle noch Aktenzeichen.

## 2. Die tragende These

Formuliere das Ergebnis für Zwangsverwaltung Zvg in einem Satz und nenne darin Parteirolle, begehrte oder abzuwehrende Rechtsfolge und den entscheidenden Prüfpunkt. Typische Rechtsfolgen in diesem Arbeitsfeld sind: Titelcheck, Vollstreckungsauftrag, PfÜB-Entwurf, Forderungsaufstellung, Erinnerung oder Schutzantrag.

Die These ist nur belastbar, wenn die folgende Kette ohne Sprung funktioniert:

2.1. Rechtsfolge: Was soll das fertige Arbeitsprodukt rechtlich oder praktisch bewirken?
2.2. Norm: Welche Vorschrift oder gesicherte Rechtsregel trägt genau diese Folge?
2.3. Tatbestandsmerkmal: Welches einzelne Merkmal ist dafür entscheidend?
2.4. Tatsache: Welche konkrete, zeitlich und personell bestimmte Aktenangabe erfüllt oder widerlegt das Merkmal?
2.5. Beleg: Welche Fundstelle, Urkunde, Aussage, Messung oder Berechnung trägt die Tatsache?
2.6. Beweislast und Beweismaß: Wer verliert den Punkt, wenn die Tatsache offenbleibt?
2.7. Gegenposition: Was ist der stärkste ernsthafte Angriff auf Norm, Tatsache, Beleg oder Rechtsfolge?
2.8. Antwort: Welcher Gegenbeleg, welche Auslegung oder welche Beweislastregel hält diesem Angriff stand?

## 3. Materienspezifische Tatbestandsarbeit

| Prüfpunkt | Konkrete Arbeitsfrage |
| --- | --- |
| Titelcheck | vollstreckbarer Inhalt, Klausel, Zustellung, Rechtskraft, Bedingung, Sicherheitsleistung und Forderungsstand prüfen |
| Vollstreckungsweg | bewegliche Sache, Forderung, Konto, Arbeitseinkommen, Herausgabe, Räumung, Grundstück oder Auskunft bestimmen |
| Antrag | Gerichtsvollzieherauftrag, Pfändungs- und Überweisungsbeschluss, Drittauskunft, Verhaftungsauftrag oder Vollstreckungsschutz passgenau ausfüllen |
| Schuldnerschutz und Rang | Pfändungsgrenzen, P-Konto, Vorpfändung, Priorität, Insolvenz, Drittwiderspruch und Erinnerung kontrollieren |
| Arbeitsprodukt | Vollstreckungsauftrag, PfÜB-Entwurf, Forderungsaufstellung, Schuldneranschreiben, Erinnerung oder Schutzantrag erstellen |

### 3.1. Verknüpfung mit den tragenden Fachskills

Öffne den zur Streitfrage passenden Arbeitsweg oder Fachtext. Übernimm dessen Norm, Aktenfund, Beweislast, Gegenposition und Rechtsfolge in das bestellte Ergebnis.

3.1.1. [Beschlagnahme: Fristen, Form, Zuständigkeit und Rechtsweg](../beschlagnahme-fristen-form-und-zustaendigkeit/FACHINHALT.md)
3.1.2. [Räumung, Kündigung und Besitzkonflikte](../raeumung-kuendigung/FACHINHALT.md)
3.1.3. [Recherche: Zahlen, Schwellenwerte und Berechnung](../recherche-zahlen-schwellen-und-berechnung/FACHINHALT.md)
3.1.4. [Verteilung: Verhandlung, Vergleich und Eskalation](../verteilung-zwangsverwaltung-aktenanlage/FACHINHALT.md)

Ordne für jeden Tabellenpunkt eine konkrete Tatsache, Fundstelle, Beweislast, Gegenposition und Rechtsfolge zu. Ein bloßes Ergebniswort oder die Wiedergabe einer Norm ist keine Subsumtion.

## 4. Normenanker

4.1. ZPO Paragraf 704 bis Paragraf 750: Titel, Klausel, Zustellung und Vollstreckungsvoraussetzungen.
4.2. ZPO Paragraf 753 bis Paragraf 802l: Gerichtsvollzieherauftrag, Vermögensauskunft, Haftbefehl und Drittauskünfte.
4.3. ZPO Paragraf 808 ff.: Pfändung körperlicher Sachen.
4.4. ZPO Paragraf 829 bis Paragraf 835: Pfändung und Überweisung von Forderungen.
4.5. ZPO Paragraf 850 ff.: Pfändungsschutz bei Arbeitseinkommen und Konten.
4.6. ZPO Paragraf 765a: Vollstreckungsschutz bei sittenwidriger Härte.

Normen werden nicht als Dekoration gesammelt. Hinter jedem Anker steht das konkrete Merkmal, das er im Fall steuert, und die Rechtsfolge, die daraus folgen kann.

## 5. Rechtsprechung und Quellenstatus

5.1. Suche Rechtsprechung erst anhand der präzisen Streitfrage. Verwende eine Entscheidung nur nach Prüfung von Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage in einer belastbaren Quelle.

5.2. Ordne jede Entscheidung als tragenden Rechtssatz, Abgrenzungsfall, bloße Analogie oder nicht übertragbar ein. Eine Entscheidung aus anderem Verfahrens- oder Tatsachenkontext wird nicht nur wegen eines ähnlichen Stichworts zitiert.
5.3. Gib den Quellenstatus an: amtlicher Normtext, amtliche Entscheidung, frei zugängliche Gerichtsveröffentlichung, Aktenfund oder noch offene Recherche. Unsichere Aktenzeichen werden weggelassen.

## 6. Beweislast und Gegenangriff

Ausgangspunkt für dieses Plugin: Gläubiger für Titel, Klausel, Zustellung und Forderungsstand; Schuldner oder Dritter für Schutz, Erfüllung, Insolvenz und Gegenrechte.

6.1. Baue zuerst die stärkste vertretbare Gegenposition auf, nicht eine leicht widerlegbare Ersatzposition.
6.2. Prüfe getrennt, ob der Angriff die Anspruchsgrundlage, ein einzelnes Merkmal, die Schlüssigkeit, die Erheblichkeit, den Beweiswert, die Beweislast, die Rechtsfolge oder nur die Höhe betrifft.
6.3. Bezeichne bei Urkunden Seite und Passage, bei Zeugen das konkrete Beweisthema, bei Berechnungen Eingabewert und Quelle, bei Gutachten Anknüpfungstatsache und offene Fachfrage.
6.4. Wenn der Kernbeleg fehlt, formuliere eine gezielte Nachforderung statt die Lücke mit einer Annahme zu schließen.

## 7. Prüffolge

7.1. Ist der Titel inhaltlich vollstreckungsfähig und liegt die richtige Klausel vor.
7.2. Ist die Zustellung der vollstreckbaren Ausfertigung nachweisbar.
7.3. Welcher Vollstreckungsgegenstand verspricht realistisch Befriedigung.
7.4. Welche Pfändungsgrenze, Vorpfändung oder Insolvenzlage blockiert den Zugriff.
7.5. Welcher Antrag muss an welches Organ mit welchen Anlagen.

## 8. Juristisches Schreiben

8.1. Stelle das Ergebnis oder den Antrag an den Anfang. Der Leser muss nach dem ersten Absatz wissen, welche Position vertreten wird und warum.
8.2. Verwende pro tragendem Punkt die Reihenfolge Kernsatz, Rechtsregel, konkrete Tatsache mit Fundstelle, Subsumtion, Gegenargument, Antwort und Rechtsfolge.
8.3. Schreibe Tatsachen konkret mit Datum, Person, Handlung, Betrag und Dokument. Vermeide Leerformeln wie offensichtlich, zweifellos oder nach ständiger Rechtsprechung ohne Beleg.
8.4. Trenne Hauptargument, Hilfsargument und bloßen Recherchepunkt. Die stärkste Linie steht zuerst; Varianten werden nach Erfolgsaussicht, Beweisrisiko und praktischem Aufwand geordnet.
8.5. Typische fertige Ausgabe für dieses Plugin: Titelcheck: Titelart, Datum, Tenor, Klausel, Zustellung, Betrag, Zinsen, Kosten, Bedingung und Anlage; Vollstreckungsauftrag: Forderung, Vollstreckungsart, bekannte Vermögenswerte, Anlagen, Auskunftsstufen und Zustellungswunsch.

## 9. Ausgabemodi

| Bedarf | Sofortausgabe |
| --- | --- |
| Schnell entscheiden | Kernsatz, stärkster Anker, schwächster Punkt, Gegenposition, Empfehlung und nächster Schritt |
| Vertieft prüfen | Tatbestandsmatrix mit Norm, Tatsache, Fundstelle, Beweislast, Gegenargument, Antwort und Rechtsfolge |
| Versenden | Empfängergerechter Entwurf mit Antrag oder Ziel, Tatsachenvortrag, Rechtsausführung, Beweisangeboten und Anlagenbezug |
| Verhandeln | Hauptposition, belastbare Untergrenze, gegnerischer Hebel, Zugeständnisfolge und formulierter Vorschlag |
| Entscheiden | Optionen mit Rechtsgrundlage, Tatsachenbasis, Risiko, Aufwand, Termin und dokumentierter Empfehlung |

## 10. Fachliche Formulierungsansätze

10.1. Titelcheck: Titelart, Datum, Tenor, Klausel, Zustellung, Betrag, Zinsen, Kosten, Bedingung und Anlage.
10.2. Vollstreckungsauftrag: Forderung, Vollstreckungsart, bekannte Vermögenswerte, Anlagen, Auskunftsstufen und Zustellungswunsch.
10.3. PfÜB-Matrix: Drittschuldner, Forderungsart, Betrag, Nebenforderungen, Rang, Pfändungsschutz und Zustellung.

## 11. Qualitätskontrolle

11.1. Deckt jeder Antrag oder Ergebnissatz eine benannte Rechtsfolge ab?
11.2. Ist jedes tragende Tatbestandsmerkmal mit konkreter Tatsache und Fundstelle verknüpft?
11.3. Ist die Beweislast dort benannt, wo eine Tatsache streitig oder offen ist?
11.4. Wurde die stärkste Gegenposition fair aufgebaut und beantwortet?
11.5. Passt jede Entscheidung in Tatsachen- und Verfahrenskontext und ist ihr Quellenstatus sichtbar?
11.6. Sind Frist, Form, Zuständigkeit, Betrag, Anlagen und nächster Arbeitsschritt widerspruchsfrei?
11.7. Ist das Ergebnis unmittelbar als Titelcheck, Vollstreckungsauftrag, PfÜB-Entwurf, Forderungsaufstellung, Erinnerung oder Schutzantrag verwendbar?

<!-- BEGIN werkstatt-visualisierung -->
## 12. Verständlich arbeiten und sichtbar prüfen

Bei komplexem Material zuerst verständlich machen, wer beteiligt ist, was geschehen ist und welche Entscheidung ansteht. Vorhandene Unterlagen auswerten und Fachbegriffe beim ersten Gebrauch kurz erklären. Danach das erste nutzbare Arbeitsergebnis liefern. Die Fachansicht und ihre Beispiele an den konkreten Auftrag, Empfänger und Bearbeitungsstand anpassen; daraus entsteht kein Auftrag für ein zusätzliches Verfahren oder andere Unterlagen. Eine passende Visualisierung direkt erstellen, wenn sie Vergleich, Ablauf, Mengen oder Zusammenhänge verständlicher macht; nicht erst allgemein anbieten oder eine Auswahl aus Werkzeugnamen verlangen. Einfache Einzelfragen knapp beantworten. Anfangs eine zentrale Ansicht mit verständlichen Beschriftungen und kurzem Befund zeigen; weitere Details nach Bedarf öffnen.

**Leitfrage für Zwangsverwaltung und Objektbewirtschaftung nach dem ZVG:** Passen tatsächliche Rechtslage, Urkunden und Register- oder Objektstand zum selben Zeitpunkt zusammen?

**Erste Ansicht:** Zeige Soll- und Ist-Stand von Beteiligten, Rechten, Vertretung und Eintragungen nebeneinander. Verbinde jede Abweichung mit der maßgeblichen Urkunde und dem notwendigen Vollzugsschritt.

**Sinnvolle Interaktion:** Eine Auswahl auf Person, Recht, Objekt oder Registerstand zeigt die zugehörige Nachweiskette. Änderungen am Schaubild sind Entwurfsszenarien, keine vorgenommenen Registereintragungen.

**Datengrundlage:** Objekt oder Rechtsträger, Registerart, Abrufstand, Rechtsposition, Vertretungsnachweis, Urkundenfundstelle und Vollzugsvoraussetzung. Je tragendem Wert die Datei und Seite, Tabellenblatt/Zelle, Zeile oder Belegkennung mitführen.

**Weiter zum Ergebnis:** begründeter Vollzugsvermerk und die beauftragte Anmeldung, Liste, Vertragsfassung oder Rückfrage. Die Ansicht ist ein Arbeitsmittel auf diesem Weg.

Nutze eine tatsächlich verfügbare Visualisierung oder Fachanwendung; bei geeigneter interaktiver Oberfläche direkt ein Applet erstellen oder die vorhandene Anwendung verwenden. Ohne diese Fähigkeit eine verständliche Tabelle oder Skizze liefern. Belege und Annahmen trennen, fehlende Werte nicht als null behandeln. Auswahl und neue Angaben im selben Arbeitsprodukt fortschreiben und dieses ausformulieren. Keine Datenübermittlung, Speicherung oder erfolgreiche Funktion behaupten, die nicht stattfand.

Bei interaktiver Arbeit die [lokalen Regeln für Oberfläche, Belege und Fortsetzung](../../references/arbeitsoberflaeche-und-visualisierung.md) lesen.
<!-- END werkstatt-visualisierung -->
