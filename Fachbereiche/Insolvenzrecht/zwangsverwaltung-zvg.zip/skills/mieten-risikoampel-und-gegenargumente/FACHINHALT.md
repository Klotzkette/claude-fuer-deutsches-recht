---
name: mieten-risikoampel-und-gegenargumente
description: "Für Mieten: Risikoampel, Gegenargumente und Verteidigungslinien: prüft Ergebnis, Beweislast und Gegenposition; Ergebnis: Fristen- und Risikoampel."
---

# Mieten: Risikoampel, Gegenargumente und Verteidigungslinien

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: ZVG § 149 Beschlagnahme mit Anordnung, Rechnungslegung 12 Monate, Verteilungstermin nach Plan, sofortige Beschwerde 2 Wochen.
- Tragende Normen verifizieren: ZVG §§ 146-161 (Zwangsverwaltung), 1-150 (Zwangsversteigerung), §§ 869-882 ZPO, GVKostG, RPflG, GBO §§ 19, 20, 53 — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Gläubiger, Schuldner, Zwangsverwalter, Vollstreckungsgericht (AG), Rechtspfleger, Grundbuchamt, Mieter, Hausverwaltung.
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Zwangsverwaltungsantrag, Anordnungsbeschluss, Verwalterbestallung, Verwaltervergütungsfestsetzung, Rechnungslegung, Verteilungsplan, Aufhebungsbeschluss — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Spezialwissen: Mieten: Risikoampel, Gegenargumente und Verteidigungslinien
- **Normen-/Quellenanker:** ZVG.

## Fallweichen
Wenn Unterlagen vorhanden sind, arbeite zuerst aus den Unterlagen. Stelle nur Rückfragen, die die nächste Weiche verändern:

1. Welche Rolle hat die fragende Person und wer ist Gegenüber?
2. Welches konkrete Ziel soll erreicht oder verhindert werden?
3. Welche Frist, Zustellung, Schwelle, Zahlung, Sanktion oder Verfahrensstufe ist kritisch?
4. Welche Dokumente, Registerauszüge, Bescheide, Verträge, Tabellen, Screenshots oder Nachrichten belegen den Punkt?
5. Welcher Output wird gebraucht: Memo, Checkliste, Tabelle, Entwurf, Schriftsatzbaustein, Mandantenbrief oder Entscheidungsvorlage?

## Arbeitsworkflow
1. **Fallbild bilden:** Sachverhalt, Rollen, Zeitachse und Dokumente in eine kurze Matrix bringen.
2. **Rechtsrahmen setzen:** Normen, Zuständigkeiten, Fristen, Formfragen und Verfahrensstand zum Themenfeld **Mieten** prüfen.
3. **Prüfpunkte abarbeiten:** Tatbestandsmerkmale, Beweisfragen, typische Fehler, Gegenargumente und Ermessens- oder Wertungsfragen trennen.
4. **Risiko bewerten:** Grün/Gelb/Rot mit Begründung, Annahmen, fehlenden Belegen und möglichen Alternativwegen ausgeben.
5. **Anschluss bauen:** Passende weitere Skills desselben Plugins vorschlagen, wenn eine Vertiefung, ein Schreiben, eine Tabelle, ein Fristenblatt oder eine Verhandlungsstrategie sinnvoll ist.

## Materielle Weichen Mieten in der Zwangsverwaltung
- **Erfassung Mieten (§ 148 Abs. 1 ZVG):** Mieten und sonstige Nutzungen sind durch die Beschlagnahme erfasst. Der Zwangsverwalter zieht die Mietzinsen ein - der Schuldner hat keine Verfügungsbefugnis mehr.
- **Mitteilungspflicht an Mieter (§ 152 ZVG):** Zwangsverwalter muss Mieter informieren - ab Mitteilung erfolgt Zahlung schuldbefreiend nur an den Verwalter. Bei Zahlung an den Schuldner trotz Mitteilung: Mieter muss erneut an Verwalter zahlen.
- **Bestand der Mietverträge:** Mietverhältnisse bleiben bestehen (§ 152 Abs. 1 ZVG); Zwangsverwalter tritt in die Position des Vermieters ein, kann aber den Vertrag nicht ohne Weiteres ändern.
- **Mieterhöhung und Mietminderung:** Zwangsverwalter kann zur ordnungsgemäßen Bewirtschaftung Mieterhöhung gem. § 558 BGB betreiben, soweit Voraussetzungen erfüllt. Mietminderung des Mieters wirkt fort - Verwalter trägt die Last der Mängelbeseitigung im Rahmen der Bewirtschaftung.
- **Kündigung durch Verwalter:** Bei Pflichtverletzungen des Mieters (Zahlungsverzug) kann Verwalter kündigen (§ 543 BGB). Vorprozessuale Mahnung sinnvoll; Räumungsklage durch Zwangsverwalter im eigenen Namen (Prozessstandschaft, § 152 Abs. 1 ZVG).
- **Vorausverfügungen des Schuldners (§ 1124 BGB):** Abtretungen von Mietzinsen oder Vorauszahlungsvereinbarungen vor Beschlagnahme bleiben in den Schranken des § 1124 BGB wirksam, nach Beschlagnahme unwirksam gegenüber den Gläubigern.
- **Treuhandkonto (§ 156 Abs. 1 ZVG):** Vereinnahmte Mieten werden auf separates Treuhandkonto eingezahlt; Verwalter trennt Vermögen Schuldner und Verwaltungsvermögen.
- **Verteilung Mieten (§ 155 ZVG i.V.m. § 156 ZVG):** Mieten dienen zuerst den Bewirtschaftungskosten (laufende Kosten, Steuern, Verwaltervergütung), dann den dinglichen Gläubigern nach Rang.
- **Wohnungseigentum:** Bei WEG-Objekten muss Verwalter Hausgeld an die GdWE laufend zahlen (§ 16 Abs. 2 WEG i.V.m. § 152 Abs. 2 ZVG) - sonst Beitritt der GdWE zum Versteigerungsverfahren möglich.
