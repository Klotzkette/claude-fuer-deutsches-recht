---
name: mieteinzug-rueckstaende
description: "Für Mieteinzug und Rückstände: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Mieteinzug und Rückstände

## Arbeitsbereich

Mieteinzug und Rückstandsbehandlung in der Zwangsverwaltung. Anwendungsfall Mieter zahlt nicht und Zwangsverwalter muss Rückstande einziehen oder Klage einleiten. Normen § 152 ZVG Mieteinzugspflicht § 543 BGB fristlose Kündigung § 286 BGB Verzug. Prüfraster Soll-Ist-Abgleich Mahnung Ratenvereinbarung Klage Zahlungseingang Kontoabgleich Dokumentation. Output Rückstandsprotokoll mit Mahnhistorie Klageprüfung und Einzugsnachweis für Rechnungslegung. Abgrenzung zu zvg-miet-und-pachtverwaltung und zvg-räumung-kündigung. Arbeite entlang dieser konkreten Prüfungslinie und trenne Rolle, Frist, Zuständigkeit, Beweislast und gewünschten Output.

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: ZVG § 149 Beschlagnahme mit Anordnung, Rechnungslegung 12 Monate, Verteilungstermin nach Plan, sofortige Beschwerde 2 Wochen.
- Tragende Normen verifizieren: ZVG §§ 146-161 (Zwangsverwaltung), 1-150 (Zwangsversteigerung), §§ 869-882 ZPO, GVKostG, RPflG, GBO §§ 19, 20, 53 — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Gläubiger, Schuldner, Zwangsverwalter, Vollstreckungsgericht (AG), Rechtspfleger, Grundbuchamt, Mieter, Hausverwaltung.
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Zwangsverwaltungsantrag, Anordnungsbeschluss, Verwalterbestallung, Verwaltervergütungsfestsetzung, Rechnungslegung, Verteilungsplan, Aufhebungsbeschluss — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Startet bei

- Mieteinnahmen fehlen
- Rückstände vor oder nach Beschlagnahme bestehen
- Zahlungen nicht zugeordnet werden können

## Eingaben

- Rent Roll, Kontoauszüge, Mieterkonten
- Rückstandsliste, Mahnungen, Einwendungen
- Mietverträge und Betriebskostenstände

## Workflow

1. **Soll-Ist-Abgleich** - Sollmieten je Einheit mit Zahlungseingängen und Altrückständen matchen.
2. **Rückstände trennen** - beschlagnahmte Nutzungen, Altansprüche und streitige Posten unterscheiden.
3. **Mahnen** - freundliche Zahlungserinnerung, Mahnung, Ratenplan oder Klagevorschlag erstellen.
4. **Gericht berichten** - wesentliche Rückstände und Einziehungsmaßnahmen dokumentieren.

## Ausgabe

- Rückstandsliste
- Mahn- und Klagepaket
- Zahlungsabgleich

<!-- BEGIN ausformulierungspflicht (autogen) -->
> **Ausformulierungspflicht und Formatstandard.** Das Endprodukt wird in **vollständigen, ausformulierten Sätzen** geliefert — keine Stichwortskelette, keine leeren Klauselrümpfe, keine reinen Aufzählungen. Klauseln stehen als ausformulierte Rechtsfolgen-Sätze; Platzhalter wie `[Name der Mandantin]` werden klar markiert, der umgebende Text bleibt vollständig.
>
> **Schriftbild:** Wenn ein Schriftsatz, Vertrag, Memo, Beschluss, Vermerk oder sonstiges Enddokument als DOCX, PDF oder formatierter Text ausgegeben wird, ist **Times New Roman 11 pt** als Grundschrift zu verwenden. Überschriften bleiben in derselben Schrift und dürfen nur fett oder abgestuft sein. Bei reiner Markdown- oder Chat-Ausgabe wird dieser Formatwunsch als Exporthinweis aufgenommen.
>
> **Nummerierung:** Gliederung ausschließlich dezimal (`1`, `1.1`, `1.1.1` und so weiter). Keine römischen Ziffern, keine Buchstaben- oder Mischgliederung.
<!-- END ausformulierungspflicht (autogen) -->

## Qualitätsgates

- jede Zahlung einer Einheit zugeordnet
- Alt- und Neurückstände getrennt
- Einwendungen protokolliert

## Rote Schwellen

- Dauerleerstand
- Mietminderung ohne Prüfung
- Kontoauszug fehlt

## Interne Vorlagen

- assets/templates/mieteinzug-rueckstaende.md
- assets/templates/konto-kassenbuch.md

## Amtliche Erstquellen

- § 8 ZwVwV
- § 13 ZwVwV

## Paragrafenkette Mieteinzug/Rückstände

§ 153 ZVG (Einziehung Nutzungen) → § 535 Abs. 2 BGB (Mietzinszahlungspflicht) → § 543 Abs. 2 Nr. 3 BGB (Kündigung wegen Zahlungsverzug) → § 286 BGB (Verzug) → § 288 BGB (Verzugszinsen) → §§ 12-13 ZwVwV (Buchführung Rückstände)

## Triage Mieteinzug/Rückstände

1. Rückstand vor oder nach Beschlagnahme entstanden? (Unterschiedliche Behandlung)
2. Hat der Mieter Einwendungen gegen die Miethöhe erhoben? (Minderung § 536 BGB prüfen)
3. Liegen mehr als zwei Monatsmieten Rückstand vor? (Außerordentliche Kündigung § 543 BGB prüfen)
4. Ist Klage wirtschaftlich sinnvoll? (Insolvenzrisiko des Mieters, Vollstreckbarkeit prüfen)

## Output-Template Mahn-/Kündigungsschreiben ZVG

**Adressat:** rückständiger Mieter — Tonfall scharf-fristsetzend

```
[ZWANGSVERWALTER]
EINSCHREIBEN MIT RÜCKSCHEIN

An [MIETER NAME]
[ADRESSE]

Zwangsverwaltung [ADRESSE], AZ [X]

Mahnung und Fristsetzung / Außerordentliche Kündigung

Sehr geehrte/r Herr/Frau [NAME],

folgende Mietrückstände sind aufgelaufen:
Monat | Betrag | Status
[TABELLE]
Gesamtrückstand: [BETRAG] EUR

Ich fordere Sie auf, den Rückstand bis zum [DATUM] zu zahlen.
[Falls Kündigung: Gleichzeitig kündige ich das Mietverhältnis fristlos nach
§ 543 Abs. 2 Nr. 3 BGB wegen Zahlungsverzugs von mehr als zwei Monatsmieten.
Bitte übergeben Sie die Wohnung spätestens zum [DATUM] geräumt.]

[UNTERSCHRIFT ZWANGSVERWALTER]
```

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
