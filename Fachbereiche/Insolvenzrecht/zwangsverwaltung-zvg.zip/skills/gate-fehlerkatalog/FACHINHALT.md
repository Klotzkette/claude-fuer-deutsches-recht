---
name: gate-fehlerkatalog
description: "Für Gate Fehlerkatalog: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: ZVG-Zwangsverwaltung - Verwalter-Cockpit."
---

# Gate Fehlerkatalog

## Zweck

Dieser Fehlerkatalog prüft Arbeitsergebnisse für **Zwangsverwaltung ZVG** vor Abgabe, Versand oder Mandantenfreigabe gegen die im Sachgebiet typischen Fehlerquellen — jeweils mit Symptom, Diagnose und Heilung.

## Fehlerkatalog

### 1. Frist falsch berechnet oder übersehen (Beschwerde gegen Anordnung)

- **Symptom:** Frist falsch berechnet oder übersehen (Beschwerde gegen Anordnung)
- **Diagnose:** Fristbeginn ab falschem Ereignis gerechnet (Zugang vs. Datum des Schreibens) oder Vorfrist im Kanzleisystem fehlt
- **Heilung:** Fristenkette aus dem Originaldokument rekonstruieren, Zugangsnachweis sichern, Vorfrist mit zwei Wochen setzen

### 2. Parallelfrist vergessen (Rechnungslegung)

- **Symptom:** Parallelfrist vergessen (Rechnungslegung)
- **Diagnose:** Zweite, unabhängig laufende Frist wird von der ersten verdeckt
- **Heilung:** Alle Fristen des Vorgangs tabellarisch erfassen und einzeln verfügen

### 3. Falsche Zuständigkeit adressiert (richtig: Amtsgericht Vollstreckungsgericht)

- **Symptom:** Falsche Zuständigkeit adressiert (richtig: Amtsgericht Vollstreckungsgericht)
- **Diagnose:** Schriftsatz oder Antrag an unzuständige Stelle — Fristwahrung gefährdet
- **Heilung:** Zuständigkeit vor Versand gegen Gesetz und aktuelle Organisationsverfügung prüfen; bei Zweifel fristwahrend bei beiden Stellen einreichen

### 4. Beweismittel nicht gesichert (Mieteinnahmen)

- **Symptom:** Beweismittel nicht gesichert (Mieteinnahmen)
- **Diagnose:** Tatsachenbehauptung im Schriftsatz ohne verfügbares Beweismittel
- **Heilung:** Pro Behauptung Beweismittel und Fundstelle notieren; fehlende Belege als Lücke ausweisen und beschaffen

### 5. Schlüsseldokument fehlt oder veraltet (Anordnungsbeschluss)

- **Symptom:** Schlüsseldokument fehlt oder veraltet (Anordnungsbeschluss)
- **Diagnose:** Arbeit mit Entwurfs- oder Altfassung statt der maßgeblichen Version
- **Heilung:** Versionsstand und Datum jedes Dokuments prüfen; maßgebliche Fassung in der Akte markieren

### 6. Normzitat ohne Fassungsprüfung (ZVG §§ 146 ff.)

- **Symptom:** Normzitat ohne Fassungsprüfung (ZVG §§ 146 ff.)
- **Diagnose:** Zitierte Norm wurde geändert, verschoben oder aufgehoben
- **Heilung:** Vor Abgabe jeden Paragraphen gegen gesetze-im-internet.de prüfen; Übergangsvorschriften beachten

### 7. Rechtsprechung aus Modellwissen zitiert

- **Symptom:** Rechtsprechung aus Modellwissen zitiert
- **Diagnose:** Aktenzeichen oder Fundstelle nicht live verifiziert — Risiko halluzinierter Zitate
- **Heilung:** Jede Entscheidung mit Gericht, Datum, Az und frei prüfbarer Quelle gegenchecken; sonst als Prüfpunkt markieren

### 8. Mandantengeheimnis bei Tool-Einsatz verletzt

- **Symptom:** Mandantengeheimnis bei Tool-Einsatz verletzt
- **Diagnose:** Klartext-Mandantendaten in Werkzeug ohne Auftragsverarbeitungsvertrag
- **Heilung:** Vor Upload anonymisieren oder AVV-gedeckte Umgebung nutzen (§ 43a Abs. 2 BRAO, § 203 StGB)

## Ausgabe

Roter/gelber/grüner Befund je Fehlerachse; jeder rote Punkt mit konkreter Korrektur und verbleibendem Restrisiko. Quellenhygiene nach `references/quellenhygiene.md`.
