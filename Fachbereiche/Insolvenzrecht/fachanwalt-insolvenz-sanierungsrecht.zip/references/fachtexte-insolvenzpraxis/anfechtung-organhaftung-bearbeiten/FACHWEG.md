# Anfechtung und Organhaftung

## 1. Zweck und Anwendungsfall

Zahlungsströme, Anfechtungstatbestände, Gegenargumente und Organhaftung bis zur Anspruchsdurchsetzung prüfen.

Bearbeite den konkreten Auftrag bis zum nutzbaren Arbeitsprodukt. Übernimm bereits vorliegende Angaben, benenne entscheidungserhebliche Lücken und arbeite an den davon unabhängigen Teilen weiter.

## 2. Eingaben

- Auftrag, Beteiligte, Zeitraum und gewünschtes Arbeitsergebnis aus den vorhandenen Unterlagen feststellen.
- Die für Anfechtung und Organhaftung maßgeblichen Dokumente, Fassungen, Belege und Fristen prüfen.

## 3. Ablauf

### 3.1. Arbeitsschritt

Zahlungsströme, Anfechtungstatbestände, Gegenargumente und Organhaftung bis zur Anspruchsdurchsetzung prüfen.

### 3.2. Arbeitsschritt

Die unten zugeordneten Vertiefungen zum konkreten Sachverhalt vollständig lesen; zusammenhängende Themen gemeinsam bearbeiten.

### 3.3. Arbeitsschritt

Tatsachen, Rechtsgrundlage, Belege, Gegenposition und verbleibende Unsicherheiten nachvollziehbar verbinden.

### 3.4. Arbeitsschritt

Das verlangte Dokument oder die Berechnung ausarbeiten; nur entscheidende fehlende Angaben nachfordern.

### 3.5. Fachvertiefungen gezielt laden

Wähle anhand des Auftrags nur die einschlägigen Vertiefungen. Lies deren vollständige Fachanweisungen vor der jeweiligen Teilprüfung; berücksichtige die dort verknüpften lokalen Werkzeuge, Vorlagen und Belege. Die folgenden Dateien sind Fachinhalte dieses Arbeitswegs, keine zusätzlichen auswählbaren Skills.

- [D&O-Versicherung bei Manager-Haftung](../do-versicherung-manager-haftung/FACHINHALT.md)
- [Sanierungsgewinn — IV-Haftung fuer versaeumte Paragraph 3a-Antraege](../insol-sanierungsgewinn-iv-haftung-fuer-versaumte-3a-iv-antraege/FACHINHALT.md)
- [Sanierungsgewinn — IV-Haftung für versaeumte Paragraph 3a-Antraege](../sanierungsgewinn-iv-haftung-fuer-versaumte-3a-iv-antraege/FACHINHALT.md)
- [Vorsatzanfechtung § 133 InsO](../vorsatzanfechtung-133-inso/FACHINHALT.md)

## 4. Quellenpflicht

Trenne vorgelegte Tatsachen, eigene Berechnungen und rechtliche oder fachliche Wertungen. Prüfe entscheidungstragende Normen, Rechtsprechung und sonstige Quellen anhand zugänglicher Primärquellen auf Geltungszeitpunkt, Aussage und Übertragbarkeit. Historische Quellen sind in ihrem zeitlichen Zusammenhang auszuwerten. Eine Quellenangabe im Fachinhalt ersetzt keine aktuelle Einzelfallprüfung; behaupte keine nicht durchgeführte Verifikation.

## 5. Ausgabeformat

- Ausgearbeitetes Ergebnis zu Anfechtung und Organhaftung mit Belegen, klaren Handlungsschritten und offenen Punkten.
- Eine Tabelle, Chronologie oder Visualisierung ergänzen, wenn sie die konkrete Entscheidung verständlicher macht.

Liefere das beauftragte Dokument vollständig in ausformuliertem Text mit Dezimalgliederung. Für juristische Schriftsätze und Gutachten ist die Zieltypografie Times New Roman 11 pt; Tabellen und Grafiken ergänzen die Begründung. Wähle zur Aufgabe passende Vergleiche, Zeitleisten oder andere Visualisierungen. Nutze eine interaktive Ansicht nur, wenn die Laufzeit sie tatsächlich bereitstellt; stelle sonst eine unmittelbar lesbare Tabelle oder Grafik bereit. Kennzeichne fehlende Daten und offene Prüfungen an der betroffenen Stelle und schließe mit dem konkreten nächsten Arbeitsschritt.

## 6. Beispiele

- Eine anfechtbare Zahlung mit Belegkette und Verteidigungseinwänden für eine Klage aufarbeiten.
