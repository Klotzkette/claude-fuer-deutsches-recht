---
name: sanierungsgewinn-3a-estg-im-insolvenzplan
description: "Für Sanierungsgewinn — Paragraph 3a EStG im Insolvenzplan: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Sanierungsgewinn — Paragraph 3a EStG im Insolvenzplan

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Sanierungsgewinn — Paragraph 3a EStG im Insolvenzplan` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Worum geht es

Der Insolvenzplan (Paragraphen 217 ff. InsO) ist das in der Praxis wichtigste Instrument für Forderungsverzichte und damit zugleich der typische Ausloeser eines Sanierungsertrags. Mit der Wiederaufnahme von Paragraph 3a EStG ist die fruehere Streitfrage, ob der Sanierungserlass per Verwaltungsanweisung oder per Gesetz gelte, erledigt: die Steuerbefreiung steht im Gesetz.

Dieser Skill arbeitet die Prüfung des Sanierungsertrags im Plan-Kontext durch: vier materielle Voraussetzungen, Verrechnungsreihenfolge, Antrag, Plan-Texte. Adressat ist der Plan-Anwalt, der Insolvenzverwalter und der StB.

## Wann dieses Modul hilft / Kaltstart-Fragen

- Insolvenzplan wird ausgearbeitet, Forderungsverzicht der Gläubiger ist Kerngegenstand.
- Plan ist eingereicht oder steht vor Einreichung — Steuerteil muss geschrieben werden.
- StB soll den Erlassantrag oder die Steuererklaerung des Sanierungsjahres vorbereiten.

Kaltstart-Fragen:

1. Schuldner: GmbH, AG, GmbH und Co. KG, Einzelunternehmer, eingetragener Kaufmann?
2. Höhe des Forderungsverzichts im Plan?
3. Plan-Quote (was bleibt den Gläubigern)?
4. Verlustvortraege bekannt (KSt, GewSt, ESt)?
5. Liegt ein Sanierungskonzept nach IDW S 6 oder vergleichbarer Standard vor?

## Rechtlicher Rahmen

- Paragraphen 217 ff. InsO — Insolvenzplan.
- Paragraph 3a EStG — Steuerbefreiung Sanierungsertrag.
- Paragraph 3a Absatz 2 EStG — vier Voraussetzungen.
- Paragraph 3a Absatz 3 EStG — Verrechnungsreihenfolge; verdraengt Mindestbesteuerung.
- Paragraph 7b GewStG — Gewerbesteuer-Parallel.
- Paragraph 251 AO — Steuern im Insolvenzverfahren.
- BFH, Urteil vom 26.02.2003 — II R 19/01: Verbindlichkeiten bleiben zivilrechtlich über die Liquidation hinaus bestehen; blosse Vermögenslosigkeit begruendet keine Ausbuchung — zur Abgrenzung Sanierungsertrag vs. Ausbuchung mangels Schuldner.

## / Schritt für Schritt

1. **Forderungsverzicht erfassen.** Welche Forderungen entfallen im Plan in welcher Höhe? Trennung Drittglaeubiger vs. Gesellschafter (Gesellschafter-Verzicht kann verdeckte Einlage sein).
2. **Werthaltigkeit der Forderungen prüfen.** Nur werthaltige Forderungen erzeugen einen vollwertigen Sanierungsertrag; nicht werthaltige Forderungen erhoehen den Sanierungsertrag rechnerisch, fuehren aber zugleich zu einer abweichenden bilanziellen Behandlung.
3. **Vier Voraussetzungen Paragraph 3a Absatz 2 EStG abarbeiten** (Sanierungsbeduerftigkeit, Sanierungsfaehigkeit, Sanierungseignung, Sanierungsabsicht der Gläubiger).
4. **Verrechnungsreihenfolge Paragraph 3a Absatz 3 EStG aufstellen.**
5. **Restsanierungsertrag berechnen.**
6. **Antrag stellen.** Mit der Steuererklaerung des Sanierungsjahres; ggf. zusaetzlich Vorabauskunft Paragraph 89 AO.
7. **Plan-Texte schreiben** (darstellender Teil mit Voraussetzungs-Belegen; gestaltender Teil mit Verzichtsklauseln).

## Vier Voraussetzungen Paragraph 3a Absatz 2 EStG

| Voraussetzung | Prüfkriterium | Beleg |
|---|---|---|
| Sanierungsbeduerftigkeit | Unternehmen ohne Verzicht nicht ueberlebensfaehig | Liquiditaetsplan, Fortbestehensprognose, Eroeffnungsantrag |
| Sanierungsfaehigkeit | Unternehmen ist nach Sanierung lebensfaehig | IDW S 6-Gutachten oder gleichwertig |
| Sanierungseignung | Forderungsverzicht ist geeignet, die Sanierung zu erreichen | Plan-Quote + Liquiditaets-Auswirkung |
| Sanierungsabsicht der Gläubiger | Gläubiger verzichten, gerade weil die Sanierung sonst nicht funktioniert | Gläubigerausschuss-Protokoll, Gläubigerbriefe, Plan-Annahme-Beschluss |

## Trade-off-Matrix

| Variante | Vorteil | Nachteil |
|---|---|---|
| Unternehmensbezogene Sanierung (Paragraph 3a Absatz 2 EStG) | Steuerbefreiung greift | Vier Voraussetzungen müssen wasserdicht belegt sein |
| Unternehmerbezogene Sanierung | nicht von Paragraph 3a Absatz 1 EStG erfasst | Steuerpflichtig — Erlass nur über Paragraph 227 AO |
| Gesellschafter-Verzicht (gesellschaftsrechtlich veranlasst) | keine Steuer (Einlage) | Werthaltigkeitspruefung; ggf. verdeckte Einlage |
| Drittglaeubiger-Verzicht | klar Sanierungsertrag | bei Werthaltigkeit gewinnerhoehend |
| Verzicht mit Besserungsschein | nur teilweise endgueltig | Sanierungsertrag entsteht ggf. nachgelagert; Buchungstechnik beachten |

## Praxistipps der alten Hasen

1. **Vier Voraussetzungen in den darstellenden Teil ausdruecklich aufnehmen.** Wer das im Plan dokumentiert, hat dem Finanzamt eine vorgefertigte Begruendung serviert.
2. **Sanierungsabsicht ist plural.** Wenn nur ein Hauptglaeubiger verzichtet, hilft das nicht — der Verzicht muss von einem ausreichenden Gläubigerkreis getragen sein, weil die Sanierung sonst nicht plausibel ist.
3. **Besserungsschein steuerlich prüfen.** Forderungsverzicht mit Besserungsabrede entstehen den Sanierungsertrag erst, wenn der Besserungsfall **nicht** eintritt — bis dahin ist der Verzicht aufschiebend.
4. **Stille Reserven nicht durch Buchungstechnik in den Sanierungsertrag mischen.** Aufdeckungen sind regulaer steuerpflichtige Gewinne.
5. **Vorabauskunft Paragraph 89 AO** ist gebuehrenpflichtig, aber bei Volumen ab ca. 1 Mio EUR Sanierungsertrag in der Regel sinnvoll.
6. **Doppelt parallel laufen** — KSt-Antrag und GewSt-Antrag (Paragraph 7b GewStG) gleichzeitig vorbereiten.

## Mustertexte / Berechnungsbeispiele

**Plan-Text für den darstellenden Teil (Auszug):**

```
III. Steuerliche Folgen des Forderungsverzichts

Der gestaltende Teil dieses Plans sieht einen Forderungsverzicht der
Insolvenzglaeubiger in Hoehe von EUR [Betrag] vor. Dieser Verzicht loest
nach den Grundsaetzen der Bilanzierung einen Sanierungsertrag aus.

Die Voraussetzungen der Steuerbefreiung nach Paragraph 3a Absatz 2 EStG
liegen vor:

1. Sanierungsbeduerftigkeit
Die Schuldnerin ist ohne den Verzicht nicht ueberlebensfaehig. Dies ist
durch den Eroeffnungsantrag, den vorläufigen Bericht des Verwalters vom
[Datum] und die diesem Plan als Anlage beigefuegte Liquiditaetsplanung
belegt.

2. Sanierungsfaehigkeit
Das diesem Plan als Anlage beigefuegte Sanierungsgutachten nach IDW S 6
[oder vergleichbar] belegt die Sanierungsfaehigkeit der Schuldnerin nach
Vollzug des Plans.

3. Sanierungseignung
Die im Plan vorgesehenen Massnahmen — insbesondere der Forderungsverzicht
in Verbindung mit [weiteren Massnahmen] — fuehren rechnerisch zur
Wiederherstellung positiver Eigenkapitalquote ab [Stichtag] gemaess
Anlage [...].

4. Sanierungsabsicht der Glaeubiger
Die Insolvenzglaeubiger verzichten in dem im gestaltenden Teil
vorgesehenen Umfang, weil eine Sanierung der Schuldnerin ohne den Verzicht
nicht moeglich waere. Dies ist im Glaeubigerausschuss-Beschluss vom
[Datum] und im Schreiben des Hauptglaeubigers vom [Datum] dokumentiert.

5. Verrechnungsreihenfolge nach Paragraph 3a Absatz 3 EStG
[Tabelle siehe Anlage S-3]
```

**Erlassantrag-Geruest:**

```
An das Finanzamt [Ort]
Steuernummer [...]

Antrag auf Behandlung des Sanierungsertrags nach Paragraph 3a EStG für
das Sanierungsjahr [Jahr]

1. Sachverhalt
[Kurze Darstellung mit Verweis auf bestaetigten Insolvenzplan]

2. Sanierungsertrag
[Betrag, Berechnung mit Verweis auf Plan-Anlage]

3. Vier Voraussetzungen Paragraph 3a Absatz 2 EStG
[Verweis auf darstellenden Teil des Plans Abschnitt III]

4. Verrechnungsreihenfolge Paragraph 3a Absatz 3 EStG
[Tabelle mit Restsanierungsertrag]

5. Antrag
Wir beantragen die Anwendung der Steuerbefreiung nach Paragraph 3a Absatz
1 EStG auf den ermittelten Restsanierungsertrag in Hoehe von EUR [Betrag].
Hilfsweise: Erlass nach Paragraph 227 AO. Hilfsweise: Stundung nach
Paragraph 222 AO.

6. Anlagen
[1. Bestaetigter Insolvenzplan, 2. IDW S 6, 3. Fortbestehensprognose,
4. Glaeubigerausschuss-Beschluss, 5. Verrechnungsreihenfolge-Tabelle]
```

## Typische Fehler

1. Vier Voraussetzungen nicht ausdruecklich im darstellenden Teil belegt.
2. Werthaltigkeitspruefung beim Gesellschafterverzicht vergessen.
3. Besserungsschein als unmittelbarer Sanierungsertrag verbucht.
4. GewSt-Parallel-Antrag (Paragraph 7b GewStG) nicht gestellt.
5. Stille Reserven mit Sanierungsertrag vermengt.
6. Annahme, die Plan-Bestaetigung loese die Steuerfreiheit automatisch aus — sie ist Voraussetzung, aber der Antrag ist gesondert zu stellen.

## Quellen Stand 06/2026

### Normen

- Paragraph 3a EStG, `gesetze-im-internet.de/estg/__3a.html`.
- Paragraph 5 Absatz 2a EStG.
- Paragraph 7b GewStG, `gesetze-im-internet.de/gewstg/__7b.html`.
- Paragraphen 217 ff. InsO, `gesetze-im-internet.de/inso/`.
- Paragraph 251 AO, `gesetze-im-internet.de/ao_1977/__251.html`.
- Paragraph 11 KStG (Liquidationsbesteuerung — für Plan-B-Pfade).

### Rechtsprechung (verifiziert)

- **BFH, Urt. v. 26.02.2003 — II R 19/01** — Verbindlichkeiten bleiben zivilrechtlich auch in Liquidation bestehen.
- **BFH, Urt. v. 30.11.2011 — I R 100/10, DStR 2012, 450** — Passivierung nur bei wirtschaftlicher Belastung.
- **BFH, Urt. v. 19.08.2020 — XI R 32/18, BStBl. II 2021, 279** — Paragraph 5 Absatz 2a EStG bei Rangrücktritt.
- **FG Koeln, Urt. v. 06.03.2012 — 13 K 3006/11, GmbHR 2012, 977** — Os. 7: Bei Liquidation rangruecktrittsbehaftete Verbindlichkeit passiviert bis Loeschung; rechtstheoretisch entstehender Gewinn mangels Steuersubjekt nicht steuerpflichtig (vorgehend zu BFH I R 34/12).
- **BFH, Beschl. v. 05.02.2014 — I R 34/12, BFH/NV 2014, 1014** — bestaetigt FG-Koeln-Linie als „nicht evident rechtsfehlerhaft".
- FG Köln, Urteil vom 04.11.2025 - 12 K 1413/25: Eine Steuerbefreiung nach Paragraf 3a EStG setzt den Nachweis von Sanierungsbedürftigkeit, Sanierungsfähigkeit, Sanierungseignung, Sanierungsabsicht und betrieblicher Veranlassung des Schuldenerlasses voraus; die Eignung ist aus Sicht des Erlasszeitpunkts zu beurteilen.

### Verwaltungsauffassung

- **OFD Frankfurt a. M., Rundverfuegung v. 26.07.2021 — S 2743 A-12-St 523, Originalquelle oder frei pruefbare Quelle vor Ausgabe pruefen**.
- **OFD Frankfurt a. M., Rundverfuegung v. 03.08.2018 — S 2743 A-12-St 525, DStR 2019, 560**.
- **OFD Nordrhein-Westfalen, Kurzinformation ESt Nr. 46/2014, akt. 22.09.2017, DB 2017, 2580**.

### Mindestbesteuerung / Definitiveffekt

- **FG Duesseldorf, Urt. v. 18.09.2018 — 6 K 454/15 K, DStRE 2019** — Definitiveffekt der Mindestbesteuerung in Liquidation. Revision anhaengig BFH I R 36/18 (ausgesetzt wegen BVerfG 2 BvL 19/14, Vorlage BFH I R 59/12).
- **OFD Frankfurt v. 27.12.2018, Originalquelle oder frei pruefbare Quelle vor Ausgabe pruefen** — Einsprueche zur Mindestbesteuerung ruhend zu stellen.

### Plan-B-Pfad Liquidation

- Siehe Fachmodul `stb-sanierungsgewinn-stehengelassene-verbindlichkeiten` (Drei-Phasen-Analyse) im Plugin `steuerrecht-anwalt-und-berater`.

Zitierweise und Quellenpruefung siehe `references/zitierweise.md`.
