---
name: sanierungsgewinn-iv-haftung-fuer-versaumte-3a-iv-antraege
description: "Für Sanierungsgewinn — IV-Haftung für versäumte Paragraph 3a-Anträge: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: Insolvenzrecht. Route: sanierungsgewinn-iv-haftung-fuer-versaumte-3a-iv-antraege."
---

# Sanierungsgewinn — IV-Haftung für versaeumte Paragraph 3a-Antraege

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Sanierungsgewinn — IV-Haftung für versaeumte Paragraph 3a-Antraege` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Worum geht es

Der Insolvenzverwalter und Sachwalter sind Treuhaender der Masse. Verletzen sie ihre Pflichten schuldhaft, haften sie nach Paragraph 60 InsO gegenueber allen Beteiligten — den Gläubigern wie dem Schuldner. Ein klassischer Haftungsfall: Der Verwalter versaeumt es, im Plan-Verfahren rechtzeitig die steuerlichen Antraege zu stellen (Paragraph 3a EStG-Anwendung, Paragraph 7b GewStG-Parallel, Vorabauskunft Paragraph 89 AO), mit der Folge, dass der Sanierungsertrag als steuerbarer Gewinn die Masse aufzehrt.

Dieser Skill arbeitet die Pflichten und die Verteidigung heraus. Adressat: Verwalter, Berater des Verwalters, Gläubigerausschuss, ggf. Klägeranwalt aus Gläubigerkreis.

## Wann dieses Modul hilft / Kaltstart-Fragen

- Verwalter steht im Verdacht, Sanierungsertrag-Steuern in voller Höhe an das Finanzamt zahlen zu müssen, weil Antraege versaeumt wurden.
- Gläubigerausschuss ueberlegt, eine Pflichtverletzung anzunehmen.
- Verwalter will praeventiv die eigene Aktenlage absichern.

Kaltstart-Fragen:

1. Aktuelle Verfahrenslage (Plan bestaetigt, Steuerbescheid ergangen, Klagephase)?
2. Welcher Antrag wurde versaeumt (Paragraph 3a EStG-Anwendung, Paragraph 7b GewStG, Vorabauskunft)?
3. Wann waere der Antrag rechtzeitig zu stellen gewesen?
4. Welche Auswirkung auf die Masse (Steuer als Masseverbindlichkeit Paragraph 55 InsO oder Insolvenzforderung Paragraph 38 InsO)?
5. Liegt eine D-und-O- bzw. IV-Berufshaftpflichtversicherung vor?

## Rechtlicher Rahmen

- Paragraph 60 InsO — Schadensersatzpflicht IV.
- Paragraph 92 InsO — Gesamtschadenliquidation.
- Paragraph 56 InsO — Anforderungen an die Person des Verwalters.
- Paragraph 58 InsO — Aufsicht durch das Gericht.
- Paragraph 69 AO — Haftung der gesetzlichen Vertreter; analoge Anwendung diskutiert.
- Paragraph 3a EStG — Sanierungsertrag.
- Paragraph 251 AO — Steuerforderungen in der Insolvenz.

## Pflichtenkreis des IV im Steuerteil

| Pflicht | Inhalt | Belegtechnik |
|---|---|---|
| Steuerliche Frueherkennung | Sanierungsertrag rechtzeitig identifizieren | Aktennotiz nach Plan-Entwurf |
| Steuerlichen Berater einbinden | StB des Schuldners aktivieren, ggf. eigenen StB beauftragen | Mandatsschreiben |
| Verlustvortrag-Modellrechnung | Paragraph 3a Absatz 3 EStG rechnen | Excel-Modell in der Akte |
| Vier Voraussetzungen dokumentieren | Sanierungsbeduerftigkeit, -faehigkeit, -eignung, -absicht | Anlagen zum darstellenden Teil |
| Vorabauskunft prüfen | Paragraph 89 AO ab gewisser Volumenschwelle | Aktenvermerk Prüfung |
| Antrag in Steuererklaerung | Mit Erklaerung des Sanierungsjahres | Erklaerungs-Kopie |
| Paragraph 7b GewStG-Parallel | Eigenstaendiger Antrag | Erklaerung GewSt |
| Plan-Text steuerlich prüfen | Darstellender Teil enthaelt die Vier-Voraussetzungs-Belege | Plan-Entwurf |

## / Schritt für Schritt

1. **Pflichtverletzung qualifizieren.** Welcher Schritt wurde versaeumt? War er pflichtgemaess geschuldet?
2. **Verschulden prüfen.** Paragraph 60 InsO verlangt Verschulden. Der Verwalter haftet **nicht** für jeden Fehler, sondern für schuldhafte Pflichtverletzung. Bei komplexen Steuerthemen ist die Hinzuziehung eines StB regelmaessig pflichtgemaess; die Auslagerung allein entlastet aber nicht.
3. **Schaden berechnen.** Mehr-Steuer = Schaden. Aber Verrechnungsreihenfolge Paragraph 3a Absatz 3 EStG durchspielen: wenn Verlustvortraege ohnehin den Ertrag aufgezehrt haetten, ist der Schaden null oder gering.
4. **Kausalitaet prüfen.** Auch ohne den versaeumten Antrag haette das FA ggf. anders entschieden — Beweislast und Vermutungs-Regeln.
5. **Versicherungsdeckung prüfen.** Die IV-Berufshaftpflicht deckt typischerweise auch Steuerthemen, sofern der Verwalter sie nicht grob fahrlaessig versaeumt hat.
6. **Verteidigung aufbauen.** Akten, externe StB-Empfehlungen, Plausibilitaetspruefungen.

## Trade-off-Matrix Pflichten / Verteidigung

| Verteidigung des IV | Stand sicher? | Stand schwach? |
|---|---|---|
| Externer StB war beauftragt | bei rechtzeitiger Hinzuziehung sehr stark | bei später oder ungeeigneter Auswahl schwach |
| Vorabauskunft beantragt | sehr stark | wenn ueberhaupt nicht erwogen, schwach |
| Vier Voraussetzungen dokumentiert | sehr stark | wenn Plan-Text duenn, schwach |
| Verrechnungsreihenfolge gerechnet | sehr stark | wenn Modellrechnung fehlt, schwach |
| Gläubigerausschuss informiert | stark | wenn nicht informiert, schwach |
| Versicherung deckt | bei Deckungszusage sicher | bei grober Fahrlaessigkeit Vorbehalt |

## Praxistipps der alten Hasen

1. **Steuerteil ist Chefsache.** Auch wenn der IV ihn delegiert: er bleibt verantwortlich (Paragraph 56 InsO Eignung; Aufsichts-Pflichten).
2. **Aktendokumentation bei jedem Schritt.** Ohne Akte keine Verteidigung.
3. **Bei Sanierungsertrag oberhalb 1 Mio EUR ist Vorabauskunft Paragraph 89 AO faktisch zwingend.** Wer sie nicht beantragt, riskiert Haftung.
4. **Versicherung frueh einbinden.** Bei kritischen Sanierungsplaenen schon vor Plan-Vorlage der Versicherung anzeigen.
5. **Gläubigerausschuss-Beschluss zum Steuerteil.** Wer den Ausschuss explizit beteiligt hat, hat einen wertvollen Verteidigungs-Anker.
6. **Mehrere Verteidigungslinien:** keine Pflichtverletzung; kein Verschulden; kein Schaden; keine Kausalitaet.

## Mustertexte / Berechnungsbeispiele

**Aktenvermerk praeventiv: Steuerteil im Verfahren XY**

```
AKTENVERMERK STEUERTEIL — PRAEVENTIVE DOKUMENTATION
Verfahren: [AZ]
Schuldner: [Name]
Datum: [Datum]
Verfasser: [IV/Sachwalter]

1. Sanierungsertrag voraussichtlich: EUR [Betrag]

2. Beauftragung StB
StB [Name] wurde mit Mandatsschreiben vom [Datum] mit der Pruefung
Paragraph 3a EStG / Paragraph 7b GewStG beauftragt.

3. Modellrechnung Paragraph 3a Absatz 3 EStG
Liegt vor: Anlage 1 vom [Datum].

4. Vorabauskunft Paragraph 89 AO
Geprueft, mit folgendem Ergebnis: [beantragt / nicht beantragt mit Begruendung].

5. Glaeubigerausschuss
Ausschuss-Beschluss zum Steuerteil vom [Datum] (Anlage 2).

6. Plan-Text
Darstellender Teil Abschnitt III enthaelt die vier Voraussetzungs-Belege
mit Anlagen-Verweis.

7. Antrag in Steuererklaerung
Sanierungsjahr ist [Jahr]. Erklaerung wird durch StB [Name] eingereicht.

8. Risiken / offene Punkte
[...]
```

**Verteidigungsschriftsatz — Geruest:**

```
SCHRIFTSATZ
in Sachen [Klaeger] gegen [IV-Beklagter]
Schadensersatzklage Paragraph 60 InsO

I. Sachverhalt
[...]

II. Rechtliche Wuerdigung

1. Keine Pflichtverletzung
Der Beklagte hat die Sanierungsertrag-Antraege rechtzeitig vorbereitet
und beauftragt. Insbesondere wurde StB [Name] am [Datum] mit der Pruefung
beauftragt; die Modellrechnung wurde am [Datum] erstellt und dem
Glaeubigerausschuss am [Datum] vorgelegt.

2. Hilfsweise: kein Verschulden
Der Beklagte durfte sich auf die Expertise des beauftragten StB verlassen.
Die Hinzuziehung eines qualifizierten Beraters entlastet einen IV im
Rahmen der ueblichen Sorgfalt eines ordentlichen Verwalters.

3. Hilfsweise: kein Schaden
Die Verrechnungsreihenfolge Paragraph 3a Absatz 3 EStG haette den
Sanierungsertrag in Hoehe der Verlustvortraege ohnehin aufgezehrt. Der
verbleibende Restbetrag betrug EUR [Betrag]; der Steueranfall wurde durch
Paragraph 3a Absatz 1 EStG aufgefangen.

4. Hilfsweise: keine Kausalitaet
[...]

5. Versicherung
Der Beklagte zeigt vorsorglich die Inanspruchnahme der IV-Berufshaftpflicht
[Name Versicherer] mit Schaden-Nr. [...] an.

Beweis: Anlagen 1-12.
```

## Typische Fehler

1. Steuerteil komplett dem StB ueberlassen, ohne eigene Aufsicht.
2. Vorabauskunft Paragraph 89 AO nicht einmal erwogen.
3. Akte enthaelt keine Modellrechnung.
4. Gläubigerausschuss zum Steuerteil nicht beteiligt.
5. Versicherung erst nach Klage angezeigt.
6. Verteidigung baut nur auf "kein Verschulden" — Verteidigung muss mehrere Linien parallel fuehren.

## Quellen Stand 06/2026

- Paragraph 60 InsO, `gesetze-im-internet.de/inso/__60.html`.
- Paragraphen 56, 58, 92 InsO, `gesetze-im-internet.de/inso/`.
- Paragraphen 69, 89, 251 AO, `gesetze-im-internet.de/ao_1977/`.
- Paragraph 3a EStG, Paragraph 7b GewStG.
- FG Köln, Urteil vom 04.11.2025 - 12 K 1413/25: Eine Steuerbefreiung nach Paragraf 3a EStG setzt den Nachweis von Sanierungsbedürftigkeit, Sanierungsfähigkeit, Sanierungseignung, Sanierungsabsicht und betrieblicher Veranlassung des Schuldenerlasses voraus; die Eignung ist aus Sicht des Erlasszeitpunkts zu beurteilen.
- Zitierweise und Quellenpruefung siehe `references/zitierweise.md`.
