---
name: ueberschuldung-pruefung-19-inso
description: "Für Zweistufige Überschuldungsprüfung gem. Paragraf 19 Abs. 2 InsO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Tatbestands- oder Anspruchsmatrix."
---

# Zweistufige Überschuldungsprüfung gem. § 19 Abs. 2 InsO

## Arbeitsbereich

Führt die zweistufige Überschuldungsprüfung gem. § 19 Abs. 2 InsO durch: Fortbestehensprognose (Stufe 1) und insolvenzrechtlicher Überschuldungsstatus auf Liquidationswertbasis (Stufe 2). Lädt, wenn Überschuldung geprüft, ein Überschuldungsstatus erstellt oder § 19 InsO ausgelegt werden soll. Arbeite entlang dieser konkreten Prüfungslinie und trenne Rolle, Frist, Zuständigkeit, Beweislast und gewünschten Output.

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Zweistufige Überschuldungsprüfung gem. § 19 Abs. 2 InsO` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Zweck

Dieser Skill leitet die strukturierte Prüfung durch, ob bei einer Kapitalgesellschaft
(insb. GmbH, UG, AG) Überschuldung i.S.d. § 19 Abs. 2 InsO als Insolvenzantragspflicht-
auslösender Eröffnungsgrund vorliegt. Er klärt den modifizierten zweistufigen
Überschuldungsbegriff, benennt die Prüfungsschritte, stellt Hinweise zur Dokumentation
bereit und warnt vor den häufigsten Bewertungsfehlern.

Wichtig: Die Fortbestehensprognose ist nicht dasselbe wie volle Sanierungsfähigkeit. Sie
prüft für § 19 InsO, ob die Zahlungsfähigkeit im Prognosezeitraum überwiegend wahrscheinlich
erhalten bleibt. Ein Sanierungskonzept geht weiter und muss Krisenursachen, Leitbild,
Maßnahmen, integrierte GuV-/Bilanz-/Liquiditätsplanung, Szenarien und Dokumentation
zusammenführen.

## Eingaben

- Jahresabschluss oder aktuelle BWA (Bilanz, GuV) des Unternehmens
- Liquiditätsplanung (Plan-GuV, Plan-Bilanz, Liquiditätsplan) — zumindest als Entwurf
- Liste der Verbindlichkeiten inkl. Rangangaben (insb. Gesellschafterdarlehen)
- Angaben zu Eventualverbindlichkeiten (Bürgschaften, Haftungsrisiken)
- Unternehmenskonzept / Sanierungsplan (sofern vorhanden)
- Stichtag der Prüfung

## Rechtlicher Rahmen

### Gesetzliche Grundlage

§ 19 Abs. 2 Satz 1 InsO definiert Überschuldung: Das Vermögen des Schuldners deckt die
bestehenden Verbindlichkeiten nicht mehr, es sei denn, die Fortführung des Unternehmens
ist nach den Umständen überwiegend wahrscheinlich. Antragspflicht gem. § 15a Abs. 1 InsO
tritt bei Überschuldung grundsätzlich innerhalb von sechs Wochen ein.

### Historische Entwicklung und aktueller Stand

Der modifizierte zweistufige Überschuldungsbegriff wurde durch das MoMiG 2008 eingeführt
und durch das SanInsFoG / StaRUG (2021) sowie das SanInsKG (2022/2023) weiterentwickelt.
Das SanInsKG verkürzte den Prognosezeitraum krisenbedingt auf vier Monate (befristete
Sonderregel, galt bis 31.12.2023). Seit 01.01.2024 gilt wieder der Regelzeitraum von
zwölf Monaten. Zum Stichtag 18.05.2026 beträgt der Prognosezeitraum zwölf Monate.

### Rechtsprechung (Pflichtpinpoints; Az. und Datum vor Ausgabe über dejure.org / openjur.de verifizieren)

**Fortbestehensprognose:** Anforderungen an die Prognoseentscheidung (st. BGH-Linie): plausibler Liquiditätsplan mit nachvollziehbaren Planungsannahmen erforderlich; bloße Hoffnung auf künftige Kapitalzuführungen genügt nicht; maßgeblich ist überwiegende Wahrscheinlichkeit der Zahlungsfähigkeitserhaltung im Prognosezeitraum (12 Monate seit 01.01.2024). Unrealistische Annahmen entwerten die Prognose insgesamt.

**Insolvenzrechtliche Überschuldung:** Im Überschuldungsstatus sind nicht handelsbilanzielle Buchwerte, sondern Liquidations- bzw. Zerschlagungswerte anzusetzen; bei negativer Fortbestehensprognose auch stille Reserven und immaterielle Vermögensgegenstände zu Zerschlagungswerten.

**Abgrenzung handelsbilanzieller vs. insolvenzrechtlicher Überschuldung:** Negative Handelsbilanz indiziert mögliche insolvenzrechtliche Überschuldung, begründet sie aber nicht zwingend. Positives HGB-Eigenkapital schließt umgekehrt eine insolvenzrechtliche Überschuldung nicht aus, wenn Vermögensgegenstände zu Fortführungswerten überhöht aktiviert sind.

**Qualifizierter Rangrücktritt:** Ein Rangrücktritt entfernt die Forderung aus dem Überschuldungsstatus nur, wenn er mehr leistet als einen bloßen Nachrang. Er muss die Durchsetzung vor und nach Insolvenzreife so sperren, dass durch Zahlung weder Zahlungsunfähigkeit noch Überschuldung ausgelöst oder vertieft wird. Zahlung darf nur aus freiem Vermögen, aus einem künftigen Bilanzgewinn, aus Liquidationsüberschuss oder aus sonstigem freien Liquiditätsüberschuss erfolgen. Die Rechtsprechung behandelt den qualifizierten Rangrücktritt als schuldrechtliche Vereinbarung mit Wirkung zugunsten der Gläubigergesamtheit; nach Insolvenzreife kann er nicht beliebig durch Schuldner und Rangrücktrittsgläubiger zu Lasten der übrigen Gläubiger beseitigt werden. Leitanker: BGH IX ZR 133/14 vom 05.03.2015, BGH IX ZR 143/17 vom 06.12.2018, BGH IX ZR 250/20 vom 24.02.2022.

**Patronat und Comfort Letter:** Eine harte Patronatserklärung kann für Fortbestehensprognose und Liquiditätsplanung nur tragen, wenn Anspruchsinhaber, Leistungspflicht, Betrag, Zeitraum, Abrufmechanik und Bonität des Patrons konkret belegt sind. Eine weiche Patronatserklärung oder bloße Unterstützungserwartung beseitigt rechnerische Überschuldung nicht und trägt die Fortbestehensprognose nur ausnahmsweise, wenn eine belastbare tatsächliche Finanzierungswahrscheinlichkeit nachgewiesen ist. Leitanker: BGH II ZR 84/20 vom 13.07.2021; bei externer harter Patronatserklärung zusätzlich BGH IX ZR 95/16 vom 12.01.2017 für Haftungsfolgen bei späterer Anfechtung.

Hinweis: Aktenzeichen und Randnummern der einschlägigen BGH-Entscheidungen (zur Fortbestehensprognose, Liquidationswerten, Rangrücktritt) vor Ausgabe in offener Quelle (dejure.org, openjur.de, bundesgerichtshof.de) prüfen.

### Quellen (nur verifiziert)

- Quellenregel: Keine Kommentar-, Handbuch-, Aufsatz- oder Tabellenfundstellen aus Modellwissen; nur Nutzerquelle, amtliche/freie Quelle oder lizenzierte Live-Verifikation verwenden.
 (umfassend zur Prüfungsreihenfolge, zum modifizierten Überschuldungsbegriff und zur
 Behandlung nachrangiger Verbindlichkeiten)
- Quellenregel: Literatur nur mit Nutzerquelle oder lizenziertem Live-Zugriff; keine Kommentar-, Handbuch- oder Aufsatzfundstellen aus Modellwissen.
 (Bewertungsmethodik Liquidationswerte, Gesellschafterdarlehen, Pensionsrückstellungen)
### Berufsständische Methodenlogik

Für Überschuldungsstatus und Fortbestehensprognose ist ein integrierter Finanzplan
erforderlich: Plan-GuV, Plan-Bilanz und Liquiditätsplan müssen zusammenpassen. Wenn
die Prüfung zugleich eine Sanierungsaussage tragen soll, sind zusätzlich die Bausteine
eines Sanierungskonzepts zu prüfen: Ausgangslage, Krisenstadium, Krisenursachen, Leitbild,
Maßnahmen, integrierte Planung, Szenarien, Sanierungsfähigkeit und Dokumentation.

## Ablauf

### Schritt 1 — Fortbestehensprognose (Stufe 1)

**1.1 Unternehmenskonzept prüfen**
Ist ein schlüssiges Unternehmenskonzept (Fortführungsstrategie, Geschäftsmodell,
Absatzplanung) vorhanden und plausibel? Ohne Konzept kann keine positive Prognose
gestellt werden.

Wenn Sanierungsfähigkeit behauptet wird, zusätzlich prüfen: Sind die wesentlichen
Krisenursachen nach Maßnahmen beseitigt oder beherrschbar? Ist das Unternehmen nach
Umsetzung wieder wettbewerbs-, rendite- und finanzierungsfähig? Eine bloße
Liquiditätsverlängerung genügt dafür nicht.

**1.2 Integrierten Finanzplan erstellen**
- Plan-GuV für die kommenden zwölf Monate (Regelzeitraum ab 01.01.2024)
- Plan-Bilanz zu den relevanten Stichtagen
- monatlicher Liquiditätsplan (Mittelzuflüsse, Mittelabflüsse, Saldo)
- Maßnahmenlog mit Kosten, Timing, Verantwortlichen, Bilanz-/GuV-/Liquiditätseffekt und Belegstatus, sofern Sanierungsfähigkeit beurteilt wird.

**1.3 Prognoseurteil**
Maßgebliches Kriterium: überwiegende Wahrscheinlichkeit (> 50 %) der Aufrechterhaltung
der Zahlungsfähigkeit im Prognosezeitraum. Die Planungsannahmen sind zu plausibilisieren
(Marktdaten, Auftragsbestand, gesicherte Finanzierungszusagen). Externe Gutachter
(Wirtschaftsprüfer, Unternehmensberater) sind hinzuzuziehen, wenn interne Kompetenz fehlt
(vgl. IDW S 11 Tz. 56 ff.).

→ **Positive Prognose**: Keine Überschuldung i.S.d. § 19 Abs. 2 InsO — Prüfung endet hier.
→ **Negative Prognose** (oder Prognose nicht mit überwiegender Wahrscheinlichkeit positiv):
 Weiter mit Schritt 2.

### Schritt 2 — Insolvenzrechtlicher Überschuldungsstatus (Stufe 2)

**2.1 Aktivseite zu Liquidationswerten bewerten**
Sämtliche Vermögensgegenstände sind zu Zerschlagungswerten (Liquidationswerten) zu
erfassen — nicht zu HGB-Buchwerten oder Fortführungswerten. Typische Abweichungen:
- Immobilien: Verkehrswert abzgl. Verwertungskosten und Zeitdruck-Abschlag
- Maschinen/Anlagen: Gebrauchtmarktwert, ggf. erheblich unter Buchwert
- Forderungen: unter Berücksichtigung von Ausfallwahrscheinlichkeiten
- Immaterielle Werte (Patente, Kundenstamm): oft stark gemindert oder null
- Latente Steueransprüche: nur ansetzen, soweit bei Liquidation realisierbar

**2.2 Passivseite vollständig erfassen**
- Sämtliche Verbindlichkeiten inkl. nachrangiger Forderungen gem. § 39 InsO
 (insb. Gesellschafterdarlehen)
- Eventualverbindlichkeiten (Bürgschaften, Garantien) nach Wahrscheinlichkeitsbewertung
- Pensionsrückstellungen: versicherungsmathematisch ermittelt, nicht HGB-Abzinsung
- Latente Steuerschulden aus stillen Reserven
- **Ausnahme § 19 Abs. 2 Satz 2 InsO**: Verbindlichkeiten mit qualifiziertem Rangrücktritt
 sind aus der Passivseite herauszulassen, wenn die Klausel eine insolvenzvermeidende
 Durchsetzungssperre enthält und Zahlungen nur aus freiem Vermögen, künftigen Gewinnen,
 Liquidationsüberschuss oder freiem Liquiditätsüberschuss zulässt. Eine bloße
 Rangreihenfolge oder ein einfacher Nachrang genügt nicht.

**2.2a Sanierungsbausteine auf Passivseite prüfen**

| Baustein | Passivierungswirkung | Prüffrage |
|---|---|---|
| Qualifizierter Rangrücktritt | Forderung kann aus dem Überschuldungsstatus ausscheiden | Sperrt die Klausel Zahlungen auch vor Insolvenzreife, soweit sie Eröffnungsgründe auslösen würden? |
| Einfacher Rangrücktritt | Forderung bleibt grundsätzlich Passivum | Wird nur die Rangfolge geregelt oder auch die Durchsetzung gesperrt? |
| Harte interne Patronatserklärung | Kann Aktiv-/Liquiditätsseite stärken | Hat die Gesellschaft einen durchsetzbaren Anspruch gegen den Patron? |
| Harte externe Patronatserklärung | Stärkt eher Gläubigerposition | Fließt rechtzeitig Liquidität an die Schuldnerin oder nur Zahlung an Dritte? |
| Weicher Comfort Letter | Keine automatische Entlastung | Ist mehr belegt als eine Unterstützungsabsicht? |

**2.3 Saldierung und Ergebnis**
Übersteigen die Passiva die Aktiva (Liquidationswerte), liegt rechnerische Überschuldung vor.
Dokumentation im Überschuldungsstatus (tabellarische Gegenüberstellung).

**2.4 Gesamtergebnis und Handlungspflichten**
Bei Überschuldung: Antragspflicht gem. § 15a Abs. 1 InsO — Frist grundsätzlich sechs Wochen.
Parallel prüfen: Zahlungsunfähigkeit gem. § 17 InsO und drohende Zahlungsunfähigkeit
gem. § 18 InsO.

## Beispiel

**Sachverhalt:** Die XY GmbH, Maschinenbau, weist zum 30.04.2026 in der Handelsbilanz
ein negatives Eigenkapital von –180.000 EUR aus. Der Geschäftsführer beauftragt eine
Überschuldungsprüfung nach § 19 Abs. 2 InsO.

---

**Gutachten (Auszug)**

**I. Sachverhalt**
Die XY GmbH (Stammkapital 25.000 EUR) erwirtschaftete im Geschäftsjahr 2025 einen
Jahresfehlbetrag von 230.000 EUR. Der Auftragsbestand ist rückläufig; Hauptkunde (40 %
Umsatz) hat Vertrag zum 30.06.2026 gekündigt.

**II. Fortbestehensprognose (Stufe 1)**

Unternehmenskonzept: Kein schlüssiges Restrukturierungskonzept vorhanden. Kostensenkungsmaßnahmen
erst in Planung, keine gesicherten Alternativaufträge. Gesellschafter hat keine verbindliche
Finanzierungszusage abgegeben.

Plan-Cashflow (12 Monate, stark vereinfacht):

| Monat | Einzahlungen | Auszahlungen | Saldo monatl. | Kumuliert |
|-------|-------------|--------------|---------------|-----------|
| Mai 26 | 85.000 | 110.000 | –25.000 | –25.000 |
| Jun 26 | 60.000 | 108.000 | –48.000 | –73.000 |
| … | … | … | … | … |
| Apr 27 | 55.000 | 105.000 | –50.000 | –420.000 |

→ Kumulierter Liquiditätssaldo nach 12 Monaten: **–420.000 EUR**
→ Ergebnis Stufe 1: **Negative Fortbestehensprognose.** Die Zahlungsfähigkeit kann im
 Prognosezeitraum (12 Monate) nicht mit überwiegender Wahrscheinlichkeit aufrechterhalten
 werden. Prüfung Stufe 2 ist durchzuführen.

**III. Überschuldungsstatus zu Liquidationswerten (Stufe 2)**

| Aktiva (Liquidationswerte) | EUR |
|------------------------------------------------|------------|
| Grundstück/Gebäude (Verkehrswert –15 %) | 320.000 |
| Maschinen/Anlagen (Gebrauchtmarktwert) | 180.000 |
| Vorräte (Liquidationsabschlag 40 %) | 90.000 |
| Forderungen (Ausfallabschlag 25 %) | 180.000 |
| Kassenbestand / Bankguthaben | 80.000 |
| **Summe Aktiva** |**850.000** |

| Passiva | EUR |
|------------------------------------------------|------------|
| Bankverbindlichkeiten | 600.000 |
| Lieferantenverbindlichkeiten | 150.000 |
| Steuerverbindlichkeiten | 80.000 |
| Pensionsrückstellungen (versicherungsmath.) | 120.000 |
| Gesellschafterdarlehen (§ 39 InsO-Nachrang, | |
| OHNE qualifizierten Rangrücktritt) | 200.000 |
| **Summe Passiva** |**1.150.000**|
| **Saldo (Unterdeckung)** |**–300.000**|

→ Ergebnis Stufe 2: **Rechnerische Überschuldung** i.H.v. 300.000 EUR.

**IV. Rechtliches Ergebnis**
Die XY GmbH ist überschuldet i.S.d. § 19 Abs. 2 InsO. Der Insolvenzantragspflicht
nach § 15a Abs. 1 InsO ist innerhalb von sechs Wochen nachzukommen, sofern keine
Beseitigung der Überschuldung (z.B. Kapitalzuführung, Rangrücktritt mit qualifizierter
Ausgestaltung) erfolgt.

## Risiken und typische Fehler

**Fehler 1 — HGB-Buchwerte statt Liquidationswerte**
Der häufigste Fehler: Der Überschuldungsstatus wird mit handelsbilanziellen Buchwerten
erstellt. Das ist unzulässig. Bei negativer Fortbestehensprognose sind ausnahmslos
Liquidations- bzw. Zerschlagungswerte anzusetzen (st. BGH-Linie; Az. vor Ausgabe verifizieren). Literatur nur bei vom Nutzer bereitgestellter oder lizenziert live geprüfter Quelle.

**Fehler 2 — Einfacher statt qualifizierter Rangrücktritt bei Gesellschafterdarlehen**
Ein Gesellschafterdarlehen mit einfachem Rangrücktritt bleibt Passivposten im
Überschuldungsstatus. Nur der qualifizierte Rangrücktritt (Erfüllung ausschließlich
aus freiem, die übrigen Verbindlichkeiten übersteigendem Vermögen) führt gem.
§ 19 Abs. 2 S. 2 InsO zum Ausscheiden aus dem Status (st. BGH-Linie; konkretes Az. vor Ausgabe verifizieren).

Prüfe zusätzlich, ob die Klausel steuerlich als Rückzahlung nur aus künftigem Bilanzgewinn, Liquidationsüberschuss oder sonstigem freien Vermögen ausgestaltet ist. Wenn die Rückzahlung aus sonstigem freien Vermögen möglich bleibt, kann eine Passivierung nach Paragraf 5 Absatz 2a EStG weiterhin geboten sein; BFH I R 25/15 vom 10.08.2016 und BFH XI R 32/18 vom 19.08.2020 als Steueranker heranziehen.

**Fehler 3 — Mangelhafte Fortbestehensprognose ohne Plausibilisierung**
Eine Fortbestehensprognose, die sich auf pauschale Hoffnungen oder ungesicherte
Finanzierungsabsichten stützt, ist rechtlich wertlos. Erforderlich sind integrierte
Finanzplanungen mit nachvollziehbaren Annahmen, die einer Plausibilitätsprüfung
standhalten (st. BGH-Linie; Az. vor Ausgabe verifizieren).

**Fehler 4 — Pensionsrückstellungen und latente Steuern falsch angesetzt**
Pensionsrückstellungen sind versicherungsmathematisch (nicht nach HGB-Abzinsung) zu
bewerten. Latente Steueransprüche sind nur insoweit aktivierbar, als sie bei Liquidation
tatsächlich realisierbar sind; latente Steuerschulden aus stillen Reserven müssen passiviert
Quellenregel: Keine Kommentar-, Handbuch-, Aufsatz- oder Tabellenfundstellen aus Modellwissen; nur Nutzerquelle, amtliche/freie Quelle oder lizenzierte Live-Verifikation verwenden.

**Fehler 5 — Eventualverbindlichkeiten vergessen**
Bürgschaften, Haftungsübernahmen und sonstige Eventualverbindlichkeiten müssen nach
Inanspruchnahmewahrscheinlichkeit bewertet und passiviert werden. Ihr Fehlen im Status
führt zu systematischer Untererfassung der Passiva.

**Fehler 6 — Prognosezeitraum verwechselt**
Seit 01.01.2024 gilt wieder der 12-Monats-Zeitraum. Die SanInsKG-Verkürzung auf
vier Monate ist ausgelaufen. Prognosezeitraum-Fehler infizieren die gesamte Prüfung.

**Fehler 7 — Fortbestehensprognose mit Sanierungskonzept verwechseln**
Eine positive Liquiditätsprognose beseitigt den Überschuldungsgrund, beweist aber noch
nicht, dass das Geschäftsmodell dauerhaft saniert ist. Für Sanierungsfähigkeit sind
Krisenursachen, Leitbild, Maßnahmen, integrierte Planung, Sensitivitäten und Nachweise
gesondert zu dokumentieren.

## Quellenpflicht

Jede Aussage zu Prüfungsmaßstäben, Bewertungsmethoden oder Rechtsfolgen ist zu belegen.
Mindeststandard:

- Grundlegende BGH-Linie zu Anforderungen an die Fortbestehensprognose (Plausibilität, Liquiditätsplanung): Aktenzeichen und Datum vor Ausgabe über dejure.org / openjur.de verifizieren.
- BGH-Linie zur Bewertung im Überschuldungsstatus (Liquidationswerte, stille Reserven): Az. vor Ausgabe verifizieren.
- BGH-Linie zur Abgrenzung handels- vs. insolvenzrechtliche Überschuldung: Az. vor Ausgabe verifizieren.
- Grundlegende BGH-Linie zum qualifizierten Rangrücktritt nach § 19 Abs. 2 S. 2 InsO: Az. vor Ausgabe verifizieren.
- **BGH IX ZR 285/14 vom 26.01.2017** (Steuerberater-Hinweispflicht) und **BGH IX ZR 56/22 vom 29.06.2023** (Drittschutz) relevant für die Berater-Position bei Erstellung der Prognose.
 <https://dejure.org/dienste/vernetzung/rechtsprechung?Gericht=BGH&Datum=26.01.2017&Aktenzeichen=IX+ZR+285/14>
 <https://dejure.org/dienste/vernetzung/rechtsprechung?Gericht=BGH&Datum=29.06.2023&Aktenzeichen=IX+ZR+56/22>
- Quellenregel: Keine Kommentar-, Handbuch-, Aufsatz- oder Tabellenfundstellen aus Modellwissen; nur Nutzerquelle, amtliche/freie Quelle oder lizenzierte Live-Verifikation verwenden.
- Quellenregel: Literatur nur mit Nutzerquelle oder lizenziertem Live-Zugriff; keine Kommentar-, Handbuch- oder Aufsatzfundstellen aus Modellwissen.
- Berufsständischer Methodenrahmen zu Insolvenzeröffnungsgründen und Sanierungskonzepten nur als Arbeitsmaßstab; keine Literaturfundstellen ohne Nutzerquelle oder lizenzierten Live-Zugriff.

---
*Dieser Skill ersetzt keine konkrete anwaltliche Beratung im Einzelfall.*

## Triage — Ueberschuldungs-Prüfung § 19 InsO

Bevor losgelegt wird, klaere:

1. **Bilanzieller Status?** Aktiva kleiner als Passiva auf Basis von Fortfuehrungswerten (erste Stufe)?
2. **Stille Reserven?** Grundstuecke, Beteiligungen, Patente zum Verkehrswert hoeher als Buchwert?
3. **Sanierungsmassnahmen einbezogen?** Rangrücktritt, Patronatserklaerung, Kapitalzufuhr — bereits wirksam oder nur geplant?
4. **Fortbestehensprognose positiv?** Dann keine Ueberschuldung trotz negativem Reinvermoegen (§ 19 Abs. 2 S. 1 InsO).
5. **Frist?** Ueberschuldung erkannt → Antragspflicht § 15a InsO: 6 Wochen.

## Output-Template Ueberschuldungs-Memo

**Adressat:** Geschäftsführung / Insolvenzgericht — Tonfall: sachlich-betriebswirtschaftlich

```
UEBERSCHULDUNGSSTATUS nach § 19 InsO
Gesellschaft: [FIRMA] Stichtag: [DATUM]

STUFE 1 — BILANZIELLER STATUS (Fortfuehrungswerte)
Aktiva (Verkehrswerte): EUR [BETRAG]
- Sachanlagen: EUR [...]
- Forderungen: EUR [...]
- Liquide Mittel: EUR [...]
Passiva: EUR [BETRAG]
- Eigenkapital: EUR [...]
- Fremdkapital: EUR [...]
BILANZIELLES REINVERMOEGEN: EUR [positiv / negativ]

STUFE 2 — FORTBESTEHENSPROGNOSE
Ergebnis Prognose: [POSITIV / NEGATIV]
Grundlage: [IDW S 11 / Eigenprognose / Liquiditaetsplanung]

ERGEBNIS:
[Ueberschuldung i.S.d. § 19 InsO: JA / NEIN]
[Antragspflicht: JA ab [DATUM] / NEIN]
```

<!-- BEGIN ausformulierungspflicht (autogen) -->
> **Ausformulierungspflicht und Formatstandard.** Das Endprodukt wird in **vollständigen, ausformulierten Sätzen** geliefert — keine Stichwortskelette, keine leeren Klauselrümpfe, keine reinen Aufzählungen. Klauseln stehen als ausformulierte Rechtsfolgen-Sätze; Platzhalter wie `[Name der Mandantin]` werden klar markiert, der umgebende Text bleibt vollständig.
>
> **Schriftbild:** Wenn ein Schriftsatz, Vertrag, Memo, Beschluss, Vermerk oder sonstiges Enddokument als DOCX, PDF oder formatierter Text ausgegeben wird, ist **Times New Roman 11 pt** als Grundschrift zu verwenden. Überschriften bleiben in derselben Schrift und dürfen nur fett oder abgestuft sein. Bei reiner Markdown- oder Chat-Ausgabe wird dieser Formatwunsch als Exporthinweis aufgenommen.
>
> **Nummerierung:** Gliederung ausschließlich dezimal (`1`, `1.1`, `1.1.1` und so weiter). Keine römischen Ziffern, keine Buchstaben- oder Mischgliederung.
<!-- END ausformulierungspflicht (autogen) -->
