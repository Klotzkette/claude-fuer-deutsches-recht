---
name: sanierungsgewinn-eigenverwaltung-und-cra
description: "Für Sanierungsgewinn — Eigenverwaltung und CRO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Sanierungsgewinn — Eigenverwaltung und CRO

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Sanierungsgewinn — Eigenverwaltung und CRO` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Worum geht es

Bei der Eigenverwaltung (Paragraph 270 ff. InsO) bleibt die Geschäftsleitung der Schuldnerin im Amt; ein Sachwalter ueberwacht. Die Verantwortung für den Steuerteil bleibt also bei der Schuldnergesellschaft selbst — sie muss die Modellrechnung Paragraph 3a Absatz 3 EStG aufstellen, die vier Voraussetzungen dokumentieren und die Antraege stellen. Der Sachwalter ist nicht "Steuerberater der Masse", sondern Aufsicht.

In groesseren Verfahren wird oft ein CRO (Chief Restructuring Officer) bestellt. Der CRO ist faktisch die operative Spitze für die Sanierung und entscheidet über den Steuerteil mit. Sein Haftungsstatus haengt von der vertraglichen Konstruktion ab — meist Vorstand/Geschäftsführer, manchmal nur Berater.

Ordnet die Rollen und gibt Praxistipps. Adressat: Geschäftsführer in Eigenverwaltung, CRO, Sachwalter, StB.

## Wann dieses Modul hilft / Kaltstart-Fragen

- Eigenverwaltung ist angeordnet (Paragraph 270 InsO).
- CRO ist bestellt oder soll bestellt werden.
- Geschäftsleitung weiss nicht, wer in der Sanierungssteuer den Hut auf hat.

Kaltstart-Fragen:

1. Status: vorläufige Eigenverwaltung (Paragraph 270c InsO), Eigenverwaltung im eroeffneten Verfahren, Schutzschirm (Paragraph 270d InsO)?
2. CRO bestellt? Als Vorstand/GF oder nur als Berater?
3. Sachwalter benannt?
4. StB des Schuldners eingebunden?
5. Stand des Plan-Entwurfs?

## Rechtlicher Rahmen

- Paragraphen 270 ff. InsO — Eigenverwaltung.
- Paragraph 270b InsO — Antrag.
- Paragraph 270c InsO — vorläufige Eigenverwaltung.
- Paragraph 270d InsO — Schutzschirm.
- Paragraphen 274 ff. InsO — Sachwalter.
- Paragraphen 277, 280 InsO — Aufsicht und Haftung Sachwalter.
- Paragraph 35 GmbHG, Paragraph 76 AktG — Geschäftsleitung.
- Paragraph 3a EStG — Sanierungsertrag.
- Paragraph 69 AO — Haftung Vertreter für Steuern.

## Rollenverteilung im Eigenverwaltungsverfahren

| Rolle | Verantwortung Steuerteil | Haftung |
|---|---|---|
| Geschäftsleitung (GF, Vorstand) | volle Verantwortung; Plan-Vorbereitung im Steuerteil | Paragraph 43 GmbHG, Paragraph 93 AktG; Paragraph 69 AO |
| CRO als Vorstand/GF | wie Geschäftsleitung | wie Geschäftsleitung |
| CRO als Berater | Beratungspflichten; keine Vertretungsmacht | Berater-Haftung, ggf. Paragraph 826 BGB |
| Sachwalter | Aufsicht; keine eigene Steuerantragspflicht | Paragraph 280 InsO bei Aufsichtsversaeumnissen |
| StB Schuldner | klassisches Mandat zur Steuererklaerung und Beratung | Paragraph 280 BGB Beratungshaftung; ggf. Paragraph 69 AO |
| Gläubigerausschuss | Aufsicht und Mitsprache bei Plan | Paragraph 71 InsO |

## / Schritt für Schritt

1. **Rolle und Verantwortlichkeit klären.** Wer entscheidet, wer berichtet, wer haftet?
2. **CRO-Vertrag prüfen.** Insbesondere: Vertretungsmacht, Haftungs-Cap, Versicherungsdeckung.
3. **Steuerteil delegieren.** StB des Schuldners aktiv halten; CRO/GF in der Verantwortung.
4. **Pflichten gegenueber Sachwalter.** Sachwalter regelmaessig informieren — er muss die Aufsicht ausuebbar haben.
5. **Plan-Entwurf abstimmen.** Steuerteil mit StB durchgehen; Voraussetzungs-Belege bereitstellen.
6. **Gläubigerausschuss einbeziehen** — bei Plan-Steuerteil Zustimmung holen.
7. **Antraege rechtzeitig stellen** (siehe Schwester-Skills).

## Trade-off-Matrix Eigenverwaltung vs. Regelverfahren (steuerlich)

| Punkt | Eigenverwaltung | Regelverfahren |
|---|---|---|
| Verantwortung Steuerteil | Schuldnergesellschaft selbst | Insolvenzverwalter |
| StB-Mandat | Schuldner haelt das Mandat | IV kann StB beauftragen |
| Sanierungsabsicht der Gläubiger | im Plan / Klassen-Voting belegbar | im Gläubigerausschuss-Protokoll |
| CRO als Hebel | typisch | seltener |
| Haftungssphaere | GF, ggf. CRO, Sachwalter (Aufsicht) | IV (Paragraph 60 InsO) |
| Vorabauskunft Paragraph 89 AO | direkt durch Schuldnergesellschaft | durch IV |
| Verlustvortrag-Modellrechnung | StB des Schuldners | StB beauftragt durch IV |

## Praxistipps der alten Hasen

1. **CRO-Vertrag klar fassen.** Wenn der CRO als Vorstand bestellt ist, haftet er wie ein Vorstand. Wenn er nur Berater ist, kann er nicht in der Vertretung handeln — und die GF haftet vollumfaenglich.
2. **Steuerteil schriftlich an StB delegieren.** Aktennotiz mit klarer Aufgabenverteilung: Modellrechnung, Voraussetzungs-Dokumentation, Antrag.
3. **Sachwalter ist nicht IV.** Wer als GF unterstellt, der Sachwalter "kuemmere sich" um den Steuerteil, hat das Verfahren falsch verstanden.
4. **Schutzschirm Paragraph 270d InsO** verschafft Zeit, aber lässt die Steuerpflichten unberuehrt.
5. **D-und-O-Versicherung prüfen.** Im Eigenverwaltungsverfahren ist die D-und-O-Deckung haeufig die letzte Schutzlinie der GF. Versicherung frueh informieren.

## Mustertexte / Berechnungsbeispiele

**Interne Steuerungsnotiz — Eigenverwaltung Steuerteil:**

```
INTERNE STEUERUNGSNOTIZ EIGENVERWALTUNG
Verfahren: [AZ]
Schuldnerin: [Name]
Stand: [Datum]

1. Rolle
- Geschaeftsfuehrer: [Name]
- CRO: [Name] (Status: Vorstand/Geschaeftsfuehrer/Berater)
- Sachwalter: [Name]

2. Steuerteil-Aufgabenverteilung
- Modellrechnung Paragraph 3a Absatz 3 EStG: StB [Name], Frist [...]
- Vier-Voraussetzungs-Doku: GF in Abstimmung mit Plan-Anwalt [Name]
- Vorabauskunft Paragraph 89 AO: GF zusammen mit StB
- Paragraph 7b GewStG-Antrag: StB

3. Reporting
- Wochenreporting an Sachwalter
- Glaeubigerausschuss-Information vor Plan-Vorlage

4. Versicherung
- D-und-O-Deckung [Versicherer] mit Schaden-Nr. [...]; Anzeige der
 Sanierungslage am [Datum] erfolgt.

5. Risiken
[...]
```

**CRO-Vertrag — relevante Klausel (Geruest):**

```
§ X Bestellung
Der CRO wird zum Geschaeftsfuehrer der Schuldnerin bestellt. Er
uebernimmt die Geschaeftsfuehrungsaufgaben gemaess GmbHG / AktG.

§ Y Sanierungsverantwortung
Der CRO ist insbesondere für die Vorbereitung und Durchfuehrung der
Sanierungs-Massnahmen verantwortlich, einschliesslich der steuerlichen
Vorbereitung des Sanierungsertrags und der Antragsmechanik nach
Paragraph 3a EStG und Paragraph 7b GewStG.

§ Z Versicherung
Der CRO wird in die bestehende D-und-O-Versicherung der Schuldnerin
einbezogen; Versicherungsumfang und -summe siehe Police vom [Datum].
```

## Typische Fehler

1. Annahme, Sachwalter sei für Steuerteil zuständig — falsch, er ist nur Aufsicht.
2. CRO nur als Berater bestellt, aber als Geschäftsführer behandelt — Vertretungsmacht fehlt.
3. StB des Schuldners nicht in die Sanierungs-Diskussion einbezogen.
4. Gläubigerausschuss nicht zum Steuerteil angehoert.
5. D-und-O-Versicherung erst nach Schaden informiert.
6. Annahme, Eigenverwaltung schliesse Paragraph 3a EStG aus — falsch, Paragraph 3a EStG ist Eigenverwaltungs- und Plan-Variante neutral.

## Quellen Stand 06/2026

- Paragraphen 270, 270b, 270c, 270d, 274 ff., 277, 280 InsO.
- Paragraph 43 GmbHG.
- Paragraph 93 AktG.
- Paragraph 69 AO.
- Paragraph 3a EStG.
- Paragraph 7b GewStG.
- Zitierweise und Quellenpruefung siehe `references/zitierweise.md`.
