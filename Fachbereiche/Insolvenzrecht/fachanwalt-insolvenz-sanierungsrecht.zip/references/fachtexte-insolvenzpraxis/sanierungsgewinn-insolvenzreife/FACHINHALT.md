---
name: sanierungsgewinn-insolvenzreife
description: "Für Sanierungsgewinn — Massehaftungsbefreiung und Bilanzbuchung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Sanierungsgewinn — Massehaftungsbefreiung und Bilanzbuchung

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Sanierungsgewinn — Massehaftungsbefreiung und Bilanzbuchung` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Worum geht es

Wenn der Insolvenzplan Forderungsverzichte vorsieht und der bestaetigte Plan rechtskraeftig wird, ist die Bilanz des Schuldners (Steuerbilanz, Handelsbilanz, ggf. IFRS) entsprechend anzupassen. Der bilanzielle Vorgang entscheidet über:

- die Höhe des Sanierungsertrags,
- die latenten Steuern,
- die Behandlung stiller Reserven,
- die Haftung des Verwalters für die korrekte Buchung (Paragraph 60 InsO).

Dieser Skill arbeitet die Buchung Schritt für Schritt und liefert Prüfvermerke. Adressat: StB des Schuldners, IV/Sachwalter und ggf. Wirtschaftspruefer.

## Wann dieses Modul hilft / Kaltstart-Fragen

- Plan ist bestaetigt; Bilanz für das Sanierungsjahr aufzustellen.
- Wirtschaftspruefer fragt im Vorfeld der Prüfung an, welche Buchungen anstehen.
- IV will sich gegen den Vorwurf einer Massehaftungsverletzung absichern.

Kaltstart-Fragen:

1. Welche Forderungen wurden im Plan verzichtet (Liste, Höhe, Gläubiger)?
2. Welche werthaltigen Forderungen wurden umgewandelt (DES)?
3. Wie hoch sind die stillen Reserven der Schuldnerin?
4. Wurde Buchwertfortfuehrung oder Bewertungsanpassung beschlossen?
5. Welcher Rechnungslegungsstandard greift (HGB, IFRS)?

## Rechtlicher Rahmen

- Paragraphen 246, 252, 266, 272 HGB.
- Paragraph 5 EStG, insbesondere Massgeblichkeit Paragraph 5 Absatz 1 EStG.
- Paragraph 5 Absatz 2a EStG — Passivierungsverbot bei qualifiziertem Rangrücktritt.
- Paragraph 3a EStG — Sanierungsertrag steuerlich.
- Paragraph 60 InsO — Haftung IV.
- Paragraph 55 InsO — Masseverbindlichkeiten.

## / Schritt für Schritt

1. **Bestandsaufnahme** aller im Plan adressierten Verbindlichkeiten.
2. **Buchungssystematik festlegen** je Verzichtsart (siehe `insol-sanierungsgewinn-verzicht-bilanz-im-plan`).
3. **Stille Reserven**: separat dokumentieren; keine Vermengung mit Sanierungsertrag.
4. **Latente Steuern**: prüfen, ob durch den Verzicht und die Nutzung der Verlustvortraege ein latenter Steuereffekt entsteht.
5. **Belege für Massehaftungsbefreiung sammeln.** Plan, Bestaetigungsbeschluss, Werthaltigkeitsgutachten, StB-Schreiben, Gläubigerausschuss-Beschluss.
6. **Bilanz-Prüfvermerk** mit ausweisbarem Sanierungsertrag.
7. **Steuererklaerung** mit Paragraph 3a EStG-Antrag und Paragraph 7b GewStG-Antrag.

## Trade-off-Matrix Bilanz-Optionen

| Bilanz-Option | Wirkung | Risiko |
|---|---|---|
| Buchwertfortfuehrung Aktiva | stille Reserven verbleiben | spaetere Veraeusserungs-/Auflassungsgewinne hoeher |
| Bewertungsanpassung (Stand Sanierung) | stille Reserven werden aufgedeckt | sofortige Gewinnrealisierung; kein Sanierungsertrag |
| Erfolgswirksamer Sanierungsertrag (Verzicht) | Eigenkapital steigt; Sanierungsertrag entsteht | Paragraph 3a EStG-Prüfung; Restbetrag ggf. steuerbar |
| Kapitalruecklage (Gesellschafter-Verzicht werthaltig) | kein Sanierungsertrag | Werthaltigkeitspruefung pflichtig |
| Auflosung Verbindlichkeit nach Rangrücktritt Paragraph 5 Absatz 2a EStG | spaetere Auflosung kann Ertrag erzeugen | Klausel-Gestaltung kritisch |
| IFRS-Sicht (IFRS 9, IAS 32) | abweichend von HGB möglich | Konzern-Bilanzierung zu prüfen |

## Praxistipps der alten Hasen

1. **Buchwertfortfuehrung ist Regel im Plan.** Wer aufdeckt, riskiert zusaetzliche Steuern, die nicht von Paragraph 3a EStG getragen werden.
2. **Latente Steuern bei Verlustvortrag-Verbrauch.** Werden Verlustvortraege durch Sanierungsertrag aufgezehrt (Paragraph 3a Absatz 3 EStG), entfallen aktive latente Steuern, die ggf. zuvor bilanziert waren — als Aufwand zu erfassen.
3. **Werthaltigkeitsgutachten pro Gesellschafterforderung** dokumentieren. Pauschale Annahmen halten der FA-Prüfung nicht stand.
4. **Stille Reserven listen.** Eine Tabelle stille Reserven (Aktiva-Position, Buchwert, gemeiner Wert, Differenz) gehoert in jede Sanierungsakte.
5. **Wirtschaftspruefer fruehzeitig einbinden.** Bei pruefungspflichtigen Unternehmen ist eine "Aha"-Reaktion des WP im Prüfungstermin der falsche Zeitpunkt.
6. **HGB versus Steuerbilanz dokumentieren.** Ueberleitungsrechnung Paragraph 5b EStG sauber halten.

## Mustertexte / Berechnungsbeispiele

**Buchungsbeleg (verkuerzt):**

```
BUCHUNGSBELEG SANIERUNGSERTRAG
Datum: [Tag der Rechtskraft Bestaetigungsbeschluss]
Mandant: [Schuldnerin]
Buchungstext: Sanierungsertrag aus Forderungsverzicht laut bestaetigtem
Plan Aktenzeichen [...]

Soll: Verbindlichkeiten 1700 ff. (Aufstellung Anlage 1) EUR x
Haben: Ausserordentlicher Ertrag 5750 (Sanierungsertrag) EUR x

Davon Gesellschafter-Verzicht werthaltig (Einlage):
Soll: Verbindlichkeiten Gesellschafter EUR y
Haben: Kapitalruecklage 2110 EUR y

Beleg Anlagen: Bestaetigungsbeschluss, Plan, Werthaltigkeits-
gutachten WP [Name].
```

**Prüfvermerk Bilanz (Geruest):**

```
PRUEFVERMERK BILANZ ZUM [Stichtag]
Mandant: [Schuldnerin]
StB: [Name]

1. Sachverhalt
Mit Bestaetigungsbeschluss vom [Datum] wurde der Insolvenzplan
rechtskraeftig. Das Plan-Volumen Forderungsverzicht: EUR [Betrag].

2. Bilanz-Erfassung
2.1 Drittglaeubiger-Verzicht endgueltig:
 EUR x als ausserordentlicher Ertrag (Sanierungsertrag).
2.2 Gesellschafter-Verzicht werthaltig:
 EUR y als Kapitalruecklage.
2.3 Gesellschafter-Verzicht nicht werthaltig:
 EUR z als ausserordentlicher Ertrag (Sanierungsertrag).
2.4 Stille Reserven Aktiva:
 Tabelle in Anlage S1; keine Aufdeckung (Buchwertfortfuehrung).

3. Steuerliche Behandlung
3.1 Paragraph 3a EStG-Antrag laeuft, Restsanierungsertrag EUR [...].
3.2 Paragraph 7b GewStG-Antrag laeuft, Restbetrag EUR [...].
3.3 Latente Steuern: Aufloesung aktiver latenter Steuern EUR [...] als
 Steueraufwand.

4. Massehaftungsbefreiung
Buchung erfolgt auf Basis Plan, WP-Gutachten und StB-Pruefung. Aktenstand:
- Plan, Bestaetigungsbeschluss
- Werthaltigkeitsgutachten WP [Name] vom [Datum]
- Glaeubigerausschuss-Beschluss vom [Datum]
- Aktennotiz Verrechnungsreihenfolge Paragraph 3a Absatz 3 EStG.
```

## Typische Fehler

1. Buchung als "ausserordentlicher Ertrag" pauschal, ohne Werthaltigkeitspruefung beim Gesellschafterverzicht.
2. Stille Reserven mit Sanierungsertrag vermengt.
3. Latente Steuern aus Verlustvortrag nicht aufgeloest.
4. HGB- und Steuerbilanz nicht abgestimmt — Ueberleitung Paragraph 5b EStG fehlt.
5. IFRS-Bilanz parallel uebersehen.
6. Bei Plan-Cramdown auf Anteilseigner (Paragraph 225a Absatz 3 InsO): Kapitalherabsetzung/-erhoehung bilanziell nicht abgebildet.

## Quellen Stand 06/2026

- Paragraphen 246, 252, 266, 272 HGB.
- Paragraph 5 EStG, Paragraph 5b EStG.
- Paragraph 3a EStG.
- Paragraph 7b GewStG.
- Paragraphen 55, 60, 225a InsO.
- Zitierweise und Quellenpruefung siehe `references/zitierweise.md`.
