---
name: sanierungsgewinn-finanzamt-im-insolvenzverfahren
description: "Für Sanierungsgewinn — Finanzamt im Insolvenzverfahren: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Sanierungsgewinn — Finanzamt im Insolvenzverfahren

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Sanierungsgewinn — Finanzamt im Insolvenzverfahren` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Worum geht es

Das Finanzamt ist im Insolvenzverfahren ein Gläubiger wie jeder andere — nicht mehr. Die Privilegierung des Fiskus aus frueheren Zeiten ist abgeschafft. Aber das Finanzamt ist ein Gläubiger mit besonderen verfahrensrechtlichen Werkzeugen: Aufrechnung, Festsetzungsbescheid, Vollstreckungsanordnung. Im Sanierungs-Kontext kommt eine zusaetzliche Rolle hinzu: das FA entscheidet über die Anwendung Paragraph 3a EStG und Paragraph 7b GewStG.

Dieser Skill arbeitet die FA-Schnittstelle im Verfahren durch. Adressat: IV, Sachwalter, StB, Plan-Anwalt.

## Wann dieses Modul hilft / Kaltstart-Fragen

- Verfahren ist eroeffnet; FA-Forderungen sind zu klassifizieren.
- Sanierungsplan wird vorbereitet; FA-Position zum Sanierungsertrag ist zentral.
- FA hat aufgerechnet oder vollstreckt; Prüfung der Zulaessigkeit.

Kaltstart-Fragen:

1. Welche Steuerforderungen sind angemeldet (Art, Höhe, Zeitraum)?
2. Welche Forderungen entstanden vor Eroeffnung, welche danach?
3. Hat das FA aufgerechnet (Paragraph 96 InsO)?
4. Welche Steuern entstehen aus der Verwaltung der Masse?
5. Liegen bereits Bescheide vor, die strittig sind?

## Rechtlicher Rahmen

- Paragraph 251 AO — Steuerforderungen im Insolvenzverfahren.
- Paragraph 251 Absatz 2 AO — Aufrechnungsbeschraenkungen im Insolvenzverfahren.
- Paragraph 35 InsO — Massezugehoerigkeit.
- Paragraphen 38, 39 InsO — Insolvenzforderungen, Nachrang.
- Paragraph 55 InsO — Masseverbindlichkeiten.
- Paragraphen 174 ff. InsO — Forderungsanmeldung.
- Paragraph 96 InsO — Aufrechnungsverbote.
- Paragraph 226 AO — Aufrechnung mit Steuerforderungen.
- Paragraph 3a EStG, Paragraph 7b GewStG.

## / Schritt für Schritt

1. **Steuerforderungen klassifizieren.**
 - Vor Eroeffnung entstanden -> Insolvenzforderung Paragraph 38 InsO, zur Tabelle.
 - Nach Eroeffnung aus Verwaltung -> Masseverbindlichkeit Paragraph 55 InsO.
 - Nicht erfuellt verbliebene Anmeldungen -> Prüfung Paragraph 175 InsO.
2. **Aufrechnung prüfen.** Wenn das FA bereits aufgerechnet hat, Paragraph 96 InsO prüfen — Aufrechnungsverbote.
3. **Vollstreckungsverbot Paragraph 89 InsO** beachten — auch FA darf nicht in die Masse vollstrecken.
4. **Sanierungs-Antraege rechtzeitig stellen.** Vorabauskunft Paragraph 89 AO; mit Steuererklaerung Antrag Paragraph 3a EStG.
5. **Verhandlungslinie mit FA aufbauen.** Erlassantrag Paragraph 227 AO, Stundungsantrag Paragraph 222 AO.
6. **Im Plan**: FA als Gläubiger der Insolvenzklasse oder eigene Klasse; Restbetraege nach Plan-Bestaetigung erlassen.

## Steuerforderungen klassifizieren

| Forderung | Klassifikation | Hinweis |
|---|---|---|
| KSt für Jahr vor Eroeffnung | Insolvenzforderung Paragraph 38 InsO | Anmeldung zur Tabelle |
| GewSt für Jahr vor Eroeffnung | Insolvenzforderung Paragraph 38 InsO | Gemeinde meldet an |
| USt aus Geschäftsbetrieb nach Eroeffnung | Masseverbindlichkeit Paragraph 55 Absatz 1 Nr. 1 InsO | Aus Masse zu zahlen |
| LSt für fortgefuehrte Beschäftigung | Masseverbindlichkeit Paragraph 55 InsO | Lohnzahlung loest LSt aus |
| KSt/GewSt auf Sanierungsertrag (verbleibender Restbetrag) | Masseverbindlichkeit Paragraph 55 InsO | erst nach Plan-Vollzug entstanden |
| GrESt auf Verwertung von Grundstuecken | Masseverbindlichkeit | aus Verwertung |
| Nicht beitreibbar versteuerte alte Schulden | bleibt offen | nach Restschuldbefreiung erlischt |

## Trade-off-Matrix Verhandlungen mit FA

| Option | Wann sinnvoll | Risiko |
|---|---|---|
| Paragraph 3a EStG-Antrag mit Steuererklaerung | Standard | FA prüfte Voraussetzungen genau |
| Vorabauskunft Paragraph 89 AO | bei hohem Volumen | Gebuehr, Zeitverzug |
| Stundungsantrag Paragraph 222 AO | wenn Restbetrag verbleibt | nur Aufschub |
| Erlassantrag Paragraph 227 AO | wenn Steuern unbillig | hohe Begruendungsanforderung |
| Tatsaechliche Verstaendigung Paragraph 78 AO | bei Beweisproblemen | nur für Tatfragen |
| Klage Finanzgericht | bei strittiger Rechtsfrage | langwierig |

## Praxistipps der alten Hasen

1. **FA-Forderungen pflegen.** Schnell klassifizieren, Tabellenanmeldung prüfen, Bestreitungen erwaegen.
2. **Aufrechnungsverbot Paragraph 96 InsO** hat enge Voraussetzungen — Prüfung im Einzelfall lohnt sich.
3. **FA-Vorabauskunft schriftlich.** Muendliche Aussagen des Sachbearbeiters sind kein Bindung.
4. **Plan-Klassenbildung prüfen.** FA kann als Gläubiger in eigene Klasse, was die Mehrheits-Mathematik vereinfacht.
5. **Aktenzeichen-Disziplin.** Im FA-Bereich gibt es Steuernummer + Vorgangs-Az + ggf. Vollstreckungs-Az. Alle zitieren.
6. **Nach Plan-Bestaetigung Schlussrechnung mit FA.** Restbetraege nach Plan-Quote können über Paragraph 227 AO erlassen werden.

## Mustertexte / Berechnungsbeispiele

**Anschreiben an Finanzamt nach Verfahrenseroeffnung:**

```
[Briefkopf IV/Sachwalter]

An das Finanzamt [Ort]
Steuernummer [...]

In dem Insolvenzverfahren ueber das Vermoegen der [Schuldnerin],
Aktenzeichen Amtsgericht [Ort] [AZ]

Sehr geehrte Damen und Herren,

mit Beschluss des Amtsgerichts [Ort] vom [Datum] wurde ueber das Vermoegen
der oben bezeichneten Schuldnerin das Insolvenzverfahren eroeffnet. Ich
bin zum Insolvenzverwalter / Sachwalter bestellt.

Ich erlaube mir folgende Hinweise:

1. Anmeldung zur Tabelle
Bestehende Steuerforderungen aus Veranlagungszeitraeumen vor dem [Datum]
sind als Insolvenzforderungen Paragraph 38 InsO zur Insolvenztabelle
anzumelden (Paragraph 251 Absatz 3 AO i.V.m. Paragraphen 174 ff. InsO).
Hierzu ist anliegender Anmeldebogen.

2. Aufrechnungsverbot
Soweit Aufrechnungen vor oder nach Eroeffnung erfolgten, weise ich auf die
Aufrechnungsverbote Paragraph 96 InsO hin und bitte um Pruefung.

3. Vollstreckungsverbot
Zwangsvollstreckungsmassnahmen sind nach Paragraph 89 InsO unzulaessig.
Soweit Massnahmen anhaengig sind, bitte ich um Einstellung.

4. Sanierungsplan
Ein Insolvenzplan ist in Vorbereitung. Hierbei wird der Sanierungsertrag
nach Paragraph 3a EStG / Paragraph 7b GewStG beantragt werden. Eine
Vorabauskunft nach Paragraph 89 AO werde ich gesondert beantragen.

Mit freundlichen Gruessen
[Unterschrift]
```

## Typische Fehler

1. Steuerforderungen falsch klassifiziert — z. B. nach Eroeffnung entstandene Steuern als Insolvenzforderung.
2. Aufrechnungsverbot Paragraph 96 InsO uebersehen — FA-Aufrechnung wird nicht angegriffen.
3. Vorabauskunft nur muendlich erfragt.
4. Vollstreckungsverbot Paragraph 89 InsO nicht eingelegt.
5. Bei Plan: FA in keine eigene Klasse — Mehrheitsmathematik verkompliziert.
6. Schluss-Erlassantrag nach Plan-Vollzug vergessen.

## Quellen Stand 06/2026

- Paragraph 251 AO, `gesetze-im-internet.de/ao_1977/__251.html`.
- Paragraph 226 AO, `gesetze-im-internet.de/ao_1977/__226.html`.
- Paragraphen 35, 38, 39, 55, 89, 96, 174 ff. InsO, `gesetze-im-internet.de/inso/`.
- Paragraph 3a EStG.
- Paragraph 7b GewStG.
- Zitierweise und Quellenpruefung siehe `references/zitierweise.md`.
