---
name: insolvenzgeld-165-sgb-iii
description: "Für Insolvenzgeld nach Paragraf 165 SGB III: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Insolvenzgeld nach § 165 SGB III

## Arbeitsbereich

Arbeitnehmer eines insolventen Unternehmens will Insolvenzgeld beantragen oder Insolvenzverwalter bearbeitet Insolvenzgeld-Anmeldungen. Prüfraster § 165 ff. SGB III Anspruchs-Voraussetzungen Arbeitsentgelt letzte drei Monate vor Insolvenz-Ereignis. Insolvenz-Ereignis § 165 Abs. 1 SGB III Eroeffnung Abweisung mangels Masse Vollstreckungs-Aussichtslosigkeit. Antragsfrist zwei Monate § 324 SGB III Vor-Finanzierung Banken bis 75 Prozent. Output Antragsentwurf Bescheinigung Abrechnung Schnittstelle Sozialversicherungs-Beitraege. Abgrenzung: forderungsanmeldung-gläubiger für allgemeine Forderungsanmeldung. Arbeite entlang dieser konkreten Prüfungslinie und trenne Rolle, Frist, Zuständigkeit, Beweislast und gewünschten Output.

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Insolvenzgeld nach § 165 SGB III` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Eingaben

- Insolvenz-Status Arbeitgeber (Antrag Eröffnung)
- Arbeitsverhältnis-Daten (Dauer Lohn Stunden)
- Lohnverzug-Zeitraum
- Bisher gezahlter Lohn
- Bei Mandant=Insolvenzverwalter: Mitarbeiter-Liste

## Schritt 1 — Anspruchs-Voraussetzungen § 165 SGB III

### Persönlich Berechtigte

- **Arbeitnehmer** im Sinne § 7 SGB IV
- **Auszubildende**
- **Heimarbeiter**
- Einschluss Mini-Job-Beschäftigte
- Einschluss Teilzeit

### Nicht berechtigt

- Geschäftsführer ohne Arbeitnehmer-Status
- Selbstständige
- Arbeitnehmer in Drittland-Filialen ohne deutschen Sozial-Versicherungs-Bezug

## Schritt 2 — Insolvenz-Ereignis § 165 Abs. 1 SGB III

### Drei Tatbestände

a) **Eröffnung des Insolvenz-Verfahrens** über Vermögen des Arbeitgebers

b) **Abweisung mangels Masse** § 26 InsO

c) **Vollständige Betriebs-Einstellung** im Inland, wenn ein Insolvenz-Antrag nicht gestellt worden ist und ein Insolvenz-Verfahren offensichtlich mangels Masse nicht in Betracht kommt

### Zeit-Punkt

- **Eröffnungs-Datum** als Insolvenz-Ereignis-Datum
- Bei Abweisung mangels Masse: Abweisungs-Beschluss
- Bei Betriebs-Einstellung: tatsächliche Einstellungs-Datum

## Schritt 3 — Anspruchs-Inhalt § 167 SGB III

### Lohn der letzten drei Monate

- **Rückwärts vom Insolvenz-Ereignis-Datum**
- Nur **noch nicht gezahltes Arbeitsentgelt**
- Brutto-Forderung bis Beitrags-Bemessungs-Grenze West / Ost

### Beispiel

```
Insolvenz-Ereignis (Eröffnung): 15.05.2026
Lohn-Forderungen:
- Februar 2026: bezahlt
- März 2026: nicht bezahlt (EUR 3.500)
- April 2026: nicht bezahlt (EUR 3.500)
- Mai 2026 anteilig: nicht bezahlt (EUR 1.700)

Anspruch Insolvenzgeld: 3 Monate
- Februar nicht relevant (bezahlt)
- Mitte Feb bis Mitte Mai = drei Monate
- Berechnung: EUR 3.500 × 2 + EUR 1.700 = EUR 8.700

Bei Beitrags-Bemessungs-Grenze (West EUR 7.550/Monat
in 2026) liegt EUR 3.500 darunter — voller Anspruch
```

### Brutto vs. Netto

- Insolvenzgeld in Höhe Netto-Anspruch
- Steuer und SV-Anteile separat berechnet
- Lohnsteuer-Klassen-bezogen

### Sonderzuwendungen

- Urlaubsgeld Weihnachtsgeld nur anteilig
- Bei Fälligkeit innerhalb der drei Monate
- Provisionen bei Fälligkeit

## Schritt 4 — Antragsverfahren

### Frist § 324 SGB III

- **Zwei Monate** ab Insolvenz-Ereignis
- **Nach-Antragsfrist sechs Monate** bei unverschuldeter Versäumnis
- Frist-Beginn bei Bekanntwerden Insolvenz-Ereignis

### Antragstellung

- **Agentur für Arbeit** zuständig
- **Online-Antrag** über BA-Webportal
- **Schriftlich** möglich

### Pflicht-Anlagen

- Arbeitsvertrag
- Lohn-Abrechnungen
- Bescheinigung Insolvenz-Verwalter (Lohn-Forderung)
- Lohn-Steuer-Karte / Identifikations-Nummer

### Bescheinigung Insolvenz-Verwalter

- **Pflicht** des Insolvenz-Verwalters auf Anfrage
- Inhalt: Lohn-Höhe Fälligkeit Erfüllungs-Stand
- Schnittstelle zur Forderungs-Anmeldung

## Schritt 5 — Insolvenzgeld-Anspruchs-Übergang § 169 SGB III

### Cessio Legis

- **Lohn-Forderung geht auf BA über** mit Zahlung Insolvenzgeld
- **Anmeldung zur Insolvenz-Tabelle** durch BA
- Insolvenz-Verwalter rechnet mit BA ab

### Folge für Insolvenz-Verwalter

- BA wird Gläubiger anstelle Arbeitnehmer
- Pflicht-Vermerk in Tabelle
- Quoten-Auszahlung an BA

### Folge für Arbeitnehmer

- **Insolvenzgeld** ohne Anmeldung in Tabelle
- Bei Differenz Lohn über Beitrags-Bemessungs-Grenze — Differenz selbst anmelden

## Schritt 6 — Vor-Finanzierung

### Praktische Konstellation

- Insolvenz-Verfahren dauert
- Arbeitnehmer braucht Geld sofort
- Vor-Finanzierung durch Bank

### Vor-Finanzierungs-Vereinbarung § 170 SGB III

- **Banken-Vorfinanzierung** bis 75 Prozent Insolvenzgeld
- **Abtretung** an Bank
- BA zahlt direkt an Bank

### Vorteil Arbeitnehmer

- Schnelle Liquidität
- Schon vor Insolvenz-Ereignis möglich (in der drei-Monats-Phase)

### Vorteil Insolvenz-Verfahren

- **Fortführungs-Möglichkeit** durch Lohn-Sicherung
- **Mitarbeiter-Bindung**
- Sanierungs-Chance

## Schritt 7 — Bei Eigenverwaltung

- Anspruch Insolvenzgeld bleibt
- Sachwalter unterstützt Anträge
- Schnellere Auszahlung möglich

## Schritt 8 — Sozial-Versicherungs-Beiträge § 173 SGB III

### Pflicht-Beiträge auf Insolvenzgeld

- **Renten-Versicherung** Krankenversicherung Pflege-Versicherung Arbeitslosen-Versicherung
- **BA übernimmt** Arbeitgeber-Anteil
- **Anwartschafts-Schutz** Arbeitnehmer

### Folge

- Keine Lücke in Sozial-Versicherungs-Karriere
- Renten-Punkte werden weitergeführt

## Schritt 9 — Anspruchs-Konkurrenz

### Kurzarbeitergeld

- Bei vor Insolvenz Kurzarbeit
- Anspruch Kurzarbeitergeld parallel möglich
- Anrechnung-Mechanismen

### Krankengeld

- Bei Erkrankung in Drei-Monats-Phase
- Krankengeld plus Insolvenzgeld theoretisch
- Vorrang-Regelungen

### Mutterschaftsgeld / Elterngeld

- Spezifische Regelungen
- Sozial-Versicherungs-Karten

### Vorruhestand / Frühverrentung

- Anspruch endet mit Renteneintritt
- Insolvenzgeld dazwischen möglich

## Schritt 10 — Praktische Konstellationen

### Konstellation A — Insolvenz-Verfahren eröffnet

- Klar: Antragsfrist läuft
- Insolvenz-Verwalter-Bescheinigung anfordern
- Antrag stellen

### Konstellation B — Insolvenz-Antrag gestellt aber noch nicht eröffnet

- Vor-Finanzierungs-Vereinbarung möglich
- Antragsfrist beginnt erst mit Eröffnung

### Konstellation C — Eröffnung verzögert sich

- Eilbedürftigkeits-Erklärung an Insolvenz-Gericht
- Vor-Finanzierung erwägen

### Konstellation D — Abweisung mangels Masse

- Insolvenz-Ereignis ist Abweisung
- Antragsfrist ab Abweisungs-Beschluss
- Häufig parallel zu fehlender Insolvenz-Verwalter-Bescheinigung — Eigenbescheinigung-Eskalation

### Konstellation E — Lohn-Verzug ohne Insolvenz-Antrag

- Kein Insolvenzgeld
- Lohn-Klage Arbeitsgericht
- Bei Vermögens-Aussichts-Losigkeit Insolvenz-Antrag möglicherweise

## Schritt 11 — Aufgaben Insolvenz-Verwalter

### Lohn-Erfassung

- Lohnkonten der letzten Monate prüfen
- Lohn-Forderungen exakt aufstellen
- Lohnsteuerkarten und SV-Daten besorgen

### Bescheinigung Insolvenzgeld

- Auf Anfrage Mitarbeiter
- Standardisiertes Formular
- Frist-eng (sieben Werktage)

### Lohn-Buchhaltung Übergang

- Übernahme der Lohn-Buchhaltung
- Steuer- und SV-Anmeldungen ggf.
- Pension-Verpflichtungen-Übergang an PSVaG

### Massearm-Konstellation

- Bei Abweisung mangels Masse keine Bescheinigung-Pflicht
- Arbeitnehmer-Eigenangabe möglich

## Schritt 12 — Bei Streit über Insolvenzgeld-Anspruch

### Widerspruch BA-Bescheid

- **Ein Monat** ab Bekanntgabe, § 84 Abs. 1 SGB X i. V. m. §§ 78 ff. SGG
- Begründung
- An BA selbst

### Klage SG

- Bei Widerspruchs-Bescheid abgelehnt
- **Ein Monat** Klage-Frist § 87 Abs. 1 SGG (drei Monate wäre § 88 SGG Untätigkeitsklage)
- PKH-Antrag empfohlen → Skill `pkh-erfolgsaussicht-pruefen`

### Häufige Streit-Punkte

- **Persönlicher Anwendungsbereich** (echte Arbeitnehmer-Eigenschaft?)
- **Berechnungs-Grundlage** (Pauschalen Provisionen)
- **Drei-Monats-Phase** korrekt berechnet?
- **Bezogen-Frist** § 324 versäumt?

## Schritt 13 — Schnittstelle Forderungs-Anmeldung Tabelle

### Forderungs-Anmeldung § 174 InsO

- Bei Insolvenzgeld-Übergang BA als Gläubiger
- Restbetrag Lohn (über Beitrags-Bemessungs-Grenze) Arbeitnehmer selbst
- Skill `glaeubigerantrag-pruefung`

### Rang (wichtige Korrektur)

- **Lohn-Forderungen aus der Zeit VOR Eröffnung** sind grundsätzlich **einfache Insolvenz-Forderungen** § 38 InsO mit Quoten-Risiko — auch wenn sie aus den letzten Monaten stammen
- **Masseverbindlichkeiten** sind nur:
 - Lohn aus **fortbestehendem** Arbeitsverhältnis NACH Verfahrens-Eröffnung → § 55 Abs. 1 Nr. 2 InsO
 - im Eröffnungs-Verfahren begründete Lohn-Ansprüche bei starkem vorläufigen Verwalter mit Verfügungs-Befugnis → § 55 Abs. 2 InsO
- Für Rückstände aus den drei Monaten vor Insolvenz-Ereignis greift das Insolvenzgeld § 165 SGB III; die Forderung selbst geht auf die BA über (§ 169 SGB III) und wird als § 38 InsO-Forderung angemeldet
- § 55 Abs. 2 InsO hilft NICHT pauschal für die "letzten sechs Monate vor Eröffnung" — das ist ein verbreiteter Irrtum

## Verzahnung mit anderen Skills

- `mandat-triage-insolvenzrecht` — Einstieg
- `arbeitsrecht-kaltstart-interview` — Arbeitsrechtliche Aspekte
- `kuendigungsschutzklage` — wenn parallel Kündigung
- `pkh-erfolgsaussicht-pruefen` — bei SG-Klage gegen BA-Bescheid
- `glaeubigerantrag-pruefung` — Forderungs-Anmeldung

## Ausgabe

- `insolvenzgeld-{az}.md` mit Anspruchs-Prüfung Antragsstellung
- BA-Antragsschrift
- Insolvenz-Verwalter-Bescheinigungs-Anforderung
- Bei Streit: Widerspruchs-/Klage-Vorbereitung
- Vor-Finanzierungs-Beratung
- Frist im Fristenbuch (zwei Monate Antrag, ein Monat Widerspruch, ein Monat Klage)

<!-- BEGIN ausformulierungspflicht (autogen) -->
> **Ausformulierungspflicht und Formatstandard.** Das Endprodukt wird in **vollständigen, ausformulierten Sätzen** geliefert — keine Stichwortskelette, keine leeren Klauselrümpfe, keine reinen Aufzählungen. Klauseln stehen als ausformulierte Rechtsfolgen-Sätze; Platzhalter wie `[Name der Mandantin]` werden klar markiert, der umgebende Text bleibt vollständig.
>
> **Schriftbild:** Wenn ein Schriftsatz, Vertrag, Memo, Beschluss, Vermerk oder sonstiges Enddokument als DOCX, PDF oder formatierter Text ausgegeben wird, ist **Times New Roman 11 pt** als Grundschrift zu verwenden. Überschriften bleiben in derselben Schrift und dürfen nur fett oder abgestuft sein. Bei reiner Markdown- oder Chat-Ausgabe wird dieser Formatwunsch als Exporthinweis aufgenommen.
>
> **Nummerierung:** Gliederung ausschließlich dezimal (`1`, `1.1`, `1.1.1` und so weiter). Keine römischen Ziffern, keine Buchstaben- oder Mischgliederung.
<!-- END ausformulierungspflicht (autogen) -->

## Quellen

- SGB III §§ 165 167 169 170 173 324
- SGB IV § 7
- SGG §§ 87 88; SGB X § 84
- InsO §§ 26 38 55 174
- BSG-Linien zu Insolvenzgeld
- Standes-Vorgaben Insolvenz-Verwalter zu Lohn-Bescheinigung

## Aktuelle Leitentscheidungen — Insolvenzgeld

- Konkrete BSG- und LSG-Entscheidungen zum Insolvenzgeld (insb. Anspruchsberechtigung Gesellschafter-Geschäftsführer, Drei-Monats-Frist, Vorfinanzierung) vor Ausgabe über sozialgerichtsbarkeit.de oder dejure.org mit Datum und Aktenzeichen verifizieren.
- Zur Schnittstelle § 142 InsO (Bargeschäft Lohnzahlungen) und Anfechtung: **BGH IX ZR 122/23 vom 05.12.2024** stellt klar, dass Lohnzahlungen ohne starre 30-Tage-Grenze auf engen zeitlichen Zusammenhang zu prüfen sind; bei Anfechtung des Verwalters gegen vorinsolvenzliche Lohnzahlungen ist die Unlauterkeit konkret darzulegen.
 Quelle: <https://dejure.org/dienste/vernetzung/rechtsprechung?Gericht=BGH&Datum=05.12.2024&Aktenzeichen=IX+ZR+122/23>

## Paragrafenkette Insolvenzgeld

§ 165 SGB III (Anspruchsvoraussetzungen) → § 166 SGB III (Höhe) → § 167 SGB III (Vorfinanzierung) → § 168 SGB III (Erloesch-Gruende) → § 26 InsO (Abweisung mangels Masse als Insolvenzereignis) → § 113 InsO (Kuendigungsrecht des IV)

## Triage — Insolvenzgeld

1. **Insolvenzereignis?** Datum der Verfahrenseroffnung oder Abweisung mangels Masse exakt festlegen.
2. **3-Monats-Zeitraum?** Welche Monate werden vom Insolvenzgeld abgedeckt? Lohnrueckstaende inventarisieren.
3. **Vorfinanzierung?** Haushausbank ansprechen; Abtretungserklaerungen der Arbeitnehmer einholen; Zeitplan Vorfinanzierung → Auszahlung BA.
4. **GF-Anspruch?** GF ist nur Arbeitnehmer wenn tatsaechlich weisungsgebunden; bei Gesellschafter-GF selten Insolvenzgeld.
