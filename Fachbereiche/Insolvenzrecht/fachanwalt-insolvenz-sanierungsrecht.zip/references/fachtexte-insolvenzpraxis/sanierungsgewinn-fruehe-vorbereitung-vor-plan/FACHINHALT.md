---
name: sanierungsgewinn-fruehe-vorbereitung-vor-plan
description: "Für Sanierungsgewinn — frühe Vorbereitung vor Insolvenzantrag oder StaRUG-Anzeige: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Sanierungsgewinn — fruehe Vorbereitung vor Insolvenzantrag oder StaRUG-Anzeige

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Sanierungsgewinn — fruehe Vorbereitung vor Insolvenzantrag oder StaRUG-Anzeige` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Worum geht es

Wer den Insolvenzplan oder den Restrukturierungsplan erst dann steuerlich denkt, wenn er bereits bei Gericht eingereicht ist, hat oft schon einen siebenstelligen Schaden produziert. Die Steuerfreiheit des Sanierungsertrags nach Paragraph 3a EStG haengt an vier materiellen Voraussetzungen (Sanierungsbeduerftigkeit, Sanierungsfaehigkeit, Sanierungseignung, Sanierungsabsicht der Gläubiger) und an einem Antrag, dessen Verrechnungsmasse nach Paragraph 3a Absatz 3 EStG **vor** Plan-Vorlage berechenbar sein muss.

Liefert die Zeitachse: Welche steuerliche Vorarbeit gehoert in welchen Monat? Wer ist verantwortlich? Welcher Output muss vor der Plan-Vorlage in der Akte liegen?

Adressat: Insolvenzverwalter, Sachwalter, Eigenverwalter, CRO, Geschäftsleitung in der Krise und ihre Steuerberater.

## Wann dieses Modul hilft / Kaltstart-Fragen

- Mandant ist Schuldnerunternehmen in der Krise, denkt über Insolvenzantrag oder StaRUG-Anzeige nach.
- Insolvenzverwalter wurde gerade bestellt und der Plan wird in den naechsten drei bis sechs Monaten vorbereitet.
- Beraterteam ist neu im Mandat und muss aufholen, was steuerlich seit Krisenbeginn versaeumt wurde.

Kaltstart-Fragen:

1. Welche Rechtsform hat das Schuldnerunternehmen (GmbH, AG, GmbH und Co. KG, Einzelunternehmer, natuerliche Person)?
2. Wann begann die Krise nach Ihrer Einschaetzung (Monat/Jahr)?
3. Liegt eine Fortbestehensprognose vor, wenn ja Stand wann?
4. Wie hoch ist der Forderungsverzicht der Gläubiger, der im Plan voraussichtlich erforderlich wird (Bandbreite reicht)?
5. Steuerliche Verlustvortraege Stand letzte verbindliche Veranlagung — bekannt?
6. Wer ist Steuerberater des Schuldners und ist er über die Sanierungsabsicht informiert?

Wenn nur drei der sechs Antworten vorliegen, beginnt die Arbeit am Zeitstrahl. Die fehlenden Antworten landen als Platzhalter `[noch zu klaeren: ...]` im ersten Entwurf.

## Rechtlicher Rahmen

- Paragraph 3a Absatz 1 EStG — Steuerbefreiung von Betriebsvermoegensmehrungen oder Betriebseinnahmen aus einem Schuldenerlass zum Zweck einer unternehmensbezogenen Sanierung.
- Paragraph 3a Absatz 2 EStG — vier Voraussetzungen: Sanierungsbeduerftigkeit, Sanierungsfaehigkeit, Sanierungseignung, Sanierungsabsicht der Gläubiger.
- Paragraph 3a Absatz 3 EStG — die zwingende Verrechnungsreihenfolge (vortragsfaehige Verluste, laufende Verluste, weitere Minderungspositionen). Wenn die Verrechnungsmasse den Sanierungsertrag vollstaendig aufzehrt, bleibt **kein steuerbarer Sanierungsgewinn** — gesonderter Erlassantrag dann obsolet.
- Paragraph 7b GewStG i.V.m. Paragraph 36 Absatz 2c GewStG — gewerbesteuerliche Parallelregelung.
- § 251 AO regelt die Vollstreckbarkeit von Verwaltungsakten. Absatz 2 wahrt die Vorschriften der Insolvenzordnung. Die Voraussetzungen einer Aussetzung der Vollziehung regeln § 361 AO und § 69 FGO. [§ 251 AO](https://www.gesetze-im-internet.de/ao_1977/__251.html) · [§ 361 AO](https://www.gesetze-im-internet.de/ao_1977/__361.html) · [§ 69 FGO](https://www.gesetze-im-internet.de/fgo/__69.html)
- Paragraphen 222, 227 AO — Stundung und Erlass.
- Paragraph 60 InsO — Haftung des Insolvenzverwalters für schuldhafte Pflichtverletzung.

## / Zeitachse mit Monaten und Antragspflichtigen

Die folgende Tabelle nimmt als Tag 0 den geplanten Tag der Plan-Einreichung oder Plan-Vorlage bei Gericht. Negative Monatszahlen sind die Vorbereitungsphase.

| Monat | Wer ist verantwortlich | Pflicht-Output | Hinweise |
|---|---|---|---|
| -9 bis -12 | Geschäftsleitung + StB | Krisenfrueherkennung dokumentieren (Liquiditaetsplanung, Fortbestehensprognose Entwurf) | Später ein zentraler Baustein für Sanierungsbeduerftigkeit. |
| -6 bis -9 | IV / Sachwalter / CRO | Verlustvortraege Bestandsaufnahme: Koerperschaftsteuer, Gewerbesteuer, ggf. Einkommensteuer | Bescheid-Kopien der letzten drei Veranlagungen. |
| -6 bis -9 | StB des Schuldners | Steuerliche Modellrechnung Paragraph 3a Absatz 3 EStG: wie viel Sanierungsertrag wird durch Verlustvortraege aufgezehrt? | Wenn Verlustvortraege das Volumen vollstaendig schlucken, ist die spaetere Steuerfreiheit weniger kritisch — Antrag bleibt aber wichtig. |
| -6 | IV / CRO | Externes Sanierungskonzept (IDW S 6 oder gleichwertig) beauftragen oder im Sachwaltermodell selbst aufsetzen | Belegt Sanierungsfaehigkeit + Sanierungseignung. |
| -4 bis -6 | IV / CRO + StB | Gläubiger-Kommunikation: Sanierungsabsicht aktenkundig machen (Protokollnotizen, Gläubigerausschuss-Beschluss, Briefe) | Sanierungsabsicht ist eine der vier Voraussetzungen — sie muss aus der Akte belegbar sein. |
| -3 bis -4 | StB + IV | Antragsraster nach Paragraph 3a EStG und Paragraph 7b GewStG vorbereiten | Antraege werden mit der Steuererklaerung des Sanierungsjahres gestellt. |
| -2 | IV + Plan-Anwalt | Plan-Entwurf in steuerlicher Hinsicht spiegelt die Verzichtsstruktur | Inhalt des darstellenden Teils muss alle vier Voraussetzungen sichtbar machen. |
| -1 | IV + StB | Pre-Filing-Abstimmung mit dem Finanzamt (Vorabauskunft, soweit möglich) | Verbindliche Auskunft Paragraph 89 AO kann sich lohnen, ist gebuehrenpflichtig. |
| 0 | IV / Plan-Anwalt | Plan-Einreichung | Steuerlich ist alles auf Knopfdruck dokumentierbar. |
| +1 bis +3 | IV + StB | Begleitung Erlassantrag oder Vorabauskunft FA, Vorbereitung Steuererklaerung | Erlassantrag braucht alle Vorab-Dokumente. |

## Trade-off-Matrix

| Entscheidung | fruehe Klärung (mehr als 6 Monate vor Plan) | spaete Klärung (weniger als 3 Monate vor Plan) |
|---|---|---|
| Verlustvortraege ermitteln | Ruhe, Beanstandungen FA klaerbar | Hektik, Bescheide oft strittig |
| Sanierungskonzept | substanzhaft, glaubwuerdig | hektisch, gläubigerseitig anzweifelbar |
| Gläubiger-Sanierungsabsicht | dokumentierbar | rekonstruktiv |
| Steuerliche Modellrechnung | iterierbar | Black Box |
| Verbindliche Auskunft | machbar | meist zu spaet |
| Haftungsrisiko IV/Sachwalter (Paragraph 60 InsO) | gering | erheblich |

## Praxistipps der alten Hasen

1. **Eine Tabelle, zwei Sichten.** Verlustvortraege koerperschaftsteuerlich und gewerbesteuerlich getrennt fuehren, weil Paragraph 7b GewStG eine eigene Antragsmechanik vorsieht.
2. **Sanierungsabsicht der Gläubiger ist eine Akten-Sache, kein Wille.** Die Voraussetzung ist erfuellt, wenn die Gläubiger im Plan dem Verzicht zustimmen, gerade weil die Sanierung sonst nicht funktioniert. Aktennotiz mit O-Ton aus Gläubigerversammlung hilft mehr als Theorie.
3. **Beraterhonorar fruehzeitig als Massehaftung sichern.** Die Beratung zu Sanierungsgewinn kostet — und der Berater haftet im Zweifel, wenn er die Modellrechnung nicht machte.
4. **Vorabauskunft ist nicht kostenlos, aber oft wirtschaftlich.** Bei Sanierungsertraegen oberhalb von rund einer Million EUR Vorabauskunft Paragraph 89 AO regelmaessig prüfen.
5. **Stille Reserven kennen.** Bei Buchwertfortfuehrung im Plan: stille Reserven können den Sanierungsertrag erhoehen oder mindern, je nach Buchungstechnik beim Verzicht.

## Mustertexte / Berechnungsbeispiele

**Aktenvermerk Prüfung Paragraph 3a EStG vor Plan-Einreichung (Geruest):**

```
AKTENVERMERK STEUERLICHE PRUEFUNG VOR PLAN-EINREICHUNG
Verfahren: [AZ]
Schuldner: [Name, Rechtsform]
Datum: [Datum]
Verfasser: [IV/Sachwalter] in Abstimmung mit [StB Name]

1. SACHVERHALT
- Krise begann ca. [Monat/Jahr]
- Forderungsverzicht im Plan voraussichtlich EUR [Betrag]
- Forderungsverzicht-Glaeubiger: [Liste, Hauptforderer]

2. VERLUSTVORTRAEGE STAND [Datum]
- KSt-Verlustvortrag: EUR [Betrag] (Bescheid vom [Datum])
- GewSt-Vortrag: EUR [Betrag] (Bescheid vom [Datum])
- ggf. laufende Verluste lfd. WJ: EUR [Betrag] (geschaetzt)

3. PARAGRAPH 3a ABSATZ 3 EStG MODELLRECHNUNG
- Sanierungsertrag voraussichtlich: EUR [Betrag]
- Abzgl. Minderungspositionen Paragraph 3a Absatz 3 EStG: EUR [Betrag]
- Verbleibender steuerbarer Restbetrag: EUR [Betrag]
=> Erlassbedarf gegen Steuer: [ja/nein]

4. PRUEFUNG DER VIER VORAUSSETZUNGEN
- Sanierungsbeduerftigkeit: [belegt durch Liquiditaetsplan vom ..., Fortbestehensprognose vom ...]
- Sanierungsfaehigkeit: [belegt durch IDW S 6 vom ...]
- Sanierungseignung: [belegt durch Plan-Entwurf vom ..., Quote ...]
- Sanierungsabsicht Glaeubiger: [belegt durch Glaeubigerausschuss-Protokoll vom ..., Briefe vom ...]

5. PARALLEL GewSt
- Paragraph 7b GewStG-Antrag: [vorbereitet, eingereicht am ...]

6. NAECHSTE SCHRITTE
- [...]
```

## Typische Fehler

1. Verlustvortraege erst nach Plan-Bestaetigung ermitteln — dann ist die Modellrechnung Paragraph 3a Absatz 3 EStG zu spaet.
2. Annahme, Sanierungsabsicht der Gläubiger sei "selbsterklaerend" — sie ist tatsaechlich zu dokumentieren.
3. Verbindliche Auskunft zu spaet beantragen — Finanzamt braucht Vorlaufzeit.
4. Paragraph 7b GewStG vergessen — der Gewerbesteuer-Antrag laeuft eigenstaendig.
5. Wahl des falschen Sanierungsbegriffs: nur die **unternehmensbezogene** Sanierung ist begnadigt, nicht die rein unternehmerbezogene.

## Quellen Stand 06/2026

- Paragraph 3a EStG, Bundesministerium der Justiz, `gesetze-im-internet.de/estg/__3a.html`.
- Paragraph 7b GewStG, `gesetze-im-internet.de/gewstg/__7b.html`.
- Paragraph 36 Absatz 2c GewStG, `gesetze-im-internet.de/gewstg/__36.html`.
- Paragraphen 251, 222, 227 AO, `gesetze-im-internet.de/ao_1977/`.
- Paragraph 60 InsO, `gesetze-im-internet.de/inso/__60.html`.
- FG Köln, Urteil vom 04.11.2025 - 12 K 1413/25: Eine Steuerbefreiung nach Paragraf 3a EStG setzt den Nachweis von Sanierungsbedürftigkeit, Sanierungsfähigkeit, Sanierungseignung, Sanierungsabsicht und betrieblicher Veranlassung des Schuldenerlasses voraus; die Eignung ist aus Sicht des Erlasszeitpunkts zu beurteilen.
- FG Koeln, Urteil vom 06.03.2012 — 13 K 3006/11, GmbHR 2012, 977 (vorgehend zu BFH I R 34/12) — Liquidation, Rangrücktritt und Steuerausfall mangels Koerperschaftsteuersubjekt; verifizierte Fundstelle für den Pfad Liquidation statt Plan.
- Zitierweise und Quellenpruefung siehe `references/zitierweise.md`.
