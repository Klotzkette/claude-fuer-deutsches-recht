---
name: glaeubigerantrag-glaeubigerausschuss
description: "Für Prüfung Gläubigerantrag nach Paragraf 14 InsO: erstellt Entwurf mit Antrag, Beweis und Anlagen; Ergebnis: Schriftsatz mit Begründungs- und Anlagenlogik."
---

# Prüfung Gläubigerantrag nach § 14 InsO

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Prüfung Gläubigerantrag nach § 14 InsO` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Eingaben

- Gläubigerseite: Art und Höhe der Forderung, Titulierungsstand, bisherige
 Vollstreckungsversuche, vorhandene Nachweise zum Eröffnungsgrund
- Schuldnerseite: Aktuelle Zahlungslage, verfügbare Liquidität, Stellungnahme zur
 bestrittenen Forderung, Bereitschaft zur sofortigen Zahlung oder zur Vorlage
 eines Sanierungskonzepts
- Verfahrensstatus: Liegt bereits ein Eigenantrag vor? Sind andere Gläubigeranträge
 anhängig? Gibt es ein laufendes StaRUG-Verfahren?

## Rechtlicher Rahmen

### Gesetzliche Grundlagen

**§ 14 Abs. 1 S. 1 InsO** legt die drei kumulativen Voraussetzungen des
Gläubigerantrags fest:

1. **Rechtliches Interesse** an der Eröffnung des Insolvenzverfahrens
2. **Glaubhaftmachung der Forderung** (Bestand, Fälligkeit, Höhe)
3. **Glaubhaftmachung des Eröffnungsgrundes** (§§ 17–19 InsO)

**§ 14 Abs. 1 S. 2 InsO** schützt das Antragsrecht bei vorausgegangener
Befriedigung: Wurde der Gläubiger in den letzten sechs Monaten vor Antragstellung
befriedigt, bleibt seine Antragsbefugnis gleichwohl bestehen, wenn die Befriedigung
als Insolvenzanfechtung nach §§ 129 ff. InsO angreifbar wäre. Dies verhindert den
"Taktikzahlungseinwand" des Schuldners, der kurz vor Verfahrenseröffnung
Teilzahlungen leistet, um den antragstellenden Gläubiger zu beseitigen, ohne die
Insolvenzlage zu beheben.

**§ 13 InsO** regelt Form und Inhalt des Antrags; für Gläubigeranträge gelten
ergänzend die §§ 14 ff. InsO.

**§ 26 InsO**: Weist das Gericht den Antrag mangels Deckung der Verfahrenskosten
ab (Abweisung mangels Masse), erfolgt die Eintragung im Schuldnerverzeichnis
(§ 882b ZPO) — eine eigenständige wirtschaftliche Sanktion.

**§ 56a InsO** gewährt dem Schuldner ein Vorschlagsrecht für den
Insolvenzverwalter, wenn er selbst Insolvenzantrag stellt. Dieses Recht entfällt
beim reinen Gläubigerantrag.

**§§ 17, 18, 19 InsO** definieren die antragsrelevanten Eröffnungsgründe:
Zahlungsunfähigkeit (§ 17), drohende Zahlungsunfähigkeit (§ 18, nur für
Schuldner-Eigenantrag) und Überschuldung (§ 19, juristische Personen).

### Rechtsprechung (Maßstab; Aktenzeichen vor Ausgabe über dejure.org / openjur.de verifizieren)

**Anforderungen an Glaubhaftmachung Forderung § 14 InsO:** Gläubiger muss Tatsachen darlegen, aus denen die überwiegende Wahrscheinlichkeit des Bestehens der Forderung folgt; vollständige Beweisführung nicht erforderlich. Zulässige Mittel: eidesstattliche Versicherung (§ 294 ZPO), Titel, Mahnbescheid, Kontoauszüge, Rechnungen mit Empfangsbestätigung.

**Indizien für Zahlungsunfähigkeit § 17 InsO:** fruchtlose Pfändungsversuche, Rückgabe von Lastschriften, Wechselproteste, Häufung von Mahnverfahren, Lohnsteuer- und SV-Rückstände, BWA mit negativem Saldo. Die Indizien dienen der Glaubhaftmachung der überwiegenden Wahrscheinlichkeit der ZU.

**Streitige Forderung:** Antrag zulässig, wenn nach § 294 ZPO glaubhaft gemacht; bloßes Bestreiten des Schuldners ohne substantiierten Gegenvortrag beseitigt die Glaubhaftmachung nicht.

**Missbräuchlicher Druckantrag:** Antrag, der allein der wirtschaftlichen Druckausübung dient, ist unzulässig; das rechtliche Interesse an der Eröffnung muss zur gerichtlichen Entscheidung noch bestehen.

Für aktuelle BGH-Linie zu allen vorgenannten Punkten Datum, Aktenzeichen und Randnummer vor Ausgabe über offene Quellen verifizieren.

### Quellen (nur verifiziert)

- Quellenregel: Keine Kommentar-, Handbuch-, Aufsatz- oder Tabellenfundstellen aus Modellwissen; nur Nutzerquelle, amtliche/freie Quelle oder lizenzierte Live-Verifikation verwenden.
 Antragsberechtigung, Glaubhaftmachung, Forderungserfordernis und Missbrauch)
- Hölzle, in: K. Schmidt, InsO, 20. Aufl. 2023, § 14 Rn. 1–55 (Dogmatik des
 rechtlichen Interesses, Zulässigkeit bei titulierter und nicht-titulierter
 Forderung, § 14 Abs. 1 S. 2 InsO)
- Quellenregel: Keine Kommentar-, Handbuch-, Aufsatz- oder Tabellenfundstellen aus Modellwissen; nur Nutzerquelle, amtliche/freie Quelle oder lizenzierte Live-Verifikation verwenden.
 Indizienbeweis, Glaubhaftmachungsstandard im Gläubigerantrag)

### IDW S 11

Der **IDW S 11 (Beurteilung des Vorliegens von Insolvenzeröffnungsgründen,
Stand 2017)** liefert das fachliche Rüstzeug zur Feststellung der
Zahlungsunfähigkeit (Liquiditätsstatus, 10 %/3-Wochen-Grundsatz) und der
Überschuldung (Fortbestehensprognose + Überschuldungsstatus). Im Gläubigerantrag
ist IDW S 11 relevant, wenn ein Gutachter zur Glaubhaftmachung des Eröffnungsgrundes
beauftragt wird oder das Gericht einen vorläufigen Sachverständigen bestellt.

## Ablauf

**Vorab:** Der untenstehende ist die typische Standardlinie. Wenn die Mandantenlage abweicht (siehe "Strategische Optionen" oben), sind die Schritte entsprechend zu verkuerzen, umzustellen oder durch ein anderes Skill zu ersetzen — der ist Leitfaden, nicht Pflichtprogramm.

### Schritt 1 — Gläubigerprüfung: Forderung

- **Titulierungsstand**: Liegt ein vollstreckbarer Titel vor (Urteil, Beschluss,
 Vollstreckungsbescheid)? Wenn ja, entfällt das Glaubhaftmachungsproblem für
 die Forderung weitgehend.
- **Nicht-titulierte Forderung**: Belege zusammenstellen — Rechnung, Lieferschein,
 Empfangsbestätigung, Kontoauszug, eidesstattliche Versicherung nach § 294 ZPO.
- **Fälligkeit**: Die Forderung muss im Zeitpunkt der Antragstellung bestehen und
 fällig sein. Eine bedingte oder gestundete Forderung genügt grundsätzlich nicht
 (Ausnahme: Stundung durch Druckausübung, Sittenwidrigkeit der Stundung).
- **Höhe**: Für das rechtliche Interesse keine gesetzliche Mindestgrenze; jedoch
 prüft das Gericht implizit, ob die Forderungshöhe im Verhältnis zur
 Verfahrenserwartung steht. Bagatellbeträge können das rechtliche Interesse in
 Frage stellen.

### Schritt 2 — Glaubhaftmachung des Eröffnungsgrundes

Aufbau eines Indizienpakets für Zahlungsunfähigkeit (§ 17 InsO):

| Indiz | Beweismittel |
|---|---|
| Fruchtlose Pfändungsversuche | Pfändungsprotokoll des GV (nicht älter als 3 Monate) |
| Lastschriftrückgaben | Kontoauszüge des Gläubigers (Stichwort "nicht eingelöst") |
| Wechselproteste | Notarprotokoll |
| SV-Rückstand ≥ 3 Monate | Kontoauszug Krankenkasse, Rückstandsbescheinigung |
| Lohnsteuerrückstände | ELSTER-Mahnbescheide, Rückstandsmitteilung FA |
| Negative BWA | Betriebswirtschaftliche Auswertung mit kumuliertem Negativsaldo |
| Häufung von Mahnverfahren | SCHUFA-Auskunft, Registerauskunft gerichtlicher Mahnbescheide |

Mindestens zwei bis drei dieser Indizien sollten kombiniert werden, um die Gesamtschau der überwiegenden Wahrscheinlichkeit der Zahlungsunfähigkeit zu tragen (st. BGH-Rspr.; konkrete Aktenzeichen vor Ausgabe über offene Quellen verifizieren).

### Schritt 3 — Antragsschrift formal (§§ 13, 14 InsO)

Zwingender Inhalt:
- Bezeichnung Gläubiger (vollständiger Name/Firma, Anschrift)
- Bezeichnung Schuldner (Firma, Sitz, Registergericht/HRB-Nr.)
- Darlegung des rechtlichen Interesses
- Darlegung und Glaubhaftmachung der Forderung mit Belegen
- Darlegung und Glaubhaftmachung des Eröffnungsgrundes mit Indizienbelegen
- Antrag auf Anordnung vorläufiger Sicherungsmaßnahmen (§§ 21, 22 InsO),
 falls eilbedürftig (z. B. drohende Vermögensverschiebungen)
- Kostenvorschuss (§ 26 InsO; wird bei Behörden oft erlassen)

### Schritt 4 — Reaktion auf Anhörung des Schuldners (§ 14 Abs. 2 InsO)

Das Insolvenzgericht hört den Schuldner vor der Entscheidung an. Typische
Schuldnerreaktionen und die rechtliche Bewertung:

- **Bestreiten der Forderung**: Substantiiertes Bestreiten hemmt nicht automatisch das Verfahren; bei titulierter oder durch starke Indizien glaubhaft gemachter Forderung bleibt der Antrag zulässig (vgl. BGH-Linie; Az. vor Ausgabe verifizieren).
- **Sofortige Zahlung der titulierten Forderung**: Beseitigt das rechtliche
 Interesse grundsätzlich, außer § 14 Abs. 1 S. 2 InsO greift (Zahlung innerhalb
 von 6 Monaten als potenzielle Anfechtungszahlung).
- **Zahlungsplan/Ratenzahlungsvereinbarung**: Kein Anspruch des Schuldners auf
 Aussetzung; missbräuchlicher Druckantrag-Einwand bei kurzfristiger Rücknahme nach Einlenken (Az. vor Ausgabe verifizieren).
- **Einreichung Sanierungskonzept**: Kein verfahrensrechtlicher Aufschubgrund;
 jedoch kann das Gericht faktisch zögern, wenn ein plausibles Sanierungskonzept
 vorgelegt wird.

### Schritt 5 — Schutzschrift / Einstweiliger Rechtsschutz (Schuldnerseite)

- **Schutzschrift**: Vor oder unmittelbar nach Anhörung beim Insolvenzgericht
 hinterlegen; Inhalt: Bestreiten der Forderung mit Belegen, Bestreiten des
 Eröffnungsgrundes (aktuelle Liquiditätsübersicht, ggf. IDW S 11-Stellungnahme),
 Druckantrag-Einwand falls zutreffend.
- **StaRUG-Verfahren**: Einleitung eines Restrukturierungsverfahrens nach StaRUG
 kann faktisch den Insolvenzantrag überlagern; Anzeige der Restrukturierungssache
 hat keine automatische Sperrwirkung gegen Gläubigeranträge, kann aber gerichtlich
 koordiniert werden.
- **Eigenantrag des Schuldners**: Strategisch oft günstiger als Abwehr — der
 Schuldner erhält das Vorschlagsrecht für den Insolvenzverwalter (§ 56a InsO),
 kann Eigenverwaltung beantragen (§§ 270 ff. InsO) und behält größeren Einfluss
 auf das Verfahren, als wenn der Gläubigerantrag zur Eröffnung führt.

## Strategische Optionen (vor dem Template entscheiden)

Bevor das Template eins-zu-eins gefuellt wird, ist zu prüfen welche Variante zur Mandantenkonstellation passt. Das Template ist **eine** moegliche Form — nicht die einzige.

| Konstellation | Empfohlener Weg |
|---|---|
| Standard — Gläubiger-Insolvenzantrag prüfend und Kurzgutachten erstellen | Kurzgutachten nach Prüfschema; Template unten |
| Variante A — Forderung noch nicht tituliert Antrag riskant | Titulierung zuerst; Insolvenzantrag nach Urteil oder Vollstreckungstitel |
| Variante B — Schuldner bietet Zahlung an wenn Antrag zurueckgenommen | Rücknahme-Verhandlung prüfen; wirtschaftliches Ergebnis beachten |
| Variante C — Mehrere Gläubiger koordinierter Antrag möglich | Koordinierter Sammelantrag prüfen; Hauptglaeubiger bestimmen |

Wenn die Mandantenkonstellation **nicht** ins Standardschema passt, ist das Template anzupassen oder durch ein anderes Skill abzuloesen — nicht das Mandat in das Schema zu pressen.

## Beispiel

**Sachverhalt:**
Das Finanzamt München stellt beim AG München — Insolvenzgericht — einen
Gläubigerantrag gegen die Muster GmbH (HRB 123456 AG München). Rückständig:
57.000 EUR Lohnsteuer (Zeitraum Jan–Jun 2024) + 30.000 EUR Umsatzsteuer
(Q1 und Q2 2024) = 87.000 EUR gesamt. Bisherige Vollstreckungsmaßnahmen:
drei Pfändungsversuche des Vollziehungsbeamten, alle fruchtlos (Protokolle
vom 15.04., 03.06. und 18.07.2024). Zusätzlich: Mahnbescheid wegen USt
rechtskräftig seit 12.03.2024; BWA-Auszüge April–Juni 2024 zeigen
kumulierten negativen Cash-flow von −38.000 EUR.

**Prüfung:**

*Zulässigkeit:*
- Rechtliches Interesse (+): Das Finanzamt ist öffentlich-rechtlicher Gläubiger;
 sein Interesse an der Verfahrenseröffnung folgt aus der Insolvenzquotenchance
 und der Anfechtungsmöglichkeit nach §§ 129 ff. InsO für zurückliegende Zahlungen.
 Behördengläubiger, insbesondere Finanzämter und Sozialversicherungsträger, stellen
 häufig Gläubigeranträge; im FA-Bereich oft im Zusammenhang mit einer
 Strafanzeige nach § 266a StGB (Vorenthalten von SV-Beiträgen), was das
 behördliche Interesse weiter objektiviert.
- Forderung glaubhaft gemacht (+): Rechtskräftiger Mahnbescheid für USt-Forderung;
 Steuerbescheide für LSt-Rückstände; Höhe belegbar durch Steuerkonto-Auszug.
- Fälligkeit (+): Steuerliche Fälligkeit nach § 41a EStG (LSt) und § 18 UStG (USt)
 jeweils eingetreten und unstreitig.

*Begründetheit:*
Eröffnungsgrund § 17 InsO durch Indizienkombination glaubhaft gemacht (st. BGH-Linie; Az. vor Ausgabe verifizieren):
- Drei fruchtlose Pfändungsversuche (schwergewichtiges Indiz)
- Negative kumulierte BWA (strukturelle Unterdeckung)
- 6-monatiger Lohnsteuerausfall (laufende Zahlungsunfähigkeit gegenüber FA)
- Rechtskräftiger Mahnbescheid ohne Zahlung (fehlende Zahlungsbereitschaft/-fähigkeit)

**Ergebnis:** Antrag zulässig und begründet; Eröffnung nach § 27 InsO zu erwarten.

## Risiken und typische Fehler

### Gläubigerseite

1. **Unzureichende Glaubhaftmachung der Forderung**: Bloße Behauptung ohne Belege
 genügt nicht; eidesstattliche Versicherung allein bei nicht-titulierter Forderung
 führt regelmäßig zur Unzulässigkeit (st. BGH-Linie; Az. vor Ausgabe verifizieren).

2. **Fehlende Aktualität der Indizienmittel**: Pfändungsprotokolle älter als drei
 bis vier Monate verlieren an Überzeugungskraft; aktuellere Beweismittel sind
 nachzuliefern.

3. **Missbräuchlicher Druckantrag**: Ein Antrag, der erkennbar nur zur
 Druckausübung gestellt und nach Zahlung sofort zurückgenommen wird, kann als
 rechtsmissbräuchlich eingestuft werden und Schadensersatzansprüche des
 Schuldners auslösen (Az. der einschlägigen BGH-Entscheidungen vor Ausgabe über
 offene Quellen verifizieren). Prüfen: hat der Mandant ein echtes
 Eröffnungsinteresse oder nur ein Zahlungsinteresse?

4. **§ 14 Abs. 1 S. 2 InsO — Taktikzahlung übersehen**: Befriedigt der Schuldner
 den antragstellenden Gläubiger kurz nach Antragstellung innerhalb der
 6-Monatsfrist, bleibt das Antragsrecht bestehen, wenn die Zahlung
 anfechtbar ist. Gläubiger darf Antrag bei anfechtbarer Befriedigung
 aufrechterhalten.

### Schuldnerseite

5. **Sofortige Zahlung als Anfechtungsrisiko**: Zahlt der Schuldner die
 antragsbegründende Forderung kurzfristig, um den Antrag zu Fall zu bringen,
 ist diese Zahlung nach § 133 Abs. 1 InsO (Vorsatzanfechtung) oder § 131 InsO
 (inkongruente Deckung) anfechtbar, wenn innerhalb der Anfechtungsfristen
 Insolvenz eröffnet wird. Der Schuldner "kauft" sich damit nur Zeit, ohne die
 Insolvenzlage zu beseitigen.

6. **Eigeninteresse vs. Gemeininteresse**: Der Gläubigerantrag dient nicht nur
 dem individuellen Gläubigerinteresse, sondern dem Schutz der
 Gläubigergesamtheit. Dies schränkt die Missbrauchsrechtsprechung auf klare
 Einzelfälle ein; der bloße Verdacht missbräuchlicher Motive genügt nicht.

7. **Zu späte Eigenantragsstellung**: Wartet der Schuldner zu lang mit dem
 Eigenantrag, verliert er das Vorschlagsrecht nach § 56a InsO und riskiert
 zudem eine persönliche Haftung der Geschäftsführer nach § 15a InsO
 (Insolvenzverschleppungshaftung).

8. **StaRUG-Verfahren ohne Sperrwirkung**: Das StaRUG-Restrukturierungsverfahren
 sperrt Gläubigeranträge nicht automatisch. Ohne gerichtliche Anordnung nach
 § 29 Abs. 2 Nr. 1 StaRUG bleibt der Gläubigerantrag vollständig wirksam.

## Quellenpflicht

Jede Handlungsempfehlung ist mit mindestens einer der nachstehenden Quellen
zu belegen. Pinpoint-Angaben (Randnummer) sind Pflicht.

| Quelle | Fundstelle |
|---|---|
| BGH IX. Zivilsenat zur Glaubhaftmachung der Forderung iSd § 14 InsO | Az., Datum, Randnummer vor Ausgabe über dejure.org / openjur.de verifizieren |
| BGH IX. Zivilsenat zur Indizienlinie der Zahlungseinstellung § 17 Abs. 2 S. 2 InsO | Az. vor Ausgabe verifizieren |
| BGH IX. Zivilsenat zum missbräuchlichen Druckantrag und rechtlichen Interesse | Az. vor Ausgabe verifizieren |
| Literatur (Kommentare, Handbücher) | nur bei vom Nutzer bereitgestellter oder lizenziert live geprüfter Quelle |
| IDW S 11 (Stand 2017) | Tz. 15–42 (Zahlungsunfähigkeit), Tz. 43–71 (Überschuldung) |

---

*Dieser Skill ersetzt keine konkrete anwaltliche Beratung im Einzelfall.*

## Triage — Gläubigerantrag

Bevor losgelegt wird, klaere:

1. **Forderung vollstreckbar?** Titel oder Glaubhaftmachung § 14 Abs. 1 InsO; eidesstattliche Versicherung ausreichend.
2. **Eröffnungsgrund glaubhaft?** Mindestens 2-3 Indizien für Zahlungsunfähigkeit iSd § 17 Abs. 2 S. 2 InsO oder Überschuldungsstatus iSd § 19 InsO.
3. **Rechtliches Interesse aktuell?** Kein missbräuchlicher Druckantrag; echtes Eröffnungsinteresse zum Zeitpunkt der gerichtlichen Entscheidung erforderlich.
4. **Sicherungsantrag § 21 InsO?** Sofort-Maßnahmen bei Vermögensgefaehrdung beantragen?
5. **Kostenvorschuss § 26 InsO?** Gläubigerinteresse an Verfahren trotz Massearmut?
- **Was will der Mandant wirklich erreichen?** (Nicht: was steht im Standardweg, sondern: welches Ergebnis ist für den Mandanten persoenlich/wirtschaftlich das beste? Manchmal ist der schnellere Vergleich besser als der formal "richtige" Weg.)

## Output-Template Kurzgutachten Gläubigerantrag

**Adressat:** Mandant (Gläubiger) — Tonfall: sachlich-empfehlend

```
INTERNES GUTACHTEN — GLAEUBIGERANTRAG § 14 InsO
Datum: [DATUM] Mandant: [GLAEUBIGER] Schuldner: [SCHULDNER]

ERGEBNIS: Glaeubigerantrag [SINNVOLL / NICHT SINNVOLL]

BEGRUENDUNG:
Forderung: EUR [BETRAG], Faelligkeit [DATUM], Vollstreckbarkeit [JA/NEIN]
ZU-Nachweis: [Indizien aufzaehlen]
Rechtsschutzbeduernis: [Beurteilung]
Sicherungsantrag § 21 InsO: [EMPFOHLEN weil ...]
Kostenvorschuss: EUR [BETRAG] ggf. erforderlich (§ 26 InsO)

NAECHSTER SCHRITT: [Antrag einreichen bis DATUM]
```

--- vor Versand klären ---
1. Welches Verhandlungsziel hat der Mandant? [Durchsetzung des Anspruchs / Vergleich / Reputationsschutz / schnelle Loesung]
2. Welche Kompromisslinien sind absolut? [Mindestforderung / Zeitrahmen / Formerfordernis]
3. Sind Anschlusswege erwuenscht? [Mediation / Direktgesprach / Einigung vor Fristablauf]

Schlussabsatz Variante A (kooperativ):
Wir regen eine guetliche Einigung an und stehen für ein klärenden Gesprach zur Verfuegung. Eine einvernehmliche Loesung erspart beiden Seiten Zeit und Kosten.

Schlussabsatz Variante B (formal-streng):
Eine aussergerichtliche Einigung kommt nur in Betracht wenn die Gegenseite innerhalb von [X] Tagen einen akzeptablen Vorschlag unterbreitet. Anderenfalls werden wir alle rechtlichen Schritte einleiten.

<!-- BEGIN ausformulierungspflicht (autogen) -->
> **Ausformulierungspflicht und Formatstandard.** Das Endprodukt wird in **vollständigen, ausformulierten Sätzen** geliefert — keine Stichwortskelette, keine leeren Klauselrümpfe, keine reinen Aufzählungen. Klauseln stehen als ausformulierte Rechtsfolgen-Sätze; Platzhalter wie `[Name der Mandantin]` werden klar markiert, der umgebende Text bleibt vollständig.
>
> **Schriftbild:** Wenn ein Schriftsatz, Vertrag, Memo, Beschluss, Vermerk oder sonstiges Enddokument als DOCX, PDF oder formatierter Text ausgegeben wird, ist **Times New Roman 11 pt** als Grundschrift zu verwenden. Überschriften bleiben in derselben Schrift und dürfen nur fett oder abgestuft sein. Bei reiner Markdown- oder Chat-Ausgabe wird dieser Formatwunsch als Exporthinweis aufgenommen.
>
> **Nummerierung:** Gliederung ausschließlich dezimal (`1`, `1.1`, `1.1.1` und so weiter). Keine römischen Ziffern, keine Buchstaben- oder Mischgliederung.
<!-- END ausformulierungspflicht (autogen) -->
