---
name: sanierungsgewinn-vergleich-mit-finanzamt-und-stundung
description: "Für Sanierungsgewinn — Vergleich mit Finanzamt und Stundung: entwickelt Ziel, Vergleich und Eskalation; Ergebnis: Verhandlungs- oder Eskalationslinie."
---

# Sanierungsgewinn — Vergleich mit Finanzamt und Stundung

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: Zuerst den im Skilltitel bezeichneten InsO- oder StaRUG-Tatbestand im aktuellen Gesetzestext prüfen. Eröffnungsantrag nach Paragraf 13 InsO, Gläubigerantrag nach Paragraf 14 InsO und Antragspflicht organschaftlicher Vertreter nach Paragraf 15a InsO strikt trennen; Steuerrecht, IDW-Standards oder Auslandsrecht nur bei einer konkreten Schnittstelle ergänzen.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Fachlicher Kern — Insolvenz- und Sanierungsrecht
- **Problemfokus dieses Skills:** Bleibe beim konkreten Titel `Sanierungsgewinn — Vergleich mit Finanzamt und Stundung` und löse die dort angelegte Fachfrage; arbeite mit konkreten Tatbestandsmerkmalen, Beweisfragen und dem unmittelbar benötigten Arbeitsprodukt. Routingfragen bleiben Hilfsmittel, wenn Frist, Zuständigkeit oder Verfahrensart offen sind.
- **Arbeitsmodus:** Zuerst Insolvenzgrund, Frist, Organpflicht, Verfahrensstand, Sicherheiten, Massebezug und Anfechtungszeitraum klären; dann Sanierungsfähigkeit, Plan/StaRUG, Haftung und Dokumentationsschutz.
- **Outputpflicht:** Krisenzeitachse, Liquiditätsstatus, Anfechtungsmatrix, Sicherheitenradar, IDW-S6-/Sanierungscheck, Register-/Grundbuch-Nachweispaket oder Schriftsatzbaustein.
- **Fehlerbremse:** Tragende Normen/Entscheidungen live oder aus der Akte verifizieren; Rechtsprechung nur mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei prüfbarer Quelle. Keine BeckRS-, juris-, Kommentar- oder Aufsatz-Blindzitate aus Modellwissen.

## Worum geht es

Auch wenn Paragraph 3a EStG nicht greift oder ein Restbetrag steuerbar bleibt, ist die Steuer noch nicht zwangslaeufig zu zahlen. Die Abgabenordnung stellt zwei Auffanglinien bereit:

- **Stundung Paragraph 222 AO** — wenn die Einziehung bei Faelligkeit eine erhebliche Haerte bedeutet und die Anspruchsverwirklichung nicht gefaehrdet ist.
- **Erlass Paragraph 227 AO** — wenn die Einziehung sachlich oder persoenlich unbillig waere.

Diese Werkzeuge sind in der Sanierungspraxis wichtig, weil sie auch dann greifen können, wenn Paragraph 3a EStG-Voraussetzungen nicht zweifelsfrei erfuellt sind. Adressat: StB, IV, Sachwalter, Plan-Anwalt.

## Wann dieses Modul hilft / Kaltstart-Fragen

- Plan-Modellrechnung zeigt einen Restsanierungsertrag, der nicht zweifelsfrei unter Paragraph 3a EStG faellt.
- Finanzamt lehnt Anwendung Paragraph 3a EStG ab.
- Sanierung ist nur traegbar, wenn Steuer gestundet oder erlassen wird.

Kaltstart-Fragen:

1. Restsanierungsertrag nach Verrechnung — wie hoch?
2. Wieso greift Paragraph 3a EStG nicht (welche Voraussetzung wird angezweifelt)?
3. Vermögenslage Schuldnerin nach Plan-Vollzug — Liquiditaetsplan vorhanden?
4. Hat das FA bereits einen Bescheid erlassen?
5. Plan-Quote der Insolvenzglaeubiger?

## Rechtlicher Rahmen

- Paragraph 222 AO — Stundung.
- Paragraph 227 AO — Erlass.
- Paragraph 78 AO — tatsaechliche Verstaendigung.
- Paragraph 76 AO — Auskuenfte und Beistand.
- Paragraph 3a EStG — Sanierungsertrag (Hauptlinie).
- Paragraph 251 AO — Insolvenzverfahren.

## / Schritt für Schritt

1. **Hauptantrag prüfen: Paragraph 3a EStG**. Erst wenn dieser greift, ist alles andere ueberfluessig.
2. **Hilfslinie Stundung Paragraph 222 AO** vorbereiten:
 - erhebliche Haerte bei Faelligkeit (Sanierung wuerde scheitern, Liquidation drohte).
 - Anspruch nicht gefaehrdet (Liquiditaetsplan zeigt Tilgung in Raten).
3. **Weitere Hilfslinie Erlass Paragraph 227 AO**:
 - sachliche Unbilligkeit (Gesetz zweckverfehlt, hier z. B. wenn Paragraph 3a EStG-Voraussetzung knapp nicht erfuellt).
 - persönliche Unbilligkeit (Existenz des Unternehmens bei Vollzug bedroht).
4. **Tatsaechliche Verstaendigung Paragraph 78 AO** bei strittigen Tatsachen (z. B. Werthaltigkeit einer Gesellschafterforderung).
5. **Steuerliche Vorabauskunft Paragraph 89 AO** als Praeventions-Werkzeug.
6. **Verhandlungslinie aufbauen** — schriftliche Begruendung, Liquiditaetsplan, Sanierungskonzept beifuegen.

## Trade-off-Matrix

| Werkzeug | Wirkung | Voraussetzung | Risiko |
|---|---|---|---|
| Paragraph 3a EStG | Steuerbefreiung | vier Voraussetzungen | Prüfung FA |
| Paragraph 222 AO | Aufschub | erhebliche Haerte + nicht gefaehrdeter Anspruch | Zinsen ggf. |
| Paragraph 227 AO | endgueltig (oder teilweise) | sachliche/persönliche Unbilligkeit | hohe Begruendungsanforderung |
| Paragraph 78 AO | Tatsachen-Fixierung | nur für Tatsachen, nicht Recht | nicht bindend bei spaeterer Klage gegen Tatsachen-Verstaendigung |
| Klage vor FG | richterliche Klärung | Bescheid liegt vor | langwierig |
| Kombination Paragraph 3a EStG + hilfsweise Paragraph 227 AO | Standard | parallel zu erklaeren | kein Risiko, wenn klar getrennt |

## Praxistipps der alten Hasen

1. **Immer kaskadiert beantragen.** Hauptantrag Paragraph 3a EStG, hilfsweise Erlass Paragraph 227 AO, hilfsweise Stundung Paragraph 222 AO.
2. **Persoenliche und sachliche Unbilligkeit getrennt begruenden.** Beide Stossrichtungen.
3. **Liquiditaetsplan beifuegen.** Ohne Liquiditaetsplan ist die Stundung schlecht zu rechtfertigen.
4. **Tatsaechliche Verstaendigung** bei strittiger Werthaltigkeit (Gesellschafterverzicht): besser eine Tatsachen-Klärung im Vorab als später Streit.
5. **Schriftform.** Muendliche Zusagen der FA-Sachbearbeitung sind kein Vertrauensschutz.
6. **Gemeinde im Blick:** Bei GewSt liegt die Hebebezugsentscheidung bei der Gemeinde; Stundung dort gesondert.

## Mustertexte / Berechnungsbeispiele

**Antrag Geruest — Erlass Paragraph 227 AO (Hilfsantrag):**

```
An das Finanzamt [Ort]
Steuernummer [...]
Veranlagungszeitraum: [Jahr]

Antrag auf Erlass nach Paragraph 227 AO (Hilfsweise)
zum Hauptantrag auf Anwendung Paragraph 3a EStG

1. Sachverhalt
[Kurze Darstellung. Verweis auf bestaetigten Plan vom [Datum].]

2. Hauptantrag
Wir beantragen die Anwendung Paragraph 3a Absatz 1 EStG auf den
ermittelten Restsanierungsertrag in Hoehe von EUR [Betrag].
Begruendung siehe Schreiben vom [Datum].

3. Hilfsantrag — Erlass Paragraph 227 AO
Wir beantragen hilfsweise, die Steuer auf den Restsanierungsertrag in
Hoehe von EUR [Betrag] zu erlassen.

3.1 Sachliche Unbilligkeit
Der Gesetzgeber hat mit Paragraph 3a EStG die Steuerfreiheit des
Sanierungsertrags angeordnet. Sollte aus formalen Gruenden die
Anwendung dieser Norm nicht moeglich sein, waere die Einziehung der
Steuer mit dem gesetzlichen Telos nicht vereinbar. Eine sachliche
Unbilligkeit liegt deshalb vor.

3.2 Persoenliche Unbilligkeit
Die Antragstellerin verfuegt nach Plan-Vollzug ueber eine Liquiditaetslage,
die die Einziehung der Steuer unmittelbar in eine erneute
Zahlungsunfaehigkeit fuehren wuerde. Liquiditaetsplan vom [Datum] —
Anlage [...]. Die Sanierung wuerde damit kontraproduktiv konterkariert.

4. Weiter hilfsweise — Stundung Paragraph 222 AO
Wir beantragen weiter hilfsweise Stundung der Steuer auf den
Restsanierungsertrag für einen Zeitraum von [X Monaten] mit
Ratenzahlung gemaess Anlage [Tilgungsplan]. Die Anspruchsverwirklichung
ist nicht gefaehrdet (siehe Liquiditaetsplan).

5. Anlagen
[bestaetigter Plan, IDW S 6, Liquiditaetsplan, Tilgungsplan, ggf.
Aktennotiz Werthaltigkeitspruefung]
```

**Antrag Geruest — Tatsaechliche Verstaendigung Paragraph 78 AO:**

```
An das Finanzamt [Ort]
Steuernummer [...]

Antrag auf Tatsaechliche Verstaendigung Paragraph 78 AO

Wir bitten um Aufnahme eines Tatsaechlichen Verstaendigungsverfahrens zu
folgender Tatsache:

Werthaltigkeit der Forderung des Gesellschafters [Name] gegen die
Schuldnerin im Zeitpunkt des Forderungsverzichts am [Datum].

Unsere Auffassung: Werthaltigkeit [X %].
Begruendung: [...] (siehe Anlage Werthaltigkeitsgutachten WP [Name]).

Wir schlagen vor, die Werthaltigkeit einvernehmlich auf [Y %] festzulegen.
```

## Typische Fehler

1. Erlassantrag ohne Hauptantrag — falsche Reihenfolge.
2. Stundungsantrag ohne Liquiditaetsplan.
3. Persoenliche und sachliche Unbilligkeit nicht getrennt begruendet.
4. Muendliche Zusagen FA gefolgt — kein Vertrauensschutz.
5. Tatsaechliche Verstaendigung mit Rechtsfragen vermischt — Paragraph 78 AO nur für Tatsachen.
6. Gemeinde-Schiene (GewSt-Hebebezug) vergessen.

## Quellen Stand 06/2026

- Paragraph 222 AO, `gesetze-im-internet.de/ao_1977/__222.html`.
- Paragraph 227 AO, `gesetze-im-internet.de/ao_1977/__227.html`.
- Paragraph 78 AO, `gesetze-im-internet.de/ao_1977/__78.html`.
- Paragraph 89 AO.
- Paragraph 3a EStG.
- Paragraph 7b GewStG.
- Zitierweise und Quellenpruefung siehe `references/zitierweise.md`.
