---
name: workflow-chronologie-und-belegmatrix
description: "Für Chronologie und Belegmatrix: ordnet Akte, Belege und Lücken; Ergebnis: Chronologie mit Beleg- und Widerspruchsmatrix. Fachgebiet: Fachanwalt Insolvenz- und Sanierungsrecht."
---

# Chronologie und Belegmatrix

## Arbeitsauftrag

Dieser Arbeitsgang macht **Chronologie und Belegmatrix** im Bereich **fachanwalt-insolvenz-sanierungsrecht** sofort bearbeitbar: erst Akte lesen, dann Rollen, Ziel, Fristen, Belege und Entscheidungspunkte ordnen. Rückfragen kommen nur, wenn sie die rechtliche Weiche, den richtigen Adressaten oder das Arbeitsprodukt wirklich verändern.

## Aktenstart ohne Leerlauf

1. Vorhandene Dokumente, Dateinamen, Metadaten, Anlagen und erkennbare Fristen auswerten, bevor Fragen gestellt werden.
2. Sichere Tatsachen, plausible Annahmen, streitige Behauptungen und fehlende Belege in vier getrennten Spalten erfassen.
3. Parteirolle, Gegner/Behörde/Gericht, Zuständigkeit, Verfahrensstand und gewünschtes Ergebnis knapp bestimmen.
4. Sofortige Risiken markieren: Notfrist, Zustellung/Zugang, Verjährung, Sanktion, Vollstreckung, Register-/Portalfrist, Beweisverlust.
5. Danach nur noch die fehlenden Punkte fragen, die den nächsten Schritt ändern.

## Fachliche Anker

- InsO §§ 13, 15a, 17-19, 21, 35, 38, 87, 129 ff., 174 ff.; StaRUG; AnfG; GmbHG § 15a/§ 64 a.F.-Nachwirkungen.
- Zahlungsfähigkeit, Überschuldung, Masse, Aussonderung/Absonderung, Anfechtung, Forderungsanmeldung und Geschäftsleiterhaftung trennen.
- Zahlen immer mit Stichtag, Quelle, Bankstand, Fälligkeit, Liquiditätslücke und Planannahme dokumentieren.

## Arbeitsprodukt

- **Kurzdiagnose:** Was ist wahrscheinlich los, welche Rechtsfrage trägt den Fall, was ist sofort zu tun?
- **Belegmatrix:** Tatsache, Quelle, Fundstelle/Anlage, Beweiswert, Lücke, Nachforderung.
- **Risikoampel:** Grün/gelb/rot mit knapper Begründung und nächstem sicheren Schritt.
- **Entwurf:** je nach Fall E-Mail, Mandantenmemo, Behörden-/Gerichtsschreiben, Checkliste, Tabelle oder Fristenplan.
- **Fehlerbremse:** keine erfundenen Normen, keine Blindzitate, keine Tatsachenergänzung ohne Aktenbeleg.
