---
name: organhaftung-zahlungen-masseabgleich
description: Bereitet die Organhaftung für Zahlungen nach Insolvenzreife durch Einzelbuchungsabgleich, Zeitfenster und belegte Massezuflüsse auf. Trennt Sorgfaltsprüfung und geringeren Gläubigerschaden nach Paragraf 15b InsO; nicht für eine bloße Liquiditätsprognose oder die Anfechtung gegen Zahlungsempfänger.
---

# 1. Zweck und Anwendungsfall

Erstelle aus Kontoauszügen und Gegenleistungsbelegen eine prüfbare Berechnung zur Geltendmachung oder Abwehr von Haftungsansprüchen gegen die Geschäftsleitung. Ausgangspunkt sind Zahlungen nach einem zu belegenden Insolvenzreifestichtag. Anders als bei Liquiditätsstatus und Anfechtung wird jede Buchung dem Organ, einem Zeitfenster und einer konkreten Entlastung zugeordnet.

## 2. Eingaben

Lies Auftrag, Organbestellung, behaupteten Reifestichtag mit Statusbelegen, Insolvenzantrag und gerichtliche Anordnungen, sämtliche einschlägigen Konten, Rechnungen, Rückzahlungen, Gegenleistungen und Sanierungsdokumentation. Erfasse tatsächlichen Zahlungstag, Buchungs- und Wertstellungsdatum getrennt. Zahlungen vor und seit dem 01.01.2021 nach der jeweils einschlägigen Rechtslage prüfen. Bei offenem Reifedatum rechne benannte Stichtagsvarianten und frage nach den konkret fehlenden Fälligkeits-, Stundungs- oder Liquiditätsbelegen. Übernimm Antworten in Stichtag und Zeitfenster, ohne bereits bekannte Angaben erneut zu erheben.

## 3. Ablauf und Checkliste

### 3.1. Ausgangstatbestand

Prüfe Insolvenzreife nach Paragrafen 17 und 19 InsO getrennt, Organstellung und Zurechnung der Zahlungen. Eine schlechte Bilanz ist noch kein vollständiger Nachweis der Insolvenzreife. Halte Tatbestandsbelege des Anspruchstellers und Entlastungsbelege des Organs getrennt. Fristen nach Paragraf 15a InsO sind Höchstfristen, kein voraussetzungsloser Zahlungsfreiraum.

[BGH, Urteil vom 12.03.2026 – Az. IX ZR 18/25](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/IX_ZS/2025/IX_ZR__18-25.pdf?__blob=publicationFile&v=1), Rn. 24–32: Fällige Schulden und verfügbare Mittel geordnet gegenüberstellen. Tatsächlich geleistete Drittmittel nicht allein wegen fehlenden Rechtsanspruchs ausschließen; kurzfristige Verfügbarkeit konkret belegen. Bloße Hilfszusagen sind kein Geldzufluss. Aussage zur Zahlungsunfähigkeit im Anfechtungsprozess, keine automatische Entlastung nach Paragraf 15b InsO.

[BGH, Urteil vom 23.01.2025 – Az. IX ZR 229/22](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/IX_ZS/2022/IX_ZR_229-22.pdf?__blob=publicationFile&v=1), Rn. 34–45: Bei vorläufig vollstreckbarem Titel, erfüllten Vollstreckungsvoraussetzungen und eingeleiteter Vollstreckung die streitige Schuld im Status zum Nennwert ansetzen, ohne Prozessrisikoabschlag. Titel, Zustellung, Sicherheit und Vollstreckungsbeginn anfordern. Subjektive Kenntnis und Organhaftung folgen daraus nicht automatisch.

### 3.2. Buchungsabgleich

Vergib für jede Zahlung eine Kennung mit Konto, Empfänger, Betrag, Zweck, Tag, Veranlasser und Beleg. Gleiche Anfangsbestand plus Einzahlungen minus Auszahlungen mit Endbestand ab. Entferne echte Dubletten. Umbuchungen zwischen eigenen frei verfügbaren Guthabenkonten nicht doppelt als Masseabfluss zählen; bei debitorischen oder besicherten Konten Wirkung und Sicherheiten gesondert prüfen. Zahlungseingänge sind nicht automatisch frei verfügbare Masse und nicht pauschal gegen Auszahlungen saldierbar.

### 3.3. Sorgfaltsprüfung je Zeitfenster

Prüfe Paragraf 15b Absätze 1 bis 3 InsO vor jeder Kürzung: ordnungsgemäßer Geschäftsgang, notwendige Betriebsfortführung, sorgfältig betriebene nachhaltige Sanierung oder Antragsvorbereitung innerhalb des zulässigen Zeitraums. Nach dessen Ablauf ist ohne Antrag die gesetzliche Regelbewertung anzuwenden. Zwischen Antrag und Eröffnung konkrete Zustimmung des vorläufigen Verwalters belegen; die bloße Bestellung ersetzt diese nicht. Gesellschafterbeschlüsse erteilen keine pauschale Haftungsfreistellung. Steuer- und Sozialversicherungszahlungen nicht gleichsetzen; Sonderkonflikte gesondert kennzeichnen, keine Zahlungsvollmacht ausgeben.

### 3.4. Berechnung und Gegenleistungen

Zeige zuerst die Summe der zurechenbaren Auszahlungen und sodann die begründet sorgfaltsgemäßen Positionen. Für verbleibende Positionen prüfe Paragraf 15b Absatz 4 Satz 2 InsO: Welcher geringere Schaden der Gläubigerschaft ist konkret belegt? Ordne Rückfluss, Warenzugang, Verwertbarkeit, Wert, Sicherungsrechte und zeitlichen Zusammenhang zu. Nennwert einer Rechnung ist kein Beweis eines entsprechenden Massewerts. Ein Anspruch auf Anfechtungsrückgewähr ist noch keine erfolgte Rückzahlung.

Halte die historische Einzelzahlungsbetrachtung und den heutigen Einwand geringeren Gläubigerschadens auseinander. Das Urteil zu Paragraf 64 GmbHG alter Fassung ist kein automatischer Ausschluss aller Löhne oder Dienstleistungen unter Paragraf 15b InsO. Keine schematische Gleichsetzung mit einem Bargeschäft nach Paragraf 142 InsO. Denselben Rückfluss nicht zugleich bei Einzelzahlung und Gesamtschaden abziehen. Stelle streitige Entlastungen in einer gesonderten Variante dar, statt sie endgültig gutzuschreiben.

### 3.5. Abschluss

Fehlt ein Rückflussbeleg oder eine behauptete Verwalterzustimmung, fordere den konkreten Nachweis an. Aktualisiere nach der Antwort Zurechnung, Entlastung und Rechnung; prüfe die davon betroffenen Summen und Doppelanrechnungen erneut. Neue entscheidende Widersprüche erlauben weitere kurze Fragen.

Liefere bei ausstehenden Belegen einen vorläufigen Teilstand und führe nach Klärung bis zur bestellten Bewertung oder vollständigen Anspruchs- beziehungsweise Verteidigungsfassung fort. Prüfe die Verjährung nach Paragraf 15b Absatz 7 InsO. Externe Anträge, Zahlungseingriffe und Anerkenntnisse erfordern ausdrückliche Freigabe.

## 4. Quellenpflicht

Beachte [Zitierweise](../../references/zitierweise.md), sofern verfügbar; prüfe amtliche Fassung zum Zahlungszeitpunkt und aktuellen Stand vor Verwendung.

- [Paragraf 15b InsO](https://www.gesetze-im-internet.de/inso/__15b.html): Sorgfalt, Zeitfenster, geringerer Gläubigerschaden und Verjährung.
- [Paragraf 15a InsO](https://www.gesetze-im-internet.de/inso/__15a.html): Antrag ohne schuldhaftes Zögern, gesetzliche Höchstfristen.
- [BGH, Urteil vom 04.07.2017, II ZR 319/15](https://www.bundesgerichtshof.de/SharedDocs/Entscheidungen/DE/Zivilsenate/II_ZS/2015/II_ZR_319-15A.pdf?__blob=publicationFile&v=1), Randnummern 10 bis 20, amtlicher Volltext geprüft am 22.09.2026: Bei behauptetem Warenzugang wirtschaftliche Zuordnung, Gläubigerverwertbarkeit und bei Liquidation Liquidationswert prüfen. Ein Rechnungspreis ersetzt keinen Massewert; bloße Dienstleistungen glichen die Aktivmasse regelmäßig nicht aus. Keine entsprechende Anwendung der Bargeschäftsregeln auf den damaligen Paragraf 64 GmbHG. Heutige Sorgfaltsausnahmen und geringeren Gläubigerschaden nach Paragraf 15b InsO eigenständig prüfen; keine pauschale Haftung für heutige Lohnzahlungen ableiten.

## 5. Ausgabeformat

Erstelle das bestellte Gutachten oder den vollständigen Anspruchs- beziehungsweise Verteidigungstext, mit abgestimmtem Zahlungsjournal und erforderlichen Berechnungsvarianten. Verwende den gewünschten Dateinamen; `ergebnis.md` ist nur die Vorgabe bei fehlendem Dateiwunsch. Sorgfalts- und Entlastungstabellen nur soweit für den Nachweis nötig; keine ungefragte Klage zu einem Bewertungsauftrag.

Endprodukt in vollständigen Sätzen, keine Stichwortskelette. Ohne Dateiexport die bestellte Bewertung oder den Entwurf samt Zahlungsabgleich und erforderlicher Rechnung vollständig in der Antwort bereitstellen; keine nicht erzeugte Datei verlinken. Dezimale Gliederung; Times New Roman 11 pt im Export, bei Markdown als Exporthinweis. Nicht geprüfte Konten, Quellenstatus und interne Kontrollen in einer gesonderten Arbeitsnotiz nennen, nicht im Mandantenbrief.

## 6. Beispiele

Passend: Ein Verwalter verlangt sämtliche Auszahlungen eines Monats, obwohl eigene Kontenumbuchungen und Rückerstattungen enthalten sind. Passend ist auch die Verteidigung mit dokumentierten Sanierungsmaßnahmen und Warenzugängen. Nicht passend sind allein eine Fortbestehensprognose oder eine Anfechtungsforderung gegen einen Lieferanten.
