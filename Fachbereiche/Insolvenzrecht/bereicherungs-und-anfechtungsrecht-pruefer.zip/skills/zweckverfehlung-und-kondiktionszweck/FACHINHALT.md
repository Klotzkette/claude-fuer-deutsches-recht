---
name: zweckverfehlung-und-kondiktionszweck
description: "Für Zweckverfehlung und Kondiktionszweck: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Zweckverfehlung und Kondiktionszweck

## Triage — kläre vor der Subsumtion

1. Für welchen Zweck wurde geleistet: Tilgung, Vertragserfüllung, Erwartung eines künftigen Verhaltens, Sicherung, Vergleich, Vorleistung?
2. War dieser Zweck Bestandteil einer erkennbaren Zweckabrede oder nur ein einseitiges Motiv?
3. Ist der Zweck endgültig verfehlt, nachträglich entfallen oder nur verzögert?
4. Welche Partei trägt nach Vertrag, Gesetz oder Risikozuweisung das Risiko des Scheiterns?
5. Gibt es Ausschlussgründe, insbesondere § 815 BGB, § 817 S. 2 BGB oder eine vorrangige Vertragsregelung?

## Kernunterscheidung

Nicht jede enttäuschte Erwartung eröffnet Bereicherungsrecht. Erforderlich ist ein rechtlich beachtlicher Leistungszweck. Dieser muss für den Empfänger erkennbar und im Verhältnis der Parteien relevant geworden sein. Ein bloßes Motiv, das der Leistende für sich behält, reicht nicht.

## Prüfungsaufbau

### 1. Leistungszweck bestimmen

Ordne den Zweck ein:

- **Tilgungszweck:** Leistung soll eine bestehende oder vermeintliche Schuld erfüllen.
- **Erwartungszweck:** Leistung soll ein künftiges Verhalten oder Ereignis veranlassen.
- **Sicherungszweck:** Leistung wird als Sicherheit, Abschlag oder Treuhandbetrag gegeben.
- **Vorbereitungszweck:** Leistung wird im Vorfeld eines geplanten Geschäfts erbracht.
- **Vergleichs- oder Befriedungszweck:** Leistung soll Streit erledigen oder Risiken abschichten.

### 2. Zweckabrede prüfen

Der Zweck muss in die Beziehung der Parteien eingetreten sein:

- ausdrücklich vereinbart,
- aus den Umständen erkennbar,
- für den Empfänger bei Annahme der Leistung verständlich,
- nicht durch Vertragsauslegung oder Spezialregelung verdrängt.

### 3. Zweckverfehlung feststellen

Prüfe, ob der Zweck wirklich gescheitert ist:

- Ereignis tritt endgültig nicht ein.
- Geschäftsgrundlage reicht nicht; es muss um den Leistungszweck gehen.
- Nur Verzögerung genügt regelmäßig nicht.
- Teilweise Zweckverfehlung führt nur zu anteiliger Rückabwicklung.

### 4. Risikozuweisung kontrollieren

Kein Anspruch, wenn der Leistende das Risiko bewusst übernommen hat oder wenn Vertrag/Gesetz die Rückabwicklung anders regelt. Besonders vorsichtig bei Vorleistungen, Aufwendungen in Vertragsverhandlungen, freiwilligen Unterstützungen und Leistungen im gesetzeswidrigen Kontext.

## Warnsignale

- "Ich hatte gehofft" ist noch keine Zweckabrede.
- "Der Vertrag kam nicht zustande" reicht nicht automatisch; zuerst vorvertragliche Ansprüche und Risikoverteilung prüfen.
- Bei gegenseitigen Verträgen nicht isoliert nur eine Leistung zurückfordern; Saldierung und Gegenleistung mitdenken.
- Bei gesetzes- oder sittenwidrigen Zwecken immer § 817 S. 2 BGB gesondert prüfen.

## Output-Template

**Zweckverfehlungs-Prüfung**

Sachverhalt: [...]

| Prüfungspunkt | Ergebnis |
|---|---|
| Leistender und Empfänger | [...] |
| Leistung | [...] |
| behaupteter Zweck | [...] |
| Zweck für Empfänger erkennbar? | ja / nein |
| Zweck rechtlich beachtlich? | ja / nein |
| Zweck endgültig verfehlt? | ja / nein / teilweise |
| Risikozuweisung gegen Rückforderung? | ja / nein |
| Ausschlussgrund | [...] |

**Ergebnis:** Rückforderung wegen Zweckverfehlung [kommt in Betracht / scheidet aus / nur anteilig], weil [...].

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.
