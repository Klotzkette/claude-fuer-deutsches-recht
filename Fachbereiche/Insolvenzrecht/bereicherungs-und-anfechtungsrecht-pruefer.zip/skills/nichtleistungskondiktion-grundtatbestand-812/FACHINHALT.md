---
name: nichtleistungskondiktion-grundtatbestand-812
description: "Für Nichtleistungskondiktion — Grundtatbestand Paragraf 812 Abs. 1 S. 1 Alt. 2 BGB: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Tatbestands- oder Anspruchsmatrix. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: nichtleistungskondiktion-grundtatbestand-812."
---

# Nichtleistungskondiktion — Grundtatbestand § 812 Abs. 1 S. 1 Alt. 2 BGB

## Triage — kläre vor der Prüfung

1. Liegt eine bewusste und zweckgerichtete Mehrung fremden Vermögens vor — wenn ja, ist § 812 Abs. 1 S. 1 Alt. 1 BGB (Leistungskondiktion) vorrangig?
2. Handelt es sich um eine Eingriffskondiktion (Eingriff in den Zuweisungsgehalt einer fremden Rechtsposition)?
3. Kommt § 816 BGB (Verfügung eines Nichtberechtigten) als Spezialregelung in Betracht?
4. Liegt eine Verwendungskondiktion vor (Aufwendungen auf fremde Sache ohne Verwendungsersatzanspruch nach §§ 994 ff. BGB)?
5. Ist der Eingriff unmittelbar aus dem Vermögen des Gläubigers oder nur mittelbar wirtschaftlich nachteilig?

## Zentrale Normen

§ 812 Abs. 1 S. 1 Alt. 2 BGB (Nichtleistungskondiktion) — § 816 BGB (Verfügung Nichtberechtigter, Spezialregelung) — § 822 BGB (Bereicherung Dritter) — § 818 BGB (Umfang der Herausgabe) — § 812 Abs. 1 S. 1 Alt. 1 BGB (Leistungskondiktion, vorrangig) — §§ 994 ff. BGB (Verwendungsersatz im EBV) — § 985 BGB (Vindikation)

## Obersatz

Wer etwas in sonstiger Weise auf Kosten eines anderen ohne rechtlichen Grund erlangt, ist zur Herausgabe verpflichtet (§ 812 Abs. 1 S. 1 Alt. 2 BGB).

## Abgrenzung zur Leistungskondiktion

Die Nichtleistungskondiktion greift subsidiär: Sie kommt nur zum Zug, wenn keine bewusste und zweckgerichtete Mehrung fremden Vermögens vorliegt.

**Anwendungsfälle:**
- Eingriffskondiktion: Eingriff in fremde Rechtssphäre ohne Rechtsgrund.
- Verfügung eines Nichtberechtigten: § 816 BGB als Spezialregelung.
- Verwendungskondiktion: Aufwendungen auf fremde Sache ohne Ersatzanspruch aus §§ 994 ff. BGB.

## Tatbestandsmerkmale

### 1. Etwas erlangt

Jeder vermögenswerte Vorteil.

### 2. In sonstiger Weise (nicht durch Leistung)

Nicht bewusst und nicht zweckgerichtet zugewendet: Nutzung fremder Schutzrechte, Verarbeitung fremder Sachen, eigenmächtiger Eingriff.

### 3. Auf Kosten des Gläubigers (unmittelbar)

Bereicherung muss unmittelbar aus dem Vermögen oder Rechtskreis des Anspruchstellers stammen.

### 4. Ohne Rechtsgrund

Kein gesetzlicher oder vertraglicher Rechtfertigungsgrund.

## Prüfschema

1. Leistungskondiktion (Alt. 1) ausschließen?
2. Spezialregelung (§ 816 BGB, § 822 BGB) ausschließen?
3. In sonstiger Weise erlangt (Eingriff, Verwendung)?
4. Unmittelbar auf Kosten des Gläubigers?
5. Ohne Rechtsgrund?

## Output-Template

**Prüfung § 812 Abs. 1 S. 1 Alt. 2 BGB — Nichtleistungskondiktion**

Sachverhalt (kurz): [...]

| Merkmal | Ergebnis |
|---|---|
| Leistungskondiktion (Alt. 1) ausgeschlossen | ja / nein → Alt. 1 vorrangig |
| § 816 / § 822 BGB als Spezialregelung | nein / ja → Spezialregelung vorrangig |
| Erlangter Vorteil | [...] |
| In sonstiger Weise (Eingriff/Verwendung) | ja: [...] / nein |
| Unmittelbar auf Kosten des Gläubigers | ja / nein (nur mittelbar → kein § 812 Alt. 2) |
| Ohne Rechtsgrund | ja / nein |

**Ergebnis:** Nichtleistungskondiktion nach § 812 Abs. 1 S. 1 Alt. 2 BGB [besteht / besteht nicht].

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

---

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
