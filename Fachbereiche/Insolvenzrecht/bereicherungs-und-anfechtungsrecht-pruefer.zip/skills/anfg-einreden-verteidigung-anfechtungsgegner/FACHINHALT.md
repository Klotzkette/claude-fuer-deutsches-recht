---
name: anfg-einreden-verteidigung-anfechtungsgegner
description: "Für Einreden und Verteidigung des Anfechtungsgegners — AnfG: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Einreden und Verteidigung des Anfechtungsgegners — AnfG

## Triage — kläre die Verteidigungsstrategie

1. Auf welchen Anfechtungstatbestand stützt der klagende Gläubiger seinen Anspruch (§ 3 oder § 4 AnfG)?
2. Liegt echte Unentgeltlichkeit vor oder wurde eine Gegenleistung erbracht?
3. Hatte der Anfechtungsgegner tatsächlich Kenntnis vom Benachteiligungsvorsatz des Schuldners?
4. Besteht die Möglichkeit der analogen Anwendung des Bargeschäftsprivilegs?

## Zentrale Normen

- § 3 AnfG — Vorsatzanfechtung (Kenntnis des Anfechtungsgegners als Tatbestandsmerkmal)
- § 4 AnfG — Unentgeltliche Leistung (kein Verschuldenserfordernis; Frist 4 Jahre)
- § 11 Abs. 2 AnfG — Wertersatz (bei Untergang des Gegenstands)
- § 142 InsO — Bargeschäftsprivileg (analoge Anwendung im AnfG str.)
- §§ 812 ff. BGB — Bereicherungsrecht (Gegenleistungs-Rückforderung gegen Schuldner)

## Überblick

Der Anfechtungsgegner hat verschiedene Verteidigungsmöglichkeiten gegen eine AnfG-Anfechtungsklage. Sie richten sich nach dem jeweiligen Anfechtungstatbestand.

## Verteidigung gegen § 3 AnfG (Vorsatzanfechtung)

### Fehlende Kenntnis des Benachteiligungsvorsatzes

Der Anfechtungsgegner bestreitet, dass er zum Zeitpunkt der Handlung den Benachteiligungsvorsatz des Schuldners kannte. Argumente:
- Keine Kenntnis von der Zahlungsunfähigkeit des Schuldners.
- Keine Kenntnis von der Gläubigerbenachteiligungsabsicht.
- Fehlen der nahestehenden-Personen-Eigenschaft (keine Vermutung).

### Kein Benachteiligungsvorsatz des Schuldners

Schuldner handelte zur Erfüllung einer berechtigten Verpflichtung, ohne Benachteiligungsabsicht.

## Verteidigung gegen § 4 AnfG (Unentgeltlichkeit)

- Nachweis einer Gegenleistung (kein Schenkungscharakter).
- Leistung in Erfüllung einer sittlichen Pflicht (§ 4 Abs. 2 AnfG).
- Fristablauf (mehr als vier Jahre seit Rechtshandlung).

## Bargeschäftsargument

Das Bargeschäftsprivileg des § 142 InsO gilt im AnfG nicht unmittelbar. Analoge Anwendung ist umstritten. Argument: Gleichwertiger Leistungsaustausch ohne Gläubigerbenachteiligung schließt Anfechtung aus (teleologische Reduktion). Nach überwiegender Meinung greift diese Argumentation im AnfG-Rahmen nur eingeschränkt.

## Entreicherungseinwand

Im AnfG gibt es keine dem § 818 Abs. 3 BGB entsprechende allgemeine Entreicherungseinrede. Bei gutgläubigem Anfechtungsgegner kann Entreicherung jedoch nach Treu und Glauben berücksichtigt werden (str.).

## Gegenforderung (Gegenleistungs-Rückforderung)

Hat der Anfechtungsgegner für das Empfangene eine Gegenleistung erbracht, kann er bei Rückgewähr seine Gegenleistung zurückfordern — aber nur gegen den Schuldner, nicht gegen den anfechtenden Gläubiger.

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.


## Materien- und Quellenkontrolle

Anfechtung einer Willenserklärung nach Paragraf 119 oder 123 BGB, bereicherungsrechtliche Rückabwicklung nach Paragraf 812 folgende BGB, Gläubigeranfechtung nach dem Anfechtungsgesetz und Insolvenzanfechtung nach Paragraf 129 folgende InsO sind getrennte Anspruchssysteme. Zuerst Anspruchsberechtigter, Anfechtungsgegner, Rechtshandlung, Benachteiligung, subjektive Merkmale, Frist und Rechtsfolge bestimmen. Eine Entscheidung aus einem anderen System nur nach ausdrücklicher Prüfung ihrer Übertragbarkeit verwenden; jedes Zitat benötigt Gericht, Datum, Aktenzeichen, tragende Aussage und Quelle.

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
