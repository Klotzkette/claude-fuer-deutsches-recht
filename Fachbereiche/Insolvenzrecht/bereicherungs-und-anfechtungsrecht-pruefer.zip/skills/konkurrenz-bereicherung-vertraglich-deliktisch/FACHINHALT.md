---
name: konkurrenz-bereicherung-vertraglich-deliktisch
description: "Für Konkurrenz: Bereicherung neben Vertrag, Delikt und EBV: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: konkurrenz-bereicherung-vertraglich-deliktisch."
---

# Konkurrenz: Bereicherung neben Vertrag, Delikt und EBV

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: §§ 812 ff. BGB, AnfG und Insolvenzanfechtung; §§ 129-147 InsO. Mit KI-Screening von Schuldnerakten; § 135 Gesellschafterdarlehen, Bargeschäft; § 142 und Verteidigung des Anfechtungsgegners. Keine Rechtsberatung — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Triage — kläre vor der Prüfung

1. Besteht ein wirksamer Vertrag mit eigenem Rückabwicklungsregime (§§ 346 ff. BGB bei Rücktritt) — verdrängt dieser § 812 BGB?
2. Ist der Vertrag nichtig (§§ 134, 138, 142 BGB) — fehlt damit der Rechtsgrund für § 812 BGB?
3. Soll Schadensersatz (§§ 823 ff. BGB, Verschulden erforderlich) oder Herausgabe des Erlangten (§ 812 BGB, kein Verschulden) geltend gemacht werden?
4. Liegt eine Konstellation des Eigentümer-Besitzer-Verhältnisses vor (§§ 987 ff. BGB als lex specialis)?
5. Welche Verjährungsfrist ist günstiger (§ 195 BGB, 3 Jahre, gilt für alle)?

## Zentrale Normen

§ 812 Abs. 1 BGB (Leistungskondiktion) — §§ 346 ff. BGB (Rücktrittsfolgen) — §§ 134, 138, 142 BGB (Nichtigkeitsgründe) — §§ 823, 826 BGB (Deliktshaftung) — §§ 985–993 BGB (Eigentümer-Besitzer-Verhältnis) — § 195 BGB (Regelverjährung) — § 199 BGB (Verjährungsbeginn)

## Grundsatz: Subsidiarität des Bereicherungsrechts

Das Bereicherungsrecht ist in bestimmten Konstellationen subsidiär, in anderen kann es neben anderen Ansprüchen stehen.

## § 812 BGB neben vertraglichen Ansprüchen

### Nebeneinander möglich

- Nichtiger Vertrag: kein Erfüllungsanspruch, aber § 812 BGB greift.
- Anfechtung des Vertrags (§ 142 BGB): § 812 BGB für die Rückabwicklung.

### Ausschluss bei wirksamen Rückabwicklungsregeln

Bei Rücktritt (§§ 346 ff. BGB) verdrängen diese den § 812 BGB-Anspruch für die Rückabwicklung des konkreten Vertragsverhältnisses.

## § 812 BGB neben §§ 823 ff. BGB (Delikt)

**Nebeneinander:** Bereicherungsrecht und Deliktsrecht stehen nebeneinander.

**Unterschied:** Delikt setzt Verschulden voraus; § 812 BGB nicht. Deliktsrecht gewährt Schmerzensgeld; § 812 BGB nur Herausgabe des wirtschaftlichen Vorteils.

**Verjährung:** § 195 BGB (drei Jahre) gilt für beide; Beginn nach § 199 BGB.

## § 812 BGB neben §§ 987 ff. BGB (EBV)

**Vorrang des EBV:** §§ 987 ff. BGB sind als lex specialis gegenüber § 812 BGB zu betrachten, solange Eigentum und Besitz auseinanderfallen.

**Subsidiarität des § 812 BGB:** Ist § 985 BGB gegeben, kann daneben kein § 812 BGB-Anspruch auf denselben Gegenstand geltend gemacht werden.

**Ausnahme:** Nach Eigentumsübergang (z. B. gutgläubiger Erwerb) greift § 812 BGB wieder.

## Prüfschema

1. Wirksamer Vertrag mit Rücktrittsfolge? → §§ 346 ff. BGB verdrängen § 812 BGB.
2. Vertrag nichtig (§§ 134/138/142)? → § 812 BGB greift.
3. Delikt und Bereicherung nebeneinander? → ja, Wahl der günstigsten Grundlage.
4. EBV (§§ 987 ff.) einschlägig? → lex specialis, § 812 BGB tritt zurück.

## Output-Template

**Konkurrenzprüfung: § 812 BGB neben anderen Ansprüchen**

Sachverhalt (kurz): [...]

| Konkurrenz | Ergebnis |
|---|---|
| Wirksamer Vertrag + Rücktritt | §§ 346 ff. BGB vorrangig / § 812 verdrängt |
| Nichtiger Vertrag | § 812 Abs. 1 S. 1 BGB direkt einschlägig |
| Deliktshaftung §§ 823 ff. | nebeneinander mit § 812 BGB |
| EBV §§ 987 ff. / § 985 BGB | lex specialis; § 812 nur nach Eigentumsübergang |

**Empfehlung:** Stütze Klage primär auf [...]; hilfsweise auf [...].

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

<!-- BEGIN ausformulierungspflicht (autogen) -->
> **Ausformulierungspflicht und Formatstandard.** Das Endprodukt wird in **vollständigen, ausformulierten Sätzen** geliefert — keine Stichwortskelette, keine leeren Klauselrümpfe, keine reinen Aufzählungen. Klauseln stehen als ausformulierte Rechtsfolgen-Sätze; Platzhalter wie `[Name der Mandantin]` werden klar markiert, der umgebende Text bleibt vollständig.
>
> **Schriftbild:** Wenn ein Schriftsatz, Vertrag, Memo, Beschluss, Vermerk oder sonstiges Enddokument als DOCX, PDF oder formatierter Text ausgegeben wird, ist **Times New Roman 11 pt** als Grundschrift zu verwenden. Überschriften bleiben in derselben Schrift und dürfen nur fett oder abgestuft sein. Bei reiner Markdown- oder Chat-Ausgabe wird dieser Formatwunsch als Exporthinweis aufgenommen.
>
> **Nummerierung:** Gliederung ausschließlich dezimal (`1`, `1.1`, `1.1.1` und so weiter). Keine römischen Ziffern, keine Buchstaben- oder Mischgliederung.
<!-- END ausformulierungspflicht (autogen) -->

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
