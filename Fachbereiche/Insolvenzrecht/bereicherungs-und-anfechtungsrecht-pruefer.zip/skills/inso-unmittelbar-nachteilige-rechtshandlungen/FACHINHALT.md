---
name: inso-unmittelbar-nachteilige-rechtshandlungen
description: "Für Unmittelbar nachteilige Rechtshandlungen — Paragraf 132 InsO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: inso-unmittelbar-nachteilige-rechtshandlungen."
---

# Unmittelbar nachteilige Rechtshandlungen — § 132 InsO

## Triage — kläre vor der Prüfung

1. Handelt es sich um eine Deckungshandlung zugunsten eines Insolvenzgläubigers (→ §§ 130, 131 InsO vorrangig), oder um eine eigenständig benachteiligende Rechtshandlung?
2. Wurde die Rechtshandlung in den letzten drei Monaten vor Insolvenzantrag vorgenommen?
3. War der Schuldner zu diesem Zeitpunkt bereits zahlungsunfähig (§ 17 InsO)?
4. Kannte der andere Teil die Zahlungsunfähigkeit oder den Eröffnungsantrag?
5. Liegt eine besonders günstige Gegenleistung vor, die § 132 InsO ausschließt (marktgerechter Preis)?

## Zentrale Normen

§ 132 InsO (unmittelbar nachteilige Rechtshandlung) — § 129 InsO (Grundtatbestand) — § 130 InsO (Kenntnisregeln entsprechend) — § 131 InsO (inkongruente Deckung) — § 133 InsO (Vorsatzanfechtung) — § 17 InsO (Zahlungsunfähigkeit) — § 143 InsO (Rückgewähr)

## Rechtsprechung

Hinweis für diesen Auditstand: § 132 InsO wird hier bewusst am Gesetzestext geführt. Unsichere Altzitate wurden nicht als tragende Arbeitsregel übernommen.

## Obersatz

Anfechtbar ist nach § 132 Abs. 1 InsO ein Rechtsgeschäft des Schuldners, das die Insolvenzgläubiger unmittelbar benachteiligt, wenn es entweder in den letzten drei Monaten vor dem Eröffnungsantrag bei Zahlungsunfähigkeit und Kenntnis des anderen Teils vorgenommen wurde oder nach dem Eröffnungsantrag bei Kenntnis der Zahlungsunfähigkeit oder des Antrags.

## Abgrenzung zu §§ 130, 131 InsO

§ 132 InsO greift bei Rechtshandlungen, die keine Deckung eines Gläubigeranspruchs darstellen, sondern bei denen die Schädigung des Gläubigervermögens die unmittelbare Folge der Rechtshandlung selbst ist.

## Tatbestandsmerkmale

### 1. Unmittelbare Nachteiligkeit

Die Rechtshandlung selbst (ohne Zwischenschritte) muss das Schuldnervermögen zum Nachteil der Gläubiger vermindern.

**Beispiele:**
- Verkauf von Vermögensgegenständen unter dem Verkehrswert.
- Aufnahme eines Kredits mit überhöhten Zinsen kurz vor Insolvenz.
- Abschluss langfristiger Verträge zu unausgewogenen Bedingungen.

### 2. Zeitraum

Entweder letzte drei Monate vor Antrag oder Handlung nach Eröffnungsantrag.

### 3. Zahlungsunfähigkeit (§ 17 InsO)

Der Schuldner war zum Zeitpunkt der Handlung bereits zahlungsunfähig.

### 4. Kenntnis

§ 132 Abs. 3 InsO verweist auf § 130 Abs. 2 und 3 InsO. Kenntnis zwingender Umstände und die Vermutung bei nahestehenden Personen sind mitzudenken.

## Praktische Bedeutung

§ 132 InsO ist subsidiär gegenüber §§ 130, 131, 133, 134 InsO und wird selten eigenständig angewendet.

## Prüfschema

1. Deckungshandlung ausschließen (kein § 130/131 InsO)?
2. Unmittelbare Nachteiligkeit festgestellt?
3. Dreimonatsfrist?
4. Zahlungsunfähigkeit und Kenntnis nachgewiesen?
5. Nach Antrag: Kenntnis von Zahlungsunfähigkeit oder Antrag?

## Output-Template

**Prüfung § 132 InsO — Unmittelbar nachteilige Rechtshandlung**

Sachverhalt (kurz): [...]

| Merkmal | Ergebnis |
|---|---|
| §§ 130/131 InsO (Deckung) ausgeschlossen | ja / nein |
| Unmittelbare Nachteiligkeit | ja: [...] / nein |
| Zeitraum vor Insolvenzantrag | [...] Monate → ≤3 Monate? ja / nein |
| Zahlungsunfähigkeit § 17 InsO | ja / nein |
| Kenntnis des anderen Teils | ja / nein / offen |

**Ergebnis:** Anfechtung nach § 132 Abs. 1 Nr. [...] InsO [begründet / unbegründet].

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.
