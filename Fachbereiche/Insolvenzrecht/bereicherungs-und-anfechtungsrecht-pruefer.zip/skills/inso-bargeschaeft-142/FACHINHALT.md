---
name: inso-bargeschaeft-142
description: "Für Bargeschäft — Paragraf 142 InsO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Bargeschäft — § 142 InsO

## Triage — kläre vor der Prüfung

1. Welche Leistung hat der Schuldner erbracht?
2. Welche Gegenleistung ist unmittelbar in das Schuldnervermögen gelangt?
3. Sind Leistung und Gegenleistung objektiv gleichwertig?
4. Passt der zeitliche Zusammenhang zur Art der Leistung und den Gepflogenheiten des Geschäftsverkehrs?
5. Handelt es sich um Arbeitsentgelt?
6. Wird zusätzlich § 133 InsO behauptet?
7. Hat der andere Teil erkannt, dass der Schuldner unlauter handelte?

## Aktueller Gesetzeskern

§ 142 Abs. 1 InsO schützt Leistungen des Schuldners, für die unmittelbar eine gleichwertige Gegenleistung in sein Vermögen gelangt. Eine Anfechtung bleibt nur möglich, wenn die Voraussetzungen des § 133 Abs. 1 bis 3 InsO gegeben sind und der andere Teil erkannt hat, dass der Schuldner unlauter handelte.

§ 142 Abs. 2 InsO definiert die Unmittelbarkeit nach Art der ausgetauschten Leistungen und den Gepflogenheiten des Geschäftsverkehrs. Bei Arbeitsentgelt ist ein enger zeitlicher Zusammenhang gegeben, wenn zwischen Arbeitsleistung und Gewährung des Arbeitsentgelts höchstens drei Monate liegen.

## Keine pauschale 30-Tage-Regel

Eine starre 30-Tage-Grenze ist zu grob. Der Zusammenhang wird nach Leistungstyp, Branche, Zahlungsziel und Verkehrssitte bewertet. Für Arbeitsentgelt enthält das Gesetz ausdrücklich eine Drei-Monats-Regel.

## Prüfschema

1. Gegenleistung identifizieren: Was gelangte in das Schuldnervermögen?
2. Gleichwertigkeit prüfen: Marktpreis, Vertragswert, objektiver Vergleich.
3. Unmittelbarkeit prüfen: Zeitabstand und Geschäftsverkehrsübung.
4. Bei Arbeitsentgelt: Drei-Monats-Regel anwenden.
5. Bei § 133 InsO: zusätzlich erkannte Unlauterkeit prüfen.
6. Ergebnis nicht als "anfechtungsfest" ausgeben, wenn § 133-Indizien und Unlauterkeit offen sind.

## Typische Fehler

- bloße Zahlung auf Altschulden als Bargeschäft behandeln.
- Ratenzahlung ohne neue Gegenleistung als Bargeschäft einordnen.
- Lieferung und Zahlung nicht transaktionsscharf zuordnen.
- § 142 als Ausschluss jeder Vorsatzanfechtung verstehen.
- Kenntnis der Zahlungsunfähigkeit mit erkannter Unlauterkeit gleichsetzen.

## Output-Template

**Prüfung § 142 InsO — Bargeschäft**

| Merkmal | Ergebnis | Beleg |
|---|---|---|
| Leistung Schuldner | [...] | [...] |
| Gegenleistung in Masse | [...] | [...] |
| Gleichwertigkeit | ja/nein/offen | [...] |
| Unmittelbarkeit | ja/nein/offen | [...] |
| Arbeitsentgelt | ja/nein | [...] |
| § 133 zusätzlich behauptet | ja/nein | [...] |
| erkannte Unlauterkeit | ja/nein/offen | [...] |

**Ergebnis:** § 142 InsO [greift / greift nicht / offen]. Bei § 133 InsO bleibt Human Review erforderlich.

---

Hinweis: Keine Rechtsberatung. § 142 InsO schützt echten Austausch, nicht nachträgliche Krisenbereinigung.
