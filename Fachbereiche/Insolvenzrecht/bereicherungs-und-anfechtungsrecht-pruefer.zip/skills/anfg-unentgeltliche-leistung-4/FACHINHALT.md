---
name: anfg-unentgeltliche-leistung-4
description: "Für Unentgeltliche Leistung — Paragraf 4 AnfG: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: anfg-unentgeltliche-leistung-4."
---

# Unentgeltliche Leistung — § 4 AnfG

## Triage — kläre vor Prüfung § 4 AnfG

1. Erhielt der Schuldner eine gleichwertige Gegenleistung? (Verneinung → unentgeltlich)
2. Liegt eine gemischte Schenkung vor? (dann nur teilweise Anfechtung)
3. Wann erfolgte die Leistung — innerhalb der Vier-Jahres-Frist?
4. Handelt es sich um eine Erfüllung einer sittlichen Pflicht (§ 4 Abs. 2 AnfG — enge Ausnahme)?

## Zentrale Normen

- § 4 Abs. 1 AnfG — Anfechtung unentgeltlicher Leistungen (Frist 4 Jahre; kein Verschuldenserfordernis)
- § 4 Abs. 2 AnfG — Ausnahme: Erfüllung sittlicher Pflicht oder anständiger Rücksicht
- §§ 516 ff. BGB — Schenkung (Vergleichsbegriff; AnfG-Unentgeltlichkeit ist weiter)
- §§ 195 199 BGB — Verjährung des Anfechtungsanspruchs

## Obersatz

Anfechtbar sind unentgeltliche Leistungen des Schuldners, es sei denn, sie sind früher als vier Jahre vor der Anfechtungserklärung vorgenommen worden (§ 4 Abs. 1 AnfG).

## Tatbestandsmerkmale

### 1. Leistung des Schuldners

Jede Zuwendung, die das Vermögen des Schuldners vermindert.

### 2. Unentgeltlichkeit

**Definition:** Der Schuldner hat keine oder keine angemessene Gegenleistung erhalten. Maßgeblich ist der objektive Wert der Gegenleistung im Verhältnis zur Leistung des Schuldners.

**Gemischte Schenkung:** Liegt teilweise Entgeltlichkeit vor, ist die Anfechtung auf den unentgeltlichen Teil beschränkt.

**Nicht unentgeltlich:**
- Schenkung unter einer Auflage (soweit Auflage wirtschaftlich gleichwertig).
- Leistung in Erfüllung einer sittlichen Pflicht (enge Ausnahme nach § 4 Abs. 2 AnfG).

### 3. Anfechtungsfrist: Vier Jahre

Die Leistung muss innerhalb von vier Jahren vor der Anfechtungserklärung vorgenommen worden sein.

## Ausnahmen — § 4 Abs. 2 AnfG

Nicht anfechtbar: Schenkungen, die in der Erfüllung einer sittlichen Pflicht oder einer auf den Anstand zu nehmenden Rücksicht bestehen (z. B. übliche Gelegenheitsgeschenke). Diese Ausnahme ist eng auszulegen.

## Verhältnis zu § 3 AnfG

§ 4 AnfG erfordert kein Verschulden und keinen Benachteiligungsvorsatz. Er ist insofern leichter zu beweisen. Der Nachteil ist die kürzere Frist (vier statt zehn Jahre).

## Praktische Bedeutung

Typische Anwendungsfälle:
- Grundstücksübertragung an Ehepartner ohne Gegenleistung.
- Schenkung an Kinder kurz vor der Insolvenz.
- Verzicht auf eine Forderung ohne Gegenleistung.

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
