---
name: inso-grundtatbestand-129
description: "Für Grundtatbestand Insolvenzanfechtung — Paragraf 129 InsO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Tatbestands- oder Anspruchsmatrix."
---

# Grundtatbestand Insolvenzanfechtung — § 129 InsO

## Triage — kläre vor der Prüfung

1. Ist ein Insolvenzverfahren eröffnet, oder handelt es sich um eine Einzelgläubigeranfechtung (→ AnfG)?
2. Wann wurde die angefochtene Rechtshandlung vorgenommen — ist die Anfechtungsfrist noch offen?
3. Liegt eine Rechtshandlung (rechtlich wirksames Handeln/Unterlassen) oder ein bloßer Tatsachenakt vor?
4. Sind die Befriedigungsaussichten der Insolvenzgläubiger durch die Handlung tatsächlich verschlechtert worden?
5. Handelt es sich um unmittelbare oder mittelbare Benachteiligung?
6. Sind alle Tatsachen aus der Akte belegt, oder handelt es sich um KI-Inferenz?

## Zentrale Normen

§ 129 InsO (Grundtatbestand) — § 130 InsO (kongruente Deckung) — § 131 InsO (inkongruente Deckung) — § 132 InsO (unmittelbar nachteilige Rechtshandlung) — § 133 InsO (Vorsatzanfechtung) — § 134 InsO (unentgeltliche Leistung) — § 142 InsO (Bargeschäftsprivileg) — § 143 InsO (Rechtsfolge Rückgewähr) — § 27 InsO (Verfahrenseröffnung)

## Tatbestandsmerkmale § 129 Abs. 1 InsO

### 1. Rechtshandlung

**Definition:** Jedes Handeln oder Unterlassen, das eine rechtliche Wirkung auslöst und das Vermögen des Schuldners verändert. Dazu gehören:
- Kaufverträge, Abtretungen, Sicherungsübereignungen.
- Zahlungen auf bestehende Schulden.
- Vollstreckungsmaßnahmen (wenn der Schuldner diese ermöglicht).
- Unterlassen der Geltendmachung einer Forderung (in engen Grenzen).

**Nicht:** bloße Tatsachenakte ohne rechtliche Bindung.

### 2. Vor Eröffnung des Insolvenzverfahrens

Die Rechtshandlung muss vor Eröffnung des Insolvenzverfahrens vorgenommen worden sein (§ 27 InsO).

### 3. Objektive Gläubigerbenachteiligung

**Definition:** Tatsächliche Verschlechterung der Befriedigungsaussichten. Maßstab: hypothetischer Vergleich.

**Unmittelbare Benachteiligung:** Durch die Rechtshandlung selbst, ohne Zwischenschritte.

**Mittelbare Benachteiligung:** Durch das Zusammenspiel mit weiteren Umständen; Kausalzusammenhang muss feststehen.

### 4. Kausalität

Die Rechtshandlung muss kausal für die Benachteiligung sein: Wären die Gläubiger ohne die Handlung besser gestellt?

## KI-Auswertung von Schuldnerakten

Bei KI-gestützter Aktenauswertung darf § 129 InsO nur als Kandidat markiert werden, wenn Rechtshandlung, Zeitpunkt, Vermögensabfluss und Gläubigerbenachteiligung jeweils mit einer Quelle belegt sind. Nicht belegte Plausibilitäten werden als Lücke ausgegeben, nicht als Tatsache.

## Anfechtungsberechtigte

Regelmäßig macht der Insolvenzverwalter die Anfechtung geltend. In Eigenverwaltung ist § 280 InsO zu beachten; dort kann der Sachwalter Rechtshandlungen nach §§ 129 bis 147 InsO anfechten. Bei vorläufiger Verwaltung ist die konkrete gerichtliche Anordnung zu prüfen.

## Prüfschema

1. Insolvenzverfahren eröffnet + Anfechtungsbefugnis gegeben?
2. Liegt eine Rechtshandlung vor (kein bloßer Tatsachenakt)?
3. Handlung vor Verfahrenseröffnung?
4. Objektive Gläubigerbenachteiligung nachweisbar?
5. Kausalzusammenhang zwischen Handlung und Benachteiligung?

## Output-Template

**Prüfung § 129 InsO — Grundtatbestand Insolvenzanfechtung**

Sachverhalt (kurz): [...]

| Merkmal | Ergebnis |
|---|---|
| Insolvenzverfahren eröffnet | ja / nein |
| Anfechtungsberechtigter | Insolvenzverwalter / Sachwalter |
| Rechtshandlung identifiziert | ja: [...] |
| Zeitpunkt: vor Verfahrenseröffnung | ja / nein |
| Objektive Gläubigerbenachteiligung | ja (unmittelbar / mittelbar) / nein |
| Kausalzusammenhang | ja / nein |

**Weiter:** Besonderer Tatbestand (§§ 130–135 InsO): [...]

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
