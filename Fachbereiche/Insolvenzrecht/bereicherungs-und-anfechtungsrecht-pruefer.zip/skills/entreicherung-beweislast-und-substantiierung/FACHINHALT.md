---
name: entreicherung-beweislast-und-substantiierung
description: "Für Entreicherung: Beweislast und Substantiierung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Beweislast- und Substantiierungsmatrix."
---

# Entreicherung: Beweislast und Substantiierung

## Einsatzbereich

Anwendungsfall: wenn § 818 Abs. 3 BGB konkret behauptet oder angegriffen werden muss. Der Skill zwingt zu einer vermögensorientierten Prüfung: erst Vorteil und Zurechnung, dann Rechtsgrund und Behaltensgrund, zuletzt Umfang, Einreden und prozessuales Ziel.

## Triage — zuerst klären

1. Was war ursprünglich erlangt und was ist heute noch vorhanden?
2. Welche Nutzungen, Surrogate, Erlöse oder Ersatzforderungen gibt es?
3. Welche eigenen Ausgaben wurden erspart?
4. Wann traten Verlust, Verbrauch, Kenntnis und Rechtshängigkeit ein?
5. Welche Bewertungsmethode ist belegbar?

## Spezifischer Prüfungsfokus

- Bestimme den konkreten Vermögensvorteil und seine heutige Spur im Vermögen.
- Ordne den Vorteil einer Leistungsbeziehung, einem Eingriff oder einer sonstigen Erwerbslage zu.
- Prüfe Rechtsgrund und Behaltensgrund getrennt.
- Kontrolliere, ob § 818 BGB den Anspruch erweitert, begrenzt oder verschärft.
- Leite erst danach Anspruchsgegner, Anspruchshöhe und prozessuales Ziel ab.

## Prüfungslogik

- Erstelle eine Vermögensbilanz statt einer Gegenstandsliste.
- Prüfe Nutzungen, Surrogate und ersparte Aufwendungen vor § 818 Abs. 3 BGB.
- Bewerte Dienstleistung und Gebrauchsvorteil objektiv nach Markt- oder Nutzungswert.
- Ordne Wertverluste nach Risiko, Kenntnis und Rechtshängigkeit zu.
- Verlange substantiierte Belege für Entreicherung.

## Substantiierungstreppe

Eine Entreicherungseinrede ist erst prüffähig, wenn sie diese Treppe hochgeht:

1. **Was genau ist weggefallen?** Geldbetrag, Sache, Nutzung, Forderung, Befreiung, Erlös.
2. **Wann ist es weggefallen?** vor Kenntnis, nach Kenntnis, nach Mahnung, nach Rechtshängigkeit.
3. **Wie ist es weggefallen?** Verbrauch, Verlust, Weitergabe, Schuldtilgung, Verrechnung, Investition.
4. **Was trat an die Stelle?** Surrogat, Ersparnis, Nutzung, Ersatzforderung, Versicherungsleistung.
5. **Warum ist der Wegfall nicht eigenes Risiko?** keine bewusste Vermögensentscheidung, keine Schutzwertung gegen Einrede.

Fehlt eine Stufe, lautet der Output nicht "Entreicherung greift", sondern "Entreicherung nicht ausreichend dargelegt".

## Gegenprüfung des Anspruchstellers

- Kontoauszüge vor und nach Zufluss verlangen.
- Schuldtilgungen und ersparte Ausgaben identifizieren.
- Weitergaben an Dritte auf § 822 BGB prüfen.
- Kenntniszeitpunkt mit Schreiben, Mahnungen, Rückfragen und Vertragsunterlagen belegen.
- Bei Barabhebungen konkrete Verwendung und Zeitpunkt abfragen.

## Typische Fehler

- "Geld ist weg" als Ergebnis genügen lassen.
- Surrogate und Ersparnisse übersehen.
- Zinsen, Nutzungen und Wertersatz doppelt zählen.

## Arbeitsausgabe

| Punkt | Ergebnis | Belegbedarf |
|---|---|---|
| Anspruchsziel | [...] | [...] |
| beteiligte Personen | [...] | [...] |
| Vermögensvorteil | [...] | [...] |
| Zweck/Zurechnung | [...] | [...] |
| Rechtsgrund/Behaltensgrund | [...] | [...] |
| § 818 BGB | [...] | [...] |
| Einreden/Spezialregime | [...] | [...] |
| vorläufiges Ergebnis | [...] | [...] |

## Entreicherungs-Output

| Stufe | Vortrag ausreichend? | Risiko |
|---|---|---|
| Wegfallgegenstand konkret | ja / nein | [...] |
| Zeitpunkt belegt | ja / nein | [...] |
| Verbrauchsart belegt | ja / nein | [...] |
| Surrogat/Ersparnis ausgeschlossen | ja / nein | [...] |
| keine verschärfte Haftung | ja / nein | [...] |

## Mini-Check vor Output

- Kein Direktanspruch ohne begründete Zurechnung.
- Kein Wertersatz ohne Bewertungsmethode.
- Keine Entreicherung ohne konkreten Vermögensweg.
- Keine Saldierung ohne beiderseitige Leistungstabelle.
- Offene Tatsachen bleiben als offen markiert.

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.
