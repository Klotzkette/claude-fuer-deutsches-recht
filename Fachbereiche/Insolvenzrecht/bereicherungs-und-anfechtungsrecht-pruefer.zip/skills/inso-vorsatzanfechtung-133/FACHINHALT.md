---
name: inso-vorsatzanfechtung-133
description: "Für Vorsatzanfechtung — Paragraf 133 InsO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Vorsatzanfechtung — § 133 InsO

## Triage — kläre vor der Prüfung

1. Welche Rechtshandlung soll angefochten werden, und wann wurde sie nach § 140 InsO vorgenommen?
2. Handelt es sich um eine Deckungshandlung, also Sicherung oder Befriedigung eines Anspruchs?
3. Welche Tatsachen belegen den Benachteiligungsvorsatz des Schuldners?
4. Welche Tatsachen belegen die Kenntnis des Anfechtungsgegners?
5. Greift die Vermutung des § 133 Abs. 1 S. 2 InsO?
6. Greift bei kongruenter Deckung § 133 Abs. 3 InsO?
7. Wurde eine Zahlungsvereinbarung oder Zahlungserleichterung gewährt?
8. Liegt ein Bargeschäft nach § 142 InsO vor und hat der andere Teil unlauteres Handeln erkannt?

## Zentrale Normen

§ 133 InsO — § 129 InsO — § 130 InsO — § 131 InsO — § 138 InsO — § 140 InsO — § 142 InsO — § 143 InsO — § 17 InsO — § 18 InsO.

## Gesetzliche Struktur

| Norm | Inhalt | Zeitraum |
|---|---|---|
| § 133 Abs. 1 InsO | vorsätzliche Benachteiligung mit Kenntnis des anderen Teils | zehn Jahre vor Antrag oder nach Antrag |
| § 133 Abs. 2 InsO | Sicherung oder Befriedigung des anderen Teils | vier Jahre statt zehn Jahre |
| § 133 Abs. 3 S. 1 InsO | bei kongruenter Deckung tritt eingetretene Zahlungsunfähigkeit an die Stelle drohender Zahlungsunfähigkeit | nur bei Deckung |
| § 133 Abs. 3 S. 2 InsO | Zahlungsvereinbarung oder Zahlungserleichterung begründet Vermutung gegen Kenntnis der Zahlungsunfähigkeit | entlastender Anknüpfungspunkt |
| § 133 Abs. 4 InsO | entgeltlicher Vertrag mit nahestehender Person bei unmittelbarer Benachteiligung | ausgeschlossen, wenn früher als zwei Jahre vor Antrag |

Wichtig: Die Vier-Jahres-Frist des § 133 Abs. 2 InsO gilt für Deckungshandlungen, nicht nur für nahestehende Personen. Nahestehende Personen sind in § 133 Abs. 4 InsO gesondert geregelt.

## Rechtsprechungsleitlinien BGH IX. ZS (offene Quellen)

- BGH, Urt. v. 06.05.2021 – Az. IX ZR 72/20 — Neuausrichtung der Vorsatzanfechtung; alleinige Kenntnis der Zahlungsunfaehigkeit traegt den Benachteiligungsvorsatz nicht mehr schematisch; massgeblich ist Wissen oder Inkaufnahme, dass kuenftige Gläubiger nicht voll befriedigt werden. Quelle: https://dejure.org/dienste/vernetzung/rechtsprechung?Gericht=BGH&Datum=06.05.2021&Aktenzeichen=IX+ZR+72/20
- BGH, Urteil vom 18.04.2024 - IX ZR 129/22: Ein außenstehender Dritter darf einen nur pauschal aufgestellten und nicht mit Einzelpositionen oder Belegen unterlegten Liquiditätsstatus grundsätzlich einfach bestreiten. Die Entscheidung ist ein Darlegungsanker zu Paragraf 17 InsO, kein pauschaler Beleg für geringere Anfechtungsrisiken.
- BGH, Urteil vom 18.04.2024 - IX ZR 239/22: Eine Deckungslücke, aus der auf fehlende künftige Vollbefriedigung geschlossen werden soll, kann regelmäßig nicht allein aus den schon für die Zahlungseinstellung verwendeten Verbindlichkeiten abgeleitet werden. Wiederholte Zahlungsverzögerungen reichen für die Überzeugung von einer Zahlungseinstellung häufig nicht. Quelle: https://dejure.org/dienste/vernetzung/rechtsprechung?Gericht=BGH&Datum=18.04.2024&Aktenzeichen=IX+ZR+239/22
- Weiterfuehrende Rechtsprechungsdurchsicht: https://www.bundesgerichtshof.de und https://openjur.de.

## § 133 als Human-Review-Norm

§ 133 InsO enthält innere Tatsachen und Gesamtwürdigung. Die KI darf hier eine Indizienmatrix bauen, aber nicht ohne fachliche Prüfung "Vorsatz bewiesen" schreiben.

| Indiz | Belastet | Entlastet |
|---|---|---|
| erkannte Zahlungsunfähigkeit | kann Vorsatz und Kenntnis stützen | genügt nach neuerer BGH-Linie nicht schematisch allein |
| inkongruente Deckung | starkes Indiz | Einzelfall und Gegenindizien prüfen |
| Zahlungsvereinbarung | kann Krise zeigen | § 133 Abs. 3 S. 2 InsO vermutet fehlende Kenntnis der Zahlungsunfähigkeit |
| Sanierungsversuch | nur belastend, wenn erkennbar untauglich | tragfähiges Konzept kann Vorsatz entkräften |
| Vollbefriedigungsperspektive | entlastend | nur mit belastbaren Informationen |

## Bargeschäft bei § 133

§ 142 Abs. 1 InsO lässt ein Bargeschäft nur anfechten, wenn die Voraussetzungen des § 133 Abs. 1 bis 3 InsO vorliegen **und** der andere Teil erkannt hat, dass der Schuldner unlauter handelte. Deshalb muss bei Bargeschäften ein eigener Unlauterkeits- und Kenntnisblock ausgefüllt werden.

## Prüfschema

1. § 129 InsO: Rechtshandlung, Gläubigerbenachteiligung, Anfechtungsbefugnis.
2. § 133 Abs. 1: Benachteiligungsvorsatz des Schuldners.
3. Kenntnis des anderen Teils oder Vermutung nach § 133 Abs. 1 S. 2.
4. Bei Deckung: Zeitraum auf vier Jahre begrenzen.
5. Bei kongruenter Deckung: § 133 Abs. 3 prüfen.
6. Zahlungserleichterung: Vermutung fehlender Kenntnis der Zahlungsunfähigkeit prüfen.
7. Nahestehende Person und § 133 Abs. 4 gesondert prüfen.
8. Bargeschäft und Unlauterkeit nach § 142 InsO prüfen.

## Output-Template

**Prüfung § 133 InsO — Vorsatzanfechtung**

| Merkmal | Ergebnis | Beleg |
|---|---|---|
| Rechtshandlung und Zeitpunkt | [...] | [...] |
| Deckungshandlung | ja/nein | [...] |
| maßgeblicher Zeitraum | zehn Jahre/vier Jahre/zwei Jahre | [...] |
| Benachteiligungsvorsatz | belegt/offen/nicht belegt | [...] |
| Kenntnis des anderen Teils | belegt/vermutet/widerlegt/offen | [...] |
| § 133 Abs. 3 | greift/greift nicht | [...] |
| Zahlungsvereinbarung | ja/nein | [...] |
| Bargeschäft und Unlauterkeit | ja/nein/offen | [...] |

**Ergebnis:** § 133 InsO [nicht tragfähig / nur Prüfspur / tragfähig nach Human Review].

---

Hinweis: Keine Rechtsberatung. § 133 InsO ist keine reine Mustererkennung; jede KI-Ausgabe muss die Indizien und Gegenindizien sichtbar machen.
