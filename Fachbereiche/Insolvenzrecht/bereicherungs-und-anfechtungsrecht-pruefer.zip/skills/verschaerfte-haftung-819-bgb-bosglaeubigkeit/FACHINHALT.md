---
name: verschaerfte-haftung-819-bgb-bosglaeubigkeit
description: "Für Verschärfte Haftung — Paragraf 819 BGB bei Bösgläubigkeit: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Schnittstellenkarte mit Zuständigkeits- und Nachweisfragen."
---

# Verschärfte Haftung — § 819 BGB bei Bösgläubigkeit

## Triage — kläre vor der Prüfung

1. Wann hatte der Empfänger Kenntnis vom Mangel des Rechtsgrundes (§ 819 Abs. 1 BGB)?
2. Liegt ein Verstoß gegen ein Verbotsgesetz oder die guten Sitten vor (§ 819 Abs. 2 i.V.m. § 817 S. 1 BGB)?
3. Wann wurde die Klage zugestellt (Rechtshängigkeit → § 818 Abs. 4 BGB)?
4. Welche Nutzungen, Gebrauchsvorteile oder Surrogate sind ab Bösgläubigkeit angefallen?
5. Ist der Gegenstand nach Bösgläubigkeit zufällig untergegangen (verschärfte Zufallshaftung)?
- **Was will der Mandant wirklich erreichen?** (Nicht: was steht im Standardweg, sondern: welches Ergebnis ist für den Mandanten persönlich/wirtschaftlich das beste? Manchmal ist der schnellere Vergleich besser als der formal "richtige" Weg.)

## Zentrale Normen

§ 819 Abs. 1 BGB (Bösgläubigkeit: Kenntnis des Mangels) — § 819 Abs. 2 BGB (Gesetz-/Sittenverstoß) — § 818 Abs. 3 BGB (Entreicherungseinrede: ausgeschlossen) — § 818 Abs. 4 BGB (Rechtshängigkeit) — § 292 BGB (Haftung bei Pflicht zur Herausgabe) — §§ 987–993 BGB (EBV, entsprechend) — § 817 S. 1 BGB (verbotener Zweck beim Empfänger)

## Tatbestand § 819 Abs. 1 BGB — Kenntnis des Mangels

**Voraussetzung:** Positive Kenntnis der Tatsachen, aus denen sich das Fehlen des Rechtsgrundes ergibt. Grob fahrlässige Unkenntnis genügt nach dem Gesetzeswortlaut nicht (str.).

**Zeitpunkt:** Kenntnis muss nicht bei Empfang vorliegen; spätere Kenntnis führt zur verschärften Haftung ab dem Zeitpunkt der Kenntniserlangung.

## Tatbestand § 819 Abs. 2 BGB — Gesetzes- oder Sittenverstoß

Ist der Empfang der Leistung mit einem Verstoß gegen ein gesetzliches Verbot oder die guten Sitten verbunden (§ 817 S. 1 BGB), tritt die verschärfte Haftung ab Empfang ein.

## Rechtsfolge der Verschärfung

- Kein Entreicherungseinwand nach § 818 Abs. 3 BGB.
- Haftung für zufälligen Untergang (§ 287 S. 2 BGB analog).
- Herausgabe von Nutzungen auch wenn nicht gezogen aber hätten können werden können.
- Haftung für Verschlechterungen.

## Rechtshängigkeit (§ 818 Abs. 4 BGB)

Ab Zustellung der Klageschrift: dieselben verschärften Regeln, unabhängig von Bösgläubigkeit.

## Prüfschema

**Vorab:** Der untenstehende ist die typische Standardlinie. Wenn die Mandantenlage abweicht (siehe "Strategische Optionen" oben), sind die Schritte entsprechend zu verkürzen, umzustellen oder durch ein anderes Skill zu ersetzen — der ist Leitfaden, nicht Pflichtprogramm.

1. Wann Kenntnis vom Mangel des Rechtsgrundes (§ 819 Abs. 1)?
2. Gesetz-/Sittenverstoß beim Empfänger (§ 819 Abs. 2)?
3. Wann Zustellung Klageschrift (Rechtshängigkeit § 818 Abs. 4)?
4. Nutzungen und Schäden ab diesem Zeitpunkt?

## Strategische Optionen (vor dem Template entscheiden)

Bevor das Template eins-zu-eins gefüllt wird, ist zu prüfen welche Variante zur Mandantenkonstellation passt. Das Template ist **eine** mögliche Form — nicht die einzige.

| Konstellation | Empfohlener Weg |
|---|---|
| Standard — Bereicherungsschuldner bösgläubig ab bestimmtem Zeitpunkt | § 819 Abs. 1 Kenntnisnachweis; Template-Prüfung unten |
| Variante A — Kenntnis schwer nachweisbar | Häufung von Indizien; Rechtshängigkeits-Zustellzeitpunkt sicherer |
| Variante B — Gesetzes- oder Sittenverstoß (§ 819 Abs. 2) | Verschärfung ab Empfang; kein Kenntnisnachweis nötig |
| Variante C — Gesamtschuldner mit unterschiedlicher Kenntnis | Individuell je Schuldner prüfen; kein Einheitsansatz |

Wenn die Mandantenkonstellation **nicht** ins Standardschema passt, ist das Template anzupassen oder durch ein anderes Skill abzulösen — nicht das Mandat in das Schema zu pressen.

## Output-Template

**Prüfung § 819 BGB — Verschärfte Haftung**

Sachverhalt (kurz): [...]

| Merkmal | Ergebnis |
|---|---|
| Positive Kenntnis des Mangels (§ 819 Abs. 1) | ja ab [...] / nein |
| Gesetz-/Sittenverstoß (§ 819 Abs. 2) | ja → ab Empfang / nein |
| Rechtshängigkeit (§ 818 Abs. 4) | ab [...] (Zustellung) |
| Entreicherungseinrede ausgeschlossen | ja (ab Bösgläubigkeit/Rechtshängigkeit) |
| Nutzungen herausgebbar | ja: [...] EUR / nein |
| Zufälliger Untergang ab Bösgläubigkeit | ja → haftet / nein |

**Ergebnis:** Verschärfte Haftung nach § 819 BGB ab [...]. Anspruch in Höhe von [...] EUR.

---

--- vor Versand klären ---
1. Welches Verhandlungsziel hat der Mandant? [Bestand / Abfindung / Reputation / Schnelle Lösung]
2. Welche Kompromisslinien sind absolut? [Mindestabfindung / Freistellung / Zeugnisformulierung]
3. Sind Anschlusswege erwünscht? [Mediation / Direktgespräch / Settlement vor Klageerhebung]

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
