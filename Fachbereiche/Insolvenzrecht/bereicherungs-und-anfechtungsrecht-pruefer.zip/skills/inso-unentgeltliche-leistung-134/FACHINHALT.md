---
name: inso-unentgeltliche-leistung-134
description: "Für Unentgeltliche Leistung — Paragraf 134 InsO: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Unentgeltliche Leistung — § 134 InsO

## Triage — kläre vor der Prüfung

1. Hat der Schuldner eine Zuwendung ohne angemessene Gegenleistung erbracht (vollständig oder teilweise unentgeltlich)?
2. Liegt die Handlung innerhalb der Vier-Jahres-Frist vor dem Insolvenzantrag?
3. Handelt es sich um ein gebräuchliches Gelegenheitsgeschenk oder eine sittliche Pflicht (Ausnahme § 134 Abs. 2 InsO)?
4. Gibt es eine teilweise Gegenleistung, sodass nur der unentgeltliche Teil zu prüfen ist?
5. Kommt statt § 134 InsO ein spezieller Tatbestand in Betracht, insbesondere § 135 InsO bei Gesellschafterdarlehen?

## Zentrale Normen

§ 134 InsO (unentgeltliche Leistung, 4-Jahres-Frist) — § 135 InsO (Gesellschafterdarlehen und gleichgestellte Forderungen) — § 138 InsO (nahestehende Personen) — § 129 InsO (Grundtatbestand) — § 143 InsO (Rückgewähr) — § 516 BGB (Schenkungsvertrag) — §§ 812 ff. BGB (Bereicherungsrecht, Konkurrenz)

## Rechtsprechung

Hinweis für diesen Auditstand: § 134 InsO wird hier vorrangig aus dem aktuellen Gesetzestext geprüft. Unsichere Einzelfallzitate sind nicht erforderlich; bei konkreter Prozessverwendung sind Rechtsprechungsnachweise fallbezogen nachzuziehen.

## Obersatz

Anfechtbar sind nach § 134 Abs. 1 InsO unentgeltliche Leistungen des Schuldners, es sei denn, sie sind früher als vier Jahre vor Insolvenzantrag vorgenommen worden.

## Tatbestandsmerkmale

### 1. Unentgeltliche Leistung

**Vollständige Unentgeltlichkeit:** Schenkung, unentgeltliche Sicherungsübereignung, Schulderlass ohne Gegenleistung.

**Teilweise Unentgeltlichkeit:** Gemischte Schenkung — Anfechtung nur für den unentgeltlichen Teil.

**Maßstab:** Objektiver Wertvergleich; keine oder erheblich hinter dem Wert zurückbleibende Gegenleistung.

### 2. Vier-Jahres-Frist

Die Leistung muss innerhalb von vier Jahren vor dem Insolvenzantrag vorgenommen worden sein.

### 3. Kein Verschulden erforderlich

§ 134 InsO setzt weder Benachteiligungsvorsatz noch Kenntnis des Anfechtungsgegners voraus.

## Ausnahmen § 134 Abs. 2 InsO

Nicht anfechtbar:
- Gebräuchliche Gelegenheitsgeschenke (Geburtstag, Weihnachten) von angemessenem Wert.
- Leistungen in Erfüllung einer sittlichen Pflicht.

## Typische Anwendungsfälle

- Grundstücksübertragung an Familienangehörige kurz vor Insolvenz.
- Schenkung erheblicher Barmittel an Lebenspartner.
- Verzicht auf Forderungen ohne Gegenleistung.
- Sicherheitsübereignung ohne zugrundeliegende gesicherte Forderung.

## Prüfschema

1. Unentgeltlich (ganz oder teilweise)?
2. Frist: innerhalb von vier Jahren vor Insolvenzantrag?
3. Ausnahme § 134 Abs. 2 InsO (Gelegenheitsgeschenk, sittliche Pflicht)?
4. Bei Gesellschafterdarlehen oder gleichgestellter Forderung → § 135 InsO prüfen.

## Output-Template

**Prüfung § 134 InsO — Unentgeltliche Leistung**

Sachverhalt (kurz): [...]

| Merkmal | Ergebnis |
|---|---|
| Unentgeltlichkeit (objektiv) | vollständig / teilweise / nein |
| Wert der Gegenleistung (falls vorhanden) | [...] EUR |
| Zeitraum vor Insolvenzantrag | [...] Jahre → innerhalb 4 Jahre? ja / nein |
| Ausnahme § 134 Abs. 2 InsO | nein / ja: [...] |
| Gesellschafterdarlehen oder gleichgestellte Forderung | ja → § 135 InsO prüfen |

**Ergebnis:** Anfechtung nach § 134 Abs. 1 InsO [begründet / unbegründet]. Rückgewährpflicht: [...].

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

<!-- BEGIN ausformulierungspflicht (autogen) -->
> **Ausformulierungspflicht und Formatstandard.** Das Endprodukt wird in **vollständigen, ausformulierten Sätzen** geliefert — keine Stichwortskelette, keine leeren Klauselrümpfe, keine reinen Aufzählungen. Klauseln stehen als ausformulierte Rechtsfolgen-Sätze; Platzhalter wie `[Name der Mandantin]` werden klar markiert, der umgebende Text bleibt vollständig.
>
> **Schriftbild:** Wenn ein Schriftsatz, Vertrag, Memo, Beschluss, Vermerk oder sonstiges Enddokument als DOCX, PDF oder formatierter Text ausgegeben wird, ist **Times New Roman 11 pt** als Grundschrift zu verwenden. Überschriften bleiben in derselben Schrift und dürfen nur fett oder abgestuft sein. Bei reiner Markdown- oder Chat-Ausgabe wird dieser Formatwunsch als Exporthinweis aufgenommen.
>
> **Nummerierung:** Gliederung ausschließlich dezimal (`1`, `1.1`, `1.1.1` und so weiter). Keine römischen Ziffern, keine Buchstaben- oder Mischgliederung.
<!-- END ausformulierungspflicht (autogen) -->

