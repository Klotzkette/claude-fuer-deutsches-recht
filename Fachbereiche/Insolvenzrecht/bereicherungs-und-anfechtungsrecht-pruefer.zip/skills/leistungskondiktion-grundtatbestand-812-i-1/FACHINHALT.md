---
name: leistungskondiktion-grundtatbestand-812-i-1
description: "Für Leistungskondiktion — Grundtatbestand Paragraf 812 Abs. 1 S. 1 Alt. 1 BGB: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Tatbestands- oder Anspruchsmatrix. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: leistungskondiktion-grundtatbestand-812-i-1."
---

# Leistungskondiktion — Grundtatbestand § 812 Abs. 1 S. 1 Alt. 1 BGB

## Triage — kläre vor der Prüfung

1. Was wurde konkret erlangt (Sache, Geld, Forderung, Nutzung, Befreiung von Schuld)?
2. Erfolgte die Vermögensmehrung durch eine Leistung (bewusste, zweckgerichtete Mehrung) des Gläubigers?
3. Fehlt ein Rechtsgrund für das Behaltendürfen — war er von Anfang an nicht vorhanden oder ist er nachträglich weggefallen?
4. Greift ein Ausschlussgrund (§ 814, § 817 S. 2, § 813 BGB)?
5. In welchem Umfang ist die Bereicherung herauszugeben (§§ 818, 819 BGB)?

## Zentrale Normen

§ 812 Abs. 1 S. 1 Alt. 1 BGB (Leistungskondiktion) — § 812 Abs. 1 S. 2 Alt. 1 BGB (condictio ob causam finitam) — § 813 BGB (dauernde Einreden) — § 814 BGB (Kenntnis der Nichtschuld) — § 817 BGB (Gesetzes-/Sittenverstoß) — § 818 BGB (Umfang der Herausgabe) — § 819 BGB (verschärfte Haftung) — §§ 134, 138, 142 BGB (Nichtigkeitsgründe)

## Dogmatischer Kontrollblick

Prüfe die Leistungskondiktion nicht als bloße Rückholung eines Gegenstands. Baue immer eine kurze Vermögens- und Zweckanalyse ein:

1. **Erlangtes:** Welcher messbare Vorteil ist dem Beklagten wirklich zugeflossen oder erspart worden?
2. **Leistungszweck:** Welchen Zweck sollte die Zuwendung aus Sicht eines objektiven Empfängers erfüllen?
3. **Rechtsgrund:** Gab es für diesen Zweck einen wirksamen Grund bei Leistung?
4. **Behaltensgrund:** Darf der Empfänger den Vorteil heute noch behalten, obwohl der ursprüngliche Zweck fehlt, weggefallen oder nur teilweise erfüllt ist?
5. **Risikozuweisung:** Würde eine Rückforderung eine gesetzliche oder vertragliche Risikoverteilung unterlaufen?

Wenn eine dieser Ebenen unklar bleibt, verwende zuerst `rechtsgrund-und-behaltensgrund-prüfen` und bei gegenseitigen Verträgen zusätzlich `saldotheorie-rueckabwicklung-nichtiger-vertraege`.

## Obersatz

Der Schuldner des Bereicherungsanspruchs hat etwas ohne rechtlichen Grund durch die Leistung des Gläubigers erlangt und ist daher zur Herausgabe verpflichtet (§ 812 Abs. 1 S. 1 Alt. 1 BGB).

## Tatbestandsmerkmale

### 1. Etwas erlangt

Jeder vermögenswerte Vorteil: Eigentum, Geld, Forderungen, Nutzungen, Befreiung von Verbindlichkeiten, ersparte Aufwendungen oder ein wirtschaftlich bewertbarer Gebrauchsvorteil. Die Bezeichnung des Gegenstands reicht nicht; der Vorteil muss in der Vermögensbilanz des Empfängers nachvollziehbar werden.

### 2. Durch Leistung

Bewusste und zweckgerichtete Mehrung fremden Vermögens. Die Zweckbestimmung muss dem Empfänger erkennbar sein. In Mehrpersonenverhältnissen ist vor jeder Anspruchsformulierung eine Leistungskarte zu erstellen: Wer bestimmt den Zweck, wer soll tilgen, wem wird der Vorteil rechtlich zugerechnet?

### 3. Ohne Rechtsgrund

- Kein Vertrag (Angebot/Annahme fehlerhaft).
- Vertrag nichtig (§§ 134, 138 BGB).
- Vertrag wirksam angefochten (§ 142 BGB).
- Rechtsgrund nachträglich weggefallen (Rücktritt, Bedingungseintritt).
- Zweck verfehlt oder nicht erreicht, wenn der Zweck rechtlich beachtlich und für den Empfänger erkennbar war.
- Teilmangel, etwa Überzahlung, falscher Zeitraum oder falsche Abrechnung.

## Behaltensgrund nachschalten

Auch bei fehlendem Rechtsgrund kann die Anspruchshöhe oder der Anspruch selbst an einer Behaltenswertung scheitern:

- § 814 BGB bei positiver Kenntnis der Nichtschuld.
- § 817 S. 2 BGB bei eigenem Gesetzes- oder Sittenverstoß.
- Spezielle Rückabwicklung, etwa Rücktrittsrecht, Widerrufsrecht, EBV, Gesellschaftsrecht oder Insolvenzrecht.
- Saldierung bei nichtigem gegenseitigem Vertrag.
- § 818 Abs. 3 BGB nur nach Prüfung von Nutzungen, Surrogaten, ersparten Aufwendungen und Risikozurechnung.

## Rechtsfolge

Herausgabe des Erlangten (§ 818 Abs. 1 BGB). Bei Unmöglichkeit: Wertersatz (§ 818 Abs. 2 BGB). Entreicherungseinrede (§ 818 Abs. 3 BGB) möglich. Verschärfte Haftung bei Bösgläubigkeit (§ 819 BGB).

## Ausschlussgründe

- § 814 BGB: positive Kenntnis der Nichtschuld.
- § 817 S. 2 BGB: eigener Gesetzes- oder Sittenverstoß.
- § 813 BGB: einredebehaftete Forderung.

## Prüfschema

1. Etwas erlangt (messbarer Vorteil)?
2. Durch Leistung (bewusst, zweckgerichtet)?
3. Ohne Rechtsgrund (ursprünglich fehlend oder nachträglich weggefallen)?
4. Behaltensgrund oder spezielles Rückabwicklungsregime?
5. Ausschlussgrund (§§ 813–817 BGB)?
6. Umfang Herausgabe (§§ 818–819 BGB)?

## Output-Template

**Prüfung § 812 Abs. 1 S. 1 Alt. 1 BGB — Leistungskondiktion**

Sachverhalt (kurz): [...]

| Merkmal | Ergebnis |
|---|---|
| Erlangter Vorteil | [...] (Geld / Sache / Forderung / Nutzung) |
| Leistung (bewusst, zweckgerichtet) | ja / nein |
| Rechtsgrund | fehlte von Anfang an / nachträglich weggefallen |
| Behaltensgrund heute | nein / ja: [...] |
| Ausschlussgrund (§§ 813–817 BGB) | nein / ja: [...] |
| Entreicherung (§ 818 Abs. 3 BGB) | nein / ja: noch [...] EUR vorhanden |
| Verschärfte Haftung (§ 819 BGB) | nein / ja: bösgläubig seit [...] |

**Ergebnis:** Bereicherungsanspruch i.H.v. [...] EUR. Herausgabe [in Natur / als Wertersatz].

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

<!-- BEGIN ausformulierungspflicht (autogen) -->
> **Ausformulierungspflicht und Formatstandard.** Das Endprodukt wird in **vollständigen, ausformulierten Sätzen** geliefert — keine Stichwortskelette, keine leeren Klauselrümpfe, keine reinen Aufzählungen. Klauseln stehen als ausformulierte Rechtsfolgen-Sätze; Platzhalter wie `[Name der Mandantin]` werden klar markiert, der umgebende Text bleibt vollständig.
>
> **Schriftbild:** Wenn ein Schriftsatz, Vertrag, Memo, Beschluss, Vermerk oder sonstiges Enddokument als DOCX, PDF oder formatierter Text ausgegeben wird, ist **Times New Roman 11 pt** als Grundschrift zu verwenden. Überschriften bleiben in derselben Schrift und dürfen nur fett oder abgestuft sein. Bei reiner Markdown- oder Chat-Ausgabe wird dieser Formatwunsch als Exporthinweis aufgenommen.
>
> **Nummerierung:** Gliederung ausschließlich dezimal (`1`, `1.1`, `1.1.1` und so weiter). Keine römischen Ziffern, keine Buchstaben- oder Mischgliederung.
<!-- END ausformulierungspflicht (autogen) -->

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
