---
name: drittleistung-bgb-ebv-bereicherungsrecht
description: "Für Drittleistung nach Paragraf 267 BGB und Rückgriff: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: drittleistung-bgb-ebv-bereicherungsrecht."
---

# Drittleistung nach § 267 BGB und Rückgriff

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: §§ 812 ff. BGB, AnfG und Insolvenzanfechtung; §§ 129-147 InsO. Mit KI-Screening von Schuldnerakten; § 135 Gesellschafterdarlehen, Bargeschäft; § 142 und Verteidigung des Anfechtungsgegners. Keine Rechtsberatung — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Einsatzbereich

Anwendungsfall: ein Dritter bewusst auf eine fremde Schuld gezahlt haben könnte. Der Skill zwingt zu einer vermögensorientierten Prüfung: erst Vorteil und Zurechnung, dann Rechtsgrund und Behaltensgrund, zuletzt Umfang, Einreden und prozessuales Ziel.

## Triage — zuerst klären

1. Welche Personen und Beziehungen bilden das Leistungsdreieck oder die Kette?
2. Wer hat den Leistungszweck objektiv gesetzt?
3. War eine Anweisung, Vollmacht, Zession oder Drittleistung wirksam und zurechenbar?
4. Welches Verhältnis ist fehlerhaft?
5. Würde ein Direktanspruch nur ein Insolvenz- oder Vertragsrisiko verschieben?

## Spezifischer Prüfungsfokus

- Bestimme den konkreten Vermögensvorteil und seine heutige Spur im Vermögen.
- Ordne den Vorteil einer Leistungsbeziehung, einem Eingriff oder einer sonstigen Erwerbslage zu.
- Prüfe Rechtsgrund und Behaltensgrund getrennt.
- Kontrolliere, ob § 818 BGB den Anspruch erweitert, begrenzt oder verschärft.
- Leite erst danach Anspruchsgegner, Anspruchshöhe und prozessuales Ziel ab.

## Prüfungslogik

- Zeichne Deckung, Valuta und Zahlungsweg vor der Anspruchswahl.
- Bestimme den Empfängerhorizont des Endempfängers.
- Wickle Fehler grundsätzlich in der jeweils fehlerhaften Beziehung ab.
- Prüfe Direktkondiktion nur mit eigenständiger Ausnahmebegründung.
- Halte Vertrauensschutz und Risikozuweisung ausdrücklich fest.

## Drittleistungsfilter

| Lage | Bereicherungsrechtliche Folge |
|---|---|
| D zahlt bewusst auf Schuld des S | Gläubiger hat Behaltensgrund durch Tilgung |
| D zahlt irrtümlich auf eigene vermeintliche Schuld | Leistungskondiktion D gegen Gläubiger prüfen |
| D zahlt als Vertreter/Bote des S | Zurechnung zu S, Rückgriff im Innenverhältnis |
| Schuld des S bestand nicht | Empfängerhorizont entscheidet, ob D oder S kondiziert |
| D tilgt wirksam und will Rückgriff | Anspruch gegen S aus Auftrag, GoA oder Bereicherung prüfen |

Der Gläubiger ist nicht deshalb bereichert, weil das Geld von D kam. Wenn eine bestehende Schuld erfüllt wurde, ist die Befreiung des Schuldners der zentrale Vermögensvorteil.

## Typische Fehler

- Tatsächlichen Empfänger automatisch als Schuldner behandeln.
- Doppelmangel zu einem Pauschalanspruch verschmelzen.
- Insolvenzrisiko ohne Rechtsgrund verlagern.

## Arbeitsausgabe

| Punkt | Ergebnis | Belegbedarf |
|---|---|---|
| Anspruchsziel | [...] | [...] |
| beteiligte Personen | [...] | [...] |
| Vermögensvorteil | [...] | [...] |
| Zweck/Zurechnung | [...] | [...] |
| Rechtsgrund/Behaltensgrund | [...] | [...] |
| § 818 BGB | [...] | [...] |
| Einreden/Spezialregime | [...] | [...] |
| vorläufiges Ergebnis | [...] | [...] |

## Rückgriffsmatrix

| Frage | Ergebnis |
|---|---|
| Schuld bestand? | ja / nein |
| Zahlung sollte wessen Schuld tilgen? | [...] |
| Gläubiger hat Behaltensgrund? | ja / nein |
| Befreiter Schuldner ist bereichert? | ja / nein |
| Rückgriff gegen | Schuldner / Gläubiger / beide hilfsweise |

## Mini-Check vor Output

- Kein Direktanspruch ohne begründete Zurechnung.
- Kein Wertersatz ohne Bewertungsmethode.
- Keine Entreicherung ohne konkreten Vermögensweg.
- Keine Saldierung ohne beiderseitige Leistungstabelle.
- Offene Tatsachen bleiben als offen markiert.

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.
