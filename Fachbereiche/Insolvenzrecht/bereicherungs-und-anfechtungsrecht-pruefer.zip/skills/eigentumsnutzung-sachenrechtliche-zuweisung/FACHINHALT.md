---
name: eigentumsnutzung-sachenrechtliche-zuweisung
description: "Für Eigentumsnutzung und sachenrechtliche Zuweisung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: eigentumsnutzung-sachenrechtliche-zuweisung."
---

# Eigentumsnutzung und sachenrechtliche Zuweisung

## Einsatzbereich

Anwendungsfall: fremdes Eigentum wirtschaftlich genutzt wurde. Der Skill zwingt zu einer vermögensorientierten Prüfung: erst Vorteil und Zurechnung, dann Rechtsgrund und Behaltensgrund, zuletzt Umfang, Einreden und prozessuales Ziel.

## Triage — zuerst klären

1. Welche Rechtsposition weist den wirtschaftlichen Nutzen zu?
2. Hat der Gegner diese Position ohne Leistung des Anspruchstellers genutzt?
3. Gab es Lizenz, Gestattung oder gesetzliche Erlaubnis?
4. Ist § 816 BGB oder § 822 BGB spezieller?
5. Wie wird der objektive Nutzungs- oder Lizenzwert bestimmt?

## Spezifischer Prüfungsfokus

- Bestimme den konkreten Vermögensvorteil und seine heutige Spur im Vermögen.
- Ordne den Vorteil einer Leistungsbeziehung, einem Eingriff oder einer sonstigen Erwerbslage zu.
- Prüfe Rechtsgrund und Behaltensgrund getrennt.
- Kontrolliere, ob § 818 BGB den Anspruch erweitert, begrenzt oder verschärft.
- Leite erst danach Anspruchsgegner, Anspruchshöhe und prozessuales Ziel ab.

## Prüfungslogik

- Prüfe zuerst, ob wirklich keine Leistungsbeziehung vorliegt.
- Bestimme den Zuweisungsgehalt der verletzten Position.
- Ordne Nutzung, Verfügung oder Weitergabe der passenden Anspruchsgrundlage zu.
- Bewerte nach objektivem Markt-, Lizenz- oder Erlöswert.
- Trenne Bereicherung von Schaden, Gewinnabschöpfung und Unterlassung.

## Typische Fehler

- Alt. 2 als Auffangtatbestand ohne Zuweisungsgehalt nutzen.
- Schadensersatz und Bereicherung vermischen.
- Lizenzwert ohne Methode schätzen.

## Eingriffskondiktion § 812 Abs. 1 S. 1 Alt. 2 BGB

- **Tatbestand:** „in sonstiger Weise" auf Kosten eines anderen — Erlangung eines Vorteils ohne dass der andere selbst geleistet hat.
- **Zuweisungsgehalt (Theorie der Eingriffskondiktion):** Erlangter Vorteil muss aus einer dem Anspruchsteller rechtlich zugewiesenen Position stammen.
- **Klassische zuweisungsgehaltreiche Positionen:**
 - **Eigentum § 903 BGB:** Nutzung fremder Sache, Verbrauch, Verfügung.
 - **Beschränkte dingliche Rechte:** Nießbrauch §§ 1030 ff. BGB, Grunddienstbarkeit §§ 1018 ff. BGB.
 - **Persönlichkeitsrechte:** Recht am eigenen Bild § 22 KUG, Namensrecht § 12 BGB.
 - **Immaterialgüterrechte:** Patent, Marke, Urheberrecht, GebrM.
- **Negativ — kein Zuweisungsgehalt:**
 - Reine wettbewerbliche Position (str.).
 - Allgemeine Marktchance, Lauterkeit (kein Bereicherungsanspruch, sondern UWG).

## Rechtsfolge — Lizenzanalogie

- **Wertersatz § 818 Abs. 2 BGB:** Bei nicht-zurückgebbarem Vorteil (Nutzungsvorteil ist konsumiert) Wertersatz in Geld.
- **Maßstab:** **Marktüblicher Lizenzpreis** für die konkret in Anspruch genommene Nutzung (Lizenzanalogie). Bei Eigentumsnutzung Mietzins; bei Patenten Lizenzgebühren; bei Urheberrecht GEMA-Sätze oder Vergleichsverträge.
- **Drei-fache Berechnungsmethode** (Wahlrecht des Geschädigten — i.d.R. Immaterialgüterrechte):
 1. Konkreter Schaden + entgangener Gewinn (§ 252 BGB).
 2. Verletzergewinn (§ 687 Abs. 2 i.V.m. §§ 681, 667 BGB analog).
 3. Lizenzanalogie (§ 812 BGB).

## Konkurrenz und Abgrenzung

- **§ 823 BGB Schadensersatz:** kumulativ möglich, aber Schaden ≠ Bereicherung; Verschulden erforderlich.
- **§ 816 BGB:** vorrangig bei Verfügung eines Nichtberechtigten (Verkauf einer fremden Sache, Vermietung an Dritten gegen Entgelt).
- **§ 985 ff. BGB EBV:** vorrangig bei Eigentümer-Besitzer-Verhältnis (Vindikation und Nutzungsersatz im Rahmen §§ 987 ff. BGB).

## Beweisbedarf

- Anspruchsteller: Eigentum / Inhaberschaft des Rechts, Nutzung durch Gegner, ohne Lizenz, in welchem Umfang.
- Gegner: Lizenz, Gestattung, gesetzliche Erlaubnis, Entreicherung § 818 Abs. 3 BGB (bei Wertersatz aber selten anwendbar, da Nutzung als „aufgedrängte Bereicherung" nicht entreicherungsfähig).

## Arbeitsausgabe

| Punkt | Ergebnis | Belegbedarf |
|---|---|---|
| Anspruchsziel | [...] | [...] |
| beteiligte Personen | [...] | [...] |
| Vermögensvorteil | [...] | [...] |
| Zweck/Zurechnung | [...] | [...] |
| Rechtsgrund/Behaltensgrund | [...] | [...] |
| § 818 BGB | [...] | [...] |
| Einreden/Spezialregime | [...] | [...] |
| vorläufiges Ergebnis | [...] | [...] |

## Mini-Check vor Output

- Kein Direktanspruch ohne begründete Zurechnung.
- Kein Wertersatz ohne Bewertungsmethode.
- Keine Entreicherung ohne konkreten Vermögensweg.
- Keine Saldierung ohne beiderseitige Leistungstabelle.
- Offene Tatsachen bleiben als offen markiert.

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.
