---
name: leistungsbegriff-bewusste-zweckgerichtete
description: "Für Leistungsbegriff: Bewusste und zweckgerichtete Mehrung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt. Fachgebiet: bereicherungs-und-anfechtungsrecht-prüfer. Route: leistungsbegriff-bewusste-zweckgerichtete."
---

# Leistungsbegriff: Bewusste und zweckgerichtete Mehrung

## Triage — kläre vor der Prüfung

1. Wer hat den Vermögensvorteil zugewendet, und war diese Zuwendung bewusst und zweckgerichtet?
2. Ist die Zweckbestimmung dem Empfänger erkennbar gewesen?
3. Sind mehr als zwei Personen beteiligt — liegt ein Anweisungsfall oder ein Mehrpersonenverhältnis vor?
4. War die Anweisung wirksam, oder liegt eine Ausnahme zur Durchgriffskondiktion vor?
5. Kommt § 814 BGB in Betracht, wenn der Leistende die Nichtschuld kannte?

## Zentrale Normen

§ 812 Abs. 1 S. 1 Alt. 1 BGB (Leistungskondiktion) — § 812 Abs. 1 S. 1 Alt. 2 BGB (Nichtleistungskondiktion) — § 814 BGB (Ausschluss bei Kenntnis) — § 817 BGB (Gesetzes-/Sittenverstoß) — § 267 BGB (Drittleistung) — § 362 BGB (Erfüllungswirkung) — § 242 BGB (Treu und Glauben bei Durchgriff)

## Definition

Nach h.M. und ständiger BGH-Rechtsprechung ist Leistung i.S.d. § 812 Abs. 1 S. 1 Alt. 1 BGB jede **bewusste und zweckgerichtete Mehrung fremden Vermögens**.

**Elemente des Leistungsbegriffs:**
1. **Bewusst:** Der Leistende weiß, dass er Vermögensvorteile zuwendet.
2. **Zweckgerichtet:** Die Zuwendung soll einen bestimmten Zweck erfüllen.
3. **Fremd:** Die Zuwendung mehrt das Vermögen eines anderen.

## Vermögens- und Zweckzuordnung

Der Leistungsbegriff ist kein psychologischer Geheimvorbehalt. Entscheidend ist, wie die Zuwendung im Rechtsverkehr objektiv zu verstehen ist:

- Welcher Vermögensvorteil wurde geschaffen?
- Sollte damit eine eigene Schuld, eine fremde Schuld, ein künftiger Zweck oder eine Sicherheit erfüllt werden?
- Durfte der Empfänger die Zuwendung als Leistung gerade dieser Person verstehen?
- Gibt es eine Anweisung, Abtretung, Stellvertretung, Geschäftsführung oder Drittleistung?
- Ist der Vorteil nur körperlich beim Empfänger angekommen oder auch rechtlich als Leistung an ihn gerichtet?

Wenn die Zweckrichtung nicht sicher feststeht, nicht sofort auf § 812 Abs. 1 S. 1 Alt. 2 BGB ausweichen. Zuerst die Leistungskettenkarte erstellen und den richtigen Schuldner bestimmen.

## Mehrpersonenverhältnisse

### Anweisungsfall

A schuldet B, B schuldet C. A zahlt auf Anweisung des B direkt an C.
- Bereicherungsausgleich bei fehlerhaftem Deckungsverhältnis: A gegen B.
- Bereicherungsausgleich bei fehlerhaftem Valutaverhältnis: B gegen C.
- A hat grundsätzlich keinen Direktanspruch gegen C.

Prüfe dabei getrennt:

- Wer hat die Zahlung veranlasst?
- Welchen Tilgungszweck durfte C erkennen?
- War die Anweisung wirksam und zurechenbar?
- Wurde C in seinem Vertrauen auf den Leistungsweg geschützt?
- Wer trägt das Insolvenzrisiko des Zwischenglieds?

### Durchgriffskondiktion (Ausnahme)

- Unwirksame Anweisung → direkter Anspruch A gegen C möglich.
- Nichtberechtigte Verfügung über Konto → ebenso.
- Fehlende Empfängeridentität → ebenso.

## Prüffragen

1. Wer hat geleistet und mit welchem Zweck?
2. An wen war die Leistung gerichtet?
3. Sind mehr als zwei Personen beteiligt?
4. Liegt eine wirksame Anweisung vor?
5. Gibt es einen objektiven Empfängerhorizont, der die behauptete Leistung trägt?
6. Ist eine direkte Kondiktion wirklich Ausnahme oder nur Abkürzung aus Bequemlichkeit?

## Output-Template

**Prüfung Leistungsbegriff — § 812 Abs. 1 S. 1 Alt. 1 BGB**

Sachverhalt (kurz): [...]

| Merkmal | Ergebnis |
|---|---|
| Leistender | [...] |
| Empfänger (zugerechnete Leistung) | [...] |
| Bewusste Zuwendung | ja / nein |
| Zweckbestimmung erkennbar | ja: [...] / nein |
| objektiver Empfängerhorizont | Leistung an [...] / unklar |
| Mehrpersonenverhältnis | ja → Anweisungsfall / Direktkondiktion ausnahmsweise |
| Wirksame Anweisung | ja / nein → Durchgriffskondiktion prüfen |

**Ergebnis:** Leistung des [...] an [...] i.S.d. § 812 BGB [liegt vor / liegt nicht vor].

---

Hinweis: Keine Rechtsberatung. Mechanische Prüfung anhand vom Nutzer behaupteter Tatsachen. Falsche Normwahl oder unvollständiger Sachverhalt kann das Ergebnis vollständig entwerten.

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
