---
name: gf-haftung-paragraph-43-gmbhg-und-paragraph-93-aktg
description: "Für Geschäftsführerhaftung — Paragraf 43 GmbHG und Paragraf 93 AktG in der Krise: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Geschäftsführerhaftung — § 43 GmbHG und § 93 AktG in der Krise

## Arbeitsbereich

Geschäftsführerhaftung bei Krisenversagen prüfe und begrenzen: GF oder Berater will Haftungsrisiken einschaetzen und Enthaftungsstrategien entwickeln. Normen: § 43 GmbHG (Sorgfaltspflicht), § 93 AktG (Vorstandshaftung), § 93 Abs. 2 S. 2 AktG (Beweislastumkehr). Prüfraster: Business Judgment Rule in der Krise, Beweislastumkehr, Enthaftungsstrategien (BJR-Dokumentation, Sanierungsberater). Output Haftungsrisiko-Analyse, Enthaftungs-Memo, Aktionsplan. Abgrenzung: Dokumentation siehe dokumentationspflicht-und-protokollierung-geschäftsführung; Insolvenzantragspflicht siehe insolvenzantragspflicht-paragraph-15a-inso-und-drei-wochen-frist. Arbeite entlang dieser konkreten Prüfungslinie und trenne Rolle, Frist, Zuständigkeit, Beweislast und gewünschten Output.

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: StaRUG; § 1 StaRUG — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Spezialwissen

Die persönliche Haftung des Geschäftsführers ist kein theoretisches Konstrukt — sie ist das scharfe Ende eines stumpfer werdenden Unternehmens. § 43 GmbHG und § 93 AktG halten das Heft des Handelns mit voller Kraft gegen die Person des Managers, sobald die Krise eintritt und Pflichten verletzt wurden. Wer in der Krise nicht dokumentiert, nicht eskaliert und nicht handelt, findet sich später als Beklagter in einem Regressprozess wieder, in dem er beweisen muss, dass er alles richtig gemacht hat.

---

## Rechtsgrundlagen

- § 43 GmbHG (Sorgfaltspflicht und Verantwortlichkeit der Geschäftsführer)
- § 93 AktG (Sorgfaltspflicht und Verantwortlichkeit der Vorstandsmitglieder)
- § 93 Abs. 2 S. 2 AktG (Beweislastumkehr)
- § 15a InsO (Insolvenzantragspflicht)
- § 15b InsO (Zahlungsverbote nach Insolvenzreife)
- § 1 StaRUG (Krisenfrüherkennungspflicht)
- **BGH II ZR 206/22 vom 23.07.2024** — Haftung des ausgeschiedenen Geschäftsführers für Neugläubigerschäden bleibt bestehen, solange die durch ihn geschaffene Gefährdungslage fortwirkt. <https://dejure.org/dienste/vernetzung/rechtsprechung?Gericht=BGH&Datum=23.07.2024&Aktenzeichen=II+ZR+206/22>
- **BGH 5 StR 287/24 vom 27.02.2025** — Faktischer Geschäftsführer / Firmenbestattung: auch Hintermänner ohne Außenauftritt. <https://dejure.org/dienste/vernetzung/rechtsprechung?Gericht=BGH&Datum=27.02.2025&Aktenzeichen=5+StR+287/24>
- **BGH IV ZR 66/25 vom 19.11.2025** — D&O-Versicherung: Wissentlichkeitsausschluss erfordert positive Kenntnis pro Pflichtverletzung; § 15a / § 15b InsO nicht koppelbar. Stärkt die Deckungsposition des GF und des Insolvenzverwalters.
- IDW S 6 (Sanierungskonzepte)

---

## Pflichten

### 1. Sorgfaltsmaßstab — Der ordentliche und gewissenhafte Geschäftsleiter

§ 43 Abs. 1 GmbHG verpflichtet jeden Geschäftsführer, die "Sorgfalt eines ordentlichen Geschäftsmannes" anzuwenden. § 93 Abs. 1 AktG formuliert für den Vorstand den Standard des "ordentlichen und gewissenhaften Geschäftsleiters". Beide Standards sind in der Krise verschärft: Je größer die Gefährdungslage, desto enger der Handlungsspielraum und desto strenger die Anforderungen an Dokumentation und Begründung.

### 2. Business Judgment Rule in der Krise

Die Business Judgment Rule (§ 93 Abs. 1 S. 2 AktG, GmbH analog) schützt den Geschäftsleiter bei unternehmerischen Entscheidungen, wenn er:

1. Zum Zeitpunkt der Entscheidung vernünftigerweise annehmen durfte, auf Basis angemessener Informationen zu handeln,
2. Nicht von sachfremden Interessen geleitet war,
3. Zum Wohl der Gesellschaft handelte.

**In der Krise gilt:** Die Business Judgment Rule greift nur noch eingeschränkt. Je näher die Insolvenz, desto weniger Ermessen hat der Geschäftsführer — und desto mehr Pflichten rücken in den Vordergrund:

| Krisenstadium | BJR-Spielraum | Schwerpunkt-Pflicht |
|---|---|---|
| Normalbetrieb | Breit | Unternehmerische Gestaltung |
| Strategiekrise | Mittel | Frühwarnsystem, § 1 StaRUG |
| Liquiditätskrise | Eng | 13-Wochen-Planung, Gläubigerinfo |
| Drohende ZU | Sehr eng | § 29 StaRUG prüfen, Berater hinzuziehen |
| Eingetretene ZU | Null | § 15a InsO: Antragspflicht, § 15b InsO: Zahlungsverbot |

### 3. Beweislastumkehr nach § 93 Abs. 2 S. 2 AktG

§ 93 Abs. 2 S. 2 AktG enthält eine der empfindlichsten Regelungen des deutschen Gesellschaftsrechts: **Im Haftungsprozess muss das Vorstandsmitglied beweisen, dass es die Sorgfalt eines ordentlichen und gewissenhaften Geschäftsleiters angewendet hat.** Für GmbH-Geschäftsführer wird die Beweislastumkehr entsprechend angewandt (vgl. konkrete BGH-Linie, vor Ausgabe Aktenzeichen über dejure.org / openjur.de verifizieren).

- Wer keine Protokolle führt, kann seine Pflichterfüllung nicht beweisen.
- Wer keine Liquiditätsplanung vorhält, kann nicht nachweisen, dass er § 1 StaRUG erfüllt hat.
- Wer keine Berater hinzugezogen hat, kann den Sorgfaltsnachweis nicht mit Sachverstand belegen.

### 4. § 15b InsO — Zahlungsverbot nach Insolvenzreife

Seit dem 1. Januar 2021 (SanInsFoG) gilt das Zahlungsverbot des § 15b InsO: Nach Eintritt der Insolvenzreife darf der Geschäftsführer keine Zahlungen mehr leisten, die mit der Sorgfalt eines ordentlichen Kaufmanns nicht vereinbar sind. Erlaubt sind nur noch Zahlungen im gewöhnlichen Geschäftsgang. Verletzungen führen zur persönlichen Haftung.

### 5. Subsidiaritätsverhältnis StaRUG / InsO

Das StaRUG ist ein vorinsolvenzliches Instrument. Es schützt denjenigen, der rechtzeitig handelt — also bei drohender Zahlungsunfähigkeit (§ 18 InsO), nicht bei eingetretener. Das Verhältnis:

```
StaRUG-Zugang: Drohende Zahlungsunfähigkeit (§ 18 InsO) — 24-Monats-Horizont
InsO-Pflicht: Eingetretene Zahlungsunfähigkeit (§ 17 InsO) ODER Überschuldung (§ 19 InsO)
Drei-Wochen-Frist: Ab Kenntnis des Insolvenzgrundes
```

Wer den StaRUG-Zug verpasst, weil er zu spät erkannt hat, steht im InsO-Verfahren — und haftet nach § 15a, § 15b InsO persönlich.

---

## Vorgehen

### Schritt 1: Haftungsrisikocheck in der Krise

Jeder Geschäftsführer sollte in der Krise monatlich prüfen:

- [ ] Liegt eine aktuelle Liquiditätsplanung (min. 24 Monate) vor?
- [ ] Sind Gesellschafter und ggf. Aufsichtsrat informiert?
- [ ] Sind alle Berater (StB, WP, RA) eingebunden?
- [ ] Wurden Krisenmaßnahmen beschlossen und protokolliert?
- [ ] Ist die Insolvenzreife ausgeschlossen (aktuelles Gutachten)?
- [ ] Wurden keine masseschmälernden Zahlungen geleistet?

### Schritt 2: Enthaftungsstrategie

Enthaftung durch Dokumentation und professionelle Begleitung:

1. **Formal beschlossene Maßnahmenpläne** mit Datum und Unterschrift
2. **Externe Sachverständige** (IDW S 6 Gutachten, Sanierungsberater)
3. **Gesellschafterbeschlüsse** über die Strategie
4. **Bankkommunikation** schriftlich und protokolliert
5. **§ 102 StaRUG Warnhinweise** von Beratern empfangen und bestätigt

### Schritt 3: D&O-Versicherung prüfen

D&O-Deckung in der Krise analysieren:

- Anzeigepflicht des Schadensfalls prüfen
- Ausschlussklauseln für wissentliche Pflichtverletzungen kennen
- Selbstbehalt nach § 93 Abs. 2 S. 3 AktG: mind. 10 % bis 150 % der Jahresvergütung

---

## Templates

### Muster: Haftungsrisiko-Protokoll (monatliche GF-Selbstprüfung)

```
Haftungsrisiko-Protokoll
Gesellschaft: [Firma]
Monat: [MM/JJJJ]
Erstellt von: [Name GF]

1. LIQUIDITÄTSLAGE
 Liquiditätsreichweite aktuell: [x] Monate
 Vormonat: [x] Monate
 Trend: [Verbesserung / stabil / Verschlechterung]

2. FRÜHWARNINDIKATOREN
 EBITDA lfd. Jahr: EUR [___] (Plan: EUR [___])
 Net-Debt/EBITDA: [x,xx]x
 Covenant-Headroom: [x] %

3. MASSNAHMEN
 Laufende Maßnahmen: [Beschreibung]
 Neu beschlossen: [Beschreibung]
 Verantwortlich: [Name]
 Frist: [Datum]

4. ESKALATION
 Gesellschafter informiert am: [Datum / noch nicht]
 AR informiert am: [Datum / nicht anwendbar]
 Berater (StB/WP/RA) informiert am: [Datum]

5. INSOLVENZREIFE-PRÜFUNG
 Zahlungsunfähigkeit eingetreten? [ ] Ja [ ] Nein
 Überschuldung eingetreten? [ ] Ja [ ] Nein
 Grundlage der Einschätzung: [eigene Analyse / Beratertestat / IDW S 11 Gutachten]

Unterschrift: _________________________ Datum: _____________
```

### Muster: Beschluss Gesellschafterversammlung — Krisenmaßnahmenpaket

```
Niederschrift über Gesellschafterbeschluss

Gesellschaft: [Firma GmbH]
Datum: [TT.MM.JJJJ]
Anwesend: alle Gesellschafter / [x von y Anteilen]

Die Gesellschafterversammlung beschließt einstimmig / mit [x/y-Mehrheit]:

1. Die Geschäftsführung wird beauftragt, ein Krisenfrüherkennungssystem
 nach § 1 StaRUG und IDW PS 340 n.F. zu implementieren.
2. Es wird eine rollierende 24-Monats-Liquiditätsplanung eingeführt
 mit monatlicher Berichterstattung an die Gesellschafter.
3. Die Geschäftsführung wird ermächtigt, externe Restrukturierungsberater
 zu beauftragen.
4. Sanierungsmaßnahmen gemäß Anlage 1 werden genehmigt.

[Ort], [Datum]
Unterschriften aller Gesellschafter: _______________________
```

---

## Fallstricke

1. **Ressortteilung schützt nicht vollständig** — jeder Geschäftsführer bleibt für Finanzfragen mit verantwortlich, auch wenn formal ein anderer GF das Finanzressort leitet (Gesamtverantwortung).

2. **Gesellschafterweisung schützt nicht in der Insolvenz** — Weisungen der Gesellschafter entbinden den GF nicht von der Insolvenzantragspflicht nach § 15a InsO.

3. **Sanierungsbonus ist kein Freifahrtschein** — Zahlungen zur Vermeidung der Insolvenz können nach Insolvenzreife trotzdem anfechtbar sein.

4. **D&O-Versicherung ist keine Blankodeckung** — vorsätzliche oder wissentliche Pflichtverletzungen sind regelmäßig ausgeschlossen. Wer Protokolle fälscht oder Insolvenzreife verbirgt, haftet persönlich ohne Versicherungsschutz.

5. **Quasi-Geschäftsführer haften wie echte** — faktische Geschäftsführer (Gesellschafter mit Dominanz über die GF) unterliegen denselben Haftungsregeln, auch ohne formelle Bestellung.

---

## Triage — Erste Einordnung

Bevor losgelegt wird, klaere:
1. **Krisenstadium?** Ertragskrise (EBIT negativ), Liquiditaetskrise (Cashflow negativ) oder akute Insolvenznaehe (ZU/Ueberschuldung)?
2. **Insolvenzgrund?** § 17 InsO (ZU), § 18 InsO (drohende ZU), § 19 InsO (Ueberschuldung)?
3. **Fristen?** Antragspflicht § 15a InsO: 3 Wochen (ZU), 6 Wochen (Ueberschuldung).
4. **Sanierungs-Pfad?** StaRUG (drohende ZU), Schutzschirm, Eigenverwaltung oder Regelverfahren?
