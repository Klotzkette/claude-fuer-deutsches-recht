---
name: restructuring-lounge-impulsvortrag-toolkit
description: "Für Impulsvortrag-Toolkit — StaRUG und Krisenfrüherkennung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Prüfprodukt mit Risiko und nächstem Schritt."
---

# Impulsvortrag-Toolkit — StaRUG und Krisenfrüherkennung

## Arbeitsweg

- Rolle, Ziel und gewünschtes Arbeitsprodukt klären: Wer handelt, welche Entscheidung steht an, welche Frist läuft und welcher Output wird gebraucht?
- Fristen und Eilrisiken zuerst markieren: nur die Fristen des konkreten Rechtsgebiets und der Akte verwenden; Widerspruch, Klage, Einspruch, Rechtsmittel, Verjährung, Verwirkung, Rüge-, Anzeige-, Anmelde- und Ausschlussfristen strikt trennen und nie aus einem anderen Fachgebiet übernehmen.
- Tragende Normen verifizieren: StaRUG; § 1 StaRUG — Fundstellen über gesetze-im-internet.de, dejure.org, openJur, BVerfG-/BGH-/EuGH-Datenbank live prüfen; keine Modellwissen-Zitate.
- Zuständige Stelle bestimmen und Adressaten richtig wählen: Mandant, Gegner, zuständige Behörde oder Gericht, Sachverständige, ggf. EU-/internationale Stelle (siehe Skill-Detail).
- Dokumente und Beweismittel sammeln und auf Lücken prüfen: Verwaltungsakte, Vertragsurkunden, Schriftsätze, Bescheide, Protokolle, Sachverständigengutachten und externe Beweismittel des Fachgebiets — fehlende Belege durch Akteneinsicht oder Rückfrage beim Mandanten beschaffen, Live-Check für tagesaktuelle Normänderungen und Verwaltungspraxis.

## Spezialwissen

Impulsvorträge zu § 1 StaRUG und Krisenfrüherkennung sind mehr als akademische Pflichtübung. Sie sind Mandantengewinnung, Reputationsaufbau und gesellschaftliche Aufgabe zugleich — denn die Mehrzahl der Unternehmen, die in die Insolvenz gehen, hätte mit früherem Handeln Alternativen gehabt. Das vorliegende Toolkit ist für Veranstaltungsformate konzipiert, bei denen Berater, Unternehmer und Sanierungsspezialisten in einer offenen Diskussionsatmosphäre zusammenkommen, wie sie etwa bei Branchen-Lounge-Formaten in Hamburg und anderen Standorten gepflegt wird — zum Beispiel im Format der Restructuring Lounge oder vergleichbarer regionaler Netzwerkveranstaltungen.

---

## Rechtsgrundlagen (Vortragsreferenzen)

- § 1 StaRUG (Krisenfrüherkennungspflicht)
- Paragraf 102 StaRUG (begrenzter Hinweis bei der Jahresabschlusserstellung)
- Paragrafen 5 bis 28 StaRUG (Restrukturierungsplan und Abstimmung)
- §§ 49-59 StaRUG (Stabilisierungsanordnung)
- §§ 15a, 15b InsO (Insolvenzantragspflicht und Zahlungsverbot)
- § 43 GmbHG, § 93 AktG (GF-Haftung)
- IDW S 6, IDW S 11, IDW PS 340 n.F.

---

## Pflichten

### 1. Vortragsdisziplin — Was ein guter Impulsvortrag leisten muss

Ein 20-Minuten-Impulsvortrag zu StaRUG und Krisenfrüherkennung muss:

1. **Eine klare Kernbotschaft** transportieren (nicht fünf, eine)
2. **Rechtliche Präzision** mit verständlicher Sprache verbinden — kein Kanzlei-Kauderwelsch
3. **Handlungsrelevanz** für die Anwesenden erzeugen — niemand kommt für abstrakte Paragrafenlesungen
4. **Haftungs-Brille** durchgehend anlegen — der GF im Publikum muss spüren: das betrifft mich persönlich
5. **Konkrete Werkzeuge** zeigen — mindestens ein Template, eine KPI-Tabelle, ein Protokoll

---

## Foliensatz-Gliederung (20 Minuten)

```
FOLIE 1 — TITELFOLIE (0:00 — 0:30)
 "Krisenfrüherkennung ist Pflicht, nicht Kür — § 1 StaRUG"
 [Name des Vortragenden, Datum, Veranstaltungsname]

FOLIE 2 — KERNBOTSCHAFT (0:30 — 1:30)
 "Paragraf 1 StaRUG verlangt fortlaufende Überwachung und Reaktion.
 Die regelmäßige 24-Monats-Prognose folgt aus Paragraf 18 Absatz 2 InsO."
 [Visuell: Timeline — 24 Monate, 12 Monate, 3 Monate, Insolvenzantrag]

FOLIE 3 — DAS PROBLEM (1:30 — 3:00)
 "Wie Unternehmen in die Insolvenz gehen — fünf Stadien."
 Visuell: IDW S 6 Stufenpyramide
 Talking Point: "Stakeholderkrise bis Liquiditätskrise — der Weg dauert Jahre,
 aber die letzten Monate laufen im Eilzugtempo."

FOLIE 4 — § 1 StaRUG — WAS DAS GESETZ VERLANGT (3:00 — 5:00)
 Kerninhalt:
 - Haftungsbeschränkte Rechtsträger = Normadressaten
 - Fortlaufende Überwachung + Gegenmaßnahmen + Unterrichtung
 - 24-Monate-Liquiditätsplanung als Standard
 Talking Point: "Das ist kein Wunsch. Das ist Gesetz seit 2021."

FOLIE 5 — DER 24-MONATS-HORIZONT (5:00 — 7:00)
 Visuell: Planungsstruktur
 Woche 1-13: wöchentlich / Monat 14-24: monatlich
 KPI-Ampel (Liquiditätsreichweite, Net-Debt/EBITDA, DSCR)
 Talking Point: "Ohne diese Sicht können Sie bei drohender
 Zahlungsunfähigkeit keinen StaRUG-Antrag stellen."

FOLIE 6 — DIE HAFTUNG (7:00 — 9:30)
 § 43 GmbHG + § 93 Abs. 2 S. 2 AktG
 Business Judgment Rule — in der Krise eingeschränkt
 Beweislastumkehr: GF muss beweisen, dass er richtig gehandelt hat
 Kernbotschaft: "Ohne Protokoll kein Beweis. Ohne Beweis: Haftung."

FOLIE 7 — PARAGRAF 102 StaRUG — DER BEGRENZTE HINWEIS (9:30 — 11:00)
 Jahresabschlusserstellung, offenkundige Anhaltspunkte und vermutete
 Unkenntnis des Mandanten als drei Kernvoraussetzungen
 Talking Point: "Nicht jede BWA löst Paragraf 102 StaRUG aus. Beim
 Jahresabschluss müssen offenkundige Insolvenzindizien aber konkret
 angesprochen werden."

FOLIE 8 — StaRUG-WERKZEUGKASTEN (11:00 — 13:00)
 Restrukturierungsplan §§ 7 ff.
 Stabilisierungsanordnung §§ 49-59 (drei Monate Schutz)
 Cross-Class-Cram-Down § 26 (Mehrheit gegen ablehnende Gruppen)
 Talking Point: "Das StaRUG ist das modernste Sanierungsgesetz Europas —
 aber es ist nur für den zugänglich, der rechtzeitig handelt."

FOLIE 9 — DIE ZEITKRITISCHE ENTSCHEIDUNG (13:00 — 15:00)
 Visuell: Entscheidungsbaum
 Drohende ZU (§ 18 InsO) → StaRUG oder freie Sanierung
 Eingetretene ZU (§ 17 InsO) → § 15a InsO, drei Wochen
 Überschuldung (§ 19 InsO) → negative FBP → § 15a InsO
 Talking Point: "Der Zug zum StaRUG fährt ab. Wer den verpasst,
 steht am Insolvenzbahnhof."

FOLIE 10 — PRAXIS-CHECKLISTE (15:00 — 17:00)
 "Was Sie diese Woche in Ihrem Unternehmen prüfen sollten:"
 1. Gibt es eine 24-Monats-Liquiditätsplanung?
 2. Gibt es ein dokumentiertes KPI-Ampelsystem?
 3. Wann wurde der Gesellschafter zuletzt über die wirtschaftliche
 Lage informiert?
 4. Wann hat Ihr StB zuletzt die Krisenthematik angesprochen?
 Talking Point: "Nicht drei von vier — alle vier."

FOLIE 11 — Q&A VORBEREITUNG (17:00 — 20:00)
 "Ihre Fragen — meine Antworten."
 [Moderiertes Gespräch]
```

---

## Talking-Points — Juristische Pointen für den Vortrag

### Point 1 — Die Pflicht ist alt, der Name ist neu
"Das Pflichtenprogramm der Krisenfrüherkennung ist nicht mit dem StaRUG 2021 neu erfunden worden. Es ergibt sich schon aus § 43 GmbHG, § 93 AktG, § 91 AktG. Das StaRUG hat es kodifiziert und mit einem Verfahren verbunden. Der Gesetzgeber hat nicht mehr Pflichten geschaffen — er hat bestehende Pflichten sichtbar gemacht."

### Point 2 — Beweislastumkehr als Schlüsselproblem
"§ 93 Abs. 2 S. 2 AktG, analog für GmbH-Geschäftsführer: Wenn der Insolvenzverwalter klagt, muss nicht er beweisen, dass der GF falsch gehandelt hat — sondern der GF muss beweisen, dass er richtig gehandelt hat. Das ist die Welt auf dem Kopf, verglichen mit normalen Haftungsprozessen. Deshalb: Kein Handeln ohne Protokoll."

### Point 3 — Das StaRUG als Versicherungspolice
"Das StaRUG ist keine Krisensanierungsmaschine für hoffnungslose Fälle. Es ist eine Versicherungspolice für das rechtzeitige Handeln. Wer früh genug einzahlt — mit valider Planung, mit Krisendiagnose, mit Beratereinbindung — der kann im Ernstfall auf moderne Instrumente zugreifen. Wer nicht einzahlt, steht im Regen."

### Point 4 — Paragraf 102 StaRUG tatbestandsgebunden erklären
"Paragraf 102 StaRUG ist keine allgemeine Dauerwarnpflicht aus jeder Monats-BWA. Die Norm greift bei der Jahresabschlusserstellung, wenn Insolvenzindizien offenkundig sind und der Mandant die mögliche Insolvenzreife vermutlich nicht erkennt. Daneben können vertragliche Pflichten bestehen; beide Ebenen müssen sauber getrennt werden."

### Point 5 — Die Kornhaas-Entscheidung als Warnung für Gesellschaftsform-Optimierer

---

## Q&A-Fallnetz — Häufige Fragen mit Antwortvorschlägen

**Frage: "Wie konkret muss die 24-Monats-Planung sein?"**
Antwort: "Konkret genug, um im Ernstfall vor dem Insolvenzgericht und dem Insolvenzverwalter zu bestehen. Das bedeutet: dokumentierte Planprämissen, wöchentliche Granularität für die ersten dreizehn Wochen, integrierter Cashflow — und vor allem: aktuell. Eine Planung, die sechs Monate alt ist, hilft im Krisenfall nicht."

**Frage: "Wir haben einen Steuerberater — reicht das?"**
Antwort: "Die Krisenfrüherkennung bleibt Aufgabe der Geschäftsführung. Paragraf 102 StaRUG verpflichtet den Steuerberater nur unter den gesetzlichen Voraussetzungen bei der Jahresabschlusserstellung zum Hinweis. Aus anderen Mandaten können zusätzliche Vertragspflichten folgen; der Steuerberater ersetzt aber weder Organentscheidung noch Insolvenzreifeprüfung."

**Frage: "Was kostet ein StaRUG-Verfahren?"**
Antwort: "Das hängt von der Komplexität ab. Für eine typische mittelständische Restrukturierung mit zwei bis vier Gläubigergruppen sind sechsstellige Beraterkosten realistisch. Das klingt viel — aber verglichen mit den Alternativkosten eines Insolvenzverfahrens (Reputation, Betriebsunterbrechung, Anfechtungsrisiken) ist es oft erheblich günstiger."

**Frage: "Können wir das StaRUG-Verfahren geheim halten?"**
Antwort: "Das Verfahren ist nicht mit einer allgemeinen Insolvenzbekanntmachung gleichzusetzen. Eine öffentliche Bekanntmachung nach Paragraf 84 StaRUG erfolgt nur auf Antrag des Schuldners. Ob andere Register-, Beteiligten- oder Veröffentlichungspflichten im konkreten Fall eingreifen, muss für das gewählte Instrument gesondert geprüft werden."

**Frage: "Was passiert, wenn ich zu spät war und § 15a InsO gilt?"**
Antwort: "Dann ist unverzügliches Handeln erforderlich. Paragraf 15a InsO verlangt den Antrag ohne schuldhaftes Zögern und nennt Höchstzeiträume von drei Wochen bei Zahlungsunfähigkeit und sechs Wochen bei Überschuldung. Zusätzlich sind Zahlungen an Paragraf 15b InsO zu prüfen. Insolvenzgrund, Eintrittsdatum, Maßnahmen und Entscheidungsgrundlagen müssen sofort fachkundig geklärt und dokumentiert werden."

---

## Format-Hinweise für Branchenlounge-Veranstaltungen

Veranstaltungsformate, bei denen Impulsgespräche zu Restrukturierungsthemen im Vordergrund stehen — wie es der Restructuring Lounge-Ansatz oder vergleichbare regionale Vernetzungsveranstaltungen verkörpern —, funktionieren nach anderen Regeln als klassische Fachkonferenzen:

- **Kürze schlägt Vollständigkeit** — 15-20 Minuten Impuls, dann Diskussion. Kein Vorlesungsvortrag.
- **Fallbeispiele** (fiktiv) erzeugen mehr Resonanz als Paragrafenzitate. Konkret werden.
- **Einladung zur Diskussion** — in lockerer Atmosphäre fragen Teilnehmer Dinge, die sie im Seminar nie fragen würden. Dort liegt der echte Erkenntniswert.
- **Take-away sichern** — eine Checkliste, ein Template oder ein QR-Code mit Ressourcen erhöht die Erinnerungsrate erheblich.
- **Keine Kanzleiwerbung auf den Folien** — Kompetenz zeigt sich im Inhalt, nicht im Logo-Pflaster.

---

## Fallstricke bei Impulsvorträgen

1. **Zu viele Rechtsgrundlagen ohne Kontext** — sieben Paragrafen in drei Minuten abfeuern ist kein Vortrag, sondern ein Gesetzesvortrag. Kontext und Konsequenz interessieren, nicht die Norm allein.

2. **Angst vor zu konkreten Aussagen** — zu vorsichtige Formulierungen (alles ein Einzelfall, immer Anwalt fragen) nehmen dem Vortrag die Substanz. Konkret sein, Haftungshinweis am Ende genügt.

3. **Kein echtes Q&A** — der Wert einer Lounge-Veranstaltung entsteht im Austausch. Wer nach dem Vortrag sofort verschwindet, verschenkt den wichtigsten Teil.

4. **Fiktive Beispiele zu nah an realen Fällen** — Fallbeispiele sollten eindeutig fiktiv sein. Namen, Branchen und Zahlen so wählen, dass kein realer Bezug herstellbar ist.

5. **Technische Panne ohne Backup** — für Kurzvorträge reicht eine ausgedruckte Gliederung als Backup. Folienpräsentation ist Hilfsmittel, nicht Inhalt.

---

## Triage — Erste Einordnung

Bevor losgelegt wird, klaere:
1. **Krisenstadium?** Ertragskrise (EBIT negativ), Liquiditaetskrise (Cashflow negativ) oder akute Insolvenznaehe (ZU/Ueberschuldung)?
2. **Insolvenzgrund?** § 17 InsO (ZU), § 18 InsO (drohende ZU), § 19 InsO (Ueberschuldung)?
3. **Fristen?** Antragspflicht § 15a InsO: 3 Wochen (ZU), 6 Wochen (Ueberschuldung).
4. **Sanierungs-Pfad?** StaRUG (drohende ZU), Schutzschirm, Eigenverwaltung oder Regelverfahren?

> Quellenregel: Entscheidungen nur nach Prüfung einer amtlichen oder frei zugänglichen Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage ausgeben.
