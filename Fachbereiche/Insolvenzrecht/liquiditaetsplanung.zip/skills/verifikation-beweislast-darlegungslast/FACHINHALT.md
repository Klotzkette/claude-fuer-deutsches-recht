---
name: verifikation-beweislast-darlegungslast
description: "Für Verifikation: Beweislast, Darlegungslast und Substantiierung: ordnet Norm, Beweislast und Gegenargument; Ergebnis: Beweislast- und Substantiierungsmatrix."
---

# Verifikation: Beweislast, Darlegungslast und Substantiierung

## Normenanker

Vor einer rechtlichen Schlussfolgerung diese Anker am aktuellen Normtext prüfen; Spezial- und Landesrecht nur hinzunehmen, wenn es den konkreten Auftrag traegt:

- `§ 1 InsO` — Ziele des Insolvenzverfahrens.
- `§ 13 InsO` — Insolvenzantrag.
- `§ 15a InsO` — Antragspflicht juristischer Personen.
- `§ 17 InsO` — Zahlungsunfaehigkeit.
- `§ 18 InsO` — drohende Zahlungsunfaehigkeit.
- `§ 19 InsO` — Ueberschuldung.
- `§ 21 InsO` — Sicherungsmaßnahmen.
- `§ 35 InsO` — Insolvenzmasse.
- `§ 80 InsO` — Verwaltungs- und Verfuegungsbefugnis.
- `§ 129 InsO` — Insolvenzanfechtung.

Rechtsprechung nur ergänzen, wenn Gericht, Datum, Aktenzeichen und eine frei prüfbare Quelle vorliegen; keine BeckRS-/juris-Blindzitate verwenden.

## Fachkern: Verifikation: Beweislast, Darlegungslast und Substantiierung
- **Normen-/Quellenanker:** InsO §§ 17, 18, 19, 15a, StaRUG-Früherkennung, IDW-S-6-/Planungslogik, 3-Wochen- und 13-Wochen-Forecast, Zahlungsstatus und Fortbestehensprognose.
- **Entscheidende Weiche:** Trenne fällige Verbindlichkeiten, liquide Mittel, harte Zahlungszusagen, Planannahmen, Quote/Lücke, Organpflicht und Dokumentationsspur.

## Fallweichen
Wenn Unterlagen vorhanden sind, arbeite zuerst aus den Unterlagen. Stelle nur Rückfragen, die die nächste Weiche verändern:

1. Welche Rolle hat die fragende Person und wer ist Gegenüber?
2. Welches konkrete Ziel soll erreicht oder verhindert werden?
3. Welche Frist, Zustellung, Schwelle, Zahlung, Sanktion oder Verfahrensstufe ist kritisch?
4. Welche Dokumente, Registerauszüge, Bescheide, Verträge, Tabellen, Screenshots oder Nachrichten belegen den Punkt?
5. Welcher Output wird gebraucht: Memo, Checkliste, Tabelle, Entwurf, Schriftsatzbaustein, Mandantenbrief oder Entscheidungsvorlage?

## Arbeitsworkflow
1. **Fallbild bilden:** Sachverhalt, Rollen, Zeitachse und Dokumente in eine kurze Matrix bringen.
2. **Rechtsrahmen setzen:** Normen, Zuständigkeiten, Fristen, Formfragen und Verfahrensstand zum Themenfeld **Verifikation** prüfen.
3. **Prüfpunkte abarbeiten:** Tatbestandsmerkmale, Beweisfragen, typische Fehler, Gegenargumente und Ermessens- oder Wertungsfragen trennen.
4. **Risiko bewerten:** Grün/Gelb/Rot mit Begründung, Annahmen, fehlenden Belegen und möglichen Alternativwegen ausgeben.
5. **Anschluss bauen:** Passende weitere Skills desselben Plugins vorschlagen, wenn eine Vertiefung, ein Schreiben, eine Tabelle, ein Fristenblatt oder eine Verhandlungsstrategie sinnvoll ist.

## Liquiditätsstatus: Darlegung und Bestreiten

BGH IX ZR 129/22 vom 18.04.2024 ist als Pflichtanker zu prüfen, wenn ein Liquiditätsstatus gegenüber einem außenstehenden Dritten verwendet wird. Die Erklärungslast der Gegenseite steigt nur mit der eigenen Darlegungstiefe. Fehlen Einzelposten, Rechnungen, Kontoauszüge oder sonstige Unterlagen, kann einfaches Bestreiten genügen.

| Darlegung | Risiko | Korrektur |
| --- | --- | --- |
| OPOS-Summe ohne Einzelposten | einfaches Bestreiten möglich | Einzelpostenliste mit Gläubiger, Fälligkeit und Beleg |
| Titel genannt, Vollstreckung unklar | Nennwertansatz angreifbar | Klausel, Zustellung, Vollstreckungsauftrag und Einstellungsbeschluss prüfen |
| Forderung nur bestritten | falsches Herausnehmen aus Passiva | materiellen Bestand und Fälligkeit entscheiden; bei Herausnahme Gegenbeweis und Gutachtenstand dokumentieren |
| Rechtsirrtum der Geschäftsleitung | Entlastung überschätzt | nur bei ungeklärter Rechtsfrage als stark markieren; eigene Vertragsauslegung bleibt rot |
| Aktiva II ohne Zuflussbeleg | Scheinliquidität | Zahlungsavis, Bankbestätigung oder Vollstreckungsrealisierung verlangen |
