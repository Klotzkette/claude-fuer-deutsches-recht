HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Sechs von zehn Stimmen und ein Angebot aus dem November

Lale Behr brachte 2022 einen Teil ihrer privaten Anteile an einer Softwarefirma in ihre Holding ein. Die Holding möchte jetzt nur einen Teil davon verkaufen. Der Käufer spricht von einem „24-Prozent-Einstieg“. In der Kanzlei sind ein Einlieferungsbeleg für eine alte Mail und ein Kaufvertragsentwurf eingegangen.

Ordnen Sie Anteilstausch, Stimmrechte und Eigentumszeitpunkt ein. Erarbeiten Sie für die Verhandlung eine Betragsrechnung mit Jahresstufen, Beitragsnachweisen und belastbaren Annahmen. Welche Einbringung und wessen Steuererklärung muss bei einem Verkauf nochmals auf den Tisch?

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
