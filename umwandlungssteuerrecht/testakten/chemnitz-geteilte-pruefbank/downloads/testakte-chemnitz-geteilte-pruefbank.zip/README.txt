HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Zwei Sparten, eine Prüfbank und ein Käufer im Flur

Die Spinnbogen Messtechnik GmbH betreibt ein Kalibrierlabor und verkauft eigene Messköpfe. Die Alleingesellschafterin möchte das Labor abspalten. Im Plan stehen zwei selbständige Teams. Ihre Schichtbücher zeigen eine gemeinsam genutzte Prüfbank. Während die Spartenleiter über den Zugriff streiten, fragt eine Beteiligungsgesellschaft nach einem Einstieg.

Entwerfen Sie für die Gesellschafterin einen Besprechungsvermerk zur Abspaltung. Ordnen Sie zuerst den Stand des Vorhabens, dann die Teilbetriebe, die prüfbedürftigen Vermögenspositionen und den möglichen späteren Verkauf ein. Zeigen Sie in Euro, worauf sich eine Wertschwelle beziehen würde.

Öffnen Sie zuerst den Ordner Grundakte. In der zweiten Runde kommen die Nachreichungen hinzu. Im Ordner Vorlagen liegen bearbeitbare Arbeitsblätter.
