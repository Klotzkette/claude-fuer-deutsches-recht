Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Muster gegen Uferwerk Verlag GmbH - Berufungswerkstatt
Aktenstand: 30. Oktober 2026. Workshop: 12. November 2026.

93 Aktenunterlagen und ein Aktenverzeichnis; insgesamt 155 PDF-Seiten.
Das Paket enthält ausschließlich PDFs und diese README.txt. Es enthält keine Berufungsbegründung.
Die Berufungseinlegung ist innerhalb der erfundenen Fallgeschichte bereits dokumentiert.
Sämtliche Parteien, Personen, Vorgänge und Kommunikationsdaten sind erfunden. Die Gerichtsnamen und Gerichtsanschriften dienen der realistischen Verfahrensdarstellung. Die Aktenzeichen gehören zur Fallfiktion; die Dokumente sind keine echten gerichtlichen oder anwaltlichen Erklärungen.
Die reservierte Domain .example wird ausschließlich für erfundene Kontakte verwendet.
Vorgeschichte (V), erste Instanz (P), Nachurteil und Berufungseinlegung (N). Das Aktenverzeichnis nennt alle Unterlagen mit Datum und Seitenzahl.
Datumsangaben in Dateinamen bezeichnen das Ablagedatum; ein später übermittelter Ausdruck kann einen älteren Vorgang enthalten. Gerichtliche Anlagenkürzel stehen in den Schriftsätzen; sie sind vom Ablagekennzeichen der PDF-Dateien zu unterscheiden.
Rechtsstand der Prompt-Begleitung: 1. November 2026; die Fallunterlagen bilden den jeweiligen historischen Dokumentstand ab. Prozessbehauptungen und Urteilsbegründungen sind selbst zu prüfen.
