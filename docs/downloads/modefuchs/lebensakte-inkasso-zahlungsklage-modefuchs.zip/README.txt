HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Am Anfang der Akte
==================

In Grundakte/00_Posteingang finden Sie diese Unterlagen:
  1. Debitorenbuchhaltung ModeFuchs an Kundenservice – Vorgang 1749 – welcher Name steht auf dem Zahlungsbeleg?
  2. Kundenservice ModeFuchs an Debitorenbuchhaltung – Beleg vom Kundentelefon

Weitere bereits vorliegende Belege (Auswahl):
  Grundakte/10_email_zahlungseingang_modefuchs_inkasso.eml
  Grundakte/AW_Zahlungsnachweis_ModeFuchs.eml
  Grundakte/Bildschirmfoto_2025-06-27_1817.png
  Grundakte/Bildschirmfoto_Postausgang_20250701.png

Für die Erstbearbeitung den Ordner Grundakte öffnen. Der übrige Bestand ist für die Weiterarbeit zugänglich.
