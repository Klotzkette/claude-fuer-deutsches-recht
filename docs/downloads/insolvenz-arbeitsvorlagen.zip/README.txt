HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

ARBEITSVORLAGEN FÜR INSOLVENZAKTEN

Die gemeinsame Vertragsvorlage steht unter Gemeinsam/. Die Fachvorlagen stehen unter Akten/.
Für eine Akte den gemeinsamen Vertrag und die unten genannten Dateien in einen Arbeitsordner kopieren.
In Word die Angaben in eckigen Klammern ersetzen und Tabellen bearbeiten.
In Excel die freien Zellen befüllen. Farblich hinterlegte Rechenfelder enthalten Formeln.
Die Datei SHA256SUMS.txt enthält die Prüfsummen der Vorlagen und dieses Inhaltsverzeichnisses.

Gemeinsamer Vertrag: Gemeinsam/asset-purchase-agreement-blanko.docx

AKTENVERZEICHNIS

1. Geschäftsführerhaftung nach Paragraf 15b InsO — Zahlungen nach Insolvenzreife (Hannover)
Schreiben zur Erstattung von Zahlungen nach Insolvenzreife
Akten/geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover/zahlungsersatz-geltend-machen.docx
Zahlungsprüfung und Masseabgleich
Akten/geschaeftsfuehrerhaftung-15b-inso-zahlungen-nach-insolvenzreife-hannover/organhaftung-zahlungsmatrix.xlsx

2. Insolvenz-Asset-Deal — ChainCortex AI GmbH (Berlin) → Voracis Ventures GmbH
Asset Deal – Anlagen und Vollzug
Akten/insolvenz-asset-deal-chaincortex-ai-berlin/anlagen-und-vollzugsliste-blanko.xlsx

3. Insolvenzanfechtung Vellnitz Kunststofftechnik — Bargeschäft und Vorkasse beim Rohstofflieferanten (Chemnitz)
Rückgewährverlangen wegen Zahlungen auf Rohstofflieferungen
Akten/insolvenzanfechtung-bargeschaeft-vorkasse-rohstofflieferant-chemnitz/rueckgewaehr-vorkasselieferungen.docx

4. Blechliebe und die letzte Stahllieferung
Mandantenbrief zu Altraten, Vorkasselieferung und Sicherungsabtretung
Akten/insolvenzanfechtung-blechliebe-bamberg/mandantenbrief-raten-vorkasse-und-zession.docx
Antwort des Lieferanten auf die Rückgewährforderung
Akten/insolvenzanfechtung-blechliebe-bamberg/antwort-lieferant-auf-rueckforderung.docx

5. Faltenwurf zwischen Familie und Werkstatt
Vertraulicher Mandantenbrief zu Darlehen, Maschine und Bürgschaft
Akten/insolvenzanfechtung-faltenwurf-fuerth/einzelmandat-darlehen-sicherheit-buergschaft.docx
Stellungnahme zur persönlichen Inanspruchnahme als Gesellschafterin
Akten/insolvenzanfechtung-faltenwurf-fuerth/stellungnahme-gesellschafterin-an-verwaltung.docx

6. Insolvenzanfechtung — Gesellschafterdarlehen im Konzern-Cash-Pool (Regensburg)
Entscheidungsvermerk zu Cash-Pool, Nachbesicherung und Minderheitsdarlehen
Akten/insolvenzanfechtung-gesellschafterdarlehen-cash-pool-regensburg/pruefvermerk-cashpool-nachbesicherung-minderheit.docx

7. Insolvenzanfechtung Vondering Metallform — Grundstücksverkauf und „Vermittlungsprovision" (Mönchengladbach)
Rückgewährverlangen wegen eines Grundstücksgeschäfts
Akten/insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach/schreiben-erwerber-grundstuecksverkauf.docx
Rückforderung einer Vermittlungsprovision
Akten/insolvenzanfechtung-glaeubigerbenachteiligung-grundstuecksverkauf-moenchengladbach/schreiben-provisionsempfaenger.docx

8. Insolvenzanfechtung — Warenlager an Erfüllungs statt an den Hauptlieferanten (Kassel)
Rückgewähr von Warenlager und abgetretenen Kundenforderungen
Akten/insolvenzanfechtung-inkongruente-deckung-warenlager-an-erfuellungs-statt-kassel/rueckgewaehr-warenlager-und-zessionen.docx

9. Insolvenzanfechtung — Inkongrünte Deckung durch Zwangsvollstreckung (Fürth)
Klageschrift auf Rückgewähr von Vollstreckungserlösen und Abwendungszahlungen
Akten/insolvenzanfechtung-inkongruente-deckung-zwangsvollstreckung-fuerth/klage-rueckgewaehr-vollstreckung.docx

10. Insolvenzanfechtung Kiezflitzer — Gesellschafterdarlehen, Beraterhonorar und Vorschuss (Berlin)
Klageschrift zu Darlehensrückzahlung, Beraterhonorar und Vorschuss
Akten/insolvenzanfechtung-kiezflitzer-gesellschafterdarlehen-berlin/klage-darlehen-beraterhonorar-vorschuss.docx

11. Insolvenzanfechtung Trave Clean — Beitragszahlung an die Krankenkasse nach Fremdantrag (Lübeck)
Entscheidungsvermerk zur Beitragszahlung nach einem Fremdantrag
Akten/insolvenzanfechtung-kongruente-deckung-krankenkasse-nach-antrag-luebeck/klageentscheidung-beitragszahlung-nach-fremdantrag.docx

12. Insolvenzanfechtung Teutoburger Möbelwerk — kongrünte Deckung, Mahnlauf und Kenntnisfrage (Bielefeld)
Klageerwiderung des Lieferanten auf Rückgewähr von Rechnungszahlungen
Akten/insolvenzanfechtung-kongruente-deckung-lieferant-mahnlauf-bielefeld/klageerwiderung-lieferant.docx

13. Insolvenzanfechtung Domblick Weinkellerei — Kontokorrent-Rückführung nach Linienherabsetzung (Mainz)
Klage auf Rückgewähr nach schrittweiser Herabsetzung einer Kreditlinie
Akten/insolvenzanfechtung-kontokorrent-rueckfuehrung-kreditlinie-mainz/klagebegruendung-linienherabsetzung.docx

14. Insolvenzanfechtung Ruhrland Getränkegroßhandel — Kontokorrent-Verrechnungen bei geduldeter Überziehung (Dortmund)
Erwiderung der Insolvenzverwaltung auf Einwendungen gegen Kontoverrechnungen
Akten/insolvenzanfechtung-kontokorrent-verrechnungen-geduldete-ueberziehung-dortmund/replik-kontokorrent-verrechnungen.docx

15. Insolvenzanfechtung Schenkung Familie — Hollmann Bau- und Sanierungs GmbH (Oldenburg)
Rückgewährverlangen wegen einer Zuwendung im Familienkreis
Akten/insolvenzanfechtung-schenkung-familie-oldenburg/rueckgewaehr-familienzuwendung.docx

16. Insolvenzanfechtung aufsteigende Konzernsicherheit — Feinwerk Präzisionswerkzeuge GmbH (Stuttgart)
Entscheidungsvermerk zur Freigabe und Verwertung von Konzernsicherheiten
Akten/insolvenzanfechtung-unentgeltlich-konzernsicherheit-upstream-stuttgart/vermerk-konzernsicherheiten.docx

17. Testakte VeedelWende: klare Darlehensrückzahlung an den 25-Prozent-Gesellschafter
Aufforderung zur Rückgewähr einer Darlehensrückzahlung
Akten/insolvenzanfechtung-veedelwende-direktrueckzahlung-koeln/zahlungsaufforderung-darlehen.docx
Klage auf Rückgewähr einer Zahlung auf ein Gesellschafterdarlehen
Akten/insolvenzanfechtung-veedelwende-direktrueckzahlung-koeln/rueckgewaehrklage-darlehen.docx

18. Testakte VeedelWende: alte Abtretung eines Gesellschafterdarlehens an einen Dritten
Prozessrisiko bei Zahlung an den Erwerber einer Darlehensforderung
Akten/insolvenzanfechtung-veedelwende-zession-koeln/prozessrisiko-forderungsabtretung.docx
Klageerwiderung des Erwerbers einer Darlehensforderung
Akten/insolvenzanfechtung-veedelwende-zession-koeln/klageerwiderung-forderungsabtretung.docx

19. Vorsatzanfechtung gegen das Finanzamt — 30 Raten im Vierjahreszeitraum (Augsburg)
Replik zur Rückgewähr von Steuerraten und zusätzlich gestellten Sicherheiten
Akten/insolvenzanfechtung-vorsatzanfechtung-finanzamt-ratenzahlung-augsburg/replik-steuerraten.docx

20. Insolvenzforderungen Rheinsteg Handwerk Köln
Prüfblatt für eine Forderungsanmeldung
Akten/insolvenzforderungen-handwerk-koeln/erklaerung-pruefungstermin.docx
Betriebskauf aus der Insolvenz · Vollzugs- und Übergabeprotokoll
Akten/insolvenzforderungen-handwerk-koeln/betriebskauf-vollzugsprotokoll.docx
Forderungsprüfung und Sicherheiten
Akten/insolvenzforderungen-handwerk-koeln/forderungspruefung-und-sicherheiten.xlsx

21. MedTech Jena: Eigenverwaltung, Schutzschirm und Liquiditätsstatus
Eigenverwaltung und Schutzschirm · Antragsentwurf
Akten/insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena/antrag-eigenverwaltung-schutzschirm.docx
Liquiditätsplanung für dreizehn Wochen
Akten/insolvenzrecht-eigenverwaltung-schutzschirm-medtech-jena/wochenliquiditaet-und-massnahmen.xlsx

22. Forderungsprüfung Berlin: Mietkaution, Aufrechnung und Absonderungsrechte
Prüfblatt für Mietforderungen, Kaution und Aufrechnung
Akten/insolvenzrecht-forderungspruefung-mietkaution-berlin/pruefblatt-mietkaution.docx

23. StaRUG-Aufhebung der Restrukturierungssache — Holding Düsseldorf (BGH IX ZB 18/25)
Sofortige Beschwerde gegen die Aufhebung einer Restrukturierungssache
Akten/starug-aufhebung-holding-duesseldorf-ix-zb-18-25/beschwerde-aufhebung-restrukturierung.docx

24. Großbach Druckguss & Präzision GmbH & Co. KG — Schutzschirm und StaRUG-Optionen
Entscheidungsvorlage für Geschäftsleitung und Sanierungsberatung
Akten/starug-schutzschirm-grossbach-druckguss-erfurt/sanierungswege-entscheidungsvorlage.docx

25. Bremer Darlehensverfahren und Vertragsübernahme
Auskunftsersuchen zu Darlehensübertragung und Zahlungswegen
Akten/fintech-darlehen-vertragsuebernahme-bremen/nachforderung-zahlungswege.docx
Darlehenszahlungen, Stichtagsstatus und Kenntnisstände
Akten/fintech-darlehen-vertragsuebernahme-bremen/darlehenszahlungen-und-kenntnis.xlsx
