HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Am Anfang der Akte
==================

In Grundakte/00_Posteingang finden Sie diese Unterlagen:
  1. Lisa Muster an Ehemalige Ansprechperson im Vertriebsinnendienst – Meine Händleraktion aus der Rotation
  2. Lisa Muster an Unterlagen für das erste Gespräch – Wiederkehrende Arbeit außerhalb der Grafik
  3. Ehemalige Ansprechperson im Vertriebsinnendienst an Lisa Muster – Das zweite Schreiben des Händlers
  4. Lisa Muster an Private Bewerbungsmappe – Was ich bei der Händleraktion am Telefon konnte
  5. Vertriebsinnendienst Uferwerk an Lisa Muster – Arbeitsblatt zur damaligen Händleraktion

Weitere bereits vorliegende Belege (Auswahl):
  Grundakte/V01_2008-01-14_Bewerbung_als_Grafikdesignerin.pdf
  Grundakte/V04_2008-02-05_Angebot_einer_unbefristeten_Beschaftigung.pdf
  Grundakte/V05_2008-02-08_Arbeitsvertrag_Lisa_Muster.pdf
  Grundakte/V07_2008-08-22_Probezeitgesprach.pdf

Für die Erstbearbeitung den Ordner Grundakte öffnen. Der übrige Bestand ist für die Weiterarbeit zugänglich.
