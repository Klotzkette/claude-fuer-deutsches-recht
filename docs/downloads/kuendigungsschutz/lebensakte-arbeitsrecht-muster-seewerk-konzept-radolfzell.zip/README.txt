HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Am Anfang der Akte
==================

In Grundakte/00_Posteingang finden Sie diese Unterlagen:
  1. Daniel Muster an Personalbüro Seewerk – Unterlagen vom Führungskreis zu den Bonuszielen
  2. Personalassistenz an Bonusordner 2025 – Unterlagen zur Zielmitteilung
  3. Personalbüro Seewerk an Daniel Muster – Vorstellung der Unternehmensziele im Führungskreis
  4. Daniel Muster an Eigene Entgeltunterlagen – Februartermin und Märzabrechnung

Weitere bereits vorliegende Belege (Auswahl):
  Grundakte/K01_Arbeitsvertrag.docx
  Grundakte/K06_Abmahnung.docx
  Grundakte/K10_Zeiterfassung.xlsx
  Grundakte/K11_Kuendigung.docx

Für die Erstbearbeitung den Ordner Grundakte öffnen. Der übrige Bestand ist für die Weiterarbeit zugänglich.
