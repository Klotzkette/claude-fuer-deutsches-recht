HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Am Anfang der Akte
==================

In Grundakte/00_Posteingang finden Sie diese Unterlagen:
  1. Fridolin Karg an Geräteausgabe – Vorder- und Rückseite des Abholscheins
  2. Gerätelager an Ausgabebuch – Rückfrage zum Gerätewechsel
  3. Geräteausgabe an Fridolin Karg – Zum Durchschlag des Abholscheins
  4. Geräteverwaltung Bonn an Wartungsplatz – Grauer Koffer am Werkstattregal

Weitere bereits vorliegende Belege (Auswahl):
  Grundakte/01_Arbeitsvertrag_Karg.docx
  Grundakte/02_Fristlose_Kuendigung.docx
  Grundakte/03_Empfang_Kuendigung.docx
  Grundakte/05_Protokoll_Anhoerung.docx

Für die Erstbearbeitung den Ordner Grundakte öffnen. Der übrige Bestand ist für die Weiterarbeit zugänglich.
