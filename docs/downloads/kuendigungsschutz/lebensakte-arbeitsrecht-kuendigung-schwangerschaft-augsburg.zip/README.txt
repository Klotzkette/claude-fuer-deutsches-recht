HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Am Anfang der Akte
==================

In Grundakte/00_Posteingang finden Sie diese Unterlagen:
  1. Adelheid Merz an Beratungsstelle – Welchen Briefumschlag soll ich zum Gespräch mitbringen?
  2. Adelheid Merz an Privater Kalender – Zwei Erinnerungen für den Termin
  3. Beratungsstelle an Adelheid Merz – Bitte bringen Sie auch die gesendete Nachricht mit
  4. Matthes Merz an Familienkalender – Was ich vom Termin weiß

Weitere bereits vorliegende Belege (Auswahl):
  Grundakte/01_Arbeitsvertrag_Merz.docx
  Grundakte/02_Kuendigung_Merz.docx
  Grundakte/03_Zugangsvermerk_Merz.docx
  Grundakte/04_Aerztliche_Bescheinigung.docx

Für die Erstbearbeitung den Ordner Grundakte öffnen. Der übrige Bestand ist für die Weiterarbeit zugänglich.
