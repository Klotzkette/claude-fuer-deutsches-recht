HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Am Anfang der Akte
==================

In Grundakte/00_Posteingang finden Sie diese Unterlagen:
  1. Daniel Muster an Schichtplanung Seewerk – Nächste Schicht am Werkstor
  2. Schichtplanung an Werkszufahrt – Ausdruck für die Pforte
  3. Schichtplanung Seewerk an Daniel Muster – Persönlicher Ausdruck für Kalenderwoche 42
  4. Schichtbüro Seewerk an Tagesübergabe Halle 2 – Zeitjournal und Schichtplan der Halle

Weitere bereits vorliegende Belege (Auswahl):
  Grundakte/E02_Schichtplan_Kalenderwoche_42_2026.docx
  Grundakte/E03_Zeiterfassungsjournal_Oktober_2026.csv
  Grundakte/E04_Entgeltabrechnung_Maerz_2025.docx
  Grundakte/E05_Entgeltabrechnung_Maerz_2026.docx

Für die Erstbearbeitung den Ordner Grundakte öffnen. Der übrige Bestand ist für die Weiterarbeit zugänglich.
