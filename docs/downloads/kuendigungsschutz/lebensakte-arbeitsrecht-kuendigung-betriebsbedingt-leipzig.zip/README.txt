HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Am Anfang der Akte
==================

In Grundakte/00_Posteingang finden Sie diese Unterlagen:
  1. Ottilie Riemenschneider an Personalbüro – Ausschreibung für die Exportassistenz
  2. Vertriebsassistenz an Übergabe Export – Arbeit am Wochenanfang
  3. Personalbüro an Ottilie Riemenschneider – Zeitfenster der Exportassistenz
  4. Ottilie Riemenschneider an Eigene Stellenmappe – Was ich beim Wechsel mitbringe

Weitere bereits vorliegende Belege (Auswahl):
  Grundakte/01_Arbeitsvertrag_Riemenschneider.docx
  Grundakte/02_Kuendigung_08102026.docx
  Grundakte/03_Botenvermerk_Zugang.docx
  Grundakte/05_Personalliste_Auswahl.docx

Für die Erstbearbeitung den Ordner Grundakte öffnen. Der übrige Bestand ist für die Weiterarbeit zugänglich.
