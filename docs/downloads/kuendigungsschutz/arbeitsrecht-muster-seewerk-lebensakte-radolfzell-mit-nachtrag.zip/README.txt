HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Seewerk | Montag, 23. November 2026

22 Eingangsbelege stehen in Grundakte/. Die weiteren 22 ursprünglichen Unterlagen stehen im Hauptverzeichnis. Nachtrag/ enthält die drei im Laufe des Mandatstages nachgereichten Unterlagen E17 bis E19. Die CSV ist lose und als identische E-Mail-Anlage verfügbar.
