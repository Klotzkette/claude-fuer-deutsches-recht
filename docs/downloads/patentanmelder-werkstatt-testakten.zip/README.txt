HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Werkstatt für Patentanmelder

Beginnen Sie mit der Grundakte und bearbeiten Sie die Nachreichungen in einer zweiten Runde. Auswertung/Erwartungshorizont.pdf dient der anschließenden Besprechung.

01-moebel-schnappfuss · Der Schnappfuß am Regal R40
KM/26-114 · R40

Ein Zubehörhersteller will seinen nachrüstbaren Fuß vor einem Händlertermin schützen. Der Vertrieb verspricht eine selbsttätige Sperre unter Last. Die Werkstattzeichnungen und die ersten Messergebnisse erlauben mehrere Deutungen.

Vertreten Sie den Zubehörhersteller. Erheben Sie die Erfindung im Gespräch mit Konstruktion, Montage und Vertrieb und protokollieren Sie zu jedem strittigen Merkmal Frage, belegte Antwort und Folge für V0. Prüfen Sie die drei vorgelegten Ansprüche an Figur 1, P-141 und den fiktiven Unterlagen D1/D2. Erstellen Sie eine einreichungsnahe deutsche Anmeldeschrift mit aufeinander abgestimmten Patentansprüchen, Beschreibung, Figurenbeschreibung, Bezugszeichenliste und Zusammenfassung. Stellen Sie daneben dar, welche Handlungen des Zubehörlieferanten und des Monteurs sich anhand welcher Belege nachweisen ließen.

Öffnen Sie am 17. und 18. November den Montagerücklauf und die Kontrolluntersuchung. Konfrontieren Sie die Erfinderin nochmals mit dem ursprünglichen Verkaufsversprechen. Legen Sie eine geänderte Anmeldeschrift und eine kurze Synopse mit den betroffenen Anspruchswörtern, den Quellen und den verbleibenden Grenzen vor.

Rechtsquellen
§ 3 PatG · https://www.gesetze-im-internet.de/patg/__3.html
§ 4 PatG · https://www.gesetze-im-internet.de/patg/__4.html
§ 34 PatG · https://www.gesetze-im-internet.de/patg/__34.html
§ 38 PatG · https://www.gesetze-im-internet.de/patg/__38.html
Art. 54 EPÜ · https://www.epo.org/de/legal/epc/2020/a54.html
Art. 56 EPÜ · https://www.epo.org/de/legal/epc/2020/a56.html
Art. 83 EPÜ · https://www.epo.org/de/legal/epc/2020/a83.html
Art. 84 EPÜ · https://www.epo.org/de/legal/epc/2020/a84.html
§ 9 PatG · https://www.gesetze-im-internet.de/patg/__9.html
§ 10 PatG · https://www.gesetze-im-internet.de/patg/__10.html

02-gewaechshaus-beschattung · Zwei Gewächshausschirme an einer Zuleitung
KM/26-119 · GH2

Ein Hersteller liefert Austauschregler, ein externer Dienst Zielwerte und eine Gärtnerei die vorhandenen Antriebe. Abnahmeprotokoll und Bildschirmfoto beschreiben unterschiedliche Ebenen. Für die Anmeldung ist zu klären, wer einen Fahrbefehl geben kann und wo die zweite Anfahrt tatsächlich freigegeben wird.

Übernehmen Sie das Mandat von Blattwinkel. Befragen Sie Produktleitung, Entwicklung, Betreiberin und Ferndienst getrennt zu Signal, Handlung und Nachweis. Prüfen Sie G0 anhand von F12 und D1/D2. Entwerfen Sie aus den tragfähigen Angaben eine vollständige deutsche Patentanmeldung einschließlich Figurenbeschreibung, Ansprüchen und Zusammenfassung. Arbeiten Sie den verkauften Regler, die Mehrzonenanlage und den tatsächlichen Ablauf auseinander. Benennen Sie dem Mandanten die Beweise, die für eine spätere Verletzungsprüfung im Client, beim Dienst und vor Ort zugänglich wären.

Legen Sie erst nach der ersten Gesprächsrunde die Antworten zum Netztrennversuch, zur Cloudquittung und zum Ersatzgerät vor. Überarbeiten Sie den Entwurf mit der neuen Signalfolge. Kennzeichnen Sie ausdrücklich, welche bisherige Behauptung entfällt und welcher technische Zustand bei fehlendem Endschalter offenbleibt.

Rechtsquellen
§ 3 PatG · https://www.gesetze-im-internet.de/patg/__3.html
§ 4 PatG · https://www.gesetze-im-internet.de/patg/__4.html
§ 34 PatG · https://www.gesetze-im-internet.de/patg/__34.html
§ 38 PatG · https://www.gesetze-im-internet.de/patg/__38.html
Art. 54 EPÜ · https://www.epo.org/de/legal/epc/2020/a54.html
Art. 56 EPÜ · https://www.epo.org/de/legal/epc/2020/a56.html
Art. 83 EPÜ · https://www.epo.org/de/legal/epc/2020/a83.html
Art. 84 EPÜ · https://www.epo.org/de/legal/epc/2020/a84.html
§ 9 PatG · https://www.gesetze-im-internet.de/patg/__9.html
§ 10 PatG · https://www.gesetze-im-internet.de/patg/__10.html

03-fruchtkisten-pruefstand · Optischer Prüfstand für wiederverwendbare Fruchtkisten
KM/26-123 · FK8

Ein Prüfstand soll schadhafte Kisten trotz driftender Beleuchtung aussortieren. Die Patentkoordination legt eine deutsche Prioritätsanmeldung, einen fehlerhaften europäischen Anspruchsentwurf und ein Laborjournal vor. Eine zweite Unterlage wurde zwischen dem Prioritätstag und der geplanten europäischen Einreichung öffentlich.

Prüfen Sie E1 Wort für Wort, einschließlich Rückbezügen, Gegenstand, zeitlicher Aussage, Prioritätsstütze und technischer Ausführbarkeit. Führen Sie ein Streitgespräch mit Erfinderin, Versuchsfeld und Patentkoordination über das angezeigte Graufeld. Geben Sie jeder Merkmalskombination eine konkrete Fundstelle und einen möglichen wirksamen Zeitrang. Prüfen Sie D1 und D2 getrennt nach Datum und Inhalt. Erstellen Sie vor der Freigabe eine vollständige europäische Anmeldeschrift mit Ansprüchen, Beschreibung, Figurenangaben und Zusammenfassung. Nennen Sie ausstehende Freigaben, ohne eine Einreichung zu behaupten.

Nach der ersten Fassung trifft die Nachricht ein, dass E1 bereits unverändert eingereicht wurde. Prüfen Sie das Zeitstempelprotokoll und die neue Figur mit der Erfinderin. Fordern Sie die Rohbilder an, soweit ihre eigene Prüfung für eine Aussage erforderlich ist. Entwerfen Sie einen auf die eingereichten Unterlagen gestützten Änderungssatz für E1 und eine gesonderte vollständige Anmeldeschrift E2 für den später konkretisierten Prüfstand. Ordnen Sie für beide Wege Prioritätsfenster, zwischenzeitliche Offenbarungen und die Vorführung am 4. Dezember ein.

Rechtsquellen
§ 3 PatG · https://www.gesetze-im-internet.de/patg/__3.html
§ 4 PatG · https://www.gesetze-im-internet.de/patg/__4.html
§ 34 PatG · https://www.gesetze-im-internet.de/patg/__34.html
§ 38 PatG · https://www.gesetze-im-internet.de/patg/__38.html
Art. 54 EPÜ · https://www.epo.org/de/legal/epc/2020/a54.html
Art. 56 EPÜ · https://www.epo.org/de/legal/epc/2020/a56.html
Art. 83 EPÜ · https://www.epo.org/de/legal/epc/2020/a83.html
Art. 84 EPÜ · https://www.epo.org/de/legal/epc/2020/a84.html
Art. 87 EPÜ · https://www.epo.org/de/legal/epc/2020/a87.html
Art. 88 EPÜ · https://www.epo.org/de/legal/epc/2020/a88.html
Art. 89 EPÜ · https://www.epo.org/de/legal/epc/2020/a89.html
Art. 123 EPÜ · https://www.epo.org/de/legal/epc/2020/a123.html
