HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Deutsche Interstate AG · Niederlassung West

Wählen Sie einen Fallordner. Bearbeiten Sie zuerst die Grundakte. Öffnen Sie die Nachreichungen nach der ersten Bearbeitungsrunde. Für Ihre Prüfung der Eingaben verwenden Sie Einwendungen-Pruefbogen.xlsx auf der obersten Ebene. Die Gesamt-PDF führt über Lesezeichen zu beiden Phasen. Das ZIP unter downloads enthält die Druckfassungen der einzelnen Unterlagen.

01-alleinstellung · Wer kann das Bildarchiv übernehmen?
DI-W/BES-26-041

Beim Umzug des Fotoarchivs der Deutschen Interstate AG, Niederlassung West, müssen nummerierte Bildserien zusammenbleiben. Die Fachabteilung möchte den Auftrag mit dem bisherigen Anbieter aushandeln. Ein zweites Unternehmen hat sich gemeldet. Am 6. November 2026 geht der noch ungezeichnete Vergabevermerk bei Ihnen ein. Die AG, das Archiv und alle Unternehmen und Vorgänge dieser Akte sind fiktiv.

Beraten Sie die Vergabestelle vor einer Einladung oder Zusage. Legen Sie der Niederlassungsleitung bis 10. November 2026 eine entscheidungsfähige Fassung des Vermerks vor. Bezeichnen Sie die zu beschaffende Leistung, den geschätzten Gesamtwert und den zulässigen Verfahrensweg. Prüfen Sie, für welche Leistungen die behauptete Alleinstellung belegt ist. Legen Sie dar, welche Aussagen von wem stammen, welche Prüfung der Vergabestelle noch fehlt und was der Einkauf den beteiligten Unternehmen jetzt mitteilen kann. Entwerfen Sie die dazu erforderlichen Schreiben.

Führen Sie den Vermerk zunächst nach der beobachteten Probe vom 11. November und nochmals nach dem Schreiben der bisherigen Anbieterin vom 16. November fort. Halten Sie bei jedem Stand fest, welche Feststellungen Sie beibehalten oder ändern. Die Leitung berät am 18. November erneut. Sie benötigt einen konkreten Auftrag an Einkauf und Archiv mit Verantwortlichen und Terminen. Die Nachricht von Lichtfaden trägt die Überschrift „Widerspruch“. Prüfen Sie anhand ihres Wortlauts und des Eingangsjournals, was die Firma konkret verlangt, wann die AG davon erfahren konnte und welche Abhilfe oder Aufklärung vor einer Einladung in Betracht kommt. Entwerfen Sie für die Leitung eine Antwort mit einem nachprüfbaren nächsten Schritt.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Nachreichungen/09_widerspruch_lichtfaden.eml
  Gegenprüfung: Nachreichungen/07_protokoll_musteruebernahme.docx
  Eingabe: Nachreichungen/09_widerspruch_lichtfaden.eml
  Gegenprüfung: Nachreichungen/10_eingang_und_einladungsstand.txt

Quellen:
§ 99 GWB – öffentliche Auftraggeber · https://www.gesetze-im-internet.de/gwb/__99.html
§ 3 VgV – Schätzung des Auftragswerts · https://www.gesetze-im-internet.de/vgv_2016/__3.html
Art. 1 Delegierte Verordnung (EU) 2025/2152 – Schwellenwerte 2026 und 2027 · https://op.europa.eu/de/publication-detail/-/publication/ed53995b-afac-11f0-b37f-01aa75ed71a1/language-de
§ 14 Abs. 4 Nr. 2 Buchst. b und c, Abs. 6 VgV – Wahl der Verfahrensart · https://www.gesetze-im-internet.de/vgv_2016/__14.html
§ 28 VgV – Markterkundung · https://www.gesetze-im-internet.de/vgv_2016/__28.html
§ 31 VgV – Leistungsbeschreibung · https://www.gesetze-im-internet.de/vgv_2016/__31.html
§ 8 VgV – Dokumentation und Vergabevermerk · https://www.gesetze-im-internet.de/vgv_2016/__8.html
§ 160 GWB – Antrag und Rüge im Nachprüfungsverfahren · https://www.gesetze-im-internet.de/gwb/__160.html

02-fachlose · Betriebshof Weidenstück – drei Gewerke, zwei Bauabschnitte
DI-W/BAU-26-073

Im Betriebshof Weidenstück der Deutschen Interstate AG, Niederlassung West, sollen beschädigte Betonflächen instand gesetzt, beanspruchte Flächen beschichtet und Sozialräume gestrichen werden. Die Bauabteilung möchte sämtliche Arbeiten mit einem Vertrag vergeben. Der Mengenplan weist Nord und Süd getrennt aus. Dürfen kleinere Firmen nur für die Beschichtung im südlichen Gebäudeteil anbieten? Die Vergabestelle erhält die ungezeichnete Bauvorlage am 9. November 2026. Es gibt weder eine Bekanntmachung noch einen Zuschlag. Betriebshof, Gesellschaft, Unternehmen und Vorgang sind erfunden.

Sie beraten die Vergabestelle für die Sitzung am 12. November 2026. Prüfen Sie den Gesamtauftrag, die Aufteilung nach Gewerken, die örtlichen Teillose Nord und Süd und die Kombination beider Zuschnitte. Ordnen Sie die Positionen und die gemeinsame Baustelleneinrichtung eindeutig zu. Vergleichen Sie Zugang für Fachunternehmen, Übergaben, Zeit, Finanzierung und Gesamtauftragswert. Kontrollieren Sie, ob ein Bieter die Preisblätter einzeln ausfüllen und der Einkauf mehrere Zuschläge widerspruchsfrei erteilen könnte. Legen Sie einen entscheidungsfähigen Vergabevermerk mit Alternativen und offenen Freigaben vor. Formulieren Sie die Rückmeldung an die Bauabteilung und eine Antwort auf die Marktrückmeldungen.

Führen Sie den Vermerk am 13., 18. und 19. November mit den jeweils verfügbaren Unterlagen fort. Grenzen Sie Baupreise, zusätzliche Koordination und Miete voneinander ab. Bezeichnen Sie, welche Übergabefrist neu belegt ist, auf welchen Loszuschnitt sie sich bezieht und für welche Alternative weiterhin eine belastbare Zusage fehlt. Die Leitung benötigt für die Sitzung am 20. November eine Entscheidungsvorlage und gegebenenfalls überarbeitete Los- und Angebotsbedingungen vor einer Bekanntmachung. Ordnen Sie den als „Einspruch“ bezeichneten Brief neben der früheren Interessenbekundung ein. Prüfen Sie für die Leitung, welche Information dem Unternehmen vorlag, welches konkrete Los es ausführen möchte und welche Änderungen an Vorhaltezeit und Übergaberegel vor einer Veröffentlichung nötig wären. Formulieren Sie eine Antwort, die alle Interessierten über denselben Informationsweg erreicht.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Nachreichungen/10_einspruch_teillos_sued.eml
  Gegenprüfung: Grundakte/06a_entwurf_losbedingungen.docx
  Eingabe: Nachreichungen/10_einspruch_teillos_sued.eml
  Gegenprüfung: Nachreichungen/11_posteingang_und_marktgespraech.docx

Quellen:
§ 97a GWB – Losgrundsatz, wirtschaftliche, technische und zeitliche Gründe · https://www.gesetze-im-internet.de/gwb/__97a.html
§ 99 GWB – öffentliche Auftraggeber · https://www.gesetze-im-internet.de/gwb/__99.html
§ 2 VgV – Vergabe von Bauaufträgen · https://www.gesetze-im-internet.de/vgv_2016/__2.html
§ 3 VgV – Schätzung des Auftragswerts · https://www.gesetze-im-internet.de/vgv_2016/__3.html
Art. 1 Delegierte Verordnung (EU) 2025/2152 – Schwellenwerte 2026 und 2027 · https://op.europa.eu/de/publication-detail/-/publication/ed53995b-afac-11f0-b37f-01aa75ed71a1/language-de
VOB/A 2026, Abschnitt 2, §§ 5a EU (Losgrundsatz), 5b EU (Loslimitierung), 7b EU (Leistungsverzeichnis) und 20 EU (Dokumentation) – BAnz AT 24.08.2026 B6 · https://bundesanzeiger.de/pub/publication/73xO0rpP1jfX5HRt0Ja/content/73xO0rpP1jfX5HRt0Ja/BAnz%20AT%2024.08.2026%20B6.pdf?inline=
§ 160 GWB – Antrag und Rüge im Nachprüfungsverfahren · https://www.gesetze-im-internet.de/gwb/__160.html

03-ausschluss · Das Kreuz bei 96 Stunden
DI-W/26-031

Auf dem Angebotsblatt steht „96 Stunden eingehalten“. Das beigelegte Datenblatt verspricht für die Grundausführung 72 Stunden. Nach einem Unwetter muss das Messnetz Kiebitzrinne vier Tage ohne Zugang zu den Stationen auskommen. Der günstigste Bieter liegt 15.600 Euro vor dem nächsten. Am 9. September liegt der Vorgang erstmals beim Rechtsdienst.

Prüfen Sie für die Vergabeleitung den ungezeichneten Ausschlussvermerk des Messnetzbetriebs vom 9. September. Gleichen Sie das ausgegebene Bieter-LV mit dem eingereichten Preisblatt W-668 und Formblatt T ab. Belegen die Preise eine bestimmte Akkubestückung? Arbeiten Sie nötige Korrekturen in denselben Vermerk ein und geben Sie zum Stichtag eine begründete Empfehlung ab. Behandeln Sie den Umsatznachweis, die technische Aufklärung und die Rangfolge getrennt. Legen Sie die nächste Bieterkorrespondenz, den möglichen Entscheidungstermin und den für eine andere Beurteilung entscheidenden Beleg bei.

Öffnen Sie danach die drei Eingänge vom 10. und 11. September. Führen Sie denselben Vermerk fort. Ordnen Sie die belegte frühere Produktkonfiguration, die nachträglich angebotene Zusatzbatterie und die inzwischen eingegangene Beanstandung jeweils dem zutreffenden Verfahrensschritt zu. Arbeiten Sie die Konsequenzen für alle Bieter und die weitere Kommunikation aus. Prüfen Sie anschließend die versandte Vorabinformation und die beiden Beanstandungen der Flutzeichen. Legen Sie eine Fristennotiz mit Versand, Eingang, möglichem Fristbeginn und frühestem zulässigem Zuschlag vor. Halten Sie die Antwort auf den Einwand und die vorerst zu treffende Entscheidung über die Zuschlagsfreigabe getrennt fest.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Nachreichungen/11_bieterstellungnahme.eml
  Gegenprüfung: Nachreichungen/10_schluesselkarte.docx
  Eingabe: Nachreichungen/13_ruege_zuschlagstermin.eml
  Gegenprüfung: Nachreichungen/14_versandjournal_w668.txt

Quellen:
GWB § 97 · Wettbewerb, Transparenz und Gleichbehandlung · https://www.gesetze-im-internet.de/gwb/__97.html
VgV § 15 Abs. 5 · Aufklärung im offenen Verfahren · https://www.gesetze-im-internet.de/vgv_2016/__15.html
VgV § 53 Abs. 7 · Änderungen der Vergabeunterlagen · https://www.gesetze-im-internet.de/vgv_2016/__53.html
VgV § 56 · Prüfung und Nachforderung · https://www.gesetze-im-internet.de/vgv_2016/__56.html
VgV § 57 · Ausschluss von Angeboten · https://www.gesetze-im-internet.de/vgv_2016/__57.html
GWB § 134 · Vorabinformation und Wartefrist · https://www.gesetze-im-internet.de/gwb/__134.html
GWB § 160 Abs. 3 · Rüge und Nachprüfungsantrag · https://www.gesetze-im-internet.de/gwb/__160.html
EuGH, 11.05.2017, C-131/16, Archus und Gama · Aufklärung und Austausch eines ursprünglich eingereichten Musters im damaligen Sektorenrecht · https://op.europa.eu/de/publication-detail/-/publication/962a0cba-3624-11e7-a08e-01aa75ed71a1/language-de
§ 169 GWB – Wirkungen der Nachprüfung · https://www.gesetze-im-internet.de/gwb/__169.html

04-oekopunkte · 180.000 Punkte für den Werkhof am Eschbach
DI-W/26-044

Die Niederlassung West will für ihr Werkhofgrundstück im Stadtgebiet Borken bis Jahresende die Kompensation nachweisen. Ein Flächenpool bietet die Zuordnung bereits durchgeführter Maßnahmen an. Ein zweiter Betrieb möchte eine Wiese erst anlegen und über Jahrzehnte pflegen. Beide schreiben auf die erste Seite „180.000 Ökopunkte“. Im Einkauf wartet eine vorbereitete Bestellung über 342.000 Euro.

Entwerfen Sie für die Niederlassungsleitung eine Beschaffungsvorlage auf dem Stand vom 8. Oktober 2026. Beschreiben Sie für jede Variante konkret, wofür die AG zahlt, wer Eigentum, Nutzung, Pflege und Ausfallrisiko trägt und welchen Nachweis die Zulassungsbehörde benötigt. Vergleichen Sie Gegenstand, Gesamtwert einschließlich Optionen, mögliche Vergabewege und Terminfolgen. Prüfen Sie das Argument des Grundstückserwerbs ebenso wie die behauptete Alleinstellung des ersten Pools. Formulieren Sie die offenen Anfragen und die nächste ausführbare Entscheidung.

Arbeiten Sie die drei späteren Eingänge ein. Berechnen Sie die tatsächlich gesicherte bzw. bestrittene Deckung, kontrollieren Sie Kompensationsraum, Maßnahmentyp und Doppelbelegung anhand der einzelnen Belege. Setzen Sie dem geänderten Vertragsangebot eine eigenständige Vertrags- und Vergabestrategie entgegen und entwerfen Sie die zeitkritischen Nachrichten an Anbieter und Behörde. Prüfen Sie, was Wiesenkante mit ihrem Schreiben erreichen will, welche Stelle über die Nebenbestimmung entscheiden kann und welche Beschaffungsentscheidung der Einkauf vor der Bindefrist der Punkteanbieter treffen darf. Antworten Sie getrennt zur Teilnahme am Wettbewerb und zum gewünschten Aufschub des Kompensationsnachweises.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Nachreichungen/11_einwendung_wiesenkante.eml
  Gegenprüfung: Nachreichungen/08_behoerdenauskunft.eml
  Eingabe: Nachreichungen/11_einwendung_wiesenkante.eml
  Gegenprüfung: Nachreichungen/12_eingang_und_adressat.txt

Quellen:
GWB § 103 · öffentlicher Auftrag und Arten der Leistungen · https://www.gesetze-im-internet.de/gwb/__103.html
GWB § 107 Abs. 1 Nr. 2 · Grundstücke, Bestandsgebäude und Rechte daran · https://www.gesetze-im-internet.de/gwb/__107.html
GWB § 110 · Hauptgegenstand gemischter Aufträge · https://www.gesetze-im-internet.de/gwb/__110.html
VgV § 3 · Auftragswert einschließlich Optionen · https://www.gesetze-im-internet.de/vgv_2016/__3.html
VgV § 14 Abs. 4 und 6 · fehlender Wettbewerb und Verfahrenswahl · https://www.gesetze-im-internet.de/vgv_2016/__14.html
BNatSchG § 15 · Ausgleich, Ersatz und Sicherung · https://www.gesetze-im-internet.de/bnatschg_2009/__15.html
BNatSchG § 16 · Bevorratung und Voraussetzungen vorgezogener Maßnahmen · https://www.gesetze-im-internet.de/bnatschg_2009/__16.html
NRW · Ökokonto VO, insbesondere §§ 2–8, anerkannte Maßnahmen, Einbuchung, Abbuchung und Kompensationsräume · https://recht.nrw.de/system/files/pdf/state-law-and-regulations/2008/06/04/1f964a/2016-11-25-verordnung-ueber-die-fuehrung-eines-oek.pdf
LANUK NRW · Zuordnung der Städte und Gemeinden zu den Kompensationsräumen · https://www.lanuk.nrw.de/fileadmin/lanuv/natur/pdf/20170925_Kompensation_staedte_u_gemeinde.pdf
Kreis Borken · örtliches Verfahren und Ökokonto · https://www.kreis-borken.de/de/kreisregion/klima-mobilitaet/umwelt/natur-landschaft/eingriffe-in-natur-landschaft.php
BFH · Grundstückserwerb und Ökokonto, grunderwerbsteuerliche Entscheidung; Reichweite der Grundstücksbindung im dortigen Sachverhalt · https://www.bundesfinanzhof.de/de/entscheidung/entscheidungen-online/detail/STRE202520306/
§ 160 GWB – Antrag und Rüge im Nachprüfungsverfahren · https://www.gesetze-im-internet.de/gwb/__160.html

05-baustreit · Schieferbachbrücke – fünf Wartetage am Widerlager West
DI-W/05-BW17

Für das Widerlager der Schieferbachbrücke fehlte eine freigegebene Bewehrungszeichnung. Die Steinbogen Ingenieurbau GmbH verlangt 13.787,00 Euro. Ihr Terminplan sieht einen Kran und drei Fachkräfte am Widerlager vor. Im Bautagebuch tauchen dieselben Ressourcen an anderer Stelle auf. Die Niederlassung West begleitet als Auftraggeberin einen laufenden Zivilprozess.

Bereiten Sie für die Prozessvertretung der Deutschen Interstate AG die Klageerwiderung und eine Entscheidungsvorlage für die Projektleitung vor. Stellen Sie den vorgesehenen Ablauf dem belegbaren Ablauf jeder Schicht gegenüber. Arbeiten Sie heraus, welche Mitwirkung geschuldet war, wann die Auftragnehmerin leistungsbereit war und welche Positionen durch welche Ursache entstanden sein können. Beziffern Sie die vertretbaren Betragsvarianten, ordnen Sie den Beweisangeboten konkrete Tatsachen zu und halten Sie die gerichtliche Frist fest.

Am 19. und 20. November gehen die Maschinenaufzeichnung und die Antwort des Kranvermieters ein. Gleichen Sie beides mit der früheren Erklärung der Bauleitung und der Kalkulation ab. Überarbeiten Sie die bestrittenen Zeitfenster, den Umfang einer noch sinnvollen Beweiserhebung und den Verhandlungsspielraum. Lesen Sie den ergänzenden Schriftsatz der Klägerin und die Erklärung des Monteurs zusammen mit dem gerichtlichen Übermittlungsvermerk. Entwerfen Sie den Gegenvortrag zum Personaleinsatz, zur Gerätebereitschaft und zur Höhe der Forderung. Ordnen Sie jede bestrittene Einzelheit einem Beweisangebot zu und halten Sie die Frist zur Klageerwiderung fest.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Nachreichungen/11_schriftsatz_klaegerin_kran.docx
  Gegenprüfung: Nachreichungen/13_monteur_zur_sperre.eml
  Eingabe: Nachreichungen/11_schriftsatz_klaegerin_kran.docx
  Gegenprüfung: Nachreichungen/12_gericht_weiterleitung.txt

Quellen:
§ 642 BGB – Mitwirkung des Bestellers · https://www.gesetze-im-internet.de/bgb/__642.html
§ 280 BGB – Schadensersatz wegen Pflichtverletzung · https://www.gesetze-im-internet.de/bgb/__280.html
§ 286 BGB – Verzug des Schuldners · https://www.gesetze-im-internet.de/bgb/__286.html
§ 291 BGB – Prozesszinsen · https://www.gesetze-im-internet.de/bgb/__291.html
§ 288 BGB – Verzugszinsen und sonstiger Verzugsschaden · https://www.gesetze-im-internet.de/bgb/__288.html
§ 138 ZPO – Erklärungspflicht über Tatsachen · https://www.gesetze-im-internet.de/zpo/__138.html
§ 286 ZPO – Freie Beweiswürdigung · https://www.gesetze-im-internet.de/zpo/__286.html
§ 287 ZPO – Schadensermittlung · https://www.gesetze-im-internet.de/zpo/__287.html
§ 296 ZPO – Zurückweisung verspäteten Vorbringens · https://www.gesetze-im-internet.de/zpo/__296.html

06-nachtrag · Knoten Feldrain – Nachtrag 7 für einen zusätzlichen Rohrmantel
DI-W/06-KF3

Am Knoten Feldrain liegt die geplante Kabelschutzrohrtrasse näher an einer alten Stützwand, als die Bestandszeichnung erkennen ließ. Tiefbau Wiesenfeld baut abschnittsweise geteilte Stahlrohrmäntel ein und verlangt dafür 21.188,00 Euro netto. Die nächste Sperrnacht steht bevor. Projektleitung, Bauüberwachung und Vertragsleitung haben der Firma unterschiedliche Mitteilungen geschickt.

Prüfen Sie für die Niederlassung West jede Position des Nachtrags 7 und entwerfen Sie die Antwort an die Auftragnehmerin vor der nächsten Sperrnacht. Unterscheiden Sie den geschuldeten Vertragsumfang, die verlangte Änderung, das Zustandekommen einer Vereinbarung und die Voraussetzungen einer einseitigen Anordnung. Ermitteln Sie aus den Belegen Preise und Mengen, weisen Sie mögliche Überschneidungen mit dem Hauptauftrag aus und benennen Sie die Nachweise für eine belastbare Teilfreigabe. Halten Sie fest, wer weitere Arbeiten mit welcher Wirkung veranlassen kann.

Der gemeinsam unterschriebene Feldbuchauszug, die Leistungsnachweise und das fortgeschriebene Nachtrags-LV vom 23. November verändern die Mengenbasis. Stellen Sie bisher ausgeführte Leistungen und die Prognose bis zum Bauende gesondert dar. Überarbeiten Sie das Verhandlungsergebnis und formulieren Sie eine umsetzbare Anweisung für die nächste Schicht. Prüfen Sie die Einwendungen gegen den Prüfabzug getrennt nach Leistung, Menge, Preis und Abschlagsgrundlage. Stellen Sie dem verlangten Zahlungstermin den dokumentierten Eingang und dem Geräteansatz die bereits im Meterpreis enthaltenen Arbeiten gegenüber. Formulieren Sie eine Antwort, die auch die Entscheidung zur nächsten Sperrnacht offenlegt.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Nachreichungen/13_widerspruch_pruefabzug.eml
  Gegenprüfung: Nachreichungen/10_schichtabgleich.xlsx
  Eingabe: Nachreichungen/13_widerspruch_pruefabzug.eml
  Gegenprüfung: Nachreichungen/14_eingang_und_zahlungslauf.txt

Quellen:
§ 650a BGB – Bauvertrag · https://www.gesetze-im-internet.de/bgb/__650a.html
§ 650b BGB – Änderung des Vertrags und Anordnungsrecht des Bestellers · https://www.gesetze-im-internet.de/bgb/__650b.html
§ 650c BGB – Vergütungsanpassung bei Anordnungen · https://www.gesetze-im-internet.de/bgb/__650c.html
§ 164 BGB – Wirkung der Erklärung des Vertreters · https://www.gesetze-im-internet.de/bgb/__164.html
§ 177 BGB – Vertragsschluss durch Vertreter ohne Vertretungsmacht · https://www.gesetze-im-internet.de/bgb/__177.html
§ 632a BGB – Abschlagszahlungen · https://www.gesetze-im-internet.de/bgb/__632a.html
§ 126b BGB – Textform · https://www.gesetze-im-internet.de/bgb/__126b.html

07-vertragsmuster · Deutsche Interstate AG · Zwei Vertragsmuster für die Kontrollschichten am Westtor
DI-W/K17-2026-07

Die Einkaufsrunde der Niederlassung West soll ein wiederverwendbares Vertragsset für Kontrollleistungen freigeben. Für das erste Projekt K17 hat der Einkauf den Rahmen ausgefüllt, die Projektleitung den Abruf. Die Daten des Lieferanten sind bereits eingetragen. Vor den Oktoberterminen will die Bauherrin wissen, wer ihr die Belege überlassen darf.

Prüfen Sie Rahmenvertrag und Abrufblatt getrennt und in ihrem Zusammenwirken mit den beiden Bedingungswerken. Erstellen Sie bis 16. September, 12 Uhr, eine Entscheidungsvorlage für Einkauf und Projektleitung. Benennen Sie je Konflikt die betroffenen Ziffern, den Verwender, die tatsächliche Verhandlungslage, das betriebliche Risiko und eine priorisierte Entscheidung. Arbeiten Sie Ersatzklauseln und eine verhandelbare Rückfallposition aus. Trennen Sie die Freigabe des Pilotabrufs von der späteren Verwendung des Musters.

Ab 17. September gehen die Gesprächserinnerung der Anbieterin, ein konkretes Änderungsblatt und die Antwort der kaufmännischen Leitung ein. Führen Sie die bestehende Prüfung bis zur Entscheidung über den unveränderten Abruf und die zusätzlich angefragten Leistungen fort. Erläutern Sie die Wertgrenzen und formulieren Sie die interne sowie externe Rückmeldung. Würdigen Sie die Nachricht der Anbieterin und das getrennte Postfachprotokoll. Prüfen Sie, welche Erklärung von welcher Person zugegangen ist, auf welche Fassung sie sich bezieht und ob für die zusätzlichen Nächte, die CSV oder eine Bereithaltung bereits eine Bindung besteht. Entwerfen Sie vor Ablauf der Personalreservierung eine nach außen eindeutige Antwort.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Nachreichungen/11_widerspruch_abruftrennung.eml
  Gegenprüfung: Grundakte/06_freigabewerte_k17.xlsx
  Eingabe: Nachreichungen/11_widerspruch_abruftrennung.eml
  Gegenprüfung: Nachreichungen/12_postfach_und_telefonnotiz.txt

Quellen:
§ 150 BGB · Verspätete und abändernde Annahme · https://www.gesetze-im-internet.de/bgb/__150.html
§ 164 BGB · Wirkung der Erklärung des Vertreters · https://www.gesetze-im-internet.de/bgb/__164.html
§ 271a Abs. 2, 3 und 5 BGB · Zahlungs-, Überprüfungs- und Abnahmefristen sowie Abschlags- und Ratenzahlungen · https://www.gesetze-im-internet.de/bgb/__271a.html
§ 99 Nr. 2 GWB · Öffentliche Auftraggeber in privater Rechtsform · https://www.gesetze-im-internet.de/gwb/__99.html
§ 305 BGB · Einbeziehung Allgemeiner Geschäftsbedingungen in den Vertrag · https://www.gesetze-im-internet.de/bgb/__305.html
§ 305b BGB · Vorrang der Individualabrede · https://www.gesetze-im-internet.de/bgb/__305b.html
§ 305c BGB · Überraschende und mehrdeutige Klauseln · https://www.gesetze-im-internet.de/bgb/__305c.html
§ 306 BGB · Rechtsfolgen bei Nichteinbeziehung und Unwirksamkeit · https://www.gesetze-im-internet.de/bgb/__306.html
§ 307 BGB · Inhaltskontrolle · https://www.gesetze-im-internet.de/bgb/__307.html
§ 310 BGB · Anwendungsbereich · https://www.gesetze-im-internet.de/bgb/__310.html
§ 339 BGB · Verwirkung der Vertragsstrafe · https://www.gesetze-im-internet.de/bgb/__339.html
§ 341 BGB · Strafversprechen für nicht gehörige Erfüllung · https://www.gesetze-im-internet.de/bgb/__341.html
§ 611 BGB · Vertragstypische Pflichten beim Dienstvertrag · https://www.gesetze-im-internet.de/bgb/__611.html
§ 631 BGB · Vertragstypische Pflichten beim Werkvertrag · https://www.gesetze-im-internet.de/bgb/__631.html
§ 640 BGB · Abnahme · https://www.gesetze-im-internet.de/bgb/__640.html
§ 641 BGB · Fälligkeit der Vergütung · https://www.gesetze-im-internet.de/bgb/__641.html
BGH, Urteil vom 15. Februar 2024 – VII ZR 42/22 · Vertragsstrafenbemessung im Einheitspreisvertrag (amtlicher Volltext, XML im ZIP) · https://www.rechtsprechung-im-internet.de/jportal/docs/bsjrs/jb-KORE304022024.zip

08-leitplanung · Korridor Riedtal – Leitplanung für West und Ost
DI-W/PLAN-26-184

Die Deutsche Interstate AG lässt auf 14,2 Kilometern Fernstraße die künftige Verkehrsführung untersuchen. Im Westen liegen ein Rastplatz und eine Betriebszufahrt, im Osten muss die Anschlussplanung daran anknüpfen. Die Vergabestelle verlangt eine Referenz aus ihrem eigenen Haus. Ein Büro mit vergleichbarer Erfahrung bei einem Landesbetrieb möchte sich für West bewerben. Sie erhalten die Ausschreibungsunterlagen und die erste Bewerberfrage. Projekt, Unternehmen, Vorgang und beteiligte Personen sind fiktiv.

Bearbeiten Sie den Stand vom 13. Oktober für die Vergabestelle. Vergleichen Sie Bekanntmachung, Honorar-LV, Auskunft und Referenzblatt. Welche Leistungen kann das Büro für West nachweisen? Welche Alternativen gibt es zur Verbindung von Umweltuntersuchung und Verkehrsanlagenplanung? Prüfen Sie auch beide regionalen Teillose, den geschätzten Wert einschließlich Optionen und den gewählten Teilnahmewettbewerb. Formulieren Sie die Entscheidungsvorlage zu möglicher Berichtigung, Information aller Bewerber und Bewerbungstermin. Ordnen Sie dem konkreten Wortlaut nach ein, was mit der ersten Nachricht bereits verlangt wird.

Arbeiten Sie die Unterlagen ab dem 14. Oktober in zeitlicher Reihenfolge durch. Führen Sie Referenzvorgabe und Losbildung als getrennte Streitpunkte. Halten Sie für jede Nachricht Absender, Adressat, Begehren, Zugang und Fristfolge fest. Gleichen Sie den „Einspruch“ im AG-Portal mit dem tatsächlichen Kammereingang ab. Legen Sie anhand der Mitteilung vom 5. November fest, welche Verfahrensschritte in welchem Los in Betracht kommen. Nutzen Sie den Arbeitsbogen für die Stellungnahme der Vergabestelle und die Entscheidung zum Projekttermin.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Grundakte/06_bewerberfrage_auftraggeber.eml
  Gegenprüfung: Grundakte/07_auskunft_04.txt
  Eingabe: Nachreichungen/09_widerspruch_teilnahmebedingungen.eml
  Gegenprüfung: Grundakte/08_referenzblatt_wiesenbogen.docx
  Eingabe: Nachreichungen/10_antwort_auf_widerspruch.eml
  Gegenprüfung: Nachreichungen/11_umweltuebergaben.docx
  Eingabe: Nachreichungen/12_einspruch_vorlage.eml
  Gegenprüfung: Nachreichungen/13_portaljournal.xlsx
  Eingabe: Nachreichungen/14_antrag_kammer.docx
  Gegenprüfung: Nachreichungen/15_mitteilung_der_kammer.docx

Quellen:
§ 97a GWB – Teil- und Fachlose · https://www.gesetze-im-internet.de/gwb/__97a.html
§ 99 GWB – öffentliche Auftraggeber · https://www.gesetze-im-internet.de/gwb/__99.html
§ 3 VgV – geschätzter Auftragswert, Optionen und Lose · https://www.gesetze-im-internet.de/vgv_2016/__3.html
Delegierte Verordnung (EU) 2025/2152 – Schwellenwerte 2026/2027 · https://op.europa.eu/de/publication-detail/-/publication/ed53995b-afac-11f0-b37f-01aa75ed71a1/language-de
§ 17 VgV – Verhandlungsverfahren · https://www.gesetze-im-internet.de/vgv_2016/__17.html
§ 74 VgV – Wahl der Verfahrensart für Planungsleistungen · https://www.gesetze-im-internet.de/vgv_2016/__74.html
§ 75 VgV – Eignung und vergleichbare Planungsreferenzen · https://www.gesetze-im-internet.de/vgv_2016/__75.html
§ 159 GWB – Zuständigkeit der Vergabekammer · https://www.gesetze-im-internet.de/gwb/__159.html
§ 160 GWB – Antragsbefugnis, Rüge und Fristen · https://www.gesetze-im-internet.de/gwb/__160.html
§ 161 GWB – Form, Inhalt und Einreichung des Antrags · https://www.gesetze-im-internet.de/gwb/__161.html
§ 169 GWB – Mitteilung des Antrags und Zuschlagsverbot · https://www.gesetze-im-internet.de/gwb/__169.html

09-brueckenneubau · Neubau der Riedangerbrücke – Zuschlagsentscheidung für die Straßenanschlüsse
DI-W/BR-26-119

Die Deutsche Interstate AG, Niederlassung West, will eine Brücke mit zwei Straßenanschlüssen bauen. Rohbau, Anschlüsse und Schutzeinrichtungen sind getrennt ausgeschrieben. Ein Straßenbaubetrieb wollte nur den kompakten Ostanschluss anbieten. Die Bieterin auf Rang zwei des Anschlussloses hält dagegen die Wertung der Bauzeit für fehlerhaft. Am 9. November liegt ihr als Widerspruch bezeichnetes Schreiben bei der Vergabestelle. Keines der Lose ist vergeben. Vorhaben, Unternehmen, Personen und Verfahrensaktenzeichen sind fiktiv.

Bereiten Sie für die Leitung den Vermerk zur Zuschlagsreife von Los B und zwei getrennte Antwortentwürfe vor. Rekonstruieren Sie für jeden Absender, was er verlangt, was er wann wissen konnte und was bis zum jeweiligen Aktenstand belegt ist. Prüfen Sie die regionale Teilbarkeit der Anschlüsse anhand des LV, der Bauabschnitte und ihrer Übergaben. Rechnen Sie die bekannt gemachte Wertung für beide Angebote nach. Halten Sie fest, welche Originalunterlagen zur Prüfung der Zeitangebote fehlen. Bestimmen Sie Zuständigkeit, maßgebliche Fristen und die Folgen für jedes betroffene Los.

Bearbeiten Sie zunächst die Auszüge aus den Angebotscontainern und das Ereignisjournal vom 10. November. Tragen Sie beide Zeitangaben mit ihren Quellen in die Wertung ein und erläutern Sie, was aufgeklärt oder korrigiert werden könnte. Führen Sie die Fristenakte nach dem Schreiben vom 12. November weiter. Ordnen Sie am 16. November nacheinander die Nachricht der Bieterin und die Unterrichtung der Kammer ein. Vermerken Sie für die Zuschlagsstelle den jeweils dokumentierten Stand und entwerfen Sie eine Stellungnahme mit Aktenverzeichnis und Vorschlag zum Umgang mit geschützten Geschäftsdaten. Eine Kammerentscheidung steht aus.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Grundakte/05_einspruch_nordsaum.docx
  Gegenprüfung: Nachreichungen/12_ereignisse_kommunikation.xlsx
  Eingabe: Grundakte/10_widerspruch_talbogen.eml
  Gegenprüfung: Nachreichungen/11_originalvergleich_zeitangebote.docx
  Eingabe: Nachreichungen/14_kopie_nachpruefungsantrag.eml
  Gegenprüfung: Nachreichungen/16_zuschlagsbuch.txt

Quellen:
§ 97a GWB – Vergabe nach Losen · https://www.gesetze-im-internet.de/gwb/__97a.html
§ 99 GWB – öffentliche Auftraggeber · https://www.gesetze-im-internet.de/gwb/__99.html
§ 127 GWB – Zuschlag · https://www.gesetze-im-internet.de/gwb/__127.html
§ 134 GWB – Information und Wartepflicht · https://www.gesetze-im-internet.de/gwb/__134.html
§ 159 GWB – Abgrenzung der Zuständigkeit der Vergabekammern · https://www.gesetze-im-internet.de/gwb/__159.html
§ 160 GWB – Antrag, Antragsbefugnis und Rüge · https://www.gesetze-im-internet.de/gwb/__160.html
§ 165 GWB – Akteneinsicht · https://www.gesetze-im-internet.de/gwb/__165.html
§ 169 GWB – Aussetzung des Vergabeverfahrens · https://www.gesetze-im-internet.de/gwb/__169.html
§ 187 GWB – Übergangsbestimmungen · https://www.gesetze-im-internet.de/gwb/__187.html
§ 2 VgV – Vergabe von Bauaufträgen · https://www.gesetze-im-internet.de/vgv_2016/__2.html
§ 3 VgV – Schätzung des Auftragswerts · https://www.gesetze-im-internet.de/vgv_2016/__3.html
Delegierte Verordnung (EU) 2025/2152 – Bauaufträge 2026 und 2027 · https://op.europa.eu/o/opportal-service/download-handler?identifier=ed53995b-afac-11f0-b37f-01aa75ed71a1&format=pdf&language=de&productionSystem=cellar&part=
VOB/A, Abschnitt 2 (2026) – Verfahrensunterlagen, Angebotsprüfung und Wertung · https://bundesanzeiger.de/pub/publication/73xO0rpP1jfX5HRt0Ja/content/73xO0rpP1jfX5HRt0Ja/BAnz%20AT%2024.08.2026%20B6.pdf?inline=

10-fahrbahnmarkierung · Markierungsprogramm Wiesenbogen – zwei Abschnitte, zwei Kolonnen?
DI-W/MK-26-148

Im Markierungsprogramm Wiesenbogen können Betriebe einzeln für Uferhöhe und Kammweg anbieten. Die Anlagen zur Bekanntmachung verlangen selbst für ein einzelnes Los zwei gleichzeitig einsatzfähige Markierungskolonnen. Ein Betrieb mit einer eigenen Kolonne kalkuliert für Uferhöhe. Aus den Planungsunterlagen geht nicht hervor, ob die zweite Kolonne in diesem Los gleichzeitig gebraucht wird.

Beraten Sie den Einkauf mit Stand 9. Oktober. Arbeiten Sie aus der veröffentlichten Frage und Antwort heraus, was der Betrieb wissen wollte und welche Bedingung für sein Angebot fortgilt. Gleichen Sie den Eignungsnachweis mit den Abrufregeln und Leistungen je Los ab. Legen Sie einen Entwurf für den Vergabevermerk und konkrete Nachfragen an den Betrieb der AG vor. Prüfen Sie, welche Klarstellung für alle Unternehmen und welche Anpassung der Angebotsfrist in Betracht kommen.

Öffnen Sie die Eingänge vom 12. bis 15. Oktober in zeitlicher Folge. Halten Sie zu jedem Schreiben Absender, eigenes Interesse, Kenntnisstand, Zugang und verlangte Abhilfe fest. Prüfen Sie den „Widerspruch“ zur Kolonnenzahl und den „Einspruch“ des Verbands zur Reinigung jeweils anhand von LV und Kalender. Entwerfen Sie die Antworten sowie gegebenenfalls eine anonymisierte Nachricht für sämtliche Bieter. Über Abhilfe, neue Unterlagen und Angebotsfrist ist noch zu entscheiden.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Grundakte/04_frage_sperrfenster.eml
  Gegenprüfung: Grundakte/05_auskunft_an_alle.txt
  Eingabe: Nachreichungen/06_widerspruch_kolonnen.eml
  Gegenprüfung: Nachreichungen/07_transaktionsjournal.txt
  Eingabe: Nachreichungen/06_widerspruch_kolonnen.eml
  Gegenprüfung: Nachreichungen/08_kalender_parallelabrufe.xlsx
  Eingabe: Nachreichungen/09_einspruch_fachkreis.eml
  Gegenprüfung: Nachreichungen/10_erwiderung_bauueberwachung.docx

Quellen:
§ 97a GWB – Losgrundsatz · https://www.gesetze-im-internet.de/gwb/__97a.html
§ 122 GWB – Eignung · https://www.gesetze-im-internet.de/gwb/__122.html
§ 2 VgV – Bauaufträge · https://www.gesetze-im-internet.de/vgv_2016/__2.html
§ 3 VgV – Auftragswert, Lose und Rahmenvereinbarungen · https://www.gesetze-im-internet.de/vgv_2016/__3.html
VOB/A 2026, Abschnitt 2 – BAnz AT 24.08.2026 B6 · https://bundesanzeiger.de/pub/publication/73xO0rpP1jfX5HRt0Ja/content/73xO0rpP1jfX5HRt0Ja/BAnz%20AT%2024.08.2026%20B6.pdf?inline=
Delegierte Verordnung (EU) 2025/2152 – Schwellenwerte für die Jahre 2026 und 2027 · https://op.europa.eu/de/publication-detail/-/publication/ed53995b-afac-11f0-b37f-01aa75ed71a1/language-de
§ 160 GWB – Rüge, Antragsbefugnis und Nachprüfungsantrag · https://www.gesetze-im-internet.de/gwb/__160.html

11-it-baupruefung · Prüfbuch West – welcher Export zählt in der Bauprüfung?
DI-W/IT-26-116

Die Bauprüfer der Deutschen Interstate AG wollen Befunde und Fotos auf der Baustelle mobil aufnehmen und als zusammengehörigen Vorgang übergeben. Zwei Anbieter zeigen an aufeinanderfolgenden Prüftagen unterschiedliche Exportwege. Die Bewertungstabelle führt einen Datensatz als fehlgeschlagen. Die Vergabestelle hat die Vorabinformation für das Anwendungs-Los elektronisch versandt. Welche Unterlage belegt, ob sie für beide Lösungen die angekündigte Wertungsregel angewendet hat?

Sie beraten die Vergabestelle mit Stand 9. November nach Versand der Vorabinformation. Rekonstruieren Sie für Los 1 anhand der veröffentlichten Regeln und Preisblätter den vorläufigen Rang und die für einen Rangwechsel nötige Korrektur. Prüfen Sie, ob die vorliegende Dokumentation die unterschiedliche Exportbewertung trägt. Legen Sie der Einkaufsleitung einen vorläufigen Vermerk mit Beleganforderung und Terminplan vor.

Öffnen Sie zunächst den „Einspruch“ vom 10. November mit dem Nachrichtenjournal. Prüfen Sie anhand der ausgetauschten Erklärungen und Protokolle, wann der Bieter die beanstandete Wertung erkennen konnte. Arbeiten Sie anschließend die Sachverhaltsaufklärung und den Antwortentwurf unter Gleichbehandlung beider Anbieter aus. Stellen Sie nach Eingang der Unterlagen vom 12. bis 16. November getrennt fest, was die Nichtabhilfe, die Bieterkopie und die Unterrichtung durch die Kammer für beide Lose und den Terminplan bedeuten. Ein Zuschlag und eine Entscheidung der Kammer liegen nicht vor.

Eingaben und Unterlagen zur Gegenprüfung
  Eingabe: Grundakte/04_bieterfrage_und_antwort.txt
  Gegenprüfung: Grundakte/03_veroeffentlichte_wertungsregeln.docx
  Eingabe: Nachreichungen/08_einspruch_wertung.eml
  Gegenprüfung: Nachreichungen/10_testprotokoll_mit_verzeichnis.docx
  Eingabe: Nachreichungen/08_einspruch_wertung.eml
  Gegenprüfung: Nachreichungen/09_versand_und_zugang.txt
  Eingabe: Nachreichungen/12_kopie_nachpruefungsantrag.eml
  Gegenprüfung: Nachreichungen/13_unterrichtung_kammer.docx

Quellen:
§ 127 GWB – Zuschlag und Zuschlagskriterien · https://www.gesetze-im-internet.de/gwb/__127.html
§ 134 GWB – Informations- und Wartepflicht · https://www.gesetze-im-internet.de/gwb/__134.html
§ 160 GWB – Rüge, Antragsbefugnis und Nachprüfungsantrag · https://www.gesetze-im-internet.de/gwb/__160.html
§ 169 GWB – Aussetzung des Vergabeverfahrens · https://www.gesetze-im-internet.de/gwb/__169.html
§ 8 VgV – Dokumentation · https://www.gesetze-im-internet.de/vgv_2016/__8.html
§ 31 VgV – Leistungsbeschreibung · https://www.gesetze-im-internet.de/vgv_2016/__31.html
§ 58 VgV – Zuschlag und Zuschlagskriterien · https://www.gesetze-im-internet.de/vgv_2016/__58.html
Delegierte Verordnung (EU) 2025/2152 – Schwellenwerte für die Jahre 2026 und 2027 · https://op.europa.eu/de/publication-detail/-/publication/ed53995b-afac-11f0-b37f-01aa75ed71a1/language-de
