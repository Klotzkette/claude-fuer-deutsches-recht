HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Der verlegte Gitarrentermin

Ordnen Sie Privatunterricht und Schulgruppe getrennt zu. Welche Feststellungen zur Ausführung tragen beide Register und welche Vertrags- oder Zahlungsbelege fehlen noch?

Zuerst Praxisnachtrag/Grundakte, danach Praxisnachtrag/Nachlieferung öffnen.
