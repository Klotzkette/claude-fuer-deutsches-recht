HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Die Rückseite von Tageszettel 1578

Ordnen Sie die beiden Schichten personenbezogen zu. Trennen Sie Arbeitszeit, belegten Arbeitsort und offenen Expositionsnachweis.

Zuerst Praxisnachtrag/Grundakte, danach Praxisnachtrag/Nachlieferung öffnen.
