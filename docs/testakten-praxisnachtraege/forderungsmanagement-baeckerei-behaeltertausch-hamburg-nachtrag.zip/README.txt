HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Der Feiertag im Tourenjournal

Prüfen Sie die Neujahrsposition gesondert. Welche Feststellung lässt das Schlüsselbuch zu, und was ändert sich durch die später belegte Herkunft des Kundenfeldes?

Zuerst Praxisnachtrag/Grundakte, danach Praxisnachtrag/Nachlieferung öffnen.
