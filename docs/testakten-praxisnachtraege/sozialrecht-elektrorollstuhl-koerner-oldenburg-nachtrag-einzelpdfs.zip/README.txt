HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Mit dem Schlüssel vor der Hoftür

Prüfen Sie, welche Teilstrecke selbstständig nutzbar war. Benennen Sie den noch fehlenden Nachweis für den gesamten Weg von der Wohnung auf die Straße.

Zuerst Praxisnachtrag/Grundakte, danach Praxisnachtrag/Nachlieferung öffnen.
