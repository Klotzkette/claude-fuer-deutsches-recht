HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Zwei Paletten für Tor 2

Klären Sie für die 09:30-Uhr-Entscheidung die tatsächlich zur Abholung vorgesehenen Stückzahlen. Arbeiten Sie später heraus, welche Rücknahmen bereits im Händlerstand enthalten sind.

Zuerst Praxisnachtrag/Grundakte, danach Praxisnachtrag/Nachlieferung öffnen.
