HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Zwei Dinge in einem Kurierumschlag

Stellen Sie den Dokumentenweg je Schriftstück dar. Welche Frage an die örtliche Fachperson ist nach Eingang des zweiten Umschlags weiterhin offen?

Zuerst Praxisnachtrag/Grundakte, danach Praxisnachtrag/Nachlieferung öffnen.
