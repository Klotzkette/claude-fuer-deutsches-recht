HINWEIS / NOTICE
=================

Diese Testakte wurde mit KI generiert und ist ein Experiment. Benutzung auf eigene Verantwortung und eigene Gefahr.

This test case file was generated with AI and is an experiment. Use at your own responsibility and risk.

Vier Hauskostenbuchungen für die Wohnung in Rom

Rekonstruieren Sie Zuflüsse und Vorschusssaldo für 2025 auf Basis der zwölf Bankgutschriften. Markieren Sie noch benötigte Belege zur persönlichen Zurechnung und zum italienischen Steuerverfahren.

Zuerst Praxisnachtrag/Grundakte, danach Praxisnachtrag/Nachlieferung öffnen.
