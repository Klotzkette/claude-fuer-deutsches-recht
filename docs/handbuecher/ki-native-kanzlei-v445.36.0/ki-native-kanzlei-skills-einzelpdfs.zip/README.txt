KI-native Kanzlei
30 vollständige Fachmodule als A4-PDFs; Fachstand 09.10.2026.
Das Plugin bündelt sie in 8 aktiven Arbeitswegen einschließlich Hauptskill.
Neusatz und Strukturprüfung: 2026-11-14; keine neue Volltextprüfung der Rechtsquellen.
Quellen, Anwendungsgrenzen und Workflow stehen in jedem Fachmodul.
Keine Testakte und kein installierbares Plugin.
Die Markdown-Quellen und installierbaren Pakete finden Sie unter:
https://github.com/Klotzkette/claude-fuer-deutsches-recht/tree/main/ki-native-kanzlei
