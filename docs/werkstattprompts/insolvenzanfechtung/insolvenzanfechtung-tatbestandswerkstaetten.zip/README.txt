Zehn eigenständig kopierbare Werkstattprompts zu §§ 130–139 InsO.
§§ 130–136: Anfechtungstatbestände; § 137: Wechsel/Scheck; § 138: Nähe; § 139: Fristen.
MD und TXT sind bytegleich; PDF-Lesefassungen enthalten den vollständigen Text.
Die Quellenstände und Grenzen stehen in jedem Prompt. Literatur nur mit echtem Zugriff.
Keine Testakte und kein Beleg eines erfolgreichen Live-Modelllaufs.
